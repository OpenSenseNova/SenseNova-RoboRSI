# Bench2Dex evaluation through Codex

Evaluation harness, prompts and tests for GPT-6 Astra on Bench2Dex. Frozen ICL
packages are distributed separately on Hugging Face so you can skip preparation.
The code and package releases are paired by SHA-256 hashes.

1. Follow [setup](docs/SETUP.md) to install the pinned simulator, testing assets,
   Linux policy dependencies and Codex CLI. A model run requires your own access
   to `gpt-6-astra`; the harness never substitutes another model.
2. Install this repository in a Python 3.10–3.12 environment (3.11 for simulation):

```bash
python -m pip install -e '.[data,test]'
```

3. Download and install a frozen package, then run its evaluation:

```bash
# Set HF_ICL_REPO to the published dataset ID (organization/dataset).
# Omit --task to download all 26 tasks; repeat it to select several.
python -m gpt6_eval.packages install --repo-id "$HF_ICL_REPO" \
  --task 26 --output data/icl

# Alternatively, use a downloaded Hugging Face snapshot containing packages/:
# python -m gpt6_eval.packages install --source /path/to/downloaded-dataset \
#   --task 26 --output data/icl

# Set the runtime environment paths as described in docs/SETUP.md first.
python -m gpt6_eval.preflight --config data/icl/config.json --task 26 --require-model
python -m gpt6_eval.packages verify data/icl
export EVAL_RUNS="$HOME/bench2dex-runs"
python -m gpt6_eval.doctor --output "$EVAL_RUNS/isolation-check"
bash scripts/evaluate.sh --task 26 --config data/icl/config.json \
  --mode hold --smoke-steps 4 --output "$EVAL_RUNS/task26-smoke"
# Hosted model inference; use a new output directory for every run.
bash scripts/evaluate.sh --task 26 --config data/icl/config.json \
  --mode codex --output "$EVAL_RUNS/task26-evaluation"
```

The generated config uses relative package paths and one Full/unseen test at
index 5. Copy and edit its episode schedule **before** a different experiment.
No raw demonstration download, export or preparation model call is needed for
frozen-package use. [Package details](docs/FROZEN_PACKAGES.md) explain offline
use, relocation, checksums and provenance. Fresh preparation and legacy zero-shot
runs remain available through [setup](docs/SETUP.md).

`result.json` contains validity and outcomes; `telemetry.json` contains usage and
timing. Use a local Linux filesystem for run outputs: policy isolation requires
Unix sockets and working file permissions. Generated runs can contain credentials,
account metadata and transcripts; keep them outside the published repository.

See [release audit](RELEASE_AUDIT.md), [protocol](docs/PROTOCOL.md) and
[reproducibility](docs/REPRODUCIBILITY.md). License selection remains pending in
[LICENSE_NOTICE.md](LICENSE_NOTICE.md).
