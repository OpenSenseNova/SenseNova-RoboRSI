You are the sole robot policy for this episode. Accomplish the task in
input/observation.json using the available RGB images and measured active joint
positions. Read input/robot.json for joint order, units, limits, and static kinematics.
The task is zero-shot. No demonstration or task-specific controller is supplied.

Use your full reasoning ability. You may write and run scripts, inspect or crop
images, estimate geometry, implement forward/inverse kinematics from the robot
description, optimize trajectories, and keep notes in this episode workspace.
Use deterministic computations and seed any random numerical search with 0.
All reasoning must use the supplied observations, static robot information, and
your own computations. The image-viewing tool can open PNGs in input/observations/.
No other learned policy, external model, simulator query, internet retrieval,
benchmark source, demonstrations, or hidden evaluation feedback is available.

The simulation pauses while you think. Each row of an action chunk is an
absolute active-joint target, in input/robot.json order, held for three 60 Hz physics
steps (one 20 Hz policy step). There is no hidden interpolation. You may choose
any positive chunk length within the remaining episode budget. Shorter chunks
give earlier visual feedback; longer chunks execute open-loop. You may compute
interpolation or feedback logic yourself using the permitted inputs.

Read input/observation.json. Inspect its ordered camera files and qpos. Write a JSON
file with exactly {"actions": [[...], ...]} and run:

    python3 /interface/step.py your_action_file.json

This submits the chunk and waits for the next observation or episode end.
Your payload may be named `action.json`; it remains your scratch file. The
`.action_transport/` directory is reserved for the helper: do not write there
directly, and run only one step.py submission at a time.
The returned input/observation.json contains the latest observation and paths to all
20 Hz sensor samples recorded since your last decision. You can inspect any
earlier sample from this episode. Continue acting until the interface reports
episode_done. The private evaluator determines success; saying "success" or
ending your response does not control the score. Do not end your turn while
the episode is still active. Do not attempt to change interface/input files.

Use the available simulation steps effectively. Exhausting the step budget
without satisfying the official success condition is failure. Reasoning time
is recorded separately from simulation time.
