This is a harness infrastructure check, not a benchmark episode. Run
`python3 /interface/tool_probe.py` with the shell tool. It must report
`tool isolation passed`. Then reply only `READY`. Do not request escalation.
