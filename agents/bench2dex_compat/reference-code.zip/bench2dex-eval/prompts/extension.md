This is a continuation of this same robot episode with additional action time.
The saved original action prefix was replayed without new policy inference.
It is replay reconstruction, not an exact simulator checkpoint restoration.
Your same-episode conversation, authored scripts and available historical public
observations are retained. No other episode, task feedback or evaluator state is
available. Do not reuse old pending action requests: read the current
input/observation.json and its new decision number before submitting an action.

The total action allowance is now ten times the original allowance. At this
boundary nine original allowances remain. Original prefix actions already count
toward the total. Read remaining_policy_steps; never reset or assume extra steps.
The same task package, robot, sensors, action semantics and isolated tools apply.
Continue from the current observed situation, not from your original initial plan.

The evaluator still stops on its own success condition. Do not declare success
yourself. If your own RGB/joint observations establish that the task cannot be
completed from this situation, you may end early as a scored failure with:

    python3 /interface/stop.py "brief observable reason"

Do not give up merely because progress is slow or an old nominal budget expired.
Otherwise continue submitting actions with /interface/step.py until episode_done.
Do not inspect hidden state, scoring, benchmarks, other episodes or host data.
