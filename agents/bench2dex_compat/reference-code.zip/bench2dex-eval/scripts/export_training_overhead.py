"""CPU-only human previews, outside every preparation and evaluation sandbox."""
import argparse
from datetime import datetime, timezone
import hashlib
import html
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import textwrap

import cv2
import h5py
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import yaml

TASKS = (3, 6, 7, 8, 9, 12, 21, 22, 24, 26, 27, 32, 34, 42, 43, 44,
         51, 60, 61, 62, 64, 67, 73, 76, 79, 80)


def select_sources(entries, task_ids=TASKS):
    selected = {}
    for entry in sorted(entries, key=lambda item: item['path']):
        path = Path(entry['path'])
        if path.is_absolute() or '..' in path.parts:
            raise ValueError('Unsafe inventory path')
        if len(path.parts) != 4 or path.parts[2] != 'replay-generalization' or path.suffix != '.hdf5':
            continue
        task_id = int(path.parts[1].split('_', 1)[0])
        if task_id in task_ids:
            selected.setdefault(task_id, entry)
    if set(selected) != set(task_ids):
        raise ValueError('Missing tasks: ' + str(sorted(set(task_ids) - set(selected))))
    return selected


def scalar(source, name, default=None):
    if name not in source:
        return default
    value = source[name][()]
    if isinstance(value, bytes):
        return value.decode('utf-8')
    return value.item() if hasattr(value, 'item') else value


def frame_count(source, count):
    homing = scalar(source, 'meta/homing_start_sim_step', -1)
    if homing >= 0 and 'time/sim_step' in source:
        steps = np.asarray(source['time/sim_step'][:])
        if len(steps) != count or np.any(np.diff(steps) < 0):
            raise ValueError('Invalid recorded timeline')
        count = int(np.count_nonzero(steps < homing))
    if count < 1:
        raise ValueError('No pre-homing demonstration frames')
    return count


def decode_frame(raw):
    array = np.asarray(raw)
    if array.ndim == 1 and array.dtype == np.uint8:
        decoded = cv2.imdecode(array, cv2.IMREAD_COLOR)
        if decoded is None:
            raise ValueError('Undecodable overhead frame')
        return decoded
    if array.ndim == 3 and array.shape[2] == 3 and array.dtype == np.uint8:
        return cv2.cvtColor(array, cv2.COLOR_RGB2BGR)
    raise ValueError('Unsupported overhead frame format')


def probe_video(path):
    command = ['ffprobe', '-v', 'error', '-count_frames', '-select_streams', 'v:0',
               '-show_entries', 'stream=codec_name,width,height,nb_read_frames,avg_frame_rate,duration',
               '-of', 'json', str(path)]
    return json.loads(subprocess.check_output(command))['streams'][0]


def export_one(dataset, entry, output, current_instruction):
    source_path = dataset / entry['path']
    stat_before = source_path.stat()
    if stat_before.st_size != entry['bytes']:
        raise ValueError('Source size differs from pinned inventory')
    task_name = Path(entry['path']).parts[1]
    stem = 'task_' + task_name + '_overhead'
    video = output / (stem + '.mp4')
    temporary = output / (stem + '.partial.mp4')
    poster = output / (stem + '.jpg')
    if video.exists() or temporary.exists() or poster.exists():
        raise FileExistsError(stem)
    with h5py.File(source_path, 'r') as source:
        sample = json.loads(scalar(source, 'meta/scene_generalization_sample'))
        if sample.get('_generalization_split') != 'seen':
            raise ValueError('Not a training/seen demonstration')
        frames = source['cameras/cam_overhead/rgb']
        count = frame_count(source, len(frames))
        fps = float(scalar(source, 'meta/effective_fps', 0))
        if not np.isfinite(fps) or fps <= 0:
            raise ValueError('Missing or invalid recorded frame rate')
        first = decode_frame(frames[0])
        height, width = first.shape[:2]
        command = ['ffmpeg', '-nostdin', '-v', 'error', '-f', 'rawvideo', '-pixel_format', 'bgr24',
                   '-video_size', f'{width}x{height}', '-framerate', str(fps), '-i', 'pipe:0',
                   '-an', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-threads', '2',
                   '-vf', 'pad=ceil(iw/2)*2:ceil(ih/2)*2', '-pix_fmt', 'yuv420p',
                   '-movflags', '+faststart', '-n', str(temporary)]
        with tempfile.TemporaryFile() as errors:
            process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=errors)
            try:
                for index in range(count):
                    frame = first if index == 0 else decode_frame(frames[index])
                    if frame.shape != first.shape:
                        raise ValueError('Overhead resolution changed within demonstration')
                    process.stdin.write(frame.tobytes())
                    if index == count // 2:
                        if not cv2.imwrite(str(poster), frame, [cv2.IMWRITE_JPEG_QUALITY, 90]):
                            raise RuntimeError('Poster export failed')
                process.stdin.close()
                if process.wait() != 0:
                    errors.seek(0)
                    raise RuntimeError(errors.read().decode('utf-8', errors='replace'))
            except BaseException:
                if process.poll() is None:
                    process.terminate()
                    process.wait()
                temporary.unlink(missing_ok=True)
                raise
        metadata = probe_video(temporary)
        if int(metadata['nb_read_frames']) != count or metadata['codec_name'] != 'h264':
            raise ValueError('Encoded frame count or codec mismatch')
        stat_after = source_path.stat()
        if (stat_before.st_size, stat_before.st_mtime_ns) != (stat_after.st_size, stat_after.st_mtime_ns):
            raise ValueError('Source changed during export')
        temporary.rename(video)
        instruction = scalar(source, 'meta/instruction', '')
    return dict(task_id=int(task_name.split('_')[0]), task_name=task_name, video=video.name,
                poster=poster.name, source=str(source_path), source_episode=source_path.name,
                source_sha256_from_inventory=entry['sha256'], source_full_hash_rechecked=False,
                camera='cam_overhead', frames=count, fps=fps, duration_seconds=count / fps,
                width=metadata['width'], height=metadata['height'], video_bytes=video.stat().st_size,
                video_sha256=hashlib.sha256(video.read_bytes()).hexdigest(),
                recorded_instruction=instruction, current_instruction=current_instruction,
                instruction_wording_matches=instruction == current_instruction)


def write_gallery(output, records):
    cards = []
    for record in records:
        title = record['task_name'].replace('_', ' ')
        notes = ''
        if not record['instruction_wording_matches']:
            notes = '<p class="note">Recorded training wording differs from the current task wording.</p>'
        cards.append(f'<article><h2>{html.escape(title)}</h2>'
                     f'<video controls preload="none" poster="{record["poster"]}" src="{record["video"]}"></video>'
                     f'<p>{record["duration_seconds"]:.1f}s · {record["fps"]:g} fps · overhead only</p>'
                     f'<p><b>Current task:</b> {html.escape(record["current_instruction"])}</p>{notes}'
                     f'<details><summary>Recorded training instruction</summary><p>{html.escape(record["recorded_instruction"])}</p>'
                     f'<p>Source: {html.escape(record["source_episode"])}</p></details></article>')
    page = '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width">'
    page += '<title>26 training demos — overhead view</title><style>body{font:16px system-ui;background:#111827;color:#e5e7eb;margin:30px}h1{font-size:30px}main{display:grid;grid-template-columns:repeat(auto-fit,minmax(360px,1fr));gap:24px}article{background:#1f2937;padding:18px;border-radius:12px}h2{font-size:19px;margin-top:0}video{width:100%;background:black}p{line-height:1.5}.note{color:#fbbf24}summary{cursor:pointer}</style>'
    page += '<h1>26 training demonstrations · overhead only</h1><p>One released seen/training demo per task. Original playback speed; post-task homing omitted. Human previews only, not evaluation-policy inputs. These are demonstrations, not Astra test results.</p><main>'
    page += ''.join(cards) + '</main></html>'
    (output / 'index.html').write_text(page)
    sheet = Image.new('RGB', (1280, 284 * ((len(records) + 3) // 4)), '#111827')
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 15)
    for position, record in enumerate(records):
        left, top = (position % 4) * 320, (position // 4) * 284
        with Image.open(output / record['poster']) as thumbnail:
            thumbnail.thumbnail((312, 234))
            sheet.paste(thumbnail, (left + (320 - thumbnail.width) // 2, top))
        title = record['task_name'].replace('_', ' ')
        draw.text((left + 6, top + 236), textwrap.fill(title, 34), font=font, fill='white')
    sheet.save(output / 'overview.jpg', quality=90)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', type=Path, required=True)
    parser.add_argument('--upstream', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    cv2.setNumThreads(1)
    inventory_path = args.dataset / '.download_logs/inventory.json'
    inventory = json.loads(inventory_path.read_text())
    selected = select_sources(inventory['files'])
    args.output.mkdir(parents=True, exist_ok=False)
    records = []
    for task_id, entry in sorted(selected.items()):
        if shutil.disk_usage(args.output).free < 2 * 1024**3:
            raise RuntimeError('Preserving 2 GiB free space for the evaluation monitor')
        scenes = list((args.upstream / 'scenes').glob(f'{task_id:02d}_*.yaml'))
        if len(scenes) != 1:
            raise ValueError('Ambiguous current task definition')
        definition = yaml.safe_load(scenes[0].read_text())
        instruction = definition['description']
        record = export_one(args.dataset, entry, args.output, instruction)
        records.append(record)
        manifest = dict(created_at=datetime.now(timezone.utc).isoformat(), state='exporting',
                        source_revision=inventory['revision'], source_inventory_sha256=hashlib.sha256(inventory_path.read_bytes()).hexdigest(),
                        selection='Lexicographically first replay-generalization file per task; not selected by success',
                        excluded='Only the post-task homing suffix', videos=records)
        (args.output / 'manifest.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n')
        print(f'{len(records)}/26 Task{task_id:02d}: {record["frames"]} frames, {record["duration_seconds"]:.1f}s', flush=True)
    write_gallery(args.output, records)
    manifest['state'] = 'complete'
    (args.output / 'manifest.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n')
    (args.output / 'README.md').write_text('# Overhead training demonstrations\n\nOpen index.html for the gallery, or play the 26 task-named MP4 files directly.\n\nThese are recorded training/seen demonstrations, not Astra evaluation videos.\nOnly the overhead view is exported, at original speed, with post-task homing removed.\nThe gallery preserves recorded instructions and shows current task instructions; older releases can differ.\nNo GPU renderer was used and evaluation inputs, packages, and results were not changed.\nSource inventory hashes are recorded, not freshly rehashed; all output frames were decoded and counted.\n')
    print(f'Complete: {args.output}', flush=True)


if __name__ == '__main__':
    main()
