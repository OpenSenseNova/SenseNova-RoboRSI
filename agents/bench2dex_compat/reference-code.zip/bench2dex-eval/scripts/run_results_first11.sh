#!/usr/bin/env bash
set -euo pipefail
eval_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
: "${ISAACLAB_PYTHON:?Set ISAACLAB_PYTHON to the installed IsaacLab Python}"
export PYTHONPATH="$eval_root/src${PYTHONPATH:+:$PYTHONPATH}"
assets="${BENCH2DEX_ASSETS:-$eval_root/../dex2bench_dataset}"
exec "${EVAL_PYTHON:-python3}" -u -m gpt6_eval.suite \
  --plan "$eval_root/configs/results_first11_suite.json" \
  --config "$eval_root/configs/results_first11_two_samples.json" \
  --upstream "${BENCH2DEX_ROOT:-$eval_root/../Bench2Dex}" \
  --isaaclab "${ISAACLAB_ROOT:-$eval_root/../IsaacLab}" \
  --assets "$assets" --python "$ISAACLAB_PYTHON" \
  --inventory "${BENCH2DEX_ASSET_INVENTORY:-$assets/.download_logs/all_tasks/selection.inventory.json}" \
  "$@"
