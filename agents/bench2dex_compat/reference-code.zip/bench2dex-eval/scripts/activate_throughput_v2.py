"""One-time audited transition; refuse scored launches without validated v2 evidence."""
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
from datetime import datetime, timezone


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,required=True)
    args=parser.parse_args();root=args.root.resolve();audit=root/'repairs/throughput_v2_20260928'
    info=json.loads((audit/'new_snapshot.json').read_text());snap=root/info['snapshot']
    sys.path.insert(0,str(snap/'runner/src'))
    from gpt6_eval.knowledge import verify_package
    from gpt6_eval.core import write_json
    spec=importlib.util.spec_from_file_location('campaign_transition',snap/'supervisor.py')
    host=importlib.util.module_from_spec(spec);spec.loader.exec_module(host)
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    with (root/'supervisor.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        state=host.read(root/'state.json');plan=host.read(root/'campaign.json')
        if state['snapshot']!= 'snapshots/v1' or state['state']!='stopped_by_request':
            raise ValueError('Unexpected campaign state; never overwrite an active transition')
        if any(not j.get('ended_at') for j in state['jobs']):raise ValueError('Undrained jobs')
        for job in state['jobs'][-3:]:
            pid=job.get('pid')
            if pid and Path(f'/proc/{pid}').exists():raise ValueError('Old PID still exists')
        if sha(root/'campaign.json')!=state['plan_sha256']:raise ValueError('Plan changed')
        for version,hashes in ((root/state['snapshot'],state['source_hashes']),(snap,info['source_hashes'])):
            for name,digest in hashes.items():
                if sha(version/'runner'/name)!=digest:raise ValueError('Frozen source changed: '+name)
        if sha(snap/'supervisor.py')!=info['supervisor_sha256']:raise ValueError('Supervisor changed')
        if (sha(snap/'base_config.json')!=info['base_config_sha256']
            or info['base_config_sha256']!=state['base_config_sha256']):raise ValueError('Experimental base config changed')
        # Policy/model-facing helpers, prompts and every experiment configuration
        # must remain byte-identical; only explicit trusted host modules changed.
        allowed={'src/gpt6_eval/bridge.py','src/gpt6_eval/cli.py','src/gpt6_eval/core.py',
                 'src/gpt6_eval/icl.py','src/gpt6_eval/knowledge.py','src/gpt6_eval/throughput.py'}
        for name,digest in info['source_hashes'].items():
            if name.startswith(('src/','prompts/','configs/')) and name not in allowed:
                if state['source_hashes'].get(name)!=digest:raise ValueError('Unapproved experimental change: '+name)
        bench=host.read(audit/'real_demo_benchmark.json')
        if not bench['identical_public_bytes'] or not bench['identical_private_provenance'] or bench['file_count']!=2831:
            raise ValueError('Export equivalence absent')
        for logfile in ('regression_134.log','campaign_10.log'):
            if not (audit/logfile).read_text().rstrip().endswith('OK'):raise ValueError('Regression checks failed')
        doctor=host.successful('isolation',audit/'isolation')
        smoke=host.successful('smoke',audit/'smoke_final')
        if smoke['mode']!='hold' or smoke['planned_episodes']!=4:raise ValueError('Wrong smoke')
        marker=host.read(audit/'smoke_final/startup/wave_0000.json')
        if marker['resident_workers']!=4:raise ValueError('Four-worker residency absent')
        cfg=host.read(snap/'base_config.json');smoke_cfg=host.read(audit/'smoke.config.json')
        if smoke_cfg!={**cfg,'start_episode':50003,'num_episodes':4}:raise ValueError('Smoke settings changed')
        reference_assets=host.read(root/'task_09/0044_evaluation/episode_0000/private/assets.json')
        smoke_indices=[]
        for ep in smoke['episodes']:
            smoke_indices.append(ep['upstream_episode_index'])
            private=audit/'smoke_final'/ep['directory']/'private'
            manifest=host.read(private/'manifest.json')
            if host.read(private/'assets.json')!=reference_assets:raise ValueError('Assets differ from completed episodes')
            if manifest['source_hashes']!=info['source_hashes']:raise ValueError('Smoke ran different source')
            if manifest['config']!={**cfg,'start_episode':ep['upstream_episode_index'],'num_episodes':1}:
                raise ValueError('Smoke effective config mismatch')
        if smoke_indices!=list(range(50003,50007)):raise ValueError('Smoke index mismatch')
        checked=[];packages=[]
        for task in state['tasks'].values():
            if task.get('package'):
                ref=task['package'];verify_package(Path(ref['path']),ref['sha256'],task['task_id'],cfg)
                packages.append({'task_id':task['task_id'],**ref})
                checked.extend(host.collect(task).values())
        if len(checked)!=54:raise ValueError('Unexpected completed episode count')
        prerequisite=Path(plan['prerequisite_cohort']).with_name('cohort_result.json')
        if sha(prerequisite)!=state['prerequisite_result_sha256']:raise ValueError('Task26 result changed')
        shutil.copyfile(root/'state.json',audit/'state.before_activation.json')
        validation={'state':'passed','at':datetime.now(timezone.utc).isoformat(),
             'unique_host_tests_passed':135,'benchmark':bench,'completed_campaign_episodes_verified':len(checked),
             'task26_completed_episodes':20,'packages_verified':packages,'snapshot':info,
             'evidence_sha256':{name:sha(audit/name) for name in ('regression_134.log','campaign_10.log',
                  'real_demo_benchmark.json','isolation/result.json','smoke_final/result.json',
                  'smoke_final/startup/wave_0000.json','infrastructure.diff','supervisor_memory.diff','smoke_resources.json')},
             'activation_script_sha256':sha(__file__),
             'interrupted_jobs':[46,47,48],
             'completed_results_unchanged':True,'all_32892_asset_hashes_match_completed_task09':True,'task22_archive_caveat_retained':True}
        write_json(audit/'validation.json',validation)
        for job in state['jobs']:
            if job['id'] in (46,47,48):job['recovery']='User-requested throughput transition before mass testing; retain attempt, same-index continuation only'
        for task in state['tasks'].values():
            for job in task['jobs']:
                if job['id'] in (46,47,48):job['recovery']='User-requested throughput transition; original attempt retained'
        state.update(**info,error=None,state='running',optimization_validation=str(audit/'validation.json'),updated_at=validation['at'])
        task=state['tasks']['9'];task.update(smoke_workers=4,isolation=str(audit/'isolation'),throughput_smoke=str(audit/'smoke_final'))
        write_json(root/'state.json',state)
        (audit/'OPTIMIZATION_HOLD.json').rename(audit/'optimization_hold_released.json')
    command=[plan['runtime']['python'],'-u',str(snap/'supervisor.py'),'--output',str(root)]
    shell='exec '+shlex.join(command)+' >> '+shlex.quote(str(root/'supervisor.log'))+' 2>&1'
    subprocess.run(['tmux','new-session','-d','-s','bench2dex-all-icl10',shell],check=True)
    print('Validated v2 activated; campaign resumed in bench2dex-all-icl10')

if __name__=='__main__':main()
