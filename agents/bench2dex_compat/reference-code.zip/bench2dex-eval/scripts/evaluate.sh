#!/usr/bin/env bash
# Portable foreground launcher; all other options pass to the original CLI.
set -euo pipefail
eval_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
: "${BENCH2DEX_ROOT:?Set BENCH2DEX_ROOT to the pinned Bench2Dex checkout}"
: "${ISAACLAB_ROOT:?Set ISAACLAB_ROOT to the pinned IsaacLab checkout}"
: "${BENCH2DEX_ASSETS:?Set BENCH2DEX_ASSETS to the testing asset directory}"
: "${ISAACLAB_PYTHON:?Set ISAACLAB_PYTHON to the simulator Python executable}"
export PYTHONPATH="$eval_root/src${PYTHONPATH:+:$PYTHONPATH}"
exec "${EVAL_PYTHON:-python}" -u -m gpt6_eval.cli \
  --upstream "$BENCH2DEX_ROOT" --isaaclab "$ISAACLAB_ROOT" \
  --assets "$BENCH2DEX_ASSETS" --python "$ISAACLAB_PYTHON" "$@"
