"""Diagnostic-only hold CLI: periodic simulator Python stacks, no model calls.

Pass the usual gpt6_eval.cli options, explicitly including --mode hold.
This instrumented command must never be used for scored evaluation.
"""
import subprocess
import sys
import os
import time
from pathlib import Path


def main():
    from gpt6_eval import cli
    args = sys.argv[1:]
    if '--mode' not in args or args[args.index('--mode') + 1] != 'hold':
        raise SystemExit('Startup diagnostics require explicit --mode hold')
    original_popen = subprocess.Popen
    bootstrap = (
        'import faulthandler,runpy,sys; '
        'faulthandler.enable(); '
        '_dump=faulthandler.dump_traceback_later; '
        'faulthandler.dump_traceback_later=lambda *a,**kw:_dump(45,repeat=True); '
        'faulthandler.cancel_dump_traceback_later=lambda:None; '
        'faulthandler.dump_traceback_later(45,repeat=True); '
        'sys.argv=["gpt6_eval.simulator",*sys.argv[1:]]; '
        'runpy.run_module("gpt6_eval.simulator",run_name="__main__")'
    )

    def diagnostic_popen(command, *positional, **kwargs):
        if isinstance(command, list) and command[1:3] == ['-m', 'gpt6_eval.simulator']:
            barrier = os.environ.get('GPT6_DIAGNOSTIC_BARRIER')
            if barrier:
                directory = Path(barrier)
                directory.mkdir(parents=True, exist_ok=True)
                (directory / str(os.getpid())).touch(exist_ok=False)
                deadline = time.monotonic() + 180
                while len(list(directory.iterdir())) < 2:
                    if time.monotonic() > deadline:
                        raise RuntimeError('Diagnostic two-process startup barrier timed out')
                    time.sleep(0.1)
            print('DIAGNOSTIC ONLY: simulator emits Python stacks every 45 seconds; '
                  'nominal manifest argv is wrapped with faulthandler.', flush=True)
            command = [command[0], '-u', '-c', bootstrap, *command[3:]]
        return original_popen(command, *positional, **kwargs)

    subprocess.Popen = diagnostic_popen
    try:
        cli.main()
    finally:
        subprocess.Popen = original_popen


if __name__ == '__main__':
    main()
