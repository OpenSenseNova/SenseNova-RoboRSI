"""Host-only final audit using each task's authorized count; never policy input."""
import argparse
import json
import math
from datetime import datetime, timezone
from pathlib import Path

from finalize_task26_twenty import read, sha, token_sum
from gpt6_eval.core import verify_model_rollouts
from gpt6_eval.knowledge import verify_package

BASE = Path('runs')
ROOT = BASE / 'all_tasks_icl10_20260924_01'


def require_indices(indices, expected=None):
    expected=list(range(5,15)) if expected is None else expected
    if sorted(indices) != expected or len(set(expected)) != len(expected):
        raise ValueError(f'Expected exactly the authorized unique indices: {expected}')


def planned_indices(task, planned):
    count=planned['target_valid_count']
    indices=planned['new_episode_indices']
    if count not in (5,10) or indices!=list(range(5,5+count)):
        raise ValueError('Unsupported campaign cohort')
    if task['target_valid_count']!=count or task['new_episode_indices']!=indices:
        raise ValueError('Plan/state sample count mismatch')
    return indices


def snapshot_sources(snapshot):
    """Require the full recorded attempt snapshot, including pre-optimization runs."""
    relative=Path(snapshot)
    if relative.is_absolute() or '..' in relative.parts:
        raise ValueError('Unsafe attempt snapshot')
    root=ROOT/relative/'runner'
    hashes={str(p.relative_to(root)):sha(p) for folder in ('src','prompts','configs','docs','scripts')
            for p in (root/folder).rglob('*') if p.is_file() and p.suffix in ('.py','.md','.json','.sh')}
    metadata = ('RELEASE_CONTENTS.json', 'RELEASE_AUDIT.md', 'LICENSE_NOTICE.md', 'setup.py', 'MANIFEST.in') if (root/'RELEASE_CONTENTS.json').is_file() else ('PROJECT_MEMORY.md', 'TASK_EVALUATABILITY.md')
    for name in ('README.md', 'AGENTS.md', *metadata, 'pyproject.toml'):
        hashes[name]=sha(root/name)
    return hashes


def check_hashes(root, hashes):
    for name, digest in hashes.items():
        if sha(root / name) != digest:
            raise ValueError(f'Hash mismatch: {root / name}')


def exact_invocation(argv):
    assert argv[argv.index('--model') + 1] == 'gpt-6-astra'
    assert 'model_reasoning_effort="max"' in argv


def invalid_costs(result, telemetry_path):
    """Canceled peers can retain costs only in host telemetry; never infer zero."""
    telemetry = read(telemetry_path) if telemetry_path.exists() else {}
    for key in ('tokens', 'timing'):
        if key in result and key in telemetry and result[key] != telemetry[key]:
            raise ValueError(f'Conflicting invalid-attempt {key}: {telemetry_path}')
    return {
        'tokens': telemetry.get('tokens', result.get('tokens', {'status': 'unavailable'})),
        'timing': telemetry.get('timing', result.get('timing', {})),
        'telemetry_path': str(telemetry_path) if telemetry else None,
        'telemetry_sha256': sha(telemetry_path) if telemetry else None,
    }


def cohort_interpretation(count, indices):
    """Describe the actual plan, never an obsolete proposed amendment."""
    return (
        f'{count} fixed new indices{indices[0]}–{indices[-1]} under the currently authorized campaign plan. '
        'The pending five-episode amendment was canceled before application; the active primary plan '
        'retains ten episodes per task and twenty for task26. Historical task22/task26 sample extensions '
        'were post-outcome. No within-task outcome-based index replacement or package updates. '
        'Preparation counted once. Variable admission-based concurrency and historical reservation '
        'profiles are recorded in batch provenance; task26 historically used three then two workers. '
        'New preparations use the disclosed trusted_reader_v1 interface; existing packages are reused unchanged. '
        'Testing partial token reports are lower bounds; cached/reasoning values are subsets. '
        'Server-only inference time is unavailable. Calendar time includes resource waits and campaign '
        'recovery gaps; run wall excludes final integrity hashing. Hosted preparation web contamination '
        'cannot be ruled out mechanically. Task22 historical archive qualification remains separate '
        'and its uncertified cohort must not enter certified pooled SR.'
    )


def stage_cost(job):
    """Preserve reconciled unknown exits without inventing duration or success."""
    out = Path(job['output'])
    record_path = out / {'training': 'manifest.json', 'preparation': 'preparation.json'}.get(job['stage'], 'result.json')
    code = job.get('returncode')
    semantics = job.get('reconciliation_time_semantics')
    if code is None and (not job.get('recovery') or semantics !=
            'ended_at is reconciliation time, not observed child exit time'):
        raise ValueError('Unknown stage exit requires explicit reconciliation evidence')
    result = {'stage': job['stage'], 'output': str(out), 'returncode': code,
        'wall_seconds_including_finalization': None if semantics else
            (datetime.fromisoformat(job['ended_at']) - datetime.fromisoformat(job['started_at'])).total_seconds(),
        'record_sha256': sha(record_path) if record_path.exists() else None,
        'record': read(record_path) if code != 0 and record_path.exists() else None}
    if semantics:
        result.update(reconciliation_time_semantics=semantics,
                      reconciliation_at=job['ended_at'], recovery=job.get('recovery'))
    return result


def training_provenance_qualification(task_id, training, preparation, package_manifest):
    """Task51-only final gate/disclosure; historic other-task JSON stays unchanged."""
    records = (training, preparation, package_manifest)
    if task_id != 51:
        if any('provenance_exception' in record for record in records):
            raise ValueError('Task51 provenance exception is not permitted for another task')
        return {}
    from gpt6_eval.task51_legacy_provenance import validate_training
    validate_training(training)
    exception = training['provenance_exception']
    if any(record.get('task_id') != task_id for record in records):
        raise ValueError('Task51 provenance task identity mismatch')
    if (preparation.get('provenance_exception') != exception
            or package_manifest.get('provenance_exception') != exception):
        raise ValueError('Task51 exception missing or changed across preparation/package')
    if (not preparation.get('training_manifest_sha256')
            or package_manifest.get('training_manifest_sha256') != preparation['training_manifest_sha256']):
        raise ValueError('Task51 package training-manifest binding mismatch')
    return {
        'provenance_exception': exception,
        'provenance_qualification': (
            'Task51-only user-approved legacy-provenance exception: the same100 pinned explicitly '
            'seen replay files were retained. Original collection namespace and episode seeds '
            'are UNKNOWN (null), not inferred as collection or reconstructed from legacy seed0. '
            'Exact task/revision/100-file source-set binding and per-file private exception records '
            'were revalidated against the training, preparation and frozen-package manifests. '
            'All original test indices/seeds, budgets, sensors, model, isolation and official scoring '
            'are unchanged. This limits original training-data provenance; it is not evidence that '
            'the official benchmark or trajectories are invalid. No additional full raw-source '
            'rehash is claimed by this final audit.'
        )}


def main():
    global ROOT, BASE
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--task', type=int, required=True)
    ap.add_argument('--root', type=Path, required=True)
    args = ap.parse_args()
    ROOT = args.root.resolve()
    BASE = ROOT.parent
    tid = args.task
    assert tid not in (22, 26), 'Inherited cohorts require their dedicated auditor'
    destination = ROOT / f'task_{tid:02d}/cohort_result.json'
    if destination.exists():
        raise FileExistsError(destination)
    state = read(ROOT / 'state.json')
    plan = read(ROOT / 'campaign.json')
    task = state['tasks'][str(tid)]
    PACKAGE = task['package']['sha256']
    budget = task['control_step_budget']
    assert task['state'] == 'complete_pending_final_audit'
    assert sha(ROOT / 'campaign.json') == state['plan_sha256']
    snapshot = ROOT / state['snapshot']
    assert sha(snapshot / 'supervisor.py') == state['supervisor_sha256']
    check_hashes(snapshot / 'runner', state['source_hashes'])
    assert sha(snapshot / 'base_config.json') == state['base_config_sha256']
    refs = task['valid_episodes']
    planned = next(t for t in plan['tasks'] if t['task_id'] == tid)
    indices=planned_indices(task,planned);count=len(indices)
    require_indices([r['episode_index'] for r in refs],indices)
    assert planned['control_step_budget'] == budget
    assert not task.get('inherited')
    jobs = [j for j in task['jobs'] if j['stage'] == 'evaluation']
    assert all(j.get('ended_at') for j in jobs)
    isolation_path = Path(task['isolation']) / 'result.json'
    assert read(isolation_path)['tool_probe'] == 'passed'
    stage_costs = []
    for job in task['jobs']:
        assert job.get('ended_at')
        out = Path(job['output'])
        record_path = out / {'training': 'manifest.json', 'preparation': 'preparation.json'}.get(job['stage'], 'result.json')
        stage_costs.append(stage_cost(job))
        if job['stage'] == 'smoke' and job.get('returncode') == 0:
            smoke = read(record_path)
            assert smoke['state'] == 'completed' and not smoke['infrastructure_errors']
            assert all(e['valid'] for e in smoke['episodes'])
            assert read(out / 'startup/wave_0000.json')['resident_workers'] == job['workers']
    batch_paths = [Path(j['output']) / 'result.json' for j in jobs]
    snapshots_by_batch={Path(j['output']):j['snapshot'] for j in jobs}
    expected_sources={name:snapshot_sources(name) for name in set(snapshots_by_batch.values())}
    # Detect untracked evaluation attempts as well as duplicates in recorded jobs.
    assert set(ROOT.glob(f'task_{tid:02d}/*_evaluation/result.json')) == set(batch_paths)
    selected, selected_snapshots, invalid, batches = {}, {}, [], []
    all_starts, all_ends = [], []
    for p in batch_paths:
        b = read(p)
        batches.append({'path': str(p), 'sha256': sha(p), 'workers': b['workers'],
                        'started_at': b['started_at'], 'wall_seconds': b['batch_wall_seconds']})
        for row in b['episodes']:
            all_starts.append(row['started_at']); all_ends.append(row['ended_at'])
            idx = row['upstream_episode_index']
            result_path = p.parent / row['directory'] / 'result.json'
            if row['valid']:
                assert idx not in selected, ('duplicate valid index', idx)
                selected[idx] = str(result_path)
                selected_snapshots[idx]=snapshots_by_batch[p.parent]
            else:
                r = read(result_path) if result_path.exists() else row.get('result') or {}
                invalid.append({'episode_index': idx, 'result': str(result_path),
                    'sha256': sha(result_path) if result_path.exists() else None,
                    'returncode': row['returncode'], 'infrastructure_error': r.get('infrastructure_error'),
                    **invalid_costs(r, result_path.with_name('telemetry.json')),
                    'worker_wall_seconds_including_finalization':
                        (datetime.fromisoformat(row['ended_at']) - datetime.fromisoformat(row['started_at'])).total_seconds()})
    require_indices(list(selected),indices)
    episodes = []
    for ref in refs:
        p = Path(ref['result']); root = p.parent
        assert selected[ref['episode_index']] == str(p)
        assert sha(p) == ref['sha256']
        r = read(p); m = read(root / 'private/manifest.json'); cfg = m['config']
        assert r['complete'] and r['eligible_for_gpt6_score'] and not r['infrastructure_error']
        assert r['mode'] == 'codex' and r['evaluation_setting'] == 'task_icl_v3'
        assert r['task_package_sha256'] == PACKAGE
        assert m['task_id'] == tid and m['official_policy_budget'] == m['executed_policy_budget'] == budget
        assert m['source_hashes'] == expected_sources[selected_snapshots[ref['episode_index']]], 'Unexpected test runner source for recorded attempt'
        for k, v in {'model':'gpt-6-astra', 'reasoning_effort':'max', 'codex_version':'codex-cli 0.154.0',
                     'generalization_profile':'inv_cov', 'generalization_split':'unseen',
                     'deployment_profile':'calibrated_deployment_v2', 'observation_profile':'baseline_4cam',
                     'seed':100000000, 'inv_cov_seed':200000000, 'decision_timeout_s':None}.items():
            assert cfg[k] == v, (p, k)
        assert cfg['start_episode'] == ref['episode_index'] and cfg['num_episodes'] == 1
        check_hashes(root / 'private/source', m['source_hashes'])
        verify_package(Path(cfg['task_packages'][str(tid)]['path']), PACKAGE, tid, cfg)
        private = root / 'episode_0000/private'
        evidence = verify_model_rollouts(private / 'codex-home')
        ev = {e['event_sha256'] for e in evidence}
        exact_invocation(read(private / 'invocation.json')['argv'])
        actions = sorted((private / 'actions').glob('*.json'))
        assert actions
        integrity = read(root / 'integrity.json')
        for action in actions:
            assert sha(action) == integrity[str(action.relative_to(root))], action
            a = read(action)
            assert a['model_evidence'] and all(e['model'] == 'gpt-6-astra' and e['event_sha256'] in ev for e in a['model_evidence'])
        official_path = root / r['official_results_path']
        official = [json.loads(s) for s in official_path.read_text().splitlines() if s.strip()]
        assert len(official) == 1
        o = official[0]
        assert o['episode_index'] == ref['episode_index'] and o['success'] == r['episodes'][0]['official_success']
        assert 0 <= o['latched_stage_completion_rate'] <= 1
        integrity = read(root / 'integrity.json')
        critical = ['result.json', 'private/manifest.json', r['official_results_path'],
                    'episode_0000/private/invocation.json', 'episode_0000/private/prompt.md']
        check_hashes(root, {n: integrity[n] for n in critical})
        asset_verification = {'mode': 'full_per_episode'}
        cache_path = root / 'private/asset_cache_use.json'
        if cache_path.is_file():
            assert sha(cache_path) == integrity['private/asset_cache_use.json']
            asset_verification = read(cache_path)
        episodes.append({**ref, 'success': o['success'], 'termination': o['terminated_reason'],
            'physics_steps': o['steps'], 'control_steps_executed': math.ceil(o['steps'] / 3),
            'official_lscr': o['latched_stage_completion_rate'], 'tokens': r['tokens'], 'timing': r['timing'],
            'model_evidence_records': len(evidence), 'action_chunks_verified': len(actions),
            'source_files_verified': len(m['source_hashes']), 'package_sha256': PACKAGE,
            'manifest_sha256': sha(root / 'private/manifest.json'),
            'asset_verification': asset_verification,
            'official_result_sha256': sha(official_path), 'integrity_manifest_sha256': sha(root / 'integrity.json')})
    prep_jobs = [j for j in task['jobs'] if j['stage'] == 'preparation' and j.get('returncode') == 0]
    assert len(prep_jobs) == 1
    prep_root = Path(prep_jobs[0]['output'])
    prep = read(prep_root / 'preparation.json')
    assert prep['state'] == 'ready' and prep['task_id'] == tid and prep['package']['sha256'] == PACKAGE
    exact_invocation(prep['argv'])
    verify_model_rollouts(prep_root / 'private/codex-home')
    check_hashes(prep_root / 'private/source', prep['source_hashes'])
    assert sha(Path(task['training']) / 'manifest.json') == prep['training_manifest_sha256']
    training = read(Path(task['training']) / 'manifest.json')
    assert training['state'] == 'complete' and len(training['demonstrations']) == 100
    assert training['dataset_revision'] == plan['protocol']['dataset_revision']
    if tid == 51:
        package_manifest_path = Path(task['package']['path']) / 'manifest.json'
        assert sha(package_manifest_path) == PACKAGE
        package_manifest = read(package_manifest_path)
    else:
        # Do not read an additional historical package or alter historical outputs.
        package_manifest = {}
    provenance = training_provenance_qualification(tid, training, prep, package_manifest)
    testing_tokens = token_sum([e['tokens'] for e in episodes])
    result = {'state': 'complete', 'task_id': tid, 'valid_episode_count': count, 'indices': indices,
        'audited_at': datetime.now(timezone.utc).isoformat(), 'campaign_path': str(ROOT / 'campaign.json'),
        'campaign_sha256': state['plan_sha256'], 'auditor_sha256': sha(Path(__file__)),
        'successes': sum(e['success'] for e in episodes), 'success_rate': sum(e['success'] for e in episodes) / count,
        'mean_official_lscr': sum(e['official_lscr'] for e in episodes) / count,
        'plan_amendments':plan.get('amendments',[]),
        'episodes': episodes, 'testing_tokens': testing_tokens,
        'testing_tool_inclusive_inference_seconds': sum(e['timing']['policy_inference_wall_seconds'] for e in episodes),
        'testing_sum_episode_wall_seconds': sum(e['timing']['run_wall_seconds'] for e in episodes),
        'testing_calendar_span_seconds': (datetime.fromisoformat(max(all_ends)) - datetime.fromisoformat(min(all_starts))).total_seconds(),
        'extension_calendar_span_seconds': (datetime.fromisoformat(jobs[-1]['ended_at']) - datetime.fromisoformat(jobs[0]['started_at'])).total_seconds(),
        'preparation_count': 1, 'preparation_tokens': prep['tokens'], 'preparation_wall_seconds': prep['wall_seconds'],
        'preparation_tool_inclusive_inference_seconds': prep['inference_tool_wall_seconds'],
        'training_export_wall_seconds': training['wall_seconds'],
        'training_manifest_sha256': prep['training_manifest_sha256'],
        'stage_provenance': task['jobs'],
        'smoke_bypass': task.get('smoke_bypass'),
        'stage_costs': stage_costs,
        'isolation_result_sha256': sha(isolation_path),
        'auditor_dependency_sha256': sha(Path(__file__).with_name('finalize_task26_twenty.py')),
        'preparation_path': str(prep_root / 'preparation.json'), 'preparation_sha256': sha(prep_root / 'preparation.json'),
        'invalid_attempts': invalid, 'invalid_attempt_tokens': token_sum([e['tokens'] for e in invalid]),
        'invalid_attempt_tool_inclusive_inference_seconds': sum(e['timing'].get('policy_inference_wall_seconds', 0) for e in invalid),
        'batch_provenance': batches,
        'audit_scope': 'Result, official metrics, invocation, prompt, archived source hashes, frozen package payloads and CLI/action identity reverified. Training manifest hash reverified. Large training/media/trajectory bytes retain their original integrity records, not a full second rehash. No policy/preparation inputs changed.',
        'interpretation': cohort_interpretation(count, indices)}
    if provenance:
        result.update(provenance)
        result['interpretation'] += ' ' + provenance['provenance_qualification']
        result['audit_scope'] += ' Task51 legacy-provenance exception and exact source-set manifest binding revalidated.'
    with destination.open('x') as f:
        json.dump(result, f, indent=2); f.write('\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('episodes', 'batch_provenance', 'stage_provenance', 'stage_costs')}, indent=2))


if __name__ == '__main__':
    main()
