"""No-model real-corpus equivalence and measured on-demand reader validation."""
import argparse
import json
from pathlib import Path
import time

from gpt6_eval.core import write_json
from gpt6_eval.demo_reader import DemoReader
from gpt6_eval.knowledge import file_hash, tree_hashes


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--training', type=Path, required=True)
    p.add_argument('--reference', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args(); args.output.mkdir()
    training = json.loads((args.training / 'manifest.json').read_text())
    reference = json.loads((args.reference / 'manifest.json').read_text())
    if training['state'] != 'complete' or len(training['demonstrations']) != 100:
        raise ValueError('Incomplete index')
    # Every fully exported reference demo has exact matching numeric/metadata files.
    numeric_files = 0
    for row in reference['demonstrations']:
        ident = row['public_id']
        for name in ('qpos.npy', 'actions.npy', 'demo.json'):
            rel = f'public/demos/{ident}/{name}'
            if file_hash(args.reference / rel) != file_hash(args.training / rel):
                raise ValueError('Numeric or metadata mismatch: ' + rel)
            numeric_files += 1
    reader = DemoReader(training, args.training / 'public', args.output)
    start = time.monotonic(); reader.start(); verified_at = time.monotonic()
    try:
        # Include arbitrary order/duplicate indices, then every image of a real demo.
        ident = '0000'; count = reader.sources[ident][2]['frames']
        first_start = time.monotonic()
        reader.images({'demo': ident, 'camera': reader.cameras[0], 'frames': [count-1, 0, count//2, 0]})
        first_seconds = time.monotonic() - first_start
        for cam in reader.cameras:
            for first in range(0, count, 64):
                reader.images({'demo': ident, 'camera': cam, 'frames': list(range(first, min(first+64, count)))})
        rendered_at = time.monotonic()
        for name, digest in reader.served.items():
            if file_hash(args.reference / 'public/demos' / name) != digest:
                raise ValueError('Image bytes differ: ' + name)
        reader.finish()
        files = tree_hashes(args.training / 'public')
        result = {'state': 'passed', 'source_count': 100,
                  'indexed_public_files': len(files),
                  'indexed_public_bytes': sum((args.training / 'public' / n).stat().st_size for n in files),
                  'index_wall_seconds': training['wall_seconds'],
                  'reference_numeric_files_identical': numeric_files,
                  'all_demo_0000_images_identical': True, 'images_compared': len(reader.served),
                  'source_verification_seconds': verified_at-start,
                  'first_request_seconds': first_seconds,
                  'full_demo_decode_seconds': rendered_at-verified_at,
                  'validation_wall_seconds': time.monotonic()-start,
                  'training_manifest_sha256': file_hash(args.training / 'manifest.json'),
                  'reader_audit_sha256': file_hash(args.output / 'demo_reader_audit.json')}
        write_json(args.output / 'result.json', result)
        print(json.dumps(result, indent=2))
    finally:
        reader.close()


if __name__ == '__main__':
    main()
