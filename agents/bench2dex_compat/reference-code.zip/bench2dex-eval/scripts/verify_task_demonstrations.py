"""Read-only streaming verification against the pinned corpus inventory."""
import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024**2), b''):
            h.update(block)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--dataset', type=Path, required=True)
    ap.add_argument('--task', type=int, required=True)
    ap.add_argument('--report', type=Path, required=True)
    args = ap.parse_args()
    if args.report.exists():
        raise FileExistsError(args.report)
    inv_path = args.dataset / '.download_logs/inventory.json'
    inv = json.loads(inv_path.read_text())
    assert inv['repo'] == 'Bench2Dex/teleopdata'
    assert inv['revision'] == 'b195787c65046083e6a43776b67bdf1389dfa3eb'
    files = [e for e in inv['files'] if e['path'].startswith(f'dataset/{args.task:02d}_')
             and '/replay-generalization/' in e['path'] and e['path'].endswith('.hdf5')]
    assert len(files) == len({e['path'] for e in files}) == 100
    rows = []
    for e in sorted(files, key=lambda e: e['path']):
        rel = Path(e['path'])
        assert not rel.is_absolute() and '..' not in rel.parts and e['sha256']
        p = args.dataset / rel
        actual = digest(p) if p.is_file() else None
        size = p.stat().st_size if p.is_file() else None
        rows.append({**e, 'actual_sha256': actual, 'actual_bytes': size,
                     'matches': actual == e['sha256'] and size == e['bytes']})
        print(f'Verified {len(rows)}/100; mismatches={sum(not r["matches"] for r in rows)}', flush=True)
    report = {'task_id': args.task, 'checked_at': datetime.now(timezone.utc).isoformat(),
              'inventory_sha256': digest(inv_path), 'files': rows,
              'state': 'passed' if all(r['matches'] for r in rows) else 'failed'}
    with args.report.open('x') as f:
        json.dump(report, f, indent=2); f.write('\n')
    print(report['state'], flush=True)


if __name__ == '__main__':
    main()
