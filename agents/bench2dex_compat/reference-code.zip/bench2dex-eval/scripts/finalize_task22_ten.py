"""Host-only post-outcome cohort audit. Never mounted into policy/preparation."""
import argparse
import json
import math
from datetime import datetime, timezone
from pathlib import Path

from finalize_task26_twenty import read, sha, token_sum
from gpt6_eval.core import verify_model_rollouts
from gpt6_eval.knowledge import verify_package

BASE = Path('runs')
ROOT = BASE / 'all_tasks_icl10_20260924_01'
PILOT = BASE / 'task22_icl_v3_20260922_01'
PAIRED = BASE / 'task22_paired_icl_vs_zero_20260922_01'
PACKAGE = 'b9883a00641afe811c95e887fd39fee2f2714ecc040c94a64978a79db8899aa9'


def require_indices(indices):
    if sorted(indices) != list(range(5, 15)):
        raise ValueError('Expected exactly ten unique indices 5–14')


def check_hashes(root, hashes):
    for name, digest in hashes.items():
        if sha(root / name) != digest:
            raise ValueError(f'Hash mismatch: {root / name}')


def exact_invocation(argv):
    assert argv[argv.index('--model') + 1] == 'gpt-6-astra'
    assert 'model_reasoning_effort="max"' in argv


def main():
    global ROOT, BASE
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    ROOT = parser.parse_args().root.resolve()
    BASE = ROOT.parent
    destination = ROOT / 'task_22/cohort_result.json'
    if destination.exists():
        raise FileExistsError(destination)
    state = read(ROOT / 'state.json')
    plan = read(ROOT / 'campaign.json')
    task = state['tasks']['22']
    assert task['state'] == 'complete_pending_final_audit'
    assert sha(ROOT / 'campaign.json') == state['plan_sha256']
    snapshot = ROOT / state['snapshot']
    assert sha(snapshot / 'supervisor.py') == state['supervisor_sha256']
    check_hashes(snapshot / 'runner', state['source_hashes'])
    assert sha(snapshot / 'base_config.json') == state['base_config_sha256']
    refs = task['valid_episodes']
    require_indices([r['episode_index'] for r in refs])
    assert task['package'] == plan['task22_package']
    for ref in plan['inherited_task22']:
        assert sha(Path(ref['result'])) == ref['sha256']
        assert ref in refs
    jobs = [j for j in task['jobs'] if j['stage'] == 'evaluation']
    assert all(j.get('ended_at') for j in jobs)
    batch_paths = [PILOT / 'evaluation/result.json', PAIRED / 'icl/result.json']
    batch_paths += [Path(j['output']) / 'result.json' for j in jobs]
    # Detect untracked evaluation attempts as well as duplicates in recorded jobs.
    assert set(ROOT.glob('task_22/*_evaluation/result.json')) == set(batch_paths[2:])
    selected, invalid, batches = {}, [], []
    all_starts, all_ends = [], []
    for p in batch_paths:
        b = read(p)
        batches.append({'path': str(p), 'sha256': sha(p), 'workers': b['workers'],
                        'started_at': b['started_at'], 'wall_seconds': b['batch_wall_seconds']})
        for row in b['episodes']:
            all_starts.append(row['started_at']); all_ends.append(row['ended_at'])
            idx = row['upstream_episode_index']
            result_path = p.parent / row['directory'] / 'result.json'
            if row['valid']:
                assert idx not in selected, ('duplicate valid index', idx)
                selected[idx] = str(result_path)
            else:
                r = read(result_path) if result_path.exists() else row.get('result') or {}
                invalid.append({'episode_index': idx, 'result': str(result_path),
                    'sha256': sha(result_path) if result_path.exists() else None,
                    'returncode': row['returncode'], 'infrastructure_error': r.get('infrastructure_error'),
                    'tokens': r.get('tokens', {'status': 'unavailable'}), 'timing': r.get('timing', {}),
                    'worker_wall_seconds_including_finalization':
                        (datetime.fromisoformat(row['ended_at']) - datetime.fromisoformat(row['started_at'])).total_seconds()})
    require_indices(list(selected))
    episodes = []
    for ref in refs:
        p = Path(ref['result']); root = p.parent
        assert selected[ref['episode_index']] == str(p)
        assert sha(p) == ref['sha256']
        r = read(p); m = read(root / 'private/manifest.json'); cfg = m['config']
        assert r['complete'] and r['eligible_for_gpt6_score'] and not r['infrastructure_error']
        assert r['mode'] == 'codex' and r['evaluation_setting'] == 'task_icl_v3'
        assert r['task_package_sha256'] == PACKAGE
        assert m['task_id'] == 22 and m['official_policy_budget'] == m['executed_policy_budget'] == 681
        for k, v in {'model':'gpt-6-astra', 'reasoning_effort':'max', 'codex_version':'codex-cli 0.154.0',
                     'generalization_profile':'inv_cov', 'generalization_split':'unseen',
                     'deployment_profile':'calibrated_deployment_v2', 'observation_profile':'baseline_4cam',
                     'seed':100000000, 'inv_cov_seed':200000000, 'decision_timeout_s':None}.items():
            assert cfg[k] == v, (p, k)
        assert cfg['start_episode'] == ref['episode_index'] and cfg['num_episodes'] == 1
        check_hashes(root / 'private/source', m['source_hashes'])
        verify_package(Path(cfg['task_packages']['22']['path']), PACKAGE, 22, cfg)
        private = root / 'episode_0000/private'
        evidence = verify_model_rollouts(private / 'codex-home')
        ev = {e['event_sha256'] for e in evidence}
        exact_invocation(read(private / 'invocation.json')['argv'])
        actions = sorted((private / 'actions').glob('*.json'))
        assert actions
        for action in actions:
            a = read(action)
            assert a['model_evidence'] and all(e['model'] == 'gpt-6-astra' and e['event_sha256'] in ev for e in a['model_evidence'])
        official_path = root / r['official_results_path']
        official = [json.loads(s) for s in official_path.read_text().splitlines() if s.strip()]
        assert len(official) == 1
        o = official[0]
        assert o['episode_index'] == ref['episode_index'] and o['success'] == r['episodes'][0]['official_success']
        assert 0 <= o['latched_stage_completion_rate'] <= 1
        integrity = read(root / 'integrity.json')
        critical = ['result.json', 'private/manifest.json', r['official_results_path'],
                    'episode_0000/private/invocation.json', 'episode_0000/private/prompt.md']
        check_hashes(root, {n: integrity[n] for n in critical})
        episodes.append({**ref, 'success': o['success'], 'termination': o['terminated_reason'],
            'physics_steps': o['steps'], 'control_steps_executed': math.ceil(o['steps'] / 3),
            'official_lscr': o['latched_stage_completion_rate'], 'tokens': r['tokens'], 'timing': r['timing'],
            'model_evidence_records': len(evidence), 'action_chunks_verified': len(actions),
            'source_files_verified': len(m['source_hashes']), 'package_sha256': PACKAGE,
            'manifest_sha256': sha(root / 'private/manifest.json'),
            'official_result_sha256': sha(official_path), 'integrity_manifest_sha256': sha(root / 'integrity.json')})
    prep_root = PILOT / 'preparation'
    prep = read(prep_root / 'preparation.json')
    assert prep['state'] == 'ready' and prep['task_id'] == 22 and prep['package']['sha256'] == PACKAGE
    exact_invocation(prep['argv'])
    verify_model_rollouts(prep_root / 'private/codex-home')
    check_hashes(prep_root / 'private/source', prep['source_hashes'])
    assert sha(PILOT / 'training/manifest.json') == prep['training_manifest_sha256']
    testing_tokens = token_sum([e['tokens'] for e in episodes])
    result = {'state': 'complete', 'task_id': 22, 'valid_episode_count': 10, 'indices': list(range(5, 15)),
        'audited_at': datetime.now(timezone.utc).isoformat(), 'campaign_path': str(ROOT / 'campaign.json'),
        'campaign_sha256': state['plan_sha256'], 'auditor_sha256': sha(Path(__file__)),
        'successes': sum(e['success'] for e in episodes), 'success_rate': sum(e['success'] for e in episodes) / 10,
        'mean_official_lscr': sum(e['official_lscr'] for e in episodes) / 10,
        'episodes': episodes, 'testing_tokens': testing_tokens,
        'testing_tool_inclusive_inference_seconds': sum(e['timing']['policy_inference_wall_seconds'] for e in episodes),
        'testing_sum_episode_wall_seconds': sum(e['timing']['run_wall_seconds'] for e in episodes),
        'testing_calendar_span_seconds': (datetime.fromisoformat(max(all_ends)) - datetime.fromisoformat(min(all_starts))).total_seconds(),
        'extension_calendar_span_seconds': (datetime.fromisoformat(jobs[-1]['ended_at']) - datetime.fromisoformat(jobs[0]['started_at'])).total_seconds(),
        'preparation_count': 1, 'preparation_tokens': prep['tokens'], 'preparation_wall_seconds': prep['wall_seconds'],
        'preparation_tool_inclusive_inference_seconds': prep['inference_tool_wall_seconds'],
        'preparation_path': str(prep_root / 'preparation.json'), 'preparation_sha256': sha(prep_root / 'preparation.json'),
        'invalid_attempts': invalid, 'invalid_attempt_tokens': token_sum([e['tokens'] for e in invalid]),
        'invalid_attempt_tool_inclusive_inference_seconds': sum(e['timing'].get('policy_inference_wall_seconds', 0) for e in invalid),
        'batch_provenance': batches,
        'audit_scope': 'Result, official metrics, invocation, prompt, archived source hashes, frozen package payloads and CLI/action identity reverified. Training manifest hash reverified. Large training/media/trajectory bytes retain their original integrity records, not a full second rehash. No policy/preparation inputs changed.',
        'interpretation': 'Post-outcome extension combining one pilot, six paired ICL episodes and three new tests. Original paired experiment denominator is unchanged. All task22 batches used one simulator worker; the wider campaign admits variable measured concurrency, and task26 historically used three then two. Invalid episode12 service interruption is excluded from scores but retained in costs. Testing token totals are partial lower bounds; cached/reasoning tokens are subsets. Server-only inference time unavailable. Calendar span includes historical gaps and resource/service waits; summed run wall excludes final integrity hashing. Preparation counted once, not per test. Hosted preparation web contamination cannot be ruled out mechanically.'}
    with destination.open('x') as f:
        json.dump(result, f, indent=2); f.write('\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('episodes', 'batch_provenance')}, indent=2))


if __name__ == '__main__':
    main()
