"""Export the fixed 78 evaluation episodes as compact 1x/10x head-view videos.

This is an offline renderer. It reads the saved HDF5 camera streams and never
starts the simulator or changes evaluation results. 10x videos concatenate the
original 1x trajectory and the saved extension trajectory. If no extension
frames exist, the two names are hard links to the same encoded video.
"""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time

import cv2
import h5py
import numpy as np


CAMERA = "cam_stereo_left"
FPS = 20
MIN_FREE_BYTES = 2 * 1024**3
ENCODER = {
    "codec": "libx265",
    "preset": "medium",
    "crf": 18,
    "pixel_format": "yuv420p10le",
    "profile": "Main 10",
}


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        while chunk := source.read(8 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def write_json_atomic(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")
    temporary.replace(path)


def scalar(source, name, default=None):
    if name not in source:
        return default
    value = source[name][()]
    if isinstance(value, bytes):
        return value.decode("utf-8")
    return value.item() if hasattr(value, "item") else value


def decode_frame(raw):
    array = np.asarray(raw)
    if array.ndim == 1 and array.dtype == np.uint8:
        decoded = cv2.imdecode(array, cv2.IMREAD_COLOR)
        if decoded is None:
            raise ValueError("Undecodable JPEG camera frame")
        return decoded
    if array.ndim == 3 and array.shape[2] == 3 and array.dtype == np.uint8:
        return cv2.cvtColor(array, cv2.COLOR_RGB2BGR)
    raise ValueError(f"Unsupported camera frame format: shape={array.shape}, dtype={array.dtype}")


def verified_result(reference, *, extension=False):
    path = Path(reference["path"])
    raw = path.read_bytes()
    actual = hashlib.sha256(raw).hexdigest()
    if actual != reference["sha256"]:
        raise ValueError(f"Result hash mismatch: {path}")
    result = json.loads(raw)
    eligible = result.get("eligible_for_extension_score") if extension else result.get("eligible_for_gpt6_score")
    if not result.get("complete") or not eligible:
        raise ValueError(f"Result is not complete and score-eligible: {path}")
    trajectories = result.get("trajectories") or []
    if len(trajectories) != 1:
        raise ValueError(f"Expected one trajectory in {path}, found {len(trajectories)}")
    trajectory = path.parent / trajectories[0]
    if not trajectory.is_file():
        raise FileNotFoundError(trajectory)
    return result, trajectory


def part_metadata(path, camera):
    stat = path.stat()
    with h5py.File(path, "r") as source:
        count = int(scalar(source, "meta/frame_count", -1))
        if count < 0:
            raise ValueError(f"Missing frame count: {path}")
        fps = float(scalar(source, "meta/fps", FPS))
        if not np.isfinite(fps) or abs(fps - FPS) > 1e-9:
            raise ValueError(f"Unexpected FPS {fps}: {path}")
        key = f"cameras/{camera}/rgb"
        if count == 0:
            if key in source and len(source[key]) != 0:
                raise ValueError(f"Zero-count trajectory has camera frames: {path}")
            resolution = None
        else:
            if key not in source:
                raise ValueError(f"Missing {camera}: {path}")
            frames = source[key]
            if len(frames) != count:
                raise ValueError(f"Frame-count mismatch: {path}")
            first = decode_frame(frames[0])
            resolution = [int(first.shape[1]), int(first.shape[0])]
    return {
        "path": str(path),
        "bytes": stat.st_size,
        "mtime_ns": stat.st_mtime_ns,
        "frames": count,
        "fps": fps,
        "resolution": resolution,
    }


def iter_frames(parts, camera):
    for part in parts:
        if part["frames"] == 0:
            continue
        path = Path(part["path"])
        with h5py.File(path, "r") as source:
            frames = source[f"cameras/{camera}/rgb"]
            for index in range(len(frames)):
                yield decode_frame(frames[index])


def probe_video(path):
    command = [
        "ffprobe", "-v", "error", "-count_frames", "-select_streams", "v:0",
        "-show_entries", "stream=codec_name,profile,pix_fmt,width,height,nb_read_frames,avg_frame_rate,duration",
        "-of", "json", str(path),
    ]
    streams = json.loads(subprocess.check_output(command))["streams"]
    if len(streams) != 1:
        raise ValueError(f"Expected one video stream: {path}")
    return streams[0]


def encode_video(parts, output, camera, label):
    expected = sum(part["frames"] for part in parts)
    if expected < 1:
        raise ValueError(f"No frames for {label}")
    if shutil.disk_usage(output.parent).free < MIN_FREE_BYTES:
        raise RuntimeError("Less than 2 GiB remains on the transfer filesystem")
    resolutions = {tuple(part["resolution"]) for part in parts if part["resolution"] is not None}
    if len(resolutions) != 1:
        raise ValueError(f"Resolution changed across trajectory parts for {label}: {resolutions}")
    width, height = next(iter(resolutions))
    temporary = output.with_name(output.stem + ".partial.mp4")
    temporary.unlink(missing_ok=True)
    command = [
        "ffmpeg", "-nostdin", "-v", "error",
        "-f", "rawvideo", "-pixel_format", "bgr24", "-video_size", f"{width}x{height}",
        "-framerate", str(FPS), "-i", "pipe:0", "-an",
        "-c:v", ENCODER["codec"], "-preset", ENCODER["preset"], "-crf", str(ENCODER["crf"]),
        "-x265-params", "log-level=error", "-pix_fmt", ENCODER["pixel_format"],
        "-tag:v", "hvc1", "-g", str(2 * FPS), "-movflags", "+faststart", "-n", str(temporary),
    ]
    stats_before = [(part["path"], Path(part["path"]).stat().st_size, Path(part["path"]).stat().st_mtime_ns)
                    for part in parts]
    started = time.monotonic()
    count = 0
    with tempfile.TemporaryFile() as errors:
        process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=errors)
        try:
            for frame in iter_frames(parts, camera):
                if frame.shape != (height, width, 3):
                    raise ValueError(f"Resolution changed within {label}: {frame.shape}")
                process.stdin.write(frame.tobytes())
                count += 1
                if count % 2000 == 0:
                    elapsed = time.monotonic() - started
                    print(f"{label}: {count}/{expected} frames ({count / elapsed:.1f} fps)", flush=True)
            process.stdin.close()
            returncode = process.wait()
            if returncode:
                errors.seek(0)
                raise RuntimeError(errors.read().decode("utf-8", errors="replace"))
        except BaseException:
            if process.poll() is None:
                process.terminate()
                process.wait()
            temporary.unlink(missing_ok=True)
            raise
    if count != expected:
        temporary.unlink(missing_ok=True)
        raise ValueError(f"Encoded {count} frames, expected {expected}: {label}")
    for path, size, mtime_ns in stats_before:
        after = Path(path).stat()
        if (after.st_size, after.st_mtime_ns) != (size, mtime_ns):
            temporary.unlink(missing_ok=True)
            raise ValueError(f"Trajectory changed during export: {path}")
    stream = probe_video(temporary)
    if (stream.get("codec_name") != "hevc" or int(stream.get("nb_read_frames", -1)) != expected
            or stream.get("avg_frame_rate") != f"{FPS}/1"
            or int(stream.get("width", -1)) != width or int(stream.get("height", -1)) != height):
        temporary.unlink(missing_ok=True)
        raise ValueError(f"Encoded video verification failed for {label}: {stream}")
    temporary.replace(output)
    elapsed = time.monotonic() - started
    return {
        "path": str(output),
        "bytes": output.stat().st_size,
        "sha256": sha256_file(output),
        "frames": expected,
        "fps": FPS,
        "duration_seconds": expected / FPS,
        "width": width,
        "height": height,
        "codec": stream["codec_name"],
        "profile": stream.get("profile"),
        "pixel_format": stream.get("pix_fmt"),
        "encoding_wall_seconds": elapsed,
        "source_parts": parts,
    }


def write_index(output, records):
    with (output / "index.csv").open("w", newline="") as destination:
        writer = csv.writer(destination)
        writer.writerow(["task_id", "episode_index", "slot", "one_x_video", "one_x_frames",
                         "ten_x_video", "ten_x_frames", "ten_x_reuses_one_x"])
        for record in sorted(records, key=lambda item: item["slot"]):
            writer.writerow([record["task_id"], record["episode_index"], record["slot"],
                             Path(record["one_x"]["path"]).relative_to(output), record["one_x"]["frames"],
                             Path(record["ten_x"]["path"]).relative_to(output), record["ten_x"]["frames"],
                             record["ten_x_reuses_one_x"]])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--slots", help="Optional comma-separated subset for testing/resume")
    args = parser.parse_args()
    cv2.setNumThreads(1)

    report_raw = args.report.read_bytes()
    report = json.loads(report_raw)
    cohort = [row for row in report["episodes"] if row["episode_index"] in (5, 6, 7)]
    if len(cohort) != 78:
        raise ValueError(f"Expected fixed 78-episode cohort, found {len(cohort)}")
    counts = {}
    for row in cohort:
        counts[row["task_id"]] = counts.get(row["task_id"], 0) + 1
    if set(counts.values()) != {3} or len(counts) != 26:
        raise ValueError(f"Cohort is not three episodes for each of 26 tasks: {counts}")
    requested = set(args.slots.split(",")) if args.slots else {row["slot"] for row in cohort}
    unknown = requested - {row["slot"] for row in cohort}
    if unknown:
        raise ValueError(f"Unknown requested slots: {sorted(unknown)}")

    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "1x").mkdir(exist_ok=True)
    (args.output / "10x").mkdir(exist_ok=True)
    manifest_path = args.output / "manifest.json"
    settings = {
        "camera": CAMERA,
        "camera_description": "left front stereo camera used as the head view",
        "fps": FPS,
        "resolution": [640, 480],
        "encoder": ENCODER,
        "no_temporary_images": True,
        "ten_x_definition": "1x saved trajectory followed by the saved extension trajectory",
    }
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text())
        if manifest["source_report"]["sha256"] != hashlib.sha256(report_raw).hexdigest() or manifest["settings"] != settings:
            raise ValueError("Existing output manifest uses different inputs or settings")
    else:
        manifest = {
            "schema": 1,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat(),
            "state": "exporting",
            "source_report": {"path": str(args.report), "sha256": hashlib.sha256(report_raw).hexdigest()},
            "cohort": "26 tasks x episode indices 05-07 = 78 episodes",
            "settings": settings,
            "records": [],
        }
        write_json_atomic(manifest_path, manifest)
    completed = {record["slot"]: record for record in manifest["records"]}

    for row in sorted(cohort, key=lambda item: item["slot"]):
        slot = row["slot"]
        if slot not in requested:
            continue
        if slot in completed:
            one = Path(completed[slot]["one_x"]["path"])
            ten = Path(completed[slot]["ten_x"]["path"])
            if not one.is_file() or not ten.is_file():
                raise FileNotFoundError(f"Manifest output missing for {slot}")
            print(f"{slot}: already complete", flush=True)
            continue
        one_result, one_trajectory = verified_result(row["source_1x_result"], extension=False)
        one_part = part_metadata(one_trajectory, CAMERA)
        extension_parts = []
        if row["selected_10x_result"] is not None:
            _, extension_trajectory = verified_result(row["selected_10x_result"], extension=True)
            extension_parts.append(part_metadata(extension_trajectory, CAMERA))
        one_path = args.output / "1x" / f"task_{row['task_id']:02d}_episode_{row['episode_index']:02d}_headview_1x.mp4"
        ten_path = args.output / "10x" / f"task_{row['task_id']:02d}_episode_{row['episode_index']:02d}_headview_10x.mp4"
        if one_path.exists() or ten_path.exists():
            raise FileExistsError(f"Untracked output already exists for {slot}")
        print(f"{slot}: encoding 1x ({one_part['frames']} frames)", flush=True)
        one_video = encode_video([one_part], one_path, CAMERA, f"{slot} 1x")
        extension_frames = sum(part["frames"] for part in extension_parts)
        if extension_frames == 0:
            os.link(one_path, ten_path)
            ten_video = dict(one_video)
            ten_video["path"] = str(ten_path)
            ten_video["source_parts"] = [one_part, *extension_parts]
            reused = True
            print(f"{slot}: 10x has no additional frames; hard-linked to 1x", flush=True)
        else:
            print(f"{slot}: encoding 10x ({one_part['frames'] + extension_frames} frames)", flush=True)
            ten_video = encode_video([one_part, *extension_parts], ten_path, CAMERA, f"{slot} 10x")
            reused = False
        record = {
            "slot": slot,
            "task_id": row["task_id"],
            "episode_index": row["episode_index"],
            "official_1x_success": bool(one_result["episodes"][0]["official_success"]),
            "official_10x_success": bool(row["official_10x_success"]),
            "one_x": one_video,
            "ten_x": ten_video,
            "ten_x_reuses_one_x": reused,
        }
        manifest["records"].append(record)
        manifest["records"].sort(key=lambda item: item["slot"])
        manifest["updated_at"] = datetime.now(timezone.utc).isoformat()
        manifest["state"] = "complete" if len(manifest["records"]) == 78 else "exporting"
        write_json_atomic(manifest_path, manifest)
        write_index(args.output, manifest["records"])
        print(f"{slot}: pair complete ({len(manifest['records'])}/78)", flush=True)

    if len(manifest["records"]) == 78:
        checksums = []
        for path in sorted((*list((args.output / "1x").glob("*.mp4")), *list((args.output / "10x").glob("*.mp4")))):
            checksums.append(f"{sha256_file(path)}  {path.relative_to(args.output)}")
        (args.output / "SHA256SUMS").write_text("\n".join(checksums) + "\n")
        apparent = sum(path.stat().st_size for path in args.output.rglob("*.mp4"))
        allocated = int(subprocess.check_output(["du", "-s", "--block-size=1", str(args.output)]).split()[0])
        manifest["state"] = "complete"
        manifest["completed_at"] = datetime.now(timezone.utc).isoformat()
        manifest["video_files"] = 156
        manifest["hard_linked_10x_files"] = sum(record["ten_x_reuses_one_x"] for record in manifest["records"])
        manifest["apparent_video_bytes"] = apparent
        manifest["allocated_output_bytes"] = allocated
        write_json_atomic(manifest_path, manifest)
        (args.output / "README.md").write_text(
            "# Bench2Dex fixed 78-episode head-view videos\n\n"
            "This directory contains 1x and 10x MP4 videos for episode indices 05-07 of all 26 tasks.\n"
            "The head view is `cam_stereo_left`, exported at the recorded 640x480 resolution and 20 fps.\n"
            "Videos use 10-bit H.265/HEVC (`hvc1`) at CRF 18. No intermediate PNGs were created.\n"
            "A 10x video is the original 1x trajectory followed by its saved extension trajectory.\n"
            "When no extension frames were executed, its 1x and 10x filenames are hard links to identical bytes.\n"
            "Use a copy method that preserves hard links (for example `rsync -aH`) to retain the space saving.\n"
            "See `manifest.json`, `index.csv`, and `SHA256SUMS` for provenance and verification.\n"
        )
        print(f"Complete: {args.output}", flush=True)
    else:
        print(f"Subset complete; full manifest remains {manifest['state']}: {args.output}", flush=True)


if __name__ == "__main__":
    main()
