"""Host-only final audit; never expose this report to preparation or policy."""
import argparse
import json
import hashlib
import math
from pathlib import Path
from datetime import datetime
from gpt6_eval.core import verify_model_rollouts
from gpt6_eval.knowledge import verify_package

BASE = Path('runs')
ROOT = BASE / 'task26_icl_twenty_20260923_01'
PACKAGE = 'd3ae8ddaa9c45728b25f11ea95e2018e4561625e81316dd1f2eadd66da06d7f1'

def read(p):
    return json.loads(p.read_text())

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def token_sum(rows):
    keys = ('input_tokens', 'cached_input_tokens', 'output_tokens', 'reasoning_output_tokens', 'total_tokens')
    return {**{k: sum(r.get(k, 0) for r in rows) for k in keys},
            'status': 'complete' if all(r.get('status') == 'complete' for r in rows) else 'partial',
            'complete_reports': sum(r.get('status') == 'complete' for r in rows), 'reports': len(rows)}

def main():
    global ROOT, BASE
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    ROOT = parser.parse_args().root.resolve()
    BASE = ROOT.parent
    cohort = read(ROOT / 'cohort.json')
    assert cohort['state'] == 'completed'
    refs = cohort['valid_episodes']
    assert sorted(r['episode_index'] for r in refs) == list(range(5, 25))
    for ref in cohort['inherited_episodes']:
        assert sha(Path(ref['result'])) == ref['sha256']
    batch_paths = [BASE/'task26_icl_six_20260923_01/evaluation/result.json',
                   BASE/'task26_icl_additional7_20260923_01/evaluation/result.json']
    batch_paths += [Path(a['output'])/'result.json' for a in cohort['attempts']]
    selected, invalid, batches = {}, [], []
    for p in batch_paths:
        batch = read(p)
        batches.append({'path': str(p), 'sha256': sha(p), 'started_at': batch['started_at'],
                        'wall_seconds': batch['batch_wall_seconds']})
        for row in batch['episodes']:
            if row['valid']:
                idx = row['upstream_episode_index']
                assert idx not in selected, ('duplicate valid index', idx)
                selected[idx] = str(p.parent/row['directory']/'result.json')
            else:
                result = row.get('result') or {}
                invalid.append({'episode_index': row['upstream_episode_index'],
                    'directory': str(p.parent/row['directory']), 'returncode': row['returncode'],
                    'infrastructure_error': result.get('infrastructure_error'),
                    'tokens': result.get('tokens', {'status': 'unavailable'}),
                    'timing': result.get('timing', {}),
                    'wall_seconds_including_finalization': (datetime.fromisoformat(row['ended_at'])-datetime.fromisoformat(row['started_at'])).total_seconds() if row.get('ended_at') else None})
    assert sorted(selected) == list(range(5, 25))
    episodes, reports = [], []
    for ref in refs:
        p = Path(ref['result']); root = p.parent
        assert selected[ref['episode_index']] == str(p)
        assert sha(p) == ref['sha256']
        r = read(p); m = read(root/'private/manifest.json'); cfg = m['config']
        assert r['complete'] and r['eligible_for_gpt6_score'] and not r['infrastructure_error']
        assert r['task_package_sha256'] == PACKAGE and r['evaluation_setting'] == 'task_icl_v3'
        assert m['task_id'] == 26 and m['official_policy_budget'] == m['executed_policy_budget'] == 871
        for k, v in {'model':'gpt-6-astra','reasoning_effort':'max','codex_version':'codex-cli 0.154.0',
                     'generalization_profile':'inv_cov','generalization_split':'unseen',
                     'deployment_profile':'calibrated_deployment_v2','observation_profile':'baseline_4cam',
                     'seed':100000000,'inv_cov_seed':200000000,'decision_timeout_s':None}.items():
            assert cfg[k] == v, (p,k)
        assert cfg['start_episode'] == ref['episode_index'] and cfg['num_episodes'] == 1
        for name, digest in m['source_hashes'].items():
            assert sha(root/'private/source'/name) == digest, (p,name)
        pkg = cfg['task_packages']['26']
        verify_package(Path(pkg['path']), PACKAGE, 26, cfg)
        private = root/'episode_0000/private'
        evidence = verify_model_rollouts(private/'codex-home')
        ev = {e['event_sha256'] for e in evidence}
        invocation = read(private/'invocation.json')['argv']
        assert invocation[invocation.index('--model')+1] == 'gpt-6-astra'
        assert 'model_reasoning_effort="max"' in invocation
        actions = sorted((private/'actions').glob('*.json'))
        assert actions
        for action in actions:
            a = read(action)
            assert a['model_evidence'] and all(e['model']=='gpt-6-astra' and e['event_sha256'] in ev for e in a['model_evidence'])
        official_path = root/r['official_results_path']
        official = [json.loads(s) for s in official_path.read_text().splitlines() if s.strip()]
        assert len(official)==1
        o = official[0]
        assert o['episode_index']==ref['episode_index'] and o['success']==r['episodes'][0]['official_success']
        integrity = read(root/'integrity.json')
        # Recheck audit-critical archived bytes. Large RGB/trajectory blobs retain
        # original finalization hashes; no claim of full second media rehash.
        critical = ['result.json','private/manifest.json',r['official_results_path'],
                    'episode_0000/private/invocation.json','episode_0000/private/prompt.md']
        for name in critical:
            assert sha(root/name)==integrity[name], (p,name)
        episodes.append({**ref,'success':o['success'],'termination':o['terminated_reason'],
            'physics_steps':o['steps'],'control_steps_executed':math.ceil(o['steps']/3),
            'official_lscr':o['latched_stage_completion_rate'],
            'model_evidence_records':len(evidence),'action_chunks_verified':len(actions),
            'source_files_verified':len(m['source_hashes']),'manifest_sha256':sha(root/'private/manifest.json'),
            'official_result_sha256':sha(official_path),'integrity_manifest_sha256':sha(root/'integrity.json'),
            'package_sha256':PACKAGE,'tokens':r['tokens'],'timing':r['timing']})
        reports.append(r)
    prep_root = BASE/'task26_icl_six_20260923_01/preparation'
    prep = read(prep_root/'preparation.json')
    prepared = read(prep_root/'frozen/manifest.json')
    result = {'state':'complete','task_id':26,'valid_episode_count':20,'indices':list(range(5,25)),
        'successes':sum(e['success'] for e in episodes),
        'success_rate':sum(e['success'] for e in episodes)/20,
        'mean_official_lscr':sum(e['official_lscr'] for e in episodes)/20,
        'episodes':episodes,'testing_tokens':token_sum([r['tokens'] for r in reports]),
        'testing_tool_inclusive_inference_seconds':sum(r['timing']['policy_inference_wall_seconds'] for r in reports),
        'testing_sum_episode_wall_seconds':sum(r['timing']['run_wall_seconds'] for r in reports),
        'extension_elapsed_wall_seconds':(datetime.fromisoformat(cohort['updated_at'])-datetime.fromisoformat(cohort['created_at'])).total_seconds(),
        'testing_calendar_span_seconds':(datetime.fromisoformat(cohort['updated_at'])-datetime.fromisoformat(batches[0]['started_at'])).total_seconds(),
        'preparation_count':1,'preparation_tokens':prep['tokens'],'preparation_wall_seconds':prep['wall_seconds'],
        'preparation_tool_inclusive_inference_seconds':prepared['preparation_inference_tool_wall_seconds'],
        'invalid_attempts':invalid,'invalid_attempt_tokens':token_sum([r['tokens'] for r in invalid]),
        'invalid_attempt_tool_inclusive_inference_seconds':sum(r['timing'].get('policy_inference_wall_seconds',0) for r in invalid),
        'batch_provenance':batches,'cohort_sha256':sha(ROOT/'cohort.json'),
        'audit_scope':'Result, metric, invocation, prompt and frozen source hashes rechecked; package payloads and CLI/action model evidence verified. Media retains original integrity manifests, not rehashed in this final audit.',
        'interpretation':'Post-outcome extension, not preregistered twenty samples; inherited six ran with three workers, later fourteen with at most two. Infrastructure retries/cancellations excluded from policy denominator but costs retained. Testing tokens may be lower bounds; server-only inference time unavailable.'}
    destination = ROOT/'cohort_result.json'
    with destination.open('x') as f:
        json.dump(result,f,indent=2); f.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('episodes','batch_provenance')}))

if __name__=='__main__':
    main()
