"""Install a versioned, host-only resource-query timeout repair while stopped.

Does not launch evaluation or modify the old frozen snapshot/results/package.
"""
import argparse
import difflib
import fcntl
import json
from pathlib import Path
import shutil

from run_task26_twenty import collect, digest, now, read, verify_snapshot, write


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--validation-log', type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    project = Path(__file__).resolve().parents[1]
    validation = args.validation_log.read_text()
    if 'Ran 116 tests in ' not in validation or not validation.rstrip().endswith('OK'):
        raise ValueError('Expected successful full 116-test validation log')
    version_name = 'repairs/resource_query_v2'
    version = output / version_name
    with (output / 'supervisor.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        report = read(output / 'cohort.json')
        if (report['state'] != 'needs_repair' or report.get('active_pid')
                or not report.get('error', '').startswith('TimeoutExpired:')
                or 'nvidia-smi' not in report['error']):
            raise ValueError('Expected stopped GPU-query timeout without active child')
        old = output / report.get('snapshot_directory', '.')
        verify_snapshot(output, report, old / 'supervisor.py')
        refs = collect(report)
        if sorted(refs) != list(range(5, 17)):
            raise ValueError('Expected preserved valid indices 5–16')
        version.mkdir(parents=True, exist_ok=False)
        for name in ('cohort.json', 'resource_wait.json'):
            shutil.copyfile(output / name, version / ('before_' + name))
        shutil.copyfile(Path(str(output) + '.launch.log'), version / 'before_launch.log')
        shutil.copytree(old / 'runner', version / 'runner')
        changed = 'src/gpt6_eval/resource_wait.py'
        shutil.copyfile(project / changed, version / 'runner' / changed)
        shutil.copyfile(project / 'scripts/run_task26_twenty.py', version / 'supervisor.py')
        shutil.copyfile(__file__, version / 'install_repair.py')
        shutil.copyfile(project / 'tests/test_twenty_recovery.py', version / 'regression_tests.py')
        shutil.copyfile(args.validation_log, version / 'regression.log')
        hashes = {name: digest(version / 'runner' / name) for name in report['source_hashes']}
        if {name for name in hashes if hashes[name] != report['source_hashes'][name]} != {changed}:
            raise ValueError('Unexpected runner changes')
        patch = []
        for before, after in ((old / 'runner' / changed, version / 'runner' / changed),
                              (old / 'supervisor.py', version / 'supervisor.py')):
            patch.extend(difflib.unified_diff(before.read_text().splitlines(True),
                         after.read_text().splitlines(True), fromfile=str(before), tofile=str(after)))
        (version / 'repair.diff').write_text(''.join(patch))
        repair = {'created_at': now(), 'reason': report['error'],
                  'snapshot_directory': version_name,
                  'previous_snapshot_directory': report.get('snapshot_directory', '.'),
                  'previous_source_hashes': report['source_hashes'],
                  'source_hashes': hashes,
                  'previous_supervisor_sha256': report['supervisor_sha256'],
                  'supervisor_sha256': digest(version / 'supervisor.py'),
                  'unchanged_completed_indices': sorted(refs),
                  'prior_attempt_outputs': [a['output'] for a in report['attempts']],
                  'policy_config_package_metrics_changed': False,
                  'regression_tests': '116 host tests passed, including 10 recovery tests',
                  'regression_log_sha256': digest(version / 'regression.log'),
                  'prior_validation_note': 'Earlier full-suite run on memory-starved host encountered an RPC test error; no deployment occurred then. Fresh full-suite output is archived here.'}
        write(version / 'repair.json', repair)
        report.setdefault('repairs', []).append(repair)
        report.update(snapshot_directory=version_name, source_hashes=hashes,
                      supervisor_sha256=repair['supervisor_sha256'])
        verify_snapshot(output, report, version / 'supervisor.py')
        write(output / 'cohort.json', report)
        print(json.dumps({'snapshot': str(version), 'preserved_valid_indices': sorted(refs)}))


if __name__ == '__main__':
    main()
