"""One-time supervisor-only fix for CPU research during GPU unavailability."""
import fcntl
import hashlib
import importlib.util
import json
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
from datetime import datetime, timezone


def main():
    root = Path(sys.argv[1]).resolve()
    audit = root/'repairs/offline_overlap_v5_20260928'
    read = lambda p: json.loads(Path(p).read_text())
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    info = read(audit/'new_snapshot.json'); snap = root/info['snapshot']
    spec = importlib.util.spec_from_file_location('overlap_supervisor', snap/'supervisor.py')
    host = importlib.util.module_from_spec(spec); spec.loader.exec_module(host)
    sys.path.insert(0, str(snap/'runner/src'))
    from gpt6_eval.knowledge import verify_package
    with (root/'supervisor.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        state = read(root/'state.json'); before = read(audit/'state.before.json')
        plan = read(root/'campaign.json'); request = read(audit/'request.json')
        if (state['state'] != 'stopped_by_request' or state['snapshot'] != 'snapshots/v4_trusted_reader'
                or state.get('error') != f'evaluation exited 1: {root}/task_12/0055_evaluation'):
            raise ValueError('Unexpected state/error; do not overwrite')
        if any(not j.get('ended_at') for j in state['jobs']):
            raise ValueError('Undrained jobs')
        for pid in (before['supervisor_pid'], state['jobs'][55]['pid'], request['worker_pid']):
            if Path(f'/proc/{pid}').exists(): raise ValueError('Old process still exists')
        if sha(root/'campaign.json') != before['plan_sha256'] or state['plan_sha256'] != before['plan_sha256']:
            raise ValueError('Plan changed')
        if info['source_hashes'] != state['source_hashes'] or info['base_config_sha256'] != state['base_config_sha256']:
            raise ValueError('Runner/config must be unchanged')
        for snapshot in (root/state['snapshot'], snap):
            for name, expected in info['source_hashes'].items():
                if sha(snapshot/'runner'/name) != expected: raise ValueError('Runner changed: '+name)
            if sha(snapshot/'base_config.json') != state['base_config_sha256']:
                raise ValueError('Base config changed')
        if sha(snap/'supervisor.py') != info['supervisor_sha256']:
            raise ValueError('Scheduler changed')
        if not (audit/'scheduler_tests.log').read_text().rstrip().endswith('OK'):
            raise ValueError('Scheduler tests failed')
        if not request['no_simulator_started'] or not request['no_model_session']:
            raise ValueError('Wait-only cancellation not established')
        attempt = Path(state['jobs'][55]['output'])/'episode_0000'
        if (attempt/'private/startup_started.json').exists() or list((attempt/'private').glob('**/sessions/**/*.jsonl')):
            raise ValueError('Scored execution began in canceled attempt')
        cfg = read(snap/'base_config.json'); results = []; packages = []
        for key, task in state['tasks'].items():
            old = before['tasks'][key]
            if task.get('package') != old.get('package') or task['target_valid_count'] != old['target_valid_count']:
                raise ValueError('Existing package or count changed')
            if task.get('package'):
                ref = task['package']; verify_package(Path(ref['path']), ref['sha256'], task['task_id'], cfg)
                checked = host.collect(task)
                if checked != host.collect(old): raise ValueError('Completed outcomes changed')
                results.extend(checked.values()); packages.append({'task_id': task['task_id'], **ref})
        prerequisite = Path(plan['prerequisite_cohort']).with_name('cohort_result.json')
        if sha(prerequisite) != state['prerequisite_result_sha256']:
            raise ValueError('Task26 result changed')
        shutil.copyfile(root/'state.json', audit/'state.before_activation.json')
        at = datetime.now(timezone.utc).isoformat()
        validation = {'state':'passed', 'at':at, 'snapshot':info['snapshot'],
                      'runner_prompts_and_configs_byte_identical_to_v4':True,
                      'scheduler_tests':13, 'completed_campaign_results_verified':len(results),
                      'packages_verified':packages, 'task26_result_unchanged':True,
                      'canceled_pre_simulator_wait_job':55, 'canceled_model_calls':0,
                      'evidence_sha256':{n:sha(audit/n) for n in ('scheduler_tests.log','test_campaign.py','supervisor.diff','request.json')},
                      'activation_script_sha256':sha(__file__)}
        host.write(audit/'validation.json', validation)
        for jobs in (state['jobs'], state['tasks']['12']['jobs']):
            for job in jobs:
                if job['id']==55:
                    job['recovery']='User-authorized scheduler transition; interrupted GPU wait before simulator/model; retain attempt and retry same index'
        state.update(**info, state='running', error=None, updated_at=at,
                     offline_overlap_validation=str(audit/'validation.json'))
        host.write(root/'state.json', state)
        request.update(state='validated_and_released', released_at=at)
        host.write(audit/'request.json', request)
        host.write(audit/'activation.json', {'state':'released', 'at':at, 'snapshot':info['snapshot']})
    command=[plan['runtime']['python'],'-u',str(snap/'supervisor.py'),'--output',str(root)]
    shell='exec '+shlex.join(command)+' >> '+shlex.quote(str(root/'supervisor.log'))+' 2>&1'
    subprocess.run(['tmux','new-session','-d','-s','bench2dex-all-icl10',shell],check=True)
    print('Released CPU exploration independently of GPU readiness')


if __name__ == '__main__': main()
