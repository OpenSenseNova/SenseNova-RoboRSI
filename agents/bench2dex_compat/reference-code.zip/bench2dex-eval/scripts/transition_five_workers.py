"""Wait for the unchanged current jobs, activate9GiB/max5, observe first five-smoke.

Only the scheduler and trusted host resource instrumentation change. A task's
five-worker scored wave remains gated on its measured, successful residency smoke.
"""
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone


def read(path): return json.loads(Path(path).read_text())
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def now(): return datetime.now(timezone.utc).isoformat()
def write(path, value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)


def validate_sources(root, audit, state, info):
    snap=root/info['snapshot'];old=root/state['snapshot']
    if sha(root/'campaign.json') != state['plan_sha256']:
        raise ValueError('Plan changed')
    for version, hashes in ((old,state['source_hashes']),(snap,info['source_hashes'])):
        for name, expected in hashes.items():
            if sha(version/'runner'/name) != expected:
                raise ValueError('Frozen source changed: '+name)
    if sha(snap/'supervisor.py') != info['supervisor_sha256']:
        raise ValueError('Supervisor changed')
    if sha(snap/'base_config.json') != state['base_config_sha256'] or info['base_config_sha256'] != state['base_config_sha256']:
        raise ValueError('Experimental config changed')
    allowed={'src/gpt6_eval/batch.py','src/gpt6_eval/resource_wait.py'}
    for name in set(state['source_hashes']) | set(info['source_hashes']):
        if name.startswith(('src/','prompts/','configs/')) and name not in allowed:
            if state['source_hashes'].get(name) != info['source_hashes'].get(name):
                raise ValueError('Unapproved experimental change: '+name)
    for name in ('targeted_tests.log','regression.log'):
        if not (audit/name).read_text().rstrip().endswith('OK'):
            raise ValueError('Host validation failed: '+name)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args();root=args.root.resolve();audit=root/'repairs/five_workers_v6_20260928'
    info=read(audit/'new_snapshot.json');before=read(audit/'state.before.json')
    snap=root/info['snapshot'];state=read(root/'state.json')
    validate_sources(root,audit,state,info)
    if args.check:
        print('Source/config/model-input invariance and host tests passed; no mutation')
        return
    worker_lock=(audit/'transition.lock').open('a')
    fcntl.flock(worker_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    def status(phase, **fields):
        write(audit/'transition_status.json',{'state':phase,'at':now(),'pid':os.getpid(),**fields})
    try:
        while True:
            state=read(root/'state.json')
            if state['snapshot'] != before['snapshot']:
                raise ValueError('Another transition changed the campaign')
            if state.get('error'):
                raise ValueError('Current job failed; preserve and diagnose: '+state['error'])
            active=[j for j in state['jobs'] if not j.get('ended_at')]
            if not active and state['state']=='stopped_by_request' and not Path(f'/proc/{before["supervisor_pid"]}').exists():
                break
            status('waiting_for_current_jobs',jobs=[{'id':j['id'],'stage':j['stage'],'task':j['task_id']} for j in active])
            time.sleep(10)
        with (root/'supervisor.lock').open('a') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            state=read(root/'state.json')
            if state['state']!='stopped_by_request' or state.get('error') or any(not j.get('ended_at') for j in state['jobs']):
                raise ValueError('Campaign not cleanly drained')
            validate_sources(root,audit,state,info)
            if state['plan_sha256']!=before['plan_sha256']:
                raise ValueError('Plan changed during drain')
            for j in before['jobs']:
                if not j.get('ended_at') and Path(f'/proc/{j["pid"]}').exists():
                    raise ValueError('Old child still exists')
            sys.path.insert(0,str(snap/'runner/src'))
            from gpt6_eval.knowledge import verify_package
            spec=importlib.util.spec_from_file_location('five_supervisor',snap/'supervisor.py')
            host=importlib.util.module_from_spec(spec);spec.loader.exec_module(host)
            if host.WORKER_MIB!=9216 or host.MAX_WORKERS!=5:
                raise ValueError('Incorrect requested worker profile')
            cfg=read(snap/'base_config.json');packages=[];outcomes=[]
            for key,task in state['tasks'].items():
                old=before['tasks'][key]
                if task['target_valid_count']!=old['target_valid_count'] or task['new_episode_indices']!=old['new_episode_indices']:
                    raise ValueError('Episode plan changed')
                if old.get('package') and task.get('package')!=old['package']:
                    raise ValueError('Existing package changed')
                if task.get('package'):
                    ref=task['package'];verify_package(Path(ref['path']),ref['sha256'],task['task_id'],cfg)
                    current=host.collect(task)
                    previous=host.collect(old) if old.get('package') else {}
                    if any(current.get(index)!=value for index,value in previous.items()):
                        raise ValueError('Existing valid outcome changed')
                    outcomes.extend(current.values());packages.append({'task_id':task['task_id'],**ref})
            plan=read(root/'campaign.json')
            prerequisite=Path(plan['prerequisite_cohort']).with_name('cohort_result.json')
            if sha(prerequisite)!=state['prerequisite_result_sha256']:
                raise ValueError('Task26 result changed')
            shutil.copyfile(root/'state.json',audit/'state.before_activation.json')
            validation={'state':'host_checks_passed_five_gpu_smoke_pending','at':now(),
                'snapshot':info['snapshot'],'worker_gpu_mib':9216,'worker_ram_mib':9216,
                'max_workers':5,'offline_ram_mib':8192,'os_ram_mib':4096,
                'completed_campaign_results_verified':len(outcomes),'packages_verified':packages,
                'episode_counts_unchanged':True,'current_jobs_finished_without_interruption':True,
                'evidence_sha256':{n:sha(audit/n) for n in ('targeted_tests.log','regression.log','implementation.diff')},
                'transition_script_sha256':sha(__file__)}
            write(audit/'validation.json',validation)
            state.update(**info,state='running',error=None,updated_at=now(),
                five_worker_validation=str(audit/'validation.json'),
                worker_profile={'gpu_mib':9216,'ram_mib':9216,'max_workers':5})
            write(root/'state.json',state)
            request=read(audit/'request.json');request.update(state='activated_pending_five_worker_smoke',activated_at=now())
            write(audit/'request.json',request)
            write(audit/'activation.json',{'at':now(),'snapshot':info['snapshot'],'state':'activated_five_smoke_pending'})
        command=[plan['runtime']['python'],'-u',str(snap/'supervisor.py'),'--output',str(root)]
        shell='exec '+shlex.join(command)+' >> '+shlex.quote(str(root/'supervisor.log'))+' 2>&1'
        subprocess.run(['tmux','new-session','-d','-s','bench2dex-all-icl10',shell],check=True)
        print('Five-worker profile activated; scored five-worker waves remain smoke-gated',flush=True)
        while True:
            state=read(root/'state.json')
            if state.get('error'):
                raise ValueError('Campaign requires diagnosis: '+state['error'])
            smokes=[j for j in state['jobs'] if j['stage']=='smoke' and j['workers']==5 and j['snapshot']==info['snapshot']]
            for j in smokes:
                if j.get('ended_at') and j.get('returncode')==0:
                    host.successful('smoke',j['output'])
                    p=Path(j['output']);memory=read(p/'startup/wave_0000.memory.json')
                    passed={'at':now(),'state':'passed','job':j['id'],'task':j['task_id'],
                        'output':str(p),'resident_workers':5,
                        'peak_sampled_gpu_used_mib':memory['peak_gpu_used_mib'],
                        'min_sampled_gpu_free_mib':memory['min_gpu_free_mib'],
                        'min_sampled_ram_available_mib':memory['min_ram_available_mib'],
                        'samples':len(memory['samples']),
                        'result_sha256':sha(p/'result.json'),'memory_sha256':sha(p/'startup/wave_0000.memory.json')}
                    write(audit/'five_worker_residency.json',passed)
                    status('complete',**{'five_worker_validation':passed})
                    print(json.dumps(passed),flush=True)
                    return
            status('awaiting_five_worker_residency',smoke_jobs=[j['id'] for j in smokes])
            time.sleep(10)
    except BaseException as exc:
        status('needs_attention',error=f'{type(exc).__name__}: {exc}')
        raise


if __name__=='__main__':main()
