#!/usr/bin/env bash
set -euo pipefail
eval_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
: "${ISAACLAB_PYTHON:?Set ISAACLAB_PYTHON to the installed IsaacLab Python}"
export PYTHONPATH="$eval_root/src${PYTHONPATH:+:$PYTHONPATH}"
assets="${BENCH2DEX_ASSETS:-$eval_root/../dex2bench_dataset}"
if [[ ! -x "$ISAACLAB_PYTHON" || ! -d "$assets" ]]; then
  echo 'Runtime or assets unavailable. Check the data disk mount before launching.' >&2
  exit 1
fi
exec "${EVAL_PYTHON:-python3}" -u -m gpt6_eval.suite \
  --plan "${BENCH2DEX_SUITE_PLAN:-$eval_root/configs/results_first11_six_workers.json}" \
  --config "$eval_root/configs/results_first11_two_samples.json" \
  --upstream "${BENCH2DEX_ROOT:-$eval_root/../Bench2Dex}" \
  --isaaclab "${ISAACLAB_ROOT:-$eval_root/../IsaacLab}" \
  --assets "$assets" --python "$ISAACLAB_PYTHON" \
  --inventory "${BENCH2DEX_ASSET_INVENTORY:-$assets/.download_logs/all_tasks/selection.inventory.json}" \
  "$@"
