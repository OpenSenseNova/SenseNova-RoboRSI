"""Host-only, immutable-attempt campaign; rolling GPU pool plus offline work.

Unknown faults drain existing children and stop for heartbeat diagnosis. No
policy changes, valid failure retries, sample replacement or inference deadline.
"""
import argparse
import difflib
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone

WORKER_MIB = 9216
MAX_WORKERS = 5
PREPARATION_MIB = 4096
TRAINING_MIB = 8192
MAX_PREPARATIONS = 2

def now():
    return datetime.now(timezone.utc).isoformat()

def read(p):
    return json.loads(Path(p).read_text())

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def write(p, value):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n'); tmp.replace(p)

def eligible(path, index, package):
    r = read(path)
    if (not r.get('complete') or not r.get('eligible_for_gpt6_score') or r.get('infrastructure_error')
        or r.get('evaluation_setting') != 'task_icl_v3' or r.get('task_package_sha256') != package
        or [e['episode_index'] for e in r['episodes']] != [index]):
        raise ValueError('Invalid result identity: '+str(path))
    return {'episode_index':index,'result':str(path),'sha256':sha(path)}

def collect(task):
    refs = {e['episode_index']:e for e in task.get('inherited', [])}
    if len(refs) != len(task.get('inherited', [])):
        raise ValueError('Duplicate inherited result')
    for attempt in task['jobs']:
        if attempt['stage'] != 'evaluation' or not attempt.get('ended_at'):
            continue
        path = Path(attempt['output'])/'result.json'
        if not path.exists():
            continue
        for row in read(path)['episodes']:
            if row.get('valid'):
                idx = row['upstream_episode_index']
                ref = eligible(path.parent/row['directory']/'result.json', idx, task['package']['sha256'])
                if idx in refs:
                    raise ValueError('Duplicate valid index')
                refs[idx] = ref
    allowed = set(task['new_episode_indices']) | {e['episode_index'] for e in task.get('inherited', [])}
    if not set(refs) <= allowed:
        raise ValueError('Unplanned result')
    for idx, ref in refs.items():
        if sha(ref['result']) != ref['sha256']:
            raise ValueError('Completed result changed')
        eligible(ref['result'], idx, task['package']['sha256'])
    return refs

def next_indices(task, n, live_gpu_jobs=()):
    if n < 1:
        return []
    done = collect(task)
    # Even reaped rows in an unfinished batch remain owned by that batch until
    # collect can validate it. Never launch the same index twice across batches.
    admitted = {i for j in live_gpu_jobs if j['task_id'] == task['task_id']
                for i in (j.get('indices') or [])}
    pending = [i for i in task['new_episode_indices'] if i not in done and i not in admitted]
    wave = []
    for i in pending:
        if len(wave) == n or (wave and i != wave[-1]+1):
            break
        wave.append(i)
    return wave

def validate_deferrals(root, tasks):
    """Scheduling-only holds require a hashed, task-specific user authorization."""
    for task in tasks.values():
        if 'scheduling_deferral' not in task:
            continue
        ref = task['scheduling_deferral']
        if not isinstance(ref, dict) or set(ref) != {'path', 'sha256'}:
            raise ValueError('Malformed scheduling deferral')
        path = Path(root)/ref['path']
        if sha(path) != ref['sha256']:
            raise ValueError('Deferral authorization changed')
        receipt = read(path)
        if (receipt.get('state') != 'user_authorized_deferral'
                or receipt.get('task_id') != task['task_id']
                or receipt.get('target_valid_count') != task['target_valid_count']
                or receipt.get('new_episode_indices') != task['new_episode_indices']
                or receipt.get('preserve_protocol_gates') is not True):
            raise ValueError('Deferral does not preserve task plan and protocol')

def admission_tasks(tasks, priority):
    """Do not remove deferred tasks or their outcomes from the campaign."""
    return [tasks[str(tid)] for tid in priority
            if 'scheduling_deferral' not in tasks[str(tid)]]

def scoped_admission_tasks(tasks, priority, only_task):
    selected = admission_tasks(tasks, priority)
    return selected if only_task is None else [t for t in selected if t['task_id'] == only_task]

def scoped_terminal_state(tasks, only_task):
    if only_task is not None:
        task = tasks[str(only_task)]
        if len(task.get('valid_episodes', [])) == task['target_valid_count']:
            return 'paused_after_scoped_task'
        return None
    return terminal_state(tasks)

def terminal_state(tasks):
    if all(t.get('state') == 'complete_pending_final_audit' for t in tasks.values()):
        return 'complete_pending_final_audit'
    if all(t.get('state') == 'complete_pending_final_audit'
           or 'scheduling_deferral' in t for t in tasks.values()):
        return 'blocked_on_deferred_tasks'
    return None

def task51_training_options(root, state, task):
    """Only the explicitly approved task-specific legacy-data condition can opt in."""
    ref = state.get('task51_legacy_provenance_authorization')
    if task['task_id'] != 51 or ref is None:
        return []
    if not isinstance(ref, dict) or set(ref) != {'path', 'sha256'}:
        raise ValueError('Malformed Task51 exception authorization')
    path = Path(root)/ref['path']
    if sha(path) != ref['sha256']:
        raise ValueError('Task51 exception authorization changed')
    receipt = read(path)
    if (receipt.get('state') != 'user_authorized_task51_legacy_exception'
            or receipt.get('task_id') != 51
            or receipt.get('dataset_revision') != 'b195787c65046083e6a43776b67bdf1389dfa3eb'
            or receipt.get('target_valid_count') != task['target_valid_count']
            or receipt.get('new_episode_indices') != task['new_episode_indices']
            or receipt.get('missing_provenance') != 'unknown'
            or receipt.get('test_protocol_unchanged') is not True):
        raise ValueError('Task51 exception authorization scope mismatch')
    return ['--task51-legacy-provenance']

def capacity(gpu, ram, offline_slots=0, *, offline_reserved_mib=None):
    if gpu is None or ram is None:
        return 0
    reserve = offline_slots * TRAINING_MIB if offline_reserved_mib is None else offline_reserved_mib
    return max(0, min(MAX_WORKERS, int(gpu)//WORKER_MIB, (int(ram)-4096-reserve)//WORKER_MIB))

def rolling_capacity(gpu, ram, reserved_slots, resident_gpu, resident_ram, offline_reserved_mib):
    """Fill released slots, reserving startup and future growth of live workers.

    Free GPU/RAM already exclude resident memory. Subtract only the remaining
    reservation, and enforce the five-worker limit across all live batches.
    Missing residency evidence supplies zero credit, preserving the full budget.
    """
    if gpu is None or ram is None:
        return 0
    gpu_gap = max(0, reserved_slots*WORKER_MIB-resident_gpu)
    ram_gap = max(0, reserved_slots*WORKER_MIB-resident_ram)
    return max(0, min(MAX_WORKERS-reserved_slots,
                     (int(gpu)-gpu_gap)//WORKER_MIB,
                     (int(ram)-4096-offline_reserved_mib-ram_gap)//WORKER_MIB))

def offline_capacity(ram, reserved_gpu_ram, active_offline=0):
    """CPU-only research proceeds regardless of GPU readiness or availability."""
    if ram is None:
        return 0
    return max(0, min(1-active_offline, (int(ram)-4096-reserved_gpu_ram)//8192))

def parallel_preparation_slots(ram, reserved_gpu_ram, active_preparations, active_training):
    """Pipeline isolated exploration with indexing, retaining every reservation."""
    if ram is None:
        return 0
    remaining = (int(ram) - 4096 - reserved_gpu_ram
                 - active_preparations * PREPARATION_MIB - active_training * TRAINING_MIB)
    return max(0, min(MAX_PREPARATIONS-active_preparations, remaining//PREPARATION_MIB))

def training_slots(ram, reserved_gpu_ram, active_preparations, active_training):
    """One indexing job can overlap exploration and an unfinished GPU wave."""
    if ram is None or active_training:
        return 0
    remaining = int(ram)-4096-reserved_gpu_ram-active_preparations*PREPARATION_MIB
    return int(remaining >= TRAINING_MIB)

def remaining_worker_slots(job, proc_root=Path('/proc')):
    """Retain all reservations unless a successful slot is provably finished.

    The batch only publishes valid=True after reaping the worker and validating
    its final result. Missing/malformed evidence or a still-existing PID retains
    the reservation; pending/unstarted workers always retain their full budget.
    This changes host admission only, never episode inputs or scoring.
    """
    workers = job['workers']
    try:
        report = read(Path(job['output'])/'result.json')
        rows = report['episodes']
        if (report['workers'] != workers or len(rows) > workers
                or len({r['worker_index'] for r in rows}) != len(rows)
                or any(type(r['worker_index']) is not int or not 0 <= r['worker_index'] < workers for r in rows)):
            return workers
        released = 0
        for row in rows:
            pid = row.get('pid')
            if (row.get('valid') is True and row.get('returncode') == 0
                    and row.get('ended_at') and type(pid) is int and pid > 0):
                try:
                    (proc_root/str(pid)).stat()
                except FileNotFoundError:
                    released += 1
        return workers-released
    except (OSError, ValueError, KeyError, TypeError):
        return workers

def host_ram_available_mib():
    """Keep CPU admission independent when the GPU query times out."""
    try:
        memory = dict(line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())
        return int(memory['MemAvailable'].split()[0])//1024
    except (OSError, ValueError, KeyError):
        return None

def process_tree_pids(pid, proc_root=Path('/proc')):
    seen = set(); pending = [pid]
    while pending:
        pid = pending.pop()
        if pid in seen:
            continue
        folder = proc_root/str(pid)
        try:
            children = (folder/'task'/str(pid)/'children').read_text()
            seen.add(pid)
            pending.extend(int(p) for p in children.split())
        except (OSError, ValueError):
            continue
    return seen

def resident_gpu_memory_mib(jobs, proc_root=Path('/proc')):
    """Credit only GPU allocations belonging to campaign child process trees."""
    if not jobs:
        return 0
    try:
        output = subprocess.check_output(
            ['nvidia-smi', '--id=0', '--query-compute-apps=pid,used_gpu_memory',
             '--format=csv,noheader,nounits'], text=True, timeout=5)
        usage = {}
        for line in output.splitlines():
            if not line.strip():
                continue
            pid, mib = (int(p.strip()) for p in line.split(','))
            if pid <= 0 or mib < 0 or pid in usage:
                return 0
            usage[pid] = mib
        total = 0; seen = set()
        for job in jobs:
            pids = process_tree_pids(job['pid'], proc_root)-seen
            seen.update(pids)
            # A larger allocation in one batch cannot consume the reservation
            # protecting another batch's unstarted simulators.
            total += min(sum(usage.get(pid, 0) for pid in pids),
                         remaining_worker_slots(job, proc_root)*WORKER_MIB)
        return total
    except (OSError, ValueError, subprocess.SubprocessError):
        return 0

def gpu_starting(jobs):
    """Offline disk work waits until the admitted wave is resident."""
    for job in jobs:
        report = Path(job['output'])/'result.json'
        if not report.is_file():
            return True
        rows = read(report).get('episodes', [])
        if len(rows) < job['workers']:
            return True
        if any(not row.get('startup_ready_at') and row.get('returncode') is None for row in rows):
            return True
    return False

def gpu_pending(tasks):
    """Use the GPU before admitting another bulk export or verification."""
    return any(t.get('package') and t.get('isolation')
               and t.get('state') != 'complete_pending_final_audit'
               and t.get('retry_after_epoch', 0) <= time.time()
               and next_indices(t, 1) for t in tasks.values())

def io_command(command, stage):
    # Only our child and its descendants are affected. Never other users' jobs.
    ionice = shutil.which('ionice')
    if not ionice:
        return command
    priority = ['-c', '2', '-n', '0' if stage in ('smoke', 'evaluation') else '4']
    return [ionice, *priority, *command]

def resident_memory_mib(jobs, proc_root=Path('/proc')):
    """Count resident anonymous and tmpfs memory, with shared pages apportioned.

    MemAvailable already subtracts these pages. Reserving their full worker
    budget again would double-count them and unnecessarily block offline work.
    Missing evidence contributes zero, keeping the full conservative reserve.
    File cache is deliberately excluded: MemAvailable can already count it.
    """
    seen = set(); total_kib = 0
    pending = [j['pid'] for j in jobs]
    while pending:
        pid = pending.pop()
        if pid in seen: continue
        seen.add(pid)
        try:
            folder = proc_root/str(pid)
            values = dict(line.split(':',1) for line in (folder/'smaps_rollup').read_text().splitlines() if ':' in line)
            total_kib += sum(max(0,int(values.get(key,'0 kB').split()[0])) for key in ('Pss_Anon','Pss_Shmem'))
            pending.extend(int(p) for p in (folder/'task'/str(pid)/'children').read_text().split())
        except (OSError,ValueError):
            continue
    return total_kib//1024

def resource_failure(output):
    path = Path(output)/'result.json'
    if path.exists() and read(path).get('state') == 'blocked_on_resources':
        return True
    for log in Path(output).glob('episode_*/private/simulator.log'):
        with log.open(errors='replace') as stream:
            for line in stream:
                if '[Error]' in line and ('PxgCudaDeviceMemoryAllocator failed to allocate' in line or 'CUDA_ERROR_OUT_OF_MEMORY' in line):
                    return True
    return False

def successful(stage, output):
    root = Path(output)
    filename = {'training':'manifest.json','preparation':'preparation.json',
                'isolation':'result.json','smoke':'result.json','evaluation':'result.json'}[stage]
    r = read(root/filename)
    if stage == 'training':
        ok = r.get('state') == 'complete' and len(r['demonstrations']) == 100
    elif stage == 'preparation':
        ok = r.get('state') == 'ready' and bool(r.get('package'))
    elif stage == 'isolation':
        ok = r.get('tool_probe') == 'passed'
    else:
        ok = (r.get('state') == 'completed' and not r.get('infrastructure_errors')
              and len(r['episodes']) == r['planned_episodes'] and all(e['valid'] for e in r['episodes']))
        if stage == 'smoke' and r.get('workers') == 5:
            marker = read(root/'startup/wave_0000.json')
            memory = read(root/'startup/wave_0000.memory.json')
            resident = marker.get('memory_at_residency', {})
            ok = (ok and marker['resident_workers'] == 5 and resident.get('ready_workers') == 5
                  and resident.get('gpu_free_mib', 0) >= 2048
                  and resident.get('ram_available_mib', 0) >= 4096
                  and memory.get('samples')
                  and memory.get('min_gpu_free_mib', 0) >= 2048
                  and memory.get('min_ram_available_mib', 0) >= 4096)
        if stage == 'evaluation':
            ok = ok and r.get('eligible_for_gpt6_score') and r.get('evaluation_setting') == 'task_icl_v3'
    if not ok:
        raise ValueError(stage+' completion gate failed')
    return r

def initialize(root, plan):
    from gpt6_eval.suite import freeze_source
    prerequisite = read(Path(plan['prerequisite_cohort']).with_name('cohort_result.json'))
    if prerequisite.get('state') != 'complete' or prerequisite.get('indices') != list(range(5,25)):
        raise ValueError('Task26 final audit required')
    snap = root/'snapshots/v1'
    snap.mkdir(parents=True, exist_ok=False)
    hashes = freeze_source(snap/'runner')
    shutil.copyfile(__file__, snap/'supervisor.py')
    project = Path(__file__).resolve().parents[1]
    base = read(project/'configs/task22_icl_pilot.json')
    write(snap/'base_config.json', base)
    old = Path(plan['prerequisite_cohort']).parent/'repairs/resource_query_v2/runner'
    diff = []
    for name in ('src/gpt6_eval/batch.py','src/gpt6_eval/resource_wait.py'):
        diff.extend(difflib.unified_diff((old/name).read_text().splitlines(True),
                    (snap/'runner'/name).read_text().splitlines(True), fromfile='previous/'+name, tofile='campaign/'+name))
    (snap/'infrastructure.diff').write_text(''.join(diff))
    tasks = {}
    for tid in plan['launch_priority']:
        t = dict(next(t for t in plan['tasks'] if t['task_id']==tid))
        t.update(jobs=[],smoke_workers=0,resource_failures=0)
        if tid == 22:
            t.update(package=plan['task22_package'],inherited=plan['inherited_task22'])
        tasks[str(tid)] = t
    state = {'state':'running','started_at':now(),'plan_sha256':sha(root/'campaign.json'),
        'snapshot':'snapshots/v1','source_hashes':hashes,'supervisor_sha256':sha(snap/'supervisor.py'),
        'base_config_sha256':sha(snap/'base_config.json'),'tasks':tasks,'jobs':[],
        'prerequisite_result_sha256':sha(Path(plan['prerequisite_cohort']).with_name('cohort_result.json'))}
    write(root/'state.json',state)
    return state

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--initialize',action='store_true')
    ap.add_argument('--only-task',type=int,choices=[51],
                    help='Admit only this task and pause after its planned episodes')
    args = ap.parse_args(); root = args.output.resolve()
    lock = (root/'supervisor.lock').open('a')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    plan = read(root/'campaign.json')
    if args.initialize:
        if (root/'state.json').exists():
            raise ValueError('Already initialized')
        state = initialize(root,plan)
        print('Initialized frozen snapshot; invoke '+str(root/state['snapshot']/'supervisor.py'),flush=True)
        return
    state = read(root/'state.json'); snap = root/state['snapshot']
    if args.only_task is not None:
        if state.get('authorized_only_task') != args.only_task:
            raise ValueError('Task scope not authorized in campaign state')
    elif state.get('authorized_only_task') is not None:
        raise ValueError('Scoped campaign cannot resume without its task scope')
    if sha(__file__) != state['supervisor_sha256'] or sha(root/'campaign.json') != state['plan_sha256']:
        raise ValueError('Supervisor or plan changed')
    for name,digest in state['source_hashes'].items():
        if sha(snap/'runner'/name) != digest:
            raise ValueError('Source snapshot changed: '+name)
    if sha(snap/'base_config.json') != state['base_config_sha256']:
        raise ValueError('Base config changed')
    if state.get('error'):
        raise ValueError('Repair must be diagnosed and archived before resuming')
    if any(not j.get('ended_at') for j in state['jobs']):
        raise ValueError('Unreconciled old children; inspect before resume')
    validate_deferrals(root, state['tasks'])
    os.environ['GPT6_EVAL_WORKER_RESERVATION_MIB'] = str(WORKER_MIB)
    sys.path.insert(0,str(snap/'runner/src'))
    from gpt6_eval.resource_wait import snapshot
    from gpt6_eval.knowledge import verify_package
    base = read(snap/'base_config.json'); runtime = plan['runtime']
    env = {**os.environ,'PYTHONPATH':str(snap/'runner/src'),'PYTHONHASHSEED':'0',
        'OMNI_KIT_ACCEPT_EULA':'YES','GPT6_EVAL_WAIT_FOR_GPU':'1','GPT6_EVAL_RAM_HEADROOM_MIB':'4096',
        'GPT6_EVAL_WORKER_RESERVATION_MIB':str(WORKER_MIB),
        'GPT6_EVAL_ASSET_CACHE':str(root/'repairs/asset_cache_v9_20260929/cache.json')}
    env.pop('GPT6_EVAL_SMOKE_RELEASE',None)
    live = {}; stop = False
    def stopped(signum, frame):
        nonlocal stop
        stop = True
    signal.signal(signal.SIGTERM,stopped)
    def save():
        state.update(updated_at=now(),supervisor_pid=os.getpid())
        write(root/'state.json',state)
    def config(task, index=None, count=None, knowledge=False):
        cfg = {**base,'start_episode':index or task['new_episode_indices'][0],
               'num_episodes':count or len(task['new_episode_indices'])}
        if knowledge:
            pkg = task['package']; verify_package(Path(pkg['path']),pkg['sha256'],task['task_id'],cfg)
            cfg.update(schema_version=3,evaluation_setting='task_icl_v3',task_packages={str(task['task_id']):pkg})
        return cfg
    def launch(task, stage, workers=0, indices=None):
        if 'scheduling_deferral' in task:
            raise ValueError('Deferred task cannot be admitted')
        number = len(state['jobs']); folder = root/f'task_{task["task_id"]:02d}'/f'{number:04d}_{stage}'
        cfg = folder.with_suffix('.config.json')
        idx = indices[0] if indices else None
        write(cfg,config(task,idx,len(indices) if indices else None,stage=='evaluation'))
        command = [runtime['python'],'-u','-m']
        if stage == 'training':
            command += ['gpt6_eval.icl','prepare','--task',str(task['task_id']),
                        '--access-mode','trusted_reader_v1']
            command += task51_training_options(root, state, task)
            for key in ('dataset','upstream','assets'):
                command += ['--'+key,runtime[key]]
        elif stage == 'preparation':
            command += ['gpt6_eval.icl','explore','--training',task['training']]
        elif stage == 'isolation':
            command += ['gpt6_eval.doctor']
        else:
            command += ['gpt6_eval.batch','--task',str(task['task_id']),'--workers',str(workers),
                        '--startup-timeout-s','600','--mode','hold' if stage=='smoke' else 'codex']
            if stage == 'smoke': command += ['--hold-until-resident','--smoke-steps','4']
            for key in ('python','upstream','isaaclab','assets'):
                command += ['--'+key,runtime[key]]
        command += ['--config',str(cfg),'--output',str(folder)]
        command = io_command(command, stage)
        record = {'id':number,'task_id':task['task_id'],'stage':stage,'output':str(folder),
                  'argv':command,'workers':workers,'indices':indices,'started_at':now(),
                  'snapshot':state['snapshot'],'config_sha256':sha(cfg)}
        # Save intent before spawning. A crash here fails closed on resume.
        state['jobs'].append(record); task['jobs'].append(record); save()
        with folder.with_suffix('.log').open('xb') as log:
            proc = subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT)
        record['pid'] = proc.pid; live[number]=(proc,record); save()
        print(now(), 'Started',task['task_id'],stage,indices or '', 'pid',proc.pid,flush=True)
    try:
        while True:
            for number,(proc,job) in list(live.items()):
                code = proc.poll()
                if code is None: continue
                job.update(returncode=code,ended_at=now()); del live[number]
                task = state['tasks'][str(job['task_id'])]; stage=job['stage']
                if code:
                    if stage == 'smoke' and job['workers'] == 5:
                        state.update(error=f'Five-worker validation failed: {job["output"]}',state='needs_repair')
                    elif stage in ('smoke','evaluation') and resource_failure(job['output']):
                        task['resource_failures'] += 1
                        task['retry_after_epoch'] = time.time()+60
                        job['recovery']='Trusted resource fault; retain costs; retry only pending indices'
                        if task['resource_failures']>=3:
                            state.update(error='Repeated resource failures need investigation',state='needs_repair')
                    else:
                        state.update(error=f'{stage} exited {code}: {job["output"]}',state='needs_repair')
                else:
                    r = successful(stage,job['output'])
                    task['resource_failures']=0
                    if stage=='training': task['training']=job['output']
                    elif stage=='preparation': task['package']=r['package']
                    elif stage=='isolation': task['isolation']=job['output']
                    elif stage=='smoke':
                        marker=read(Path(job['output'])/'startup/wave_0000.json')
                        if marker['resident_workers'] != job['workers']:
                            raise ValueError('Concurrent residency not proven')
                        task['smoke_workers']=max(task['smoke_workers'],job['workers'])
                if task.get('package'):
                    task['valid_episodes']=list(collect(task).values())
                    if len(task['valid_episodes']) == task['target_valid_count']:
                        task['state']='complete_pending_final_audit'
                save()
            if state.get('error') or stop:
                if not live: break
                save(); time.sleep(5); continue
            terminal = scoped_terminal_state(state['tasks'], args.only_task)
            if terminal and not live:
                state['state']=terminal; save(); break
            resident_gpu_ram=resident_memory_mib([j for _,j in live.values() if j['stage'] in ('smoke','evaluation')])
            try:
                resources=snapshot()
            except subprocess.TimeoutExpired:
                resources={'gpu_free_mib':None,'ram_available_mib':host_ram_available_mib(),
                           'admitted':False,'query_timeout':True}
            free=shutil.disk_usage(root).free; vfs=os.statvfs(root)
            resources.update(free_disk_bytes=free,free_inodes=vfs.f_favail,checked_at=now())
            resources['gpu_jobs_resident_unreclaimable_mib']=resident_gpu_ram
            state['resources']=resources
            active_tasks={j['task_id'] for _,j in live.values()}
            gpu_jobs=[j for _,j in live.values() if j['stage'] in ('smoke','evaluation')]
            offline=[j for _,j in live.values() if j['stage'] in ('training','preparation')]
            # Offline admission reserves each not-yet-resident GPU worker too.
            ram=resources.get('ram_available_mib') or 0
            reserved_slots=sum(remaining_worker_slots(j) for j in gpu_jobs)
            resources['gpu_jobs_reserved_worker_slots']=reserved_slots
            reserved_gpu_ram=max(0,reserved_slots*WORKER_MIB-resident_gpu_ram)
            resources['gpu_jobs_remaining_ram_reservation_mib']=reserved_gpu_ram
            # Release finished worker slots immediately. One indexing job and
            # two isolated explorations can overlap unfinished scored workers.
            # Indexing still reserves 8 GiB and never overlaps another indexer.
            preparations=[j for j in offline if j['stage']=='preparation']
            training=[j for j in offline if j['stage']=='training']
            offline_reserved_mib=len(preparations)*PREPARATION_MIB+len(training)*TRAINING_MIB
            preparation_slots=parallel_preparation_slots(ram,reserved_gpu_ram,
                                                        len(preparations),len(training))
            resources['offline_reserved_mib']=offline_reserved_mib
            for task in scoped_admission_tasks(state['tasks'], plan['launch_priority'], args.only_task):
                tid=task['task_id']
                if tid in active_tasks or task.get('state')=='complete_pending_final_audit': continue
                if task.get('package'):
                    if not task.get('isolation'):
                        launch(task,'isolation'); active_tasks.add(tid)
                    continue
                if task.get('training'):
                    if preparation_slots > 0:
                        launch(task,'preparation'); active_tasks.add(tid); offline.append(state['jobs'][-1])
                        preparations.append(state['jobs'][-1])
                        offline_reserved_mib+=PREPARATION_MIB
                        preparation_slots-=1
                elif training_slots(ram,reserved_gpu_ram,len(preparations),len(training)):
                    # Reader indexing writes only small permitted numeric arrays.
                    # Requested images retain the original 50 GiB safety reserve.
                    need = 51 * 1024**3
                    task.update(storage_admission='trusted_reader_v1',
                                export_required_free_bytes=need)
                    if free >= need and vfs.f_favail > 100000:
                        task.pop('waiting_for_storage', None)
                        launch(task, 'training'); active_tasks.add(tid); offline.append(state['jobs'][-1])
                        training.append(state['jobs'][-1]);offline_reserved_mib+=TRAINING_MIB
                        preparation_slots=parallel_preparation_slots(ram,reserved_gpu_ram,
                                                                    len(preparations),len(training))
                    else:
                        task['waiting_for_storage'] = True
            resident_gpu=resident_gpu_memory_mib(gpu_jobs)
            resources['gpu_jobs_resident_vram_mib']=resident_gpu
            resources['gpu_jobs_remaining_vram_reservation_mib']=max(0,reserved_slots*WORKER_MIB-resident_gpu)
            n=rolling_capacity(resources.get('gpu_free_mib'),resources.get('ram_available_mib'),
                               reserved_slots,resident_gpu,resident_gpu_ram,offline_reserved_mib)
            resources['gpu_worker_slots_available_this_check']=n
            resources['gpu_worker_slots_admitted_this_check']=0
            busy_offline_tasks={j['task_id'] for _,j in live.values()
                                if j['stage'] not in ('smoke','evaluation')}
            for task in scoped_admission_tasks(state['tasks'], plan['launch_priority'], args.only_task):
                if not n:
                    break
                tid=task['task_id']
                if tid in busy_offline_tasks or not task.get('isolation') or not task.get('package'): continue
                if task.get('retry_after_epoch',0)>time.time(): continue
                indices=next_indices(task,n,gpu_jobs)
                if not indices: continue
                workers=len(indices)
                if task['smoke_workers']<workers and 'smoke_bypass' not in task:
                    task['smoke_bypass']={
                        'scope':'Remaining v9 task-specific no-model residency smoke only',
                        'reason':'User-authorized 48-hour throughput priority; scored startup and resource failures still checked',
                        'at':now(), 'first_workers':workers}
                launch(task,'evaluation',workers,indices)
                gpu_jobs.append(state['jobs'][-1])
                n-=workers
                resources['gpu_worker_slots_admitted_this_check']+=workers
            resources['offline_reserved_mib']=offline_reserved_mib
            save(); time.sleep(15)
    except BaseException as exc:
        state.update(state='needs_repair',error=f'{type(exc).__name__}: {exc}'); save()
        # Do not orphan children or automatically retry an unknown error.
        for proc,job in live.values():
            job.update(returncode=proc.wait(),ended_at=now())
        save(); raise
    if stop: state['state']='stopped_by_request'
    save()

if __name__=='__main__':
    main()
