#!/usr/bin/env python3
"""Export timestamped Astra transcripts beside rendered evaluation videos.

The source evaluation archive keeps exact decision-boundary observations,
accepted action batches, timing records, public Codex events, and the full CLI
session.  This exporter joins those records to the already-rendered 20 Hz
videos without re-encoding or copying evaluation imagery.
"""

from __future__ import annotations

import argparse
import bisect
import hashlib
import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable




def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument(
        "--slots",
        nargs="*",
        help="Optional slot filter, for example 12_06 12_07 (default: all 78)",
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        help="Write a mirrored test package here instead of beside the videos",
    )
    parser.add_argument(
        "--no-manifest-update",
        action="store_true",
        help="Do not update the package manifest or checksum list",
    )
    return parser.parse_args()


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def sha256_file(path: Path, block_size: int = 4 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(block_size):
            digest.update(chunk)
    return digest.hexdigest()


def parse_time(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def atomic_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".partial")
    temp.write_text(text, encoding="utf-8")
    os.replace(temp, path)


def atomic_json(path: Path, value: Any) -> None:
    atomic_text(path, json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def policy_private(result_path: str) -> Path:
    parent = Path(result_path).parent
    candidates = (parent / "episode_0000" / "private", parent / "private")
    for candidate in candidates:
        if (candidate / "codex.events.jsonl").is_file():
            return candidate
    raise FileNotFoundError(f"policy private archive not found for {result_path}")


def indexed_json(directory: Path) -> dict[int, dict[str, Any]]:
    found: dict[int, dict[str, Any]] = {}
    if not directory.is_dir():
        return found
    for path in sorted(directory.glob("*.json")):
        value = load_json(path)
        decision = int(value.get("decision", int(path.stem)))
        found[decision] = value
    return found


def content_text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict) and isinstance(item.get("text"), str):
                parts.append(item["text"])
        return "".join(parts)
    return ""


def normalize_command(command: Any) -> str:
    if isinstance(command, list):
        if len(command) >= 3 and command[1] == "-c":
            return str(command[2])
        return " ".join(str(part) for part in command)
    return str(command or "")


def sanitize_completed_item(item: dict[str, Any]) -> dict[str, Any] | None:
    kind = item.get("type")
    common = {"kind": kind, "id": item.get("id")}
    if kind == "AgentMessage":
        return {
            **common,
            "phase": item.get("phase"),
            "text": content_text(item.get("content")),
        }
    if kind == "Reasoning":
        summary = item.get("summary_text") or []
        raw = item.get("raw_content") or []
        if not summary and not raw:
            return None
        return {**common, "summary_text": summary, "raw_content": raw}
    if kind == "ImageView":
        path = item.get("path")
        match = re.search(r"observations/(\d+)/([^/]+)$", str(path))
        return {
            **common,
            "path": path,
            "observation_policy_step": int(match.group(1)) if match else None,
            "camera_file": match.group(2) if match else None,
        }
    if kind == "CommandExecution":
        return {
            **common,
            "command": normalize_command(item.get("command")),
            "cwd": item.get("cwd"),
            "status": item.get("status"),
            "exit_code": item.get("exit_code"),
            "duration": item.get("duration"),
            "stdout": item.get("stdout", ""),
            "stderr": item.get("stderr", ""),
            "aggregated_output": item.get("aggregated_output", ""),
        }
    if kind == "UserMessage":
        return None
    # Preserve uncommon completed outputs while avoiding duplicated display-only
    # fields.  JSON serialization below remains the exact source representation
    # for all other meaningful fields.
    kept = dict(item)
    kept.pop("formatted_output", None)
    kept["kind"] = kept.pop("type", kind)
    return kept


def session_events(
    private: Path, first_started_at: datetime
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Read completed model-facing items after the phase boundary.

    Extension archives contain the resumed baseline session history as well as
    the extension.  The first timing record is therefore the authoritative
    lower bound for selecting only the current phase.
    """

    lower_bound = first_started_at.timestamp() - 5.0
    events: list[dict[str, Any]] = []
    sources: list[dict[str, Any]] = []
    session_root = private / "codex-home" / "sessions"
    files = sorted(session_root.rglob("rollout*.jsonl"))
    if not files:
        raise FileNotFoundError(f"no rollout transcript beneath {session_root}")

    seen: set[tuple[Any, ...]] = set()
    for path in files:
        digest = hashlib.sha256()
        selected = 0
        with path.open("rb") as handle:
            for raw_line in handle:
                digest.update(raw_line)
                # The encrypted Reasoning response records dominate archive
                # size. Completed items are the model-visible, auditable stream.
                if b'"event_msg"' not in raw_line or b'"item_completed"' not in raw_line:
                    continue
                try:
                    record = json.loads(raw_line)
                except (UnicodeDecodeError, json.JSONDecodeError):
                    continue
                if record.get("type") != "event_msg":
                    continue
                payload = record.get("payload") or {}
                if payload.get("type") != "item_completed":
                    continue
                timestamp = record.get("timestamp")
                if not timestamp:
                    continue
                event_dt = parse_time(timestamp)
                if event_dt.timestamp() < lower_bound:
                    continue
                item = payload.get("item") or {}
                clean = sanitize_completed_item(item)
                if clean is None:
                    continue
                identity = (timestamp, record.get("ordinal"), clean.get("kind"), clean.get("id"))
                if identity in seen:
                    continue
                seen.add(identity)
                events.append(
                    {
                        "timestamp": timestamp,
                        "ordinal": record.get("ordinal"),
                        **clean,
                    }
                )
                selected += 1
        sources.append(
            {
                "path": str(path),
                "bytes": path.stat().st_size,
                "sha256": digest.hexdigest(),
                "selected_completed_items": selected,
            }
        )
    events.sort(key=lambda event: (parse_time(event["timestamp"]), event.get("ordinal") or -1))
    return events, sources


def phase_data(result_ref: dict[str, Any], phase: str) -> dict[str, Any]:
    private = policy_private(result_ref["path"])
    timings = indexed_json(private / "timing")
    if not timings:
        raise ValueError(f"no timing records in {private}")
    ordered = sorted(timings.values(), key=lambda row: (parse_time(row["started_at"]), row["decision"]))
    starts = [parse_time(row["started_at"]) for row in ordered]
    events, session_sources = session_events(private, starts[0])
    actions = indexed_json(private / "actions")
    requests = indexed_json(private / "requests")
    observations = indexed_json(private / "decisions")
    grouped: dict[int, list[dict[str, Any]]] = {int(row["decision"]): [] for row in ordered}

    for event in events:
        when = parse_time(event["timestamp"])
        index = bisect.bisect_right(starts, when) - 1
        index = max(0, min(index, len(ordered) - 1))
        grouped[int(ordered[index]["decision"])].append(event)

    first_observation = observations.get(int(ordered[0]["decision"]), {})
    telemetry_path = private / "telemetry.json"
    telemetry = load_json(telemetry_path) if telemetry_path.is_file() else None
    decisions: list[dict[str, Any]] = []
    for timing in ordered:
        decision = int(timing["decision"])
        observation = dict(observations.get(decision, {}))
        observation.pop("camera_calibration", None)
        observation.pop("instruction", None)
        action = actions.get(decision)
        request = requests.get(decision)
        action_result: dict[str, Any] = {
            "accepted": timing.get("accepted"),
            "error": timing.get("error"),
            "accepted_action_record_present": action is not None,
            "request_record_present": request is not None,
        }
        if action is not None:
            action_result.update(action)
            action_result["action_count"] = len(action.get("actions") or [])
        elif request is not None:
            payload = request.get("payload") or {}
            action_result["submitted_request"] = payload
            action_result["action_count"] = len(payload.get("actions") or [])

        decisions.append(
            {
                "record_type": "astra_decision",
                "phase": phase,
                "decision_index": decision,
                "policy_step": int(timing["policy_step"]),
                "timing": timing,
                "observation": observation,
                "astra_events": grouped.get(decision, []),
                "action_result": action_result,
                "source_private": str(private),
            }
        )

    return {
        "phase": phase,
        "result_ref": result_ref,
        "private": str(private),
        "instruction": first_observation.get("instruction"),
        "camera_calibration": first_observation.get("camera_calibration"),
        "telemetry": telemetry,
        "codex_events": {
            "path": str(private / "codex.events.jsonl"),
            "bytes": (private / "codex.events.jsonl").stat().st_size,
            "sha256": sha256_file(private / "codex.events.jsonl"),
        },
        "session_sources": session_sources,
        "decisions": decisions,
    }


def video_alignment(policy_step: int, frames: int, fps: float) -> dict[str, Any]:
    if frames <= 0:
        raise ValueError("video must have at least one frame")
    frame = max(0, min(policy_step, frames - 1))
    return {
        "source_policy_step": policy_step,
        "video_frame_zero_based": frame,
        "video_time_seconds": round(frame / fps, 6),
        "clamped_to_video_range": frame != policy_step,
        "mapping": "20 Hz policy step maps to the same zero-based rendered trajectory frame",
    }


def hhmmss(seconds: float) -> str:
    milliseconds = max(0, round(seconds * 1000))
    hours, milliseconds = divmod(milliseconds, 3_600_000)
    minutes, milliseconds = divmod(milliseconds, 60_000)
    secs, milliseconds = divmod(milliseconds, 1_000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}.{milliseconds:03d}"


def message_texts(decision: dict[str, Any]) -> list[str]:
    texts: list[str] = []
    for event in decision["astra_events"]:
        if event.get("kind") == "AgentMessage" and event.get("text", "").strip():
            texts.append(event["text"].strip())
        elif event.get("kind") == "Reasoning":
            for value in event.get("summary_text") or []:
                if isinstance(value, dict):
                    value = value.get("text", "")
                if str(value).strip():
                    texts.append(str(value).strip())
    return texts


def vtt_text(decisions: list[dict[str, Any]], frames: int, fps: float) -> str:
    duration = frames / fps
    lines = ["WEBVTT", "", "NOTE Astra transcript aligned at 20 Hz policy decision boundaries.", ""]
    for index, decision in enumerate(decisions):
        alignment = decision["video_alignment"]
        start = alignment["video_time_seconds"]
        next_start = duration
        for later in decisions[index + 1 :]:
            candidate = later["video_alignment"]["video_time_seconds"]
            if candidate > start:
                next_start = candidate
                break
        if start >= duration:
            start = max(0.0, duration - 0.05)
        end = min(duration, next_start)
        if end <= start:
            end = min(duration, start + max(0.05, 1.0 / fps))
        if end <= start:
            start = max(0.0, end - 0.05)

        phase = decision["phase"]
        decision_index = decision["decision_index"]
        frame = alignment["video_frame_zero_based"]
        source_step = alignment["source_policy_step"]
        header = f"[{phase} D{decision_index} | frame {frame} | source step {source_step}]"
        body = message_texts(decision)
        if not body:
            action = decision["action_result"]
            count = action.get("action_count", 0)
            status = "accepted" if action.get("accepted") else "not accepted"
            body = [f"Astra decision submitted {count} control steps; {status}."]
        cue = "\n".join([header, *body]).replace("-->", "→")
        lines.extend(
            [
                f"{index + 1}",
                f"{hhmmss(start)} --> {hhmmss(end)}",
                cue,
                "",
            ]
        )
    return "\n".join(lines)


def markdown_text(
    metadata: dict[str, Any], decisions: list[dict[str, Any]]
) -> str:
    lines = [
        f"# Astra transcript: task {metadata['task_id']:02d}, episode {metadata['episode_index']:02d}, {metadata['version']}",
        "",
        f"Video: `{metadata['video_path']}`",
        "",
        "Each heading gives the original policy step and its corresponding zero-based video frame/time. "
        "Astra's visible messages and any saved reasoning summaries are reproduced verbatim. The complete "
        "model-facing command/output events and exact accepted action arrays are in the adjacent JSONL file. "
        "Encrypted hidden reasoning is not decrypted or reconstructed.",
        "",
    ]
    if metadata.get("instruction"):
        lines.extend(["## Task instruction", "", str(metadata["instruction"]).strip(), ""])

    for decision in decisions:
        alignment = decision["video_alignment"]
        clamp = " (clamped to the final video frame)" if alignment["clamped_to_video_range"] else ""
        lines.extend(
            [
                f"## {decision['phase']} decision {decision['decision_index']}",
                "",
                f"Policy step {decision['policy_step']}; video frame "
                f"{alignment['video_frame_zero_based']} at {alignment['video_time_seconds']:.3f} s{clamp}.",
                "",
            ]
        )
        messages = message_texts(decision)
        if messages:
            lines.append("**Saved Astra output**")
            lines.append("")
            for message in messages:
                lines.append(message)
                lines.append("")

        views = [event for event in decision["astra_events"] if event.get("kind") == "ImageView"]
        if views:
            rendered = []
            for view in views:
                camera = view.get("camera_file") or view.get("path")
                observed_step = view.get("observation_policy_step")
                rendered.append(f"{camera} at observation step {observed_step}")
            lines.extend(["**Viewed observations:** " + "; ".join(rendered), ""])

        action = decision["action_result"]
        status = "accepted" if action.get("accepted") else "not accepted"
        lines.extend(
            [
                f"**Action result:** {status}; {action.get('action_count', 0)} control steps; "
                f"reasoning/action wall time {decision['timing'].get('wall_seconds', 0):.3f} s.",
                "",
            ]
        )
    return "\n".join(lines)


def sidecar_paths(video_path: Path, output_root: Path | None, package: Path) -> dict[str, Path]:
    if output_root is None:
        base = video_path.with_suffix("")
    else:
        relative = video_path.relative_to(package)
        base = (output_root / relative).with_suffix("")
    return {
        "jsonl": base.with_suffix(".astra.jsonl"),
        "markdown": base.with_suffix(".astra.md"),
        "webvtt": base.with_suffix(".astra.vtt"),
    }


def write_sidecars(
    paths: dict[str, Path],
    metadata: dict[str, Any],
    phases: list[dict[str, Any]],
    video: dict[str, Any],
) -> dict[str, Any]:
    frames = int(video["frames"])
    fps = float(video["fps"])
    decisions: list[dict[str, Any]] = []
    for phase in phases:
        for original in phase["decisions"]:
            decision = dict(original)
            decision["video_alignment"] = video_alignment(decision["policy_step"], frames, fps)
            decisions.append(decision)
    decisions.sort(key=lambda row: (row["policy_step"], parse_time(row["timing"]["started_at"])))

    header = {
        "record_type": "astra_video_metadata",
        "schema": 1,
        **metadata,
        "video": {
            "path": video["path"],
            "sha256": video["sha256"],
            "frames": frames,
            "fps": fps,
            "duration_seconds": video["duration_seconds"],
        },
        "alignment": {
            "frame_indexing": "zero-based",
            "formula": "video_frame = policy_step at 20 Hz",
            "endpoint_rule": "calls at/after the last stored frame are clamped and flagged",
        },
        "availability": {
            "visible_astra_messages": True,
            "model_facing_tool_commands_and_outputs": True,
            "viewed_image_paths": True,
            "accepted_action_arrays": True,
            "saved_reasoning_summaries_when_present": True,
            "encrypted_hidden_reasoning_decrypted": False,
        },
        "phases": [
            {
                key: phase[key]
                for key in (
                    "phase",
                    "result_ref",
                    "private",
                    "telemetry",
                    "codex_events",
                    "session_sources",
                )
            }
            for phase in phases
        ],
        "camera_calibration": phases[0].get("camera_calibration"),
        "instruction": phases[0].get("instruction"),
        "decision_records": len(decisions),
    }

    paths["jsonl"].parent.mkdir(parents=True, exist_ok=True)
    temp = paths["jsonl"].with_name(paths["jsonl"].name + ".partial")
    with temp.open("w", encoding="utf-8") as handle:
        handle.write(json.dumps(header, ensure_ascii=False, separators=(",", ":")) + "\n")
        for decision in decisions:
            handle.write(json.dumps(decision, ensure_ascii=False, separators=(",", ":")) + "\n")
    os.replace(temp, paths["jsonl"])
    atomic_text(paths["webvtt"], vtt_text(decisions, frames, fps))
    atomic_text(paths["markdown"], markdown_text({**metadata, "instruction": header["instruction"]}, decisions))

    result: dict[str, Any] = {
        "schema": 1,
        "decision_records": len(decisions),
        "astra_completed_events": sum(len(row["astra_events"]) for row in decisions),
        "visible_message_events": sum(len(message_texts(row)) for row in decisions),
        "endpoint_clamped_records": sum(
            bool(row["video_alignment"]["clamped_to_video_range"]) for row in decisions
        ),
    }
    for name, path in paths.items():
        result[name] = {
            "path": str(path),
            "bytes": path.stat().st_size,
            "sha256": sha256_file(path),
        }
    return result


def by_slot(rows: Iterable[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    return {str(row["slot"]): row for row in rows}


def main() -> int:
    args = parse_args()
    report = load_json(args.report)
    manifest_path = args.package / "manifest.json"
    manifest = load_json(manifest_path)
    report_rows = by_slot(
        row for row in report["episodes"] if int(row["episode_index"]) in (5, 6, 7)
    )
    manifest_rows = by_slot(manifest["records"])
    slots = sorted(set(report_rows) & set(manifest_rows))
    if args.slots:
        requested = set(args.slots)
        missing = requested - set(slots)
        if missing:
            raise ValueError(f"unknown slots: {sorted(missing)}")
        slots = [slot for slot in slots if slot in requested]
    if not args.slots and len(slots) != 78:
        raise ValueError(f"expected 78 shared slots, found {len(slots)}")

    generated: list[dict[str, Any]] = []
    for number, slot in enumerate(slots, 1):
        report_row = report_rows[slot]
        manifest_row = manifest_rows[slot]
        baseline = phase_data(report_row["source_1x_result"], "1x")
        extension = None
        if report_row.get("selected_10x_result"):
            extension = phase_data(report_row["selected_10x_result"], "extension")

        common = {
            "created_at": iso_now(),
            "slot": slot,
            "task_id": int(report_row["task_id"]),
            "episode_index": int(report_row["episode_index"]),
            "model": "gpt-6-astra",
            "camera": manifest["settings"]["camera"],
        }
        versions = (
            ("1x", manifest_row["one_x"], [baseline]),
            ("10x", manifest_row["ten_x"], [baseline] + ([extension] if extension else [])),
        )
        version_results: dict[str, Any] = {}
        for version, video, phases in versions:
            video_path = Path(video["path"])
            if not video_path.is_file():
                raise FileNotFoundError(video_path)
            if sha256_file(video_path) != video["sha256"]:
                raise ValueError(f"video hash mismatch: {video_path}")
            metadata = {**common, "version": version, "video_path": str(video_path)}
            paths = sidecar_paths(video_path, args.output_root, args.package)
            version_results[version] = write_sidecars(paths, metadata, phases, video)
            manifest_row["one_x" if version == "1x" else "ten_x"]["astra_sidecars"] = version_results[version]

        generated.append({"slot": slot, **version_results})
        print(
            f"[{number:02d}/{len(slots):02d}] {slot}: "
            f"1x {version_results['1x']['decision_records']} decisions, "
            f"10x {version_results['10x']['decision_records']} decisions",
            flush=True,
        )

    if not args.no_manifest_update and args.output_root is None:
        manifest["updated_at"] = iso_now()
        manifest["astra_sidecars"] = {
            "schema": 1,
            "state": "complete" if len(slots) == 78 else "partial",
            "video_versions": len(generated) * 2,
            "formats_per_video": ["jsonl", "markdown", "webvtt"],
            "mapping": "20 Hz policy_step to same zero-based video frame",
            "availability_note": (
                "Exports visible Astra messages, model-facing completed tool events, saved reasoning "
                "summaries when present, and exact accepted actions. Encrypted hidden reasoning is not decrypted."
            ),
            "completed_at": iso_now(),
        }
        atomic_json(manifest_path, manifest)

        checksum_entries: list[tuple[str, str]] = []
        for record in manifest["records"]:
            for key in ("one_x", "ten_x"):
                for artifact in (record[key].get("astra_sidecars") or {}).values():
                    if not isinstance(artifact, dict) or "path" not in artifact:
                        continue
                    path = Path(artifact["path"])
                    checksum_entries.append((artifact["sha256"], str(path.relative_to(args.package))))
        checksum_entries.sort(key=lambda pair: pair[1])
        atomic_text(
            args.package / "ASTRA_SHA256SUMS",
            "".join(f"{digest}  {relative}\n" for digest, relative in checksum_entries),
        )

    print(json.dumps({"slots": len(slots), "video_versions": len(slots) * 2}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
