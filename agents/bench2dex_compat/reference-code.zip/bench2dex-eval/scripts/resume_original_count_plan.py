"""Resume the unchanged ten-episode plan after the previously requested drain."""
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import time


def read(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,data):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(data,indent=2)+'\n');temp.replace(path)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);args=ap.parse_args()
    root=args.root.resolve();folder=root/'amendments/restore_ten_20260928';request=read(folder/'request.json')
    with (folder/'resume.lock').open('a') as owner:
        fcntl.flock(owner,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if (folder/'resumed.json').exists():return
        write(folder/'status.json',{'state':'waiting_for_current_preparation','pid':os.getpid()})
        while True:
            state=read(root/'state.json')
            if any(not j.get('ended_at') for j in state['jobs']):time.sleep(15);continue
            with (root/'supervisor.lock').open('a') as lock:
                try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
                except BlockingIOError:time.sleep(2);continue
                state=read(root/'state.json');plan=read(root/'campaign.json')
                if any(not j.get('ended_at') for j in state['jobs']):raise ValueError('Undrained children')
                if state['state'] not in ('stopped_by_request','needs_repair'):raise ValueError('Unexpected state')
                if sha(root/'campaign.json')!=request['plan_sha256'] or state['plan_sha256']!=request['plan_sha256']:
                    raise ValueError('Original ten-episode plan changed')
                if any(t['target_valid_count']!=(20 if t['task_id']==26 else 10) for t in plan['tasks']):
                    raise ValueError('Wrong sample count')
                if any(t['target_valid_count']!=10 or len(t['new_episode_indices'])+len(t.get('inherited',[]))!=10 for t in state['tasks'].values()):
                    raise ValueError('Wrong runtime count')
                if plan['final_valid_episode_total_including_task26']!=270:raise ValueError('Wrong denominator')
                snap=root/state['snapshot']
                if sha(snap/'supervisor.py')!=state['supervisor_sha256'] or sha(snap/'base_config.json')!=state['base_config_sha256']:
                    raise ValueError('Frozen orchestration/config changed')
                for name,digest in state['source_hashes'].items():
                    if sha(snap/'runner'/name)!=digest:raise ValueError('Frozen runner changed')
                if state.get('error'):
                    write(folder/'status.json',{'state':'needs_infrastructure_repair','error':state['error']});return
                write(folder/'state.before_resume.json',state)
                state.update(state='running',updated_at=datetime.now(timezone.utc).isoformat(),count_reversion=str(folder/'request.json'))
                write(root/'state.json',state)
            cmd=[plan['runtime']['python'],'-u',str(snap/'supervisor.py'),'--output',str(root)]
            for _ in range(10):
                if subprocess.run(['tmux','has-session','-t','bench2dex-all-icl10'],capture_output=True).returncode:break
                time.sleep(1)
            subprocess.run(['tmux','new-session','-d','-s','bench2dex-all-icl10','exec '+shlex.join(cmd)+' >> '+shlex.quote(str(root/'supervisor.log'))+' 2>&1'],check=True)
            record={'state':'resumed','at':datetime.now(timezone.utc).isoformat(),'final_total':270,'plan_sha256':state['plan_sha256'],'script_sha256':sha(Path(__file__))}
            write(folder/'resumed.json',record);write(folder/'status.json',record);print(json.dumps(record),flush=True);return


if __name__=='__main__':main()
