"""Two-worker task26 cohort with immutable attempts and resource-error recovery.

Preserve valid indices 5–10; finish 11–24. Resume never reruns a valid episode.
Unexpected faults stop as needs_repair for the authorized monitoring agent.
"""
import argparse
import difflib
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone

PACKAGE = 'd3ae8ddaa9c45728b25f11ea95e2018e4561625e81316dd1f2eadd66da06d7f1'
TARGET = list(range(5, 25))


def now():
    return datetime.now(timezone.utc).isoformat()


def read(path):
    return json.loads(path.read_text())


def digest(path):
    with path.open('rb') as stream:
        value = hashlib.sha256()
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
        return value.hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    temp.replace(path)


def result_ref(path, index):
    result = read(path)
    if (not result.get('complete') or not result.get('eligible_for_gpt6_score')
            or result.get('task_package_sha256') != PACKAGE
            or result.get('evaluation_setting') != 'task_icl_v3'):
        raise ValueError('Invalid episode/package: ' + str(path))
    return {'episode_index': index, 'result': str(path), 'sha256': digest(path)}


def collect(report):
    refs = {r['episode_index']: r for r in report['inherited_episodes']}
    for attempt in report['attempts']:
        path = Path(attempt['output']) / 'result.json'
        if not path.is_file():
            continue
        batch = read(path)
        for row in batch['episodes']:
            if row.get('valid'):
                index = row['upstream_episode_index']
                ref = result_ref(path.parent / row['directory'] / 'result.json', index)
                if index in refs and refs[index] != ref:
                    raise ValueError('Duplicate valid episode: ' + str(index))
                refs[index] = ref
    if any(i not in TARGET for i in refs):
        raise ValueError('Unexpected episode index')
    for ref in refs.values():
        if digest(Path(ref['result'])) != ref['sha256']:
            raise ValueError('Completed result changed')
    return refs


def next_indices(refs):
    pending = [i for i in TARGET if i not in refs]
    if len(pending) > 1 and pending[1] == pending[0] + 1:
        return pending[:2]
    return pending[:1]


def verify_snapshot(output, report, supervisor):
    root = output / report.get('snapshot_directory', '.')
    if digest(supervisor) != report['supervisor_sha256']:
        raise ValueError('Supervisor source changed')
    for name, sha in report['source_hashes'].items():
        if digest(root / 'runner' / name) != sha:
            raise ValueError('Frozen source changed: ' + name)
    return root


def resource_failure(output):
    # Read trusted simulator errors only, never policy-generated text.
    for path in output.glob('episode_*/private/simulator.log'):
        with path.open(errors='replace') as stream:
            for line in stream:
                if ('[Error]' in line and ('PxgCudaDeviceMemoryAllocator failed to allocate' in line
                        or 'CUDA_ERROR_OUT_OF_MEMORY' in line)):
                    return True
    result = output / 'result.json'
    return result.is_file() and read(result)['state'] == 'blocked_on_resources'


def freeze(args):
    original = read(args.previous / 'cohort.json')
    config = read(args.previous / 'config.json')
    if (config['model'] != 'gpt-6-astra' or config['reasoning_effort'] != 'max'
            or config['task_packages']['26']['sha256'] != PACKAGE
            or config['generalization_profile'] != 'inv_cov'
            or config['generalization_split'] != 'unseen'
            or config['observation_profile'] != 'baseline_4cam'
            or config['decision_timeout_s'] is not None):
        raise ValueError('Experiment contract mismatch')
    for name, sha in original['source_hashes'].items():
        if digest(args.previous / 'runner' / name) != sha:
            raise ValueError('Previous source changed: ' + name)
    inherited = list(original['inherited_episodes'])
    for row in read(args.previous / 'evaluation/result.json')['episodes']:
        if row['valid']:
            inherited.append(result_ref(args.previous / 'evaluation' / row['directory'] / 'result.json',
                                        row['upstream_episode_index']))
    if sorted(r['episode_index'] for r in inherited) != list(range(5, 11)):
        raise ValueError('Expected exactly six inherited results, indices 5–10')
    shutil.copytree(args.previous / 'runner', args.output / 'runner')
    project = Path(__file__).resolve().parents[1]
    hashes, patches = dict(original['source_hashes']), []
    for name in ('src/gpt6_eval/cli.py', 'src/gpt6_eval/resource_wait.py'):
        old = args.previous / 'runner' / name
        new = project / name
        patches.extend(difflib.unified_diff(old.read_text().splitlines(True) if old.exists() else [],
                       new.read_text().splitlines(True), fromfile='previous/' + name, tofile='new/' + name))
        shutil.copyfile(new, args.output / 'runner' / name)
        hashes[name] = digest(new)
    (args.output / 'resource_fix.diff').write_text(''.join(patches))
    shutil.copyfile(__file__, args.output / 'supervisor.py')
    config.update(start_episode=11, num_episodes=14)
    write(args.output / 'config.json', config)
    report = {'state': 'preflight', 'created_at': now(), 'task_id': 26,
              'planned_indices': TARGET, 'inherited_episodes': inherited,
              'new_indices': list(range(11, 25)), 'workers': 2,
              'task_package_sha256': PACKAGE, 'source_hashes': hashes,
              'previous_cohort': str(args.previous), 'attempts': [],
              'supervisor_sha256': digest(args.output / 'supervisor.py'),
              'interpretation': 'Post-outcome extension to 20; variable historical concurrency. Infrastructure-only same-index retries authorized; no valid failure reruns.',
              'preparation_cost_count': 1}
    write(args.output / 'cohort.json', report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('previous', 'output', 'upstream', 'isaaclab', 'assets'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--resume', action='store_true')
    args = parser.parse_args()
    for name, value in vars(args).items():
        if isinstance(value, Path): setattr(args, name, value.resolve())
    if not args.resume:
        args.output.mkdir(parents=True, exist_ok=False)
    with (args.output / 'supervisor.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        report = read(args.output / 'cohort.json') if args.resume else freeze(args)
        snapshot_root = verify_snapshot(args.output, report, Path(__file__).resolve())
        sys.path.insert(0, str(snapshot_root / 'runner/src'))
        from gpt6_eval.resource_wait import wait_for_resources
        from gpt6_eval.knowledge import verify_package
        config = read(args.output / 'config.json')
        verify_package(Path(config['task_packages']['26']['path']), PACKAGE, 26, config)
        env = {**os.environ, 'PYTHONPATH': str(snapshot_root / 'runner/src'),
               'PYTHONHASHSEED': '0', 'OMNI_KIT_ACCEPT_EULA': 'YES', 'GPT6_EVAL_WAIT_FOR_GPU': '1'}
        env.pop('GPT6_EVAL_SMOKE_RELEASE', None)
        def interrupted(signum, frame):
            raise KeyboardInterrupt(f'Signal {signum}')
        signal.signal(signal.SIGTERM, interrupted)
        def save(state):
            report.update(state=state, updated_at=now())
            write(args.output / 'cohort.json', report)
        def execute(command, logfile):
            with logfile.open('xb') as log:
                child = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT)
                report['active_pid'] = child.pid
                save(report['state'])
                try:
                    return child.wait()
                finally:
                    if child.poll() is None:
                        child.terminate()
                        child.wait()  # batch cleans its own worker/simulator children
                    report['active_pid'] = None
        try:
            # Resume is only safe after prior children have exited; fail closed.
            if report.get('active_pid'):
                try: os.kill(report['active_pid'], 0)
                except ProcessLookupError: pass
                else: raise RuntimeError('Prior child may still be running; inspect before resume')
            isolation = args.output / f'isolation_{len(report["attempts"]):04d}_{time.time_ns()}'
            save('isolation')
            code = execute([sys.executable, '-m', 'gpt6_eval.doctor', '--config', str(args.output / 'config.json'),
                            '--output', str(isolation)], isolation.with_suffix('.log'))
            if code: raise RuntimeError('Isolation checks failed')
            report.pop('error', None)  # Prior interruption retained in recovery archive.
            while True:
                refs = collect(report)
                report['valid_episodes'] = [refs[i] for i in sorted(refs)]
                report['completed_count'] = len(refs)
                indices = next_indices(refs)
                if not indices:
                    save('completed')
                    return
                save('waiting_for_resources')
                wait_for_resources(args.output / 'resource_wait.json', len(indices))
                attempt_id = len(report['attempts'])
                base = args.output / f'attempt_{attempt_id:04d}'
                cfg = base.with_suffix('.config.json')
                write(cfg, {**config, 'start_episode': indices[0], 'num_episodes': len(indices)})
                command = [sys.executable, '-u', '-m', 'gpt6_eval.batch', '--config', str(cfg), '--task', '26',
                           '--workers', '2', '--startup-timeout-s', '600', '--output', str(base),
                           '--python', sys.executable, '--upstream', str(args.upstream), '--isaaclab', str(args.isaaclab),
                           '--assets', str(args.assets)]
                attempt = {'indices': indices, 'output': str(base), 'started_at': now(), 'argv': command,
                           'snapshot_directory': report.get('snapshot_directory', '.'),
                           'supervisor_sha256': report['supervisor_sha256'],
                           'source_hashes': report['source_hashes']}
                report['attempts'].append(attempt)
                save('evaluation')
                code = execute(command, base.with_suffix('.log'))
                attempt.update(returncode=code, ended_at=now())
                collect(report)  # check eligible reports even on partial batch completion
                if code:
                    if resource_failure(base):
                        attempt['recovery'] = 'Resource failure: preserve attempts, wait, retry only unscored indices'
                        save('resource_cooldown')
                        time.sleep(60)
                    else:
                        raise RuntimeError('Unexpected infrastructure error; requires diagnosis before retry')
        except BaseException as exc:
            report['error'] = f'{type(exc).__name__}: {exc}'
            save('needs_repair')
            raise


if __name__ == '__main__':
    main()
