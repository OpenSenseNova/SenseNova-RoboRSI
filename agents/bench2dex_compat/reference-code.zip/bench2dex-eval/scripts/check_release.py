#!/usr/bin/env python3
"""Check a source release for excluded artifacts, likely secrets and stale host paths.

This deterministic local scan prints locations/types only, never matched secret
values. It is a release hygiene check, not proof of absence of every possible secret.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

EXCLUDED_DIRS = {'.git', '.codex', 'runs', 'private', 'maintenance', 'previews',
                 '__pycache__', '.venv', 'build', 'dist', '.cache'}
EXCLUDED_FILES = {'auth.json', 'PROJECT_MEMORY.md', '.env'}
EXTENSIONS = {'.py', '.sh', '.md', '.json', '.toml', '.in'}
SPECIAL = {'.gitignore', 'SHA256SUMS'}
PATTERNS = {
    'private key': re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
    'provider credential': re.compile(r'\b(?:sk-[A-Za-z0-9_-]{20,}|hf_[A-Za-z0-9]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|AKIA[A-Z0-9]{16})\b'),
    'JWT credential': re.compile(r'\beyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\b'),
    'credential URL': re.compile(r'https?://[^\s/@:]+:[^\s/@]+@'),
    'host-specific path': re.compile(r'(?:/ho' r'me/(?!policy(?:[\s/\"\x27)]|$))[A-Za-z0-9_.-]+|/Use' r'rs/[A-Za-z0-9_.-]+|/da' r'ta/shared/|[A-Za-z]:\\Use' r'rs\\)'),
    'email address': re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b'),
    'credential assignment': re.compile(r'''(?i)(?:api_key|access_token|refresh_token|client_secret|password)["']?\s*[:=]\s*["'][A-Za-z0-9_./+=-]{16,}["']'''),
}


def scan_content(text):
    return [{'kind': kind, 'line': text.count('\n', 0, match.start()) + 1}
            for kind, regex in PATTERNS.items() for match in regex.finditer(text)]


def audit(root):
    findings, names = [], []
    for path in sorted(root.rglob('*')):
        rel = path.relative_to(root)
        if path.is_symlink():
            findings.append({'path': str(rel), 'kind': 'symlink'})
            continue
        if path.is_dir():
            if path.name in EXCLUDED_DIRS or path.name.endswith('.egg-info'):
                findings.append({'path': str(rel), 'kind': 'excluded directory'})
            continue
        if not path.is_file():
            findings.append({'path': str(rel), 'kind': 'special file'})
            continue
        names.append(str(rel))
        if path.name in EXCLUDED_FILES or (path.suffix not in EXTENSIONS and path.name not in SPECIAL):
            findings.append({'path': str(rel), 'kind': 'excluded or unexpected file type'})
        try:
            contents = path.read_text(encoding='utf-8')
        except UnicodeError:
            findings.append({'path': str(rel), 'kind': 'binary/non-UTF8 file'})
            continue
        findings.extend({'path': str(rel), **row} for row in scan_content(contents))
    checksums = root / 'SHA256SUMS'
    if checksums.exists():
        listed = set()
        for line in checksums.read_text().splitlines():
            try:
                expected, name = line.split('  ', 1)
                relative = Path(name)
                if relative.is_absolute() or '..' in relative.parts or name in listed:
                    raise ValueError('unsafe or duplicate checksum path')
                listed.add(name)
                actual = hashlib.sha256((root / name).read_bytes()).hexdigest()
                if actual != expected:
                    findings.append({'path': name, 'kind': 'checksum mismatch'})
            except (ValueError, OSError):
                findings.append({'kind': 'invalid or missing checksum entry'})
        if listed != set(names) - {'SHA256SUMS'}:
            findings.append({'kind': 'checksum file does not cover exactly the release files'})
    return {'passed': not findings, 'files_checked': len(names),
            'checksums_present': checksums.exists(), 'findings': findings}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    report = audit(args.root.resolve())
    print(json.dumps(report, indent=2))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
