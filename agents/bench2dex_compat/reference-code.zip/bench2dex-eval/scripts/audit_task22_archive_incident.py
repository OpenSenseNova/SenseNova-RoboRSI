"""Read-only archive inspection; write a separate incident record, not scores."""
import json
from datetime import datetime, timezone
from pathlib import Path
from finalize_task22_ten import ROOT, read, sha


def main():
    state = read(ROOT / 'state.json')
    refs = state['tasks']['22']['valid_episodes']
    failures, checked, critical = [], 0, []
    for ref in refs:
        root = Path(ref['result']).parent
        integrity = read(root / 'integrity.json')
        result = read(root / 'result.json')
        for relative in ['result.json', 'private/manifest.json', result['official_results_path'],
                         'episode_0000/private/invocation.json', 'episode_0000/private/prompt.md']:
            p = root / relative
            critical.append({'episode_index': ref['episode_index'], 'path': str(p),
                             'matches': sha(p) == integrity[relative]})
        for p in sorted((root / 'episode_0000/private/actions').glob('*.json')):
            checked += 1
            expected = integrity[str(p.relative_to(root))]
            actual = sha(p)
            if actual != expected:
                failures.append({'episode_index': ref['episode_index'], 'path': str(p),
                    'expected_sha256': expected, 'actual_sha256': actual,
                    'size': p.stat().st_size, 'first_24_bytes_hex': p.read_bytes()[:24].hex()})
    report = {'state': 'final_audit_blocked', 'task_id': 22,
        'checked_at': datetime.now(timezone.utc).isoformat(), 'action_files_checked': checked,
        'action_hash_mismatches': failures, 'critical_file_checks': critical,
        'recorded_complete_episode_indices': [r['episode_index'] for r in refs],
        'aggregate_score_certified': False, 'cause': 'Unknown archive integrity failure; not established as a policy or harness failure.',
        'preservation': 'No original bytes changed. No valid episode rerun. Existing campaign supervisor is untouched.',
        'next_step': 'Find a preserved copy matching each original integrity SHA256; never replace expected hashes or reconstruct evidence as if original. Investigate storage if no authentic copies are available.',
        'auditor_sha256': sha(Path(__file__))}
    p = ROOT / 'task_22/archive_integrity_incident_20260924.json'
    with p.open('x') as f:
        json.dump(report, f, indent=2); f.write('\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'critical_file_checks'}, indent=2))
    print('Critical file failures:', sum(not x['matches'] for x in critical))


if __name__ == '__main__':
    main()
