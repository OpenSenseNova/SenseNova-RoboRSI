"""Release the user-authorized reader transition after concrete validation."""
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
from datetime import datetime, timezone


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, required=True)
    args = p.parse_args(); root = args.root.resolve()
    audit = root / 'repairs/trusted_reader_v4_20260928'
    read = lambda p: json.loads(Path(p).read_text())
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    info = read(audit / 'new_snapshot.json'); snap = root / info['snapshot']
    sys.path.insert(0, str(snap / 'runner/src'))
    from gpt6_eval.knowledge import verify_package
    from gpt6_eval.core import write_json
    spec = importlib.util.spec_from_file_location('reader_supervisor', snap / 'supervisor.py')
    host = importlib.util.module_from_spec(spec); spec.loader.exec_module(host)
    with (root / 'supervisor.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        state = read(root / 'state.json'); plan = read(root / 'campaign.json')
        before = read(audit / 'state.before.json')
        if state['snapshot'] != 'snapshots/v3_throughput_memory' or state['state'] != 'stopped_by_request':
            raise ValueError('Unexpected state or concurrent transition')
        expected_error = f'training exited -2: {root}/task_21/0053_training'
        if state.get('error') != expected_error:
            raise ValueError('Do not clear an unexpected error')
        if any(not j.get('ended_at') for j in state['jobs']):
            raise ValueError('Undrained campaign jobs')
        for j in state['jobs'][-2:]:
            if Path(f'/proc/{j["pid"]}').exists():
                raise ValueError('Old child still exists')
        if sha(root / 'campaign.json') != state['plan_sha256'] or state['plan_sha256'] != before['plan_sha256']:
            raise ValueError('Plan changed')
        for version, hashes in ((root / state['snapshot'], state['source_hashes']), (snap, info['source_hashes'])):
            for name, digest in hashes.items():
                if sha(version / 'runner' / name) != digest:
                    raise ValueError('Frozen source changed: ' + name)
        if sha(snap / 'supervisor.py') != info['supervisor_sha256']:
            raise ValueError('Supervisor changed')
        if sha(snap / 'base_config.json') != state['base_config_sha256'] or info['base_config_sha256'] != state['base_config_sha256']:
            raise ValueError('Experimental config changed')
        allowed = {'src/gpt6_eval/icl.py', 'src/gpt6_eval/isolation.py',
                   'src/gpt6_eval/demo_reader.py', 'src/gpt6_eval/demo_reader_client.py',
                   'prompts/preparation_reader.md'}
        for name, digest in info['source_hashes'].items():
            if name.startswith(('src/', 'prompts/', 'configs/')) and name not in allowed:
                if state['source_hashes'].get(name) != digest:
                    raise ValueError('Unapproved experimental change: ' + name)
        for name in state['source_hashes']:
            if name.startswith(('src/', 'prompts/', 'configs/')) and name not in info['source_hashes']:
                raise ValueError('Missing prior source')
        for name in ('regression.log', 'reader_tests.log'):
            if not (audit / name).read_text().rstrip().endswith('OK'):
                raise ValueError('Validation failed: ' + name)
        host.successful('isolation', audit / 'isolation')
        bench = read(audit / 'real_validation/result.json')
        if bench['state'] != 'passed' or not bench['all_demo_0000_images_identical'] or bench['images_compared'] != 2828:
            raise ValueError('Real complete-demo parity absent')
        training_path = audit / 'task21_index'
        training = host.successful('training', training_path)
        if training.get('access_mode') != 'trusted_reader_v1' or training['source_hashes'] != info['source_hashes']:
            raise ValueError('Wrong indexed source version')
        if sha(training_path / 'manifest.json') != bench['training_manifest_sha256']:
            raise ValueError('Index changed after validation')
        cfg = read(snap / 'base_config.json'); results = []; packages = []
        for key, task in state['tasks'].items():
            if task['target_valid_count'] != before['tasks'][key]['target_valid_count']:
                raise ValueError('Counts changed')
            if task.get('package') != before['tasks'][key].get('package'):
                raise ValueError('Existing package reference changed')
            if task.get('package'):
                ref = task['package']; verify_package(Path(ref['path']), ref['sha256'], task['task_id'], cfg)
                packages.append({'task_id': task['task_id'], **ref})
                current = host.collect(task)
                previous = host.collect(before['tasks'][key])
                if current != previous:
                    raise ValueError('Completed results changed')
                results.extend(current.values())
        prerequisite = Path(plan['prerequisite_cohort']).with_name('cohort_result.json')
        if sha(prerequisite) != state['prerequisite_result_sha256']:
            raise ValueError('Task26 result changed')
        host.successful('smoke', state['jobs'][54]['output'])
        if state['tasks']['12']['smoke_workers'] != 4:
            raise ValueError('Task12 completed residency evidence missing')
        shutil.copyfile(root / 'state.json', audit / 'state.before_activation.json')
        at = datetime.now(timezone.utc).isoformat()
        validation = {'state': 'passed', 'at': at, 'snapshot': info,
                      'completed_campaign_results_verified': len(results),
                      'task26_results_unchanged': True, 'packages_verified': packages,
                      'real_benchmark': bench, 'interrupted_job': 53,
                      'no_raw_data_policy_access': True, 'ten_episode_plan_unchanged': True,
                      'prior_task22_archive_caveat_retained': True,
                      'validation_hashes': {n: sha(audit / n) for n in
                          ('regression.log', 'reader_tests.log', 'real_validation/result.json', 'isolation/result.json')},
                      'activation_script_sha256': sha(__file__)}
        write_json(audit / 'validation.json', validation)
        for jobs in [state['jobs'], state['tasks']['21']['jobs']]:
            for job in jobs:
                if job['id'] == 53:
                    job['recovery'] = 'User-authorized cancellation of bulk PNG export; original attempt retained, replaced by trusted reader index'
        # This no-model index was produced by the exact frozen validated runner.
        state['tasks']['21'].update(training=str(training_path), demonstration_access='trusted_reader_v1')
        state.update(**info, error=None, state='running', updated_at=at,
                     reader_validation=str(audit / 'validation.json'))
        write_json(root / 'state.json', state)
        request = read(audit / 'request.json'); request.update(state='validated_and_released', released_at=at)
        write_json(audit / 'request.json', request)
        write_json(audit / 'activation.json', {'at': at, 'state': 'released', 'snapshot': info['snapshot']})
    command = [plan['runtime']['python'], '-u', str(snap / 'supervisor.py'), '--output', str(root)]
    shell = 'exec ' + shlex.join(command) + ' >> ' + shlex.quote(str(root / 'supervisor.log')) + ' 2>&1'
    subprocess.run(['tmux', 'new-session', '-d', '-s', 'bench2dex-all-icl10', shell], check=True)
    print('Trusted reader activated; existing campaign resumed')


if __name__ == '__main__':
    main()
