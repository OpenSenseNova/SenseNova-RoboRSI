#!/usr/bin/env bash
# Launch in the foreground; use nohup or a terminal multiplexer for detachment.
set -euo pipefail
eval_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
: "${ISAACLAB_PYTHON:?Set ISAACLAB_PYTHON to your installed IsaacLab Python executable}"
export PYTHONPATH="$eval_root/src${PYTHONPATH:+:$PYTHONPATH}"
exec "${EVAL_PYTHON:-python3}" -u -m gpt6_eval.batch \
  --task 26 --config "$eval_root/configs/task26_pilot8.json" \
  --upstream "${BENCH2DEX_ROOT:-$eval_root/../Bench2Dex}" \
  --isaaclab "${ISAACLAB_ROOT:-$eval_root/../IsaacLab}" \
  --assets "${BENCH2DEX_ASSETS:-$eval_root/../dex2bench_dataset}" \
  --python "$ISAACLAB_PYTHON" "$@"
