"""Launch the seven-episode extension with a startup-clock infrastructure fix.

No preparation, policy prompt, simulator code, or completed result is modified.
The original incomplete six-episode experiment remains a separate artifact.
"""
import argparse
import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from datetime import datetime, timezone


def digest(path):
    with path.open('rb') as stream:
        value = hashlib.sha256()
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
        return value.hexdigest()


def write(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    temp.replace(path)


def now():
    return datetime.now(timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('previous', 'output', 'upstream', 'isaaclab', 'assets'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    args.previous, args.output = args.previous.resolve(), args.output.resolve()
    previous = args.previous
    config = json.loads((previous / 'test_config.json').read_text())
    original = json.loads((previous / 'workflow.json').read_text())
    batch = json.loads((previous / 'evaluation/result.json').read_text())
    package_hash = 'd3ae8ddaa9c45728b25f11ea95e2018e4561625e81316dd1f2eadd66da06d7f1'
    if (original['task_id'] != 26 or config['model'] != 'gpt-6-astra'
            or config['reasoning_effort'] != 'max'
            or config['task_packages']['26']['sha256'] != package_hash
            or config['generalization_profile'] != 'inv_cov'
            or config['generalization_split'] != 'unseen'
            or config['observation_profile'] != 'baseline_4cam'
            or config['decision_timeout_s'] is not None):
        raise ValueError('Original experiment contract mismatch')
    inherited = []
    for index in (5, 6, 7):
        rows = [r for r in batch['episodes'] if r['upstream_episode_index'] == index]
        if len(rows) != 1 or not rows[0]['valid']:
            raise ValueError('Missing valid inherited episode')
        row = rows[0]
        result_path = previous / 'evaluation' / row['directory'] / 'result.json'
        result = json.loads(result_path.read_text())
        if not result['eligible_for_gpt6_score'] or result['task_package_sha256'] != package_hash:
            raise ValueError('Inherited model/package eligibility mismatch')
        inherited.append({'episode_index': index, 'result': str(result_path),
                          'sha256': digest(result_path)})
    if any(r['valid'] and r['upstream_episode_index'] in range(8, 15) for r in batch['episodes']):
        raise ValueError('New schedule overlaps a scored episode')
    for relative, expected in original['source_hashes'].items():
        if digest(previous / 'runner' / relative) != expected:
            raise ValueError('Original frozen source changed: ' + relative)
    args.output.mkdir(parents=True, exist_ok=False)
    shutil.copytree(previous / 'runner', args.output / 'runner')
    # Freeze only the two trusted orchestration changes; retain all other
    # original runner bytes, especially policy code/prompts and simulator code.
    project = Path(__file__).resolve().parents[1]
    patches = []
    source_hashes = dict(original['source_hashes'])
    for relative in ('src/gpt6_eval/batch.py', 'src/gpt6_eval/cli.py'):
        old = previous / 'runner' / relative
        new = project / relative
        patches.extend(difflib.unified_diff(old.read_text().splitlines(True),
                                          new.read_text().splitlines(True),
                                          fromfile='original/' + relative, tofile='fixed/' + relative))
        shutil.copyfile(new, args.output / 'runner' / relative)
        source_hashes[relative] = digest(new)
    (args.output / 'startup_fix.diff').write_text(''.join(patches))
    shutil.copyfile(__file__, args.output / 'launch_source.py')
    config = {**config, 'start_episode': 8, 'num_episodes': 7}
    write(args.output / 'config.json', config)
    report = {
        'state': 'preflight', 'created_at': now(), 'task_id': 26,
        'prior_experiment': str(previous), 'inherited_episodes': inherited,
        'new_episode_indices': list(range(8, 15)), 'planned_combined_episode_indices': list(range(5, 15)),
        'planned_combined_count': 10, 'workers': 3, 'waves': [[8, 9, 10], [11, 12, 13], [14]],
        'startup_timeout_s': 600, 'previous_startup_timeout_s': 600,
        'startup_clock_origin': 'simulator_launch_after_asset_verification',
        'official_policy_budget': 871, 'model': 'gpt-6-astra', 'reasoning_effort': 'max',
        'task_package_sha256': package_hash, 'source_hashes': source_hashes,
        'original_source_hashes': original['source_hashes'],
        'source_unchanged': False, 'policy_and_simulator_unchanged': True,
        'infrastructure_patch': 'startup_fix.diff',
        'config_changes': {'start_episode': [5, 8], 'num_episodes': [6, 7]},
        'prior_episode8': 'Infrastructure interruption during asset hashing, before simulator or inference; retained in original run.',
        'interpretation': 'User-authorized extension after inspecting first three results; all three retained. Not the original six-episode protocol.',
        'preparation_cost_count': 1, 'stages': [],
    }
    write(args.output / 'cohort.json', report)
    env = {**os.environ, 'PYTHONPATH': str(args.output / 'runner/src'),
           'PYTHONHASHSEED': '0', 'OMNI_KIT_ACCEPT_EULA': 'YES'}
    env.pop('GPT6_EVAL_SMOKE_RELEASE', None)
    base = [sys.executable, '-u', '-m']
    stages = [
        ('isolation', base + ['gpt6_eval.doctor', '--config', str(args.output / 'config.json'),
                             '--output', str(args.output / 'isolation')]),
        ('evaluation', base + ['gpt6_eval.batch', '--config', str(args.output / 'config.json'),
             '--task', '26', '--workers', '3', '--startup-timeout-s', '600', '--mode', 'codex',
             '--output', str(args.output / 'evaluation'), '--python', sys.executable,
             '--upstream', str(args.upstream.resolve()), '--isaaclab', str(args.isaaclab.resolve()),
             '--assets', str(args.assets.resolve())]),
    ]
    try:
        for name, command in stages:
            report['state'] = name
            stage = {'name': name, 'argv': command, 'started_at': now(), 'returncode': None}
            report['stages'].append(stage)
            write(args.output / 'cohort.json', report)
            print(f'{now()} Starting {name}', flush=True)
            with (args.output / (name + '.log')).open('xb') as log:
                stage['returncode'] = subprocess.call(command, env=env, stdout=log, stderr=subprocess.STDOUT)
            stage['ended_at'] = now()
            write(args.output / 'cohort.json', report)
            if stage['returncode']:
                raise RuntimeError(f'{name} exited {stage["returncode"]}; no automatic retry')
        result = json.loads((args.output / 'evaluation/result.json').read_text())
        if result['state'] != 'completed' or not result['eligible_for_gpt6_score'] or result['scored_episodes'] != 7:
            raise RuntimeError('Seven-episode completion/eligibility gate failed')
        report['state'] = 'completed'
    except BaseException as error:
        report.update(state='stopped_on_error', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        report['ended_at'] = now()
        write(args.output / 'cohort.json', report)


if __name__ == '__main__':
    main()
