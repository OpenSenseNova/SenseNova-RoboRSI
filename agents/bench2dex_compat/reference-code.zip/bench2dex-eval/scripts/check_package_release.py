#!/usr/bin/env python3
"""Inspect the matching dataset ZIPs, including text and image/array metadata.

Run after installing the evaluation source with its data/test extras. Findings
report paths and categories, never matched credentials. Does not execute payloads.
"""
import argparse
import ast
import io
import json
from pathlib import Path
import tempfile
import tokenize
import zipfile

import numpy as np
from PIL import Image

from check_release import scan_content, PATTERNS
from gpt6_eval.cli import ROOT, load_config
from gpt6_eval.knowledge import verify_package
from gpt6_eval.packages import read_catalog, extract_verified

TEXT_SUFFIXES = {'.md', '.json', '.py', '.urdf', '.sha256', '.csv', '.txt'}


def scan_text(text, python=False):
    findings = scan_content(text)
    if python:
        ast.parse(text)
        # NumPy matrix products can resemble an email address (name @ module.attr).
        operators = [(t.start[0], t.start[1]) for t in tokenize.generate_tokens(io.StringIO(text).readline)
                     if t.type == tokenize.OP and t.string == '@']
        actual_email_lines = set()
        for match in PATTERNS['email address'].finditer(text):
            line = text.count('\n', 0, match.start()) + 1
            start = match.start() - (text.rfind('\n', 0, match.start()) + 1)
            if not any(row == line and start <= col < start + len(match.group()) for row, col in operators):
                actual_email_lines.add(line)
        findings = [f for f in findings if f['kind'] != 'email address' or f['line'] in actual_email_lines]
    return findings


def audit(dataset, catalog_path):
    catalog = read_catalog(catalog_path)
    config = load_config(ROOT / 'configs/icl_base.json')
    findings = []
    counts = {'packages': 0, 'files': 0, 'images': 0, 'arrays': 0, 'text_files': 0}
    for row in catalog['packages']:
        archive = dataset / row['archive']
        with tempfile.TemporaryDirectory(prefix='package-audit-') as temporary:
            root = Path(temporary) / 'package'
            extract_verified(archive, root, row)
            verify_package(root, row['manifest_sha256'], row['task_id'], config)
            counts['packages'] += 1
            for path in sorted(root.rglob('*')):
                if not path.is_file():
                    continue
                counts['files'] += 1
                location = f'task_{row["task_id"]:02d}/' + str(path.relative_to(root))
                text = None
                if path.suffix in TEXT_SUFFIXES:
                    text = path.read_text()
                    counts['text_files'] += 1
                elif path.suffix in {'.jpg', '.png'}:
                    with Image.open(path) as picture:
                        picture.verify()
                    with Image.open(path) as picture:
                        metadata = {k: str(v) for k, v in picture.info.items()
                                    if k not in {'dpi', 'jfif', 'jfif_version', 'jfif_unit', 'jfif_density'}}
                        if metadata or picture.getexif():
                            findings.append({'path': location, 'kind': 'image metadata requires review'})
                    counts['images'] += 1
                elif path.suffix == '.npz':
                    with np.load(path, allow_pickle=False) as arrays:
                        for key in arrays.files:
                            value = arrays[key]  # Object/pickled arrays fail here.
                            counts['arrays'] += 1
                            if value.dtype.kind in 'SUV':
                                for finding in scan_text(repr(value.tolist())):
                                    findings.append({'path': location, 'array': key, **finding})
                else:
                    findings.append({'path': location, 'kind': 'unexpected file type'})
                if text is not None:
                    for finding in scan_text(text, python=path.suffix == '.py'):
                        findings.append({'path': location, **finding})
                    if 'rollout-' in text:
                        findings.append({'path': location, 'kind': 'internal session filename'})
    return {'passed': not findings, 'counts': counts, 'findings': findings,
            'scope': 'Heuristic privacy checks and exact integrity; no execution or proof of absence of all sensitive content'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dataset', type=Path, required=True)
    parser.add_argument('--catalog', type=Path, default=ROOT / 'configs/icl_packages.json')
    args = parser.parse_args()
    try:
        report = audit(args.dataset, args.catalog)
    except (OSError, ValueError, SyntaxError, zipfile.BadZipFile) as exc:
        parser.exit(1, f'Package audit failed: {type(exc).__name__}\n')
    print(json.dumps(report, indent=2))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
