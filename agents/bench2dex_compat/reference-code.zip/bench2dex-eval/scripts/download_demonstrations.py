"""Resumable full official demonstration download, isolated from scoring assets.

Run with the existing Hugging Face environment. Uses hf download, pins revision,
records the full inventory, and verifies sizes and published LFS SHA256 hashes.
No evaluation, model inference, asset replacement, or dataset extraction occurs.
"""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone

REPO = 'Bench2Dex/teleopdata'
REVISION = 'b195787c65046083e6a43776b67bdf1389dfa3eb'


def now():
    return datetime.now(timezone.utc).isoformat()


def save(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--workers', type=int, default=2)
    args = parser.parse_args()
    if not 1 <= args.workers <= 8:
        parser.error('workers must be between 1 and 8')
    root = args.output.resolve()
    root.mkdir(parents=True, exist_ok=True)
    logs = root / '.download_logs'
    logs.mkdir(exist_ok=True)
    lock = (logs / 'download.lock').open('a')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise SystemExit('A downloader is already running for this destination')
    hf = Path(sys.executable).parent / 'hf'
    if not hf.is_file():
        raise RuntimeError('Use the installed Hugging Face environment Python')
    from huggingface_hub import HfApi
    info = HfApi().dataset_info(REPO, revision=REVISION, files_metadata=True)
    if info.sha != REVISION:
        raise RuntimeError('Dataset revision mismatch')
    inventory = []
    for entry in sorted(info.siblings, key=lambda e: e.rfilename):
        name = Path(entry.rfilename)
        if name.is_absolute() or '..' in name.parts or entry.size is None:
            raise RuntimeError('Invalid dataset inventory entry')
        lfs = entry.lfs
        checksum = (lfs.get('sha256') if isinstance(lfs, dict)
                    else getattr(lfs, 'sha256', None))
        inventory.append({'path': entry.rfilename, 'bytes': entry.size, 'sha256': checksum})
    record = {'repo': REPO, 'revision': REVISION, 'files': inventory}
    manifest = logs / 'inventory.json'
    if manifest.exists() and json.loads(manifest.read_text()) != record:
        raise RuntimeError('Existing inventory differs; choose a new destination')
    save(manifest, record)
    total = sum(x['bytes'] for x in inventory)
    remaining = sum(x['bytes'] for x in inventory
                    if not (root / x['path']).is_file()
                    or (root / x['path']).stat().st_size != x['bytes'])
    if shutil.disk_usage(root).free < remaining + 20 * 1024**3:
        raise RuntimeError('Insufficient space including a 20 GiB reserve')
    started = time.monotonic()
    state = {'repo': REPO, 'revision': REVISION, 'started_at': now(),
             'files': len(inventory), 'total_bytes': total, 'workers': args.workers,
             'status': 'downloading', 'verification': 'pending'}
    status_path = logs / 'status.json'
    save(status_path, state)
    env = {**os.environ, 'HF_HUB_DISABLE_XET': '1',
           'HF_HUB_CACHE': str(root / '.cache/huggingface/hub'),
           'HF_XET_CACHE': str(root / '.cache/huggingface/xet')}
    cmd = [str(hf), 'download', REPO, '--repo-type', 'dataset', '--revision', REVISION,
           '--local-dir', str(root), '--max-workers', str(args.workers)]
    try:
        for attempt in range(1, 13):
            state.update(attempt=attempt, updated_at=now(), status='downloading')
            save(status_path, state)
            print(f'{now()} Download attempt {attempt}: {len(inventory)} files, {total} bytes', flush=True)
            rc = subprocess.call(cmd, env=env)
            if rc == 0:
                break
            if attempt == 12:
                raise RuntimeError(f'hf download failed after {attempt} attempts; exit {rc}')
            state.update(status='retry_wait', last_exit_code=rc, updated_at=now())
            save(status_path, state)
            print(f'{now()} Waiting 310 seconds before resuming; existing files retained', flush=True)
            time.sleep(310)
        state.update(status='verifying', updated_at=now())
        save(status_path, state)
        for index, entry in enumerate(inventory, 1):
            path = root / entry['path']
            if not path.is_file() or path.stat().st_size != entry['bytes']:
                raise RuntimeError(f"Missing or wrong-sized file: {entry['path']}")
            if entry['sha256']:
                digest = hashlib.sha256()
                with path.open('rb') as stream:
                    for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
                        digest.update(block)
                if digest.hexdigest() != entry['sha256']:
                    raise RuntimeError(f"Checksum mismatch: {entry['path']}")
            if index % 50 == 0:
                state.update(verified_files=index, updated_at=now())
                save(status_path, state)
                print(f'{now()} Verified {index}/{len(inventory)} files', flush=True)
        state.update(status='complete', verification='passed', verified_files=len(inventory),
                     sha256_verified_files=sum(bool(x['sha256']) for x in inventory),
                     completed_at=now(), wall_seconds=time.monotonic()-started)
    except BaseException as error:
        state.update(status='stopped', error=f'{type(error).__name__}: {error}', updated_at=now())
        save(status_path, state)
        raise
    save(status_path, state)
    print(json.dumps(state, indent=2), flush=True)


if __name__ == '__main__':
    main()
