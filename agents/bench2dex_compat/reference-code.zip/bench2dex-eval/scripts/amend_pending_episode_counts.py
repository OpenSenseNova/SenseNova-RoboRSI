"""Apply an authorized sample-count amendment after the existing supervisor drains."""
import argparse
import copy
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import time


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, data):
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
    tmp.replace(path)


def revised_state(state, before, proposed, request):
    """Only untouched task schedules and campaign totals may change."""
    tasks=set(request['task_ids'])
    expected=copy.deepcopy(before)
    for task in expected['tasks']:
        if task['task_id'] in tasks:
            task.update(target_valid_count=5,new_episode_indices=list(range(5,10)))
    expected['planned_new_valid_episodes']-=5*len(tasks)
    expected['final_valid_episode_total_including_task26']-=5*len(tasks)
    # These two fields record authorization; they are never policy inputs.
    expected['amendments']=proposed['amendments']
    expected['execution_note']=proposed['execution_note']
    if expected!=proposed:
        raise ValueError('Amendment changes more than authorized episode counts')
    out=copy.deepcopy(state)
    for tid in tasks:
        task=out['tasks'][str(tid)]
        if (task.get('inherited') or task.get('valid_episodes')
                or any(j['stage']=='evaluation' for j in task['jobs'])):
            raise ValueError(f'Task {tid} has already been tested')
        if task['target_valid_count']!=10 or task['new_episode_indices']!=list(range(5,15)):
            raise ValueError('Unexpected previous task schedule')
        task.update(target_valid_count=5,new_episode_indices=list(range(5,10)))
    for task in proposed['tasks']:
        if task['task_id']==26:
            if task['target_valid_count']!=20:
                raise ValueError('Task26 prerequisite count changed')
            continue
        live=out['tasks'][str(task['task_id'])]
        if any(live[k]!=task[k] for k in ('target_valid_count','new_episode_indices')):
            raise ValueError('Plan and state targets disagree')
    if sum(t['target_valid_count'] for t in out['tasks'].values())+20!=proposed['final_valid_episode_total_including_task26']:
        raise ValueError('Wrong campaign denominator')
    return out


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',type=Path,required=True)
    ap.add_argument('--amendment',type=Path,required=True)
    args=ap.parse_args();root=args.root.resolve();folder=args.amendment.resolve()
    request=read(folder/'request.json')
    with (folder/'transition.lock').open('a') as owner:
        fcntl.flock(owner,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if (folder/'applied.json').exists():
            print('Already applied; do not launch a duplicate supervisor',flush=True);return
        write(folder/'transition.json',{'state':'waiting_for_current_jobs','pid':os.getpid()})
        while True:
            state=read(root/'state.json')
            if all(j.get('ended_at') for j in state['jobs']):
                with (root/'supervisor.lock').open('a') as lock:
                    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
                    except BlockingIOError:
                        time.sleep(2);continue
                    state=read(root/'state.json')
                    if state['state'] not in ('stopped_by_request','needs_repair'):
                        raise ValueError('Supervisor did not stop at the requested boundary')
                    if sha(root/'campaign.json')!=request['old_plan_sha256'] or state['plan_sha256']!=request['old_plan_sha256']:
                        raise ValueError('Another plan change needs reconciliation')
                    before=read(folder/'campaign.before.json');proposed=read(folder/'campaign.proposed.json')
                    new=revised_state(state,before,proposed,request)
                    snap=root/state['snapshot']
                    if sha(snap/'supervisor.py')!=state['supervisor_sha256']:
                        raise ValueError('Supervisor changed')
                    if sha(snap/'base_config.json')!=state['base_config_sha256']:
                        raise ValueError('Experimental config changed')
                    for name,digest in state['source_hashes'].items():
                        if sha(snap/'runner'/name)!=digest:raise ValueError('Frozen source changed')
                    for task in state['tasks'].values():
                        for ref in task.get('valid_episodes',[]):
                            if sha(Path(ref['result']))!=ref['sha256']:raise ValueError('Completed result changed')
                    stamp=datetime.now(timezone.utc).isoformat()
                    new.update(plan_sha256=sha(folder/'campaign.proposed.json'),updated_at=stamp,
                               state='needs_repair' if state.get('error') else 'running')
                    new.setdefault('plan_amendments',[]).append({'request':str(folder/'request.json'),'applied_at':stamp})
                    write(folder/'state.before_apply.json',state);write(folder/'state.proposed.json',new)
                    # Both replacements are journaled; a crash between them fails
                    # the supervisor's plan hash gate and is recoverable here.
                    temp=root/'campaign.amendment.tmp';temp.write_bytes((folder/'campaign.proposed.json').read_bytes());temp.replace(root/'campaign.json')
                    write(root/'state.json',new)
                    applied={'state':'applied','at':stamp,'task_ids':request['task_ids'],
                             'episodes_removed':5*len(request['task_ids']),'final_total':proposed['final_valid_episode_total_including_task26'],
                             'plan_sha256':new['plan_sha256'],'transition_script_sha256':sha(Path(__file__)),
                             'preserved_error':new.get('error'),'snapshot':new['snapshot']}
                    write(folder/'applied.json',applied)
                if not new.get('error'):
                    command=[proposed['runtime']['python'],'-u',str(snap/'supervisor.py'),'--output',str(root)]
                    shell='exec '+shlex.join(command)+' >> '+shlex.quote(str(root/'supervisor.log'))+' 2>&1'
                    # The old tmux pane closes immediately after releasing its
                    # lock. Avoid a transient same-session-name collision.
                    for _ in range(10):
                        if subprocess.run(['tmux','has-session','-t','bench2dex-all-icl10'],capture_output=True).returncode:
                            break
                        time.sleep(1)
                    subprocess.run(['tmux','new-session','-d','-s','bench2dex-all-icl10',shell],check=True)
                    applied['state']='resumed'
                else:applied['state']='applied_needs_infrastructure_repair'
                write(folder/'transition.json',applied)
                print(json.dumps(applied),flush=True);return
            time.sleep(15)


if __name__=='__main__':
    main()
