#!/usr/bin/env bash
# Operator-only asset setup; never launches a simulator or policy.
set -euo pipefail
eval_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
: "${ISAACLAB_PYTHON:?Set ISAACLAB_PYTHON to the installed runtime Python}"
: "${BENCH2DEX_ASSETS:?Set BENCH2DEX_ASSETS to the shared testing asset directory}"
export PYTHONPATH="$eval_root/src${PYTHONPATH:+:$PYTHONPATH}"
export HF_HUB_DISABLE_XET=1
download_dir="${BENCH2DEX_DOWNLOAD_LOGS:-$BENCH2DEX_ASSETS/.download_logs/all_tasks}"
mkdir -p "$download_dir"
# Prevent duplicate launches of this helper. Older manual hf commands do not
# use this lock: finish or interrupt those before starting this helper.
exec 9>"$download_dir/launcher.lock"
flock -n 9 || { echo "An all-task downloader is already running."; exit 1; }
for attempt in $(seq 1 12); do
  attempt_log="$download_dir/attempt_$(date -u +%Y%m%dT%H%M%S)_${attempt}.log"
  echo "Attempt $attempt/12; detailed progress: $attempt_log"
  if "$ISAACLAB_PYTHON" -u -m gpt6_eval.prepare_task26_assets \
      --all-tasks --upstream "${BENCH2DEX_ROOT:-$eval_root/../Bench2Dex}" \
      --destination "$BENCH2DEX_ASSETS" \
      --manifest "$download_dir/selection.json" \
      --download-workers "${BENCH2DEX_DOWNLOAD_WORKERS:-2}" 2>&1 | tee "$attempt_log"; then
    echo "DOWNLOAD_AND_CHECKSUM_VERIFICATION_COMPLETE"
    echo "All-task simulator readiness still requires dependency audits and embodiment smoke tests."
    exit 0
  fi
  if ! grep -Eq '429|Too Many Requests|rate limit' "$attempt_log"; then
    echo "Stopped on a non-rate-limit error; inspect $attempt_log before retrying."
    exit 1
  fi
  if (( attempt < 12 )); then
    echo "Rate limited; waiting 310 seconds before resuming. Completed files are retained."
    sleep 310
  fi
done
echo "Stopped after 12 rate-limited attempts. Rerun this helper later to resume."
exit 1
