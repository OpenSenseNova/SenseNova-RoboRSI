"""Measure a trusted no-model command's process-tree RSS (requires psutil)."""
import argparse
import json
from pathlib import Path
import subprocess
import time

import psutil


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--log', type=Path, required=True)
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ['--'] else args.command
    if args.report.exists() or args.log.exists():
        parser.error('Use new profiling output paths')
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.log.parent.mkdir(parents=True, exist_ok=True)
    peak, samples, started = 0, 0, time.monotonic()
    with args.log.open('xb') as stream:
        proc = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT)
        try:
            while proc.poll() is None:
                try:
                    root = psutil.Process(proc.pid)
                    rss = 0
                    for child in [root, *root.children(recursive=True)]:
                        try:
                            rss += child.memory_info().rss
                        except psutil.NoSuchProcess:
                            pass
                    peak = max(peak, rss)
                    samples += 1
                except psutil.NoSuchProcess:
                    pass
                time.sleep(.2)
        finally:
            if proc.poll() is None:
                proc.terminate()
                proc.wait(timeout=45)
            result = {'schema_version': 1, 'command': command, 'returncode': proc.returncode,
                      'peak_tree_rss_mib': peak / 2**20, 'samples': samples,
                      'wall_seconds': time.monotonic() - started,
                      'definition': 'Sampled aggregate process-tree RSS at 0.2s; shared pages may be counted more than once. Short smoke, not a full-episode peak guarantee.'}
            args.report.write_text(json.dumps(result, indent=2) + '\n')
            print(json.dumps(result), flush=True)
    raise SystemExit(proc.returncode)


if __name__ == '__main__':
    main()
