# Evaluation source instructions

Read docs/PROTOCOL.md and docs/IN_CONTEXT_LEARNING.md before changing evaluation
behavior. Preserve exact model identity, sensor boundaries, per-task budgets,
scoring and task-package integrity. Never expose evaluator data to the policy.
Use separate, new output directories. Never modify upstream repositories.
Keep credentials, generated runs and raw data out of source releases.
