"""Task62-only alias for the official replay files' historical scene label.

This changes neither the current scene nor the seen/collection eligibility
checks. The source inventory and the recorded old label are both pinned.
"""
import hashlib
import json

TASK = 62
REPO = 'Bench2Dex/teleopdata'
REVISION = 'b195787c65046083e6a43776b67bdf1389dfa3eb'
CURRENT_SCENE = '62_shoebox_accessory_pack'
RECORDED_SCENE = '62_pet_shoebox_accessory_pack'
ROBOT = 'multi_xarm7_with_leap'
SET_SHA256 = '9b204eb05f22f4cadef4ccc3b55f9d25a2a68378086e0cbd0a560ed694b4829a'


def source_set_digest(entries):
    rows = [{key: entry[key] for key in ('path', 'bytes', 'sha256')}
            for entry in entries]
    if len(rows) != 100 or len({row['path'] for row in rows}) != 100:
        raise ValueError('Task62 alias requires exactly 100 distinct pinned files')
    if any(not row['path'].startswith('dataset/62_shoebox_accessory_pack/replay-generalization/')
           or not row['path'].endswith('.hdf5') for row in rows):
        raise ValueError('Task62 alias source path mismatch')
    return hashlib.sha256(json.dumps(sorted(rows, key=lambda row: row['path']),
                          sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def disclosure():
    return {'id': 'task62_official_scene_name_alias_v1', 'task_id': TASK,
            'dataset_repo': REPO, 'dataset_revision': REVISION,
            'source_set_sha256': SET_SHA256, 'source_count': 100,
            'current_scene_name': CURRENT_SCENE, 'recorded_scene_name': RECORDED_SCENE,
            'scope': 'Historical name only; seen split, collection namespace, robot, task and scoring unchanged'}


def validate_selection(task, repo, revision, scene, robot, entries):
    if (task != TASK or repo != REPO or revision != REVISION
            or scene != CURRENT_SCENE or robot != ROBOT
            or source_set_digest(entries) != SET_SHA256):
        raise ValueError('Task62 official scene alias identity mismatch')
    return disclosure()


def validate_recorded_scene(current, robot, recorded, alias):
    if (alias != disclosure() or current != CURRENT_SCENE or robot != ROBOT
            or recorded != RECORDED_SCENE):
        raise ValueError('Task62 recorded scene alias mismatch')


def validate_training(training):
    alias = training.get('scene_alias')
    if alias is None:
        if training.get('task_id') == TASK:
            raise ValueError('Task62 alias disclosure missing')
        return
    rows = training['demonstrations']
    validate_selection(training['task_id'], training['dataset_repo'], training['dataset_revision'],
                       training['scene_name'], training['robot_key'], rows)
    if alias != disclosure() or any(row.get('recorded_scene_name') != RECORDED_SCENE
                                    or row.get('split') != 'seen'
                                    or row.get('collection_namespace') not in (None, 'collection')
                                    for row in rows):
        raise ValueError('Task62 scene alias training disclosure mismatch')
