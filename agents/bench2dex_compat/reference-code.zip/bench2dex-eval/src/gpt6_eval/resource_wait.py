"""Host-only resource admission. Checks are not exclusive GPU reservations."""
import os
from pathlib import Path
import subprocess
import time

from .core import write_json
from .telemetry import utc_now

def worker_reservation_mib():
    """Explicit campaign host profile; legacy invocations retain10GiB."""
    value = int(os.environ.get('GPT6_EVAL_WORKER_RESERVATION_MIB', '10240'))
    if value not in (9216, 10240):
        raise ValueError('Unsupported worker memory reservation')
    return value


def memory_sample():
    """Whole-device usage and available host RAM; includes unrelated workloads."""
    values = subprocess.check_output(['nvidia-smi', '--id=0',
        '--query-gpu=memory.total,memory.used,memory.free',
        '--format=csv,noheader,nounits'], text=True, timeout=15)
    total, used, free = [int(v.strip()) for v in values.strip().split(',')]
    memory = dict(line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines())
    return {'at':utc_now(), 'gpu_total_mib':total, 'gpu_used_mib':used,
            'gpu_free_mib':free, 'ram_available_mib':int(memory['MemAvailable'].split()[0])//1024}


def snapshot(workers=1):
    gpu = int(subprocess.check_output(
        ['nvidia-smi', '--id=0', '--query-gpu=memory.free', '--format=csv,noheader,nounits'],
        text=True, timeout=15).strip())
    memory = dict(line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())
    ram = int(memory['MemAvailable'].split()[0]) // 1024
    required = worker_reservation_mib() * workers
    return {'checked_at': utc_now(), 'gpu_free_mib': gpu, 'ram_available_mib': ram,
            'required_gpu_mib': required, 'required_ram_mib': required,
            'admitted': gpu >= required and ram >= required}


def wait_for_resources(path, workers=1):
    query_timeouts = 0
    while True:
        try:
            report = snapshot(workers)
            # Campaign-only OS headroom; legacy frozen runs remain unchanged.
            headroom = int(os.environ.get('GPT6_EVAL_RAM_HEADROOM_MIB', '0'))
            if headroom < 0:
                raise ValueError('RAM headroom must be nonnegative')
            if headroom:
                report['required_ram_mib'] += headroom
                report['admitted'] = (report['admitted'] and
                    report['ram_available_mib'] >= report['required_ram_mib'])
        except subprocess.TimeoutExpired as exc:
            # A missing GPU reading is never permission to admit a worker.
            # Retry only this diagnosed transient probe fault, not arbitrary
            # configuration, permission, parsing or integrity errors.
            query_timeouts += 1
            report = {'checked_at': utc_now(), 'gpu_free_mib': None,
                      'ram_available_mib': None, 'required_gpu_mib': worker_reservation_mib() * workers,
                      'required_ram_mib': worker_reservation_mib() * workers, 'admitted': False,
                      'query_error': f'{type(exc).__name__}: {exc}'}
        report['query_timeouts_this_wait'] = query_timeouts
        write_json(path, report)
        if report['admitted']:
            return report
        time.sleep(15)


def before_simulator(output):
    # Opt in only for the new supervised cohort. Legacy invocations unchanged.
    if os.environ.get('GPT6_EVAL_WAIT_FOR_GPU') == '1':
        wait_for_resources(output / 'private/resource_admission.json')
