"""Verify archived bytes without exposing them to an evaluation policy."""
import argparse
import json
from pathlib import Path

from PIL import Image
import numpy as np

from .cli import hash_file
from .core import digest


def audit(root: Path):
    integrity = json.loads((root / "integrity.json").read_text())
    for relative, expected in integrity.items():
        path = root / relative
        if not path.is_file() or hash_file(path) != expected:
            raise ValueError(f"Artifact changed or missing: {relative}")
    count = 0
    for metadata in sorted(root.glob("episode_*/private/observations/*/observation.json")):
        obs = json.loads(metadata.read_text())
        for camera in obs["cameras"]:
            path = metadata.parent / Path(camera["path"]).name
            if hash_file(path) != camera["sha256"]:
                raise ValueError(f"PNG hash mismatch: {path}")
            rgb = np.asarray(Image.open(path).convert("RGB"))
            if digest(rgb.tobytes()) != camera["rgb_sha256"]:
                raise ValueError(f"RGB hash mismatch: {path}")
        count += 1
    return {"verified_artifacts": len(integrity), "verified_observations": count}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path)
    print(audit(parser.parse_args().run))


if __name__ == "__main__":
    main()
