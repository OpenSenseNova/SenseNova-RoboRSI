"""Policy-side file interface; copied into /interface in the isolated process."""
import json
from pathlib import Path
import sys
import time

def submit(payload_path, workspace=Path("/workspace"), transport=None):
    root = workspace / "input"
    transport = transport or workspace / ".action_transport"
    payload_path = Path(payload_path)
    if payload_path.resolve().is_relative_to(transport.resolve()):
        raise ValueError("Save the action payload outside the reserved transport directory")
    current = json.loads((root / "observation.json").read_text())
    payload = json.loads(payload_path.read_text())
    request = {"decision": current["decision"], "payload": payload}
    # Exclusive creation prevents concurrent helpers from overwriting requests.
    # The user payload is never changed or removed.
    with (transport / "submission.lock").open("x"):
        try:
            target = transport / "request.json"
            if target.exists():
                raise RuntimeError("An action submission is already pending")
            temp = transport / "request.tmp"
            temp.write_text(json.dumps(request, allow_nan=False))
            temp.replace(target)
            while True:
                if (root / "episode_done.json").exists():
                    return {"episode_done": True}
                nxt = json.loads((root / "observation.json").read_text())
                if nxt["decision"] > current["decision"]:
                    return nxt
                time.sleep(0.1)
        finally:
            (transport / "submission.lock").unlink()


if __name__ == "__main__":
    print(json.dumps(submit(Path(sys.argv[1])), allow_nan=False))
