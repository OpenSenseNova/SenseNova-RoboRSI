"""Bounded rolling admission for the separate, fixed-cohort 10x evaluation."""
from __future__ import annotations

import argparse
import copy
import fcntl
import json
import os
from pathlib import Path
import signal
import subprocess
import time

from .cli import ROOT
from .core import write_json
from .extension import SETTING, read, reference, require, storage_admission
from .extension_campaign import (SETTLED, original_gpu_queue_finished, refresh_storage,
                                 select_source, source_summary, supplemental_source, summarize)
from .knowledge import file_hash
from .resource_wait import memory_sample
from .telemetry import utc_now


def slot_key(slot):
    return f"{slot['task_id']:02d}_{slot['episode_index']:02d}"


def process_identity(pid):
    root = Path('/proc') / str(pid)
    fields = (root / 'stat').read_text().rsplit(')', 1)[1].split()
    require(fields[0] != 'Z', 'Process is a zombie')
    return {'pid': pid, 'start_ticks': fields[19],
            'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
            'argv': [part.decode() for part in (root / 'cmdline').read_bytes().split(b'\0') if part]}


def live_identity(expected):
    try:
        return process_identity(expected['pid']) == expected
    except (OSError, ValueError, IndexError):
        return False


def validate_retry_failure(attempt, approved):
    """Accept only unscored infrastructure failures with preserved cause evidence."""
    result = read(attempt['result']['path'])
    require(not result.get('complete') and not result.get('eligible_for_extension_score')
            and not result.get('eligible_for_gpt6_score'), 'Valid scored outcomes cannot be retried')
    require(result.get('extension', {}).get('replay_validation', {}).get('state') != 'diverged',
            'Replay divergence cannot be retried')
    service_messages = {
        'codex_model_capacity': 'Selected model is at capacity. Please try a different model.',
        'codex_api_credit_exhausted': (
            'stream disconnected before completion: You have no credits remaining. '
            'Add credits to continue using the API at https://platform.openai.com/settings/organization/billing/.'),
    }
    cause = approved.get('cause')
    if result.get('infrastructure_error'):
        require(cause not in service_messages, 'Diagnosed service failure has an unexpected aggregate error')
        return
    # Runtime policy-service errors are recorded on the episode, while the
    # aggregate infrastructure_error field covers setup/collection exceptions.
    # Require the exact diagnosed service failure, not merely a nonzero exit.
    require(cause in service_messages, 'Undiagnosed episode failure')
    episodes = result.get('episodes', [])
    require(len(episodes) == 1 and episodes[0].get('outcome') == 'infrastructure_error'
            and episodes[0].get('terminated_reason') == 'error'
            and episodes[0].get('error') == {
                'error': 'RuntimeError: Codex process failed with exit code 1', 'policy_failure': False}
            and episodes[0].get('official_success') is False, 'Not the diagnosed infrastructure episode')
    extension = result.get('extension', {})
    require(extension.get('state') == 'unresolved' and extension.get('success') is None
            and extension.get('lscr') is None and extension.get('replay_validated') is True
            and extension.get('replay_validation', {}).get('state') == 'verified',
            'Invalid service-failure replay or outcome')
    events_path = Path(attempt['output']) / 'episode_0000/private/codex.events.jsonl'
    require(reference(events_path) == approved.get('failed_events'), 'Service evidence changed or wrong attempt')
    events = [json.loads(line) for line in events_path.read_text().splitlines() if line.strip()]
    message = service_messages[cause]
    require(events[-2:] == [{'type': 'error', 'message': message},
                           {'type': 'turn.failed', 'error': {'message': message}}],
            'Service failure is not the terminal CLI event')


def validate_retry_lineage(record, key, approved):
    """Require contiguous, preserved, unscored execution attempts before a retry."""
    attempts = [row for row in record['attempts'] if row.get('output')]
    require(attempts and type(approved.get('next_attempt')) is int
            and approved['next_attempt'] == len(attempts) + 1, 'Unexpected retry lineage')
    parent = Path(attempts[0]['output']).parent
    for number, attempt in enumerate(attempts, 1):
        output = Path(attempt['output'])
        require(output == parent / f'attempt_{number:04d}' and attempt['slot'] == key
                and attempt['returncode'] != 0
                and attempt['result']['path'] == str(output / 'result.json')
                and reference(output / 'result.json') == attempt['result'],
                'Retry history changed or is not contiguous')
        result = read(output / 'result.json')
        require(not result.get('complete') and not result.get('eligible_for_extension_score')
                and not result.get('eligible_for_gpt6_score')
                and result.get('extension', {}).get('replay_validation', {}).get('state') != 'diverged',
                'Scored or divergent history cannot be retried')


def initialize(plan_path, plan):
    predecessor = plan['predecessor']
    require(reference(predecessor['snapshot']['path']) == predecessor['snapshot'], 'Predecessor snapshot changed')
    require(reference(predecessor['drain_receipt']['path']) == predecessor['drain_receipt'], 'Drain receipt changed')
    previous = read(predecessor['snapshot']['path'])
    receipt = read(predecessor['drain_receipt']['path'])
    require(receipt['identity'] == predecessor['identity'] and receipt['snapshot'] == predecessor['snapshot']
            and receipt['signal'] in ('SIGTERM', 'already_exited'), 'Unbound predecessor drain')
    require(previous['plan'] == predecessor['plan'] and previous['probe_verified'] is True,
            'Qualified predecessor required')
    slots = copy.deepcopy(previous['slots'])
    if previous.get('active'):
        require(not previous.get('error') and receipt['signal'] == 'SIGTERM', 'Unhealthy active predecessor')
        require(previous['active']['slot'] in slots, 'Missing predecessor source record')
        slots[previous['active']['slot']]['state'] = 'external_active'
    else:
        require(receipt['signal'] == 'already_exited' and not live_identity(predecessor['identity']),
                'Predecessor must be stopped before importing completed records')
        resolution = plan.get('retry_resolution')
        if resolution:
            require(reference(resolution['path']) == resolution, 'Retry resolution changed')
            repair = read(resolution['path'])
            require(repair['predecessor_state'] == predecessor['snapshot'] and repair['state'] == 'verified',
                    'Retry resolution is not bound to predecessor')
            for key, approved in repair['retries'].items():
                record = slots[key]
                attempt = record['attempts'][-1]
                require(record['state'] == 'needs_diagnosis' and attempt['returncode'] != 0
                        and attempt['result'] == approved['failed_result']
                        and reference(attempt['result']['path']) == attempt['result']
                        and record['source'] == approved['source'], 'Retry must preserve the diagnosed attempt and source')
                validate_retry_failure(attempt, approved)
                validate_retry_lineage(record, key, approved)
                record.update(state='ready', next_attempt=approved['next_attempt'], retry_resolution=resolution)
    return {'plan': reference(plan_path), 'slots': slots, 'active': {}, 'probe_verified': True,
            'qualification_imported': previous['qualification_imported'], 'started_at': utc_now(),
            'predecessor_active': previous.get('active'),
            'predecessor_imported': False if previous.get('active') else predecessor['snapshot']}


def validate_result(record, attempt):
    result_path = Path(attempt['output']) / 'result.json'
    result = read(result_path) if result_path.exists() else {}
    require(attempt.get('result') == (reference(result_path) if result else None), 'Attempt result binding changed')
    if result.get('infrastructure_error') and not result.get('complete') and not result.get('eligible_for_extension_score'):
        record['state'] = 'needs_diagnosis'
        return
    if result:
        source = record['source']['ref']
        require(result.get('evaluation_setting') == SETTING and result.get('baseline') == record['baseline']
                and result.get('extension', {}).get('source_result') == {
                    'path': source['result'], 'sha256': source['sha256']}, 'Result source or setting mismatch')
    if attempt['returncode'] == 0 and result.get('eligible_for_extension_score'):
        require(result['extension']['state'] == 'verified' and result['extension']['replay_validated'],
                'Unvalidated continuation')
        record.update(state='complete', extension=result['extension'])
    elif result.get('extension', {}).get('replay_validation', {}).get('state') == 'diverged':
        record.update(state='diverged', extension=result['extension'])
    else:
        record['state'] = 'needs_diagnosis'


def reconcile_predecessor(plan, state):
    if state['predecessor_imported']:
        return []
    predecessor = plan['predecessor']
    previous = read(Path(predecessor['control']) / 'state.json')
    require(previous['plan'] == predecessor['plan'] and previous['pid'] == predecessor['identity']['pid'],
            'Predecessor controller identity changed')
    snapshot = read(predecessor['snapshot']['path'])
    require(set(previous['slots']) == set(snapshot['slots']), 'Predecessor admitted unexpected slots')
    active = state['predecessor_active']
    key = active['slot']
    require(previous['slots'][key]['source'] == state['slots'][key]['source'], 'Predecessor source changed')
    if previous.get('active'):
        require(previous['active'] == active, 'Predecessor active attempt changed')
        require(live_identity(predecessor['identity']), 'Predecessor owner disappeared; reconcile, do not retry')
        require(live_identity(predecessor['worker_identity']) or (Path(active['output']) / 'result.json').is_file(),
                'Predecessor worker disappeared without a result')
        return [{'owner': 'predecessor', **active,
                 'startup_ready': str(Path(active['output']) / 'private/startup_ready.json')}]
    attempts = previous['slots'][key].get('attempts', [])
    require(attempts and all(attempts[-1].get(name) == value for name, value in active.items()),
            'Predecessor completion is not the reserved attempt')
    record = copy.deepcopy(previous['slots'][key])
    validate_result(record, attempts[-1])
    require(record['state'] == previous['slots'][key]['state'], 'Predecessor classification mismatch')
    state['slots'][key] = record
    state['predecessor_imported'] = reference(Path(predecessor['control']) / 'state.json')
    return []


def baseline_workers(controller):
    return [{'owner': 'baseline', 'pid': job['pid'], 'output': job['output'],
             'startup_ready': str(Path(job['output']) / 'episode_0000/private/startup_ready.json')}
            for job in controller.get('jobs', []) if not job.get('ended_at')]


def admission(active, external, resources, profile):
    workers = list(active.values()) + external
    count = len(workers)
    if count >= profile['max_workers']:
        return {'admitted': False, 'reason': 'six_worker_limit', 'occupied': count}
    if any(not Path(worker['startup_ready']).is_file() for worker in workers):
        return {'admitted': False, 'reason': 'waiting_for_startup_residency', 'occupied': count}
    admitted = (resources['gpu_free_mib'] >= profile['launch_reservation_mib']
                and resources['ram_available_mib'] >= profile['launch_reservation_mib'] + profile['ram_headroom_mib'])
    return {**resources, 'admitted': admitted, 'reason': 'ready' if admitted else 'memory_headroom',
            'occupied': count, 'profile': profile}


def prepare_slots(plan, state, controller):
    settled = completion_states(plan)
    first_pending = any(state['slots'].get(slot_key(slot), {}).get('state') not in settled
                        for slot in plan['slots'] if slot['episode_index'] < 8)
    ready = []
    for slot in plan['slots']:
        if first_pending and slot['episode_index'] >= 8:
            continue
        key = slot_key(slot)
        record = state['slots'].get(key, {})
        if record.get('state') in (*SETTLED, 'active', 'external_active', 'needs_diagnosis'):
            continue
        selected = record.get('source') or select_source(slot['original'], controller)
        if not selected:
            selected, unavailable = supplemental_source(plan, controller, slot)
            if unavailable:
                state['slots'][key] = {'state': 'source_unavailable', 'source_issue': unavailable}
            if not selected:
                continue
        baseline = record.get('baseline') or source_summary(selected['ref'])
        record.update(source=selected, baseline=baseline,
                      state='ready' if baseline['eligible_for_extension'] else 'carried')
        state['slots'][key] = record
        if record['state'] == 'ready':
            ready.append(slot)
    return ready


def completion_states(plan):
    return (*SETTLED, 'needs_diagnosis') if plan.get('healthy_first_authorization') else SETTLED


def prepare_healthy_launch(ready, state):
    for slot in ready:
        record = state['slots'][slot_key(slot)]
        selected = record['source']
        try:
            require(reference(selected['audit']['path']) == selected['audit'], 'Source certificate changed')
            require(source_summary(selected['ref']) == record['baseline'], 'Source baseline changed')
            manifest = read(Path(selected['ref']['result']).parent / 'private/manifest.json')
            require(isinstance(manifest['config'], dict), 'Source config missing')
        except (FileNotFoundError, ValueError, KeyError) as error:
            record.update(state='needs_diagnosis', deferred_reason={
                'phase': 'source_preflight', 'error': f'{type(error).__name__}: {error}', 'at': utc_now()})
            continue
        return [slot]
    return []


def launch(plan, state, slot, control_root, storage_status, resources):
    key = slot_key(slot)
    record = state['slots'][key]
    selected = record['source']
    require(reference(selected['audit']['path']) == selected['audit'], 'Source certificate changed')
    source_root = Path(selected['ref']['result']).parent
    config = read(source_root / 'private/manifest.json')['config']
    config_path = control_root / 'configs' / (key + '.json')
    require(not config_path.exists(), 'Existing launch configuration requires reconciliation')
    write_json(config_path, config)
    attempt = (Path(plan['output_root']) / f"task_{slot['task_id']:02d}" / f"index_{slot['episode_index']:02d}"
               / f"attempt_{record.get('next_attempt', 1):04d}")
    require(not attempt.exists(), 'Existing attempt must not be replayed or overwritten')
    runtime = plan['runtime']
    argv = [runtime['python'], '-u', '-m', 'gpt6_eval.cli', '--task', str(slot['task_id']),
            '--config', str(config_path), '--output', str(attempt), '--extension-source', str(source_root),
            '--extension-audit', selected['audit']['path'], '--storage-status', str(storage_status)]
    for name in ('python', 'upstream', 'isaaclab', 'assets'):
        argv += ['--' + name, runtime[name]]
    profile = plan['rolling']
    environment = {**os.environ, 'PYTHONPATH': str(ROOT / 'src'), 'PYTHONDONTWRITEBYTECODE': '1',
                   'PYTHONHASHSEED': '0', 'OMNI_KIT_ACCEPT_EULA': 'YES', 'GPT6_EVAL_WAIT_FOR_GPU': '1',
                   'GPT6_EVAL_WORKER_RESERVATION_MIB': str(profile['launch_reservation_mib']),
                   'GPT6_EVAL_RAM_HEADROOM_MIB': str(profile['ram_headroom_mib']),
                   'GPT6_EVAL_ASSET_CACHE': str(Path(plan['campaign']) / 'repairs/asset_cache_v9_20260929/cache.json')}
    if plan.get('extension_sqlite_root'):
        environment['GPT6_EVAL_EXTENSION_SQLITE_ROOT'] = plan['extension_sqlite_root']
    worker = {'slot': key, 'output': str(attempt), 'argv': argv, 'started_at': utc_now(),
              'startup_ready': str(attempt / 'private/startup_ready.json'), 'admission': resources}
    if record.get('retry_resolution'):
        worker['retry_resolution'] = record['retry_resolution']
    state['active'][key] = worker
    record['state'] = 'active'
    write_json(control_root / 'state.json', state)
    log = control_root / 'logs' / (key + '.log')
    log.parent.mkdir(parents=True, exist_ok=True)
    with log.open('xb') as stream:
        process = subprocess.Popen(argv, env=environment, stdout=stream, stderr=subprocess.STDOUT,
                                   start_new_session=True)
    worker.update(pid=process.pid, identity=process_identity(process.pid))
    return process


def collect(state, processes):
    for key, process in list(processes.items()):
        code = process.poll()
        if code is None:
            continue
        worker = state['active'].pop(key)
        result_path = Path(worker['output']) / 'result.json'
        attempt = {**worker, 'returncode': code, 'ended_at': utc_now(),
                   'result': reference(result_path) if result_path.exists() else None}
        record = state['slots'][key]
        record.setdefault('attempts', []).append(attempt)
        record['state'] = 'needs_diagnosis'
        del processes[key]
        validate_result(record, attempt)


def run(plan_path, control_root):
    plan = read(plan_path)
    require(plan['setting'] == SETTING and plan['multiplier'] == 10, 'Unexpected evaluation setting')
    require(plan['rolling'] == {'max_workers': 6, 'launch_reservation_mib': 9216,
                                'ram_headroom_mib': 4096, 'poll_seconds': 15}, 'Unapproved resource profile')
    for name, expected in plan['runner_hashes'].items():
        require(file_hash(ROOT / name) == expected, 'Frozen runner changed')
    require(reference(plan['scheduling_authorization']['path']) == plan['scheduling_authorization'],
            'Scheduling authorization changed')
    if plan.get('healthy_first_authorization'):
        approved = plan['healthy_first_authorization']
        require(reference(approved['path']) == approved, 'Healthy-first authorization changed')
        require(read(approved['path'])['policy'] == 'defer_unresolved_without_retry',
                'Unexpected deferral policy')
    control_root.mkdir(parents=True, exist_ok=True)
    with (control_root / 'lock').open('a') as guard:
        fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
        state_path = control_root / 'state.json'
        require(not state_path.exists(), 'Existing rolling controller needs explicit reconciliation; no blind restart')
        state = initialize(plan_path, plan)
        processes = {}
        stopped = False
        fault = None

        def stop(signum, frame):
            nonlocal stopped
            stopped = True

        signal.signal(signal.SIGTERM, stop)

        def save(phase):
            state.update(state=phase, error=fault, pid=os.getpid(), updated_at=utc_now(),
                         admission_closed=stopped or bool(fault))
            write_json(state_path, state)
            write_json(control_root / 'report.json', summarize(state, plan))

        save('starting')
        while True:
            phase = 'running_rolling'
            try:
                collect(state, processes)
                external = reconcile_predecessor(plan, state)
                controller = read(plan['controller'])
                external += baseline_workers(controller)
                state['external_workers'] = external
                ready = prepare_slots(plan, state, controller)
                if plan.get('healthy_first_authorization'):
                    ready = prepare_healthy_launch(ready, state)
                failed = [key for key, row in state['slots'].items() if row['state'] == 'needs_diagnosis']
                if failed and not plan.get('healthy_first_authorization'):
                    fault = 'Invalid attempts require diagnosis, not automatic replay: ' + ', '.join(failed)
                state['deferred_slots'] = [key for key, row in state['slots'].items()
                                           if row['state'] in ('needs_diagnosis', 'diverged', 'source_unavailable')]
                storage_status = refresh_storage(plan, control_root)
                try:
                    storage_admission(storage_status)
                    state.pop('storage_error', None)
                except (ValueError, OSError, KeyError) as error:
                    state['storage_error'] = str(error)
                    phase = 'waiting_for_healthy_storage'
                if not stopped and not fault and ready and phase != 'waiting_for_healthy_storage':
                    require(original_gpu_queue_finished(controller, plan), 'Existing queue must acknowledge closed admission and residency')
                    resources = admission(state['active'], external, memory_sample(), plan['rolling'])
                    state['admission'] = resources
                    if resources['admitted']:
                        processes[slot_key(ready[0])] = launch(plan, state, ready[0], control_root, storage_status, resources)
                    else:
                        phase = resources['reason']
                if all(state['slots'].get(slot_key(slot), {}).get('state') in completion_states(plan) for slot in plan['slots']):
                    save('coverage_finished' if any(row['state'] in ('diverged', 'source_unavailable', 'needs_diagnosis')
                                                   for row in state['slots'].values()) else 'complete')
                    return 0
            except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
                fault = f'{type(error).__name__}: {error}'
            save('needs_diagnosis' if fault else 'draining' if stopped else phase)
            if (stopped or fault) and not processes:
                if not fault:
                    save('drained')
                return 2 if fault else 0
            time.sleep(plan['rolling']['poll_seconds'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--control', type=Path, required=True)
    args = parser.parse_args()
    raise SystemExit(run(args.plan.resolve(), args.control.resolve()))


if __name__ == '__main__':
    main()
