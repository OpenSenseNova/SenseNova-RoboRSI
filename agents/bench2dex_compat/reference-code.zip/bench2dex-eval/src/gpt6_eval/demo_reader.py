"""Host-only allowlisted image reader. Never import this into the policy namespace.

The mailbox accepts demo IDs, approved cameras and frame indices, never paths,
HDF5 keys, Python expressions or destination filenames. Outputs are host-owned
and mounted read-only. Full source hashes are checked before and after research.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import threading
import time

from .core import CAMERAS, write_json
from .knowledge import tree_hashes
from .throughput import encode_frames

MODE = 'trusted_reader_v1'
MAX_REQUEST_BYTES = 4096
MAX_FRAMES = 64
RESERVE_BYTES = 50 * 1024**3


def source_signature(path):
    path = Path(path)
    if not path.is_absolute() or path.resolve() != path:
        raise ValueError('Source must be an absolute path without symbolic links')
    s = path.lstat()
    if not stat.S_ISREG(s.st_mode) or s.st_nlink != 1:
        raise ValueError('Source must be an independent regular file')
    return [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns]


def verified_source(path, expected_hash, expected_signature):
    if source_signature(path) != expected_signature:
        raise ValueError('Source identity changed')
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        s = os.fstat(f.fileno())
        if [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns] != expected_signature:
            raise ValueError('Source replaced while opening')
        for chunk in iter(lambda: f.read(4 * 1024**2), b''):
            h.update(chunk)
    if h.hexdigest() != expected_hash or source_signature(path) != expected_signature:
        raise ValueError('Source content changed')


class DemoReader:
    def __init__(self, training, public, private, *, reserve_bytes=RESERVE_BYTES):
        from .task51_legacy_provenance import validate_training
        validate_training(training)
        from .task62_scene_alias import validate_training as validate_task62_training
        validate_task62_training(training)
        self.training, self.public, self.private = training, Path(public), Path(private)
        if training.get('access_mode') != MODE:
            raise ValueError('Incorrect reader mode')
        self.cameras = tuple(CAMERAS[training['contract']['observation_profile']])
        self.sources = {}
        root = Path(training['dataset_root'])
        for row in training['demonstrations']:
            rel = Path(row['path'])
            if rel.is_absolute() or '..' in rel.parts:
                raise ValueError('Unsafe source path')
            ident = row['public_id']
            if not re.fullmatch(r'[0-9]{4}', ident) or ident in self.sources:
                raise ValueError('Invalid demonstration ID')
            info = json.loads((self.public / 'demos' / ident / 'demo.json').read_text())
            if tuple(info['camera_order']) != self.cameras or info['frames'] != row['frames']:
                raise ValueError('Public manifest mismatch')
            self.sources[ident] = (root / rel, row, info)
        if len(self.sources) != 100:
            raise ValueError('Reader requires the entire selected 100-demo corpus')
        self.requests = self.private / 'demo-reader-requests'
        self.responses = self.private / 'demo-reader-public'
        self.requests.mkdir()
        self.responses.mkdir()
        (self.responses / 'replies').mkdir()
        (self.responses / 'images').mkdir()
        # A policy can modify mailbox entries, never this directory descriptor
        # or the response tree. O_NOFOLLOW/nonblocking opens reject links/FIFOs.
        self.request_fd = os.open(self.requests, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        self.reserve_bytes = reserve_bytes
        self.stop = threading.Event()
        self.thread = None
        self.failure = None
        self.handled = set()
        self.served = {}
        self.log = (self.private / 'demo_reader_requests.jsonl').open('x')

    def verify_sources(self):
        from .task51_legacy_provenance import validate_training
        validate_training(self.training)
        from .task62_scene_alias import validate_training as validate_task62_training
        validate_task62_training(self.training)
        for index, (source, row, _) in enumerate(self.sources.values(), 1):
            verified_source(source, row['sha256'], row['source_signature'])
            if index % 10 == 0:
                print(f'Reader source verification: {index}/100', flush=True)

    def start(self):
        try:
            self.verify_sources()
        except BaseException:
            self.close()
            raise
        self.thread = threading.Thread(target=self._serve, name='trusted-demo-reader', daemon=True)
        self.thread.start()

    def validate(self, request):
        if not isinstance(request, dict) or set(request) != {'demo', 'camera', 'frames'}:
            raise ValueError('Expected demo, camera and frames only')
        ident, camera, frames = request['demo'], request['camera'], request['frames']
        if not isinstance(ident, str) or ident not in self.sources:
            raise ValueError('Unknown demonstration')
        if not isinstance(camera, str) or camera not in self.cameras:
            raise ValueError('Camera not permitted')
        if not isinstance(frames, list) or not 1 <= len(frames) <= MAX_FRAMES:
            raise ValueError('Request between 1 and 64 frames; batch longer sequences')
        count = self.sources[ident][2]['frames']
        if any(type(f) is not int or not 0 <= f < count for f in frames):
            raise ValueError('Frame outside permitted demonstration range')
        return ident, camera, frames

    def images(self, request):
        import h5py
        ident, camera, frames = self.validate(request)
        source, row, _ = self.sources[ident]
        signature = row['source_signature']
        if source_signature(source) != signature:
            raise RuntimeError('Source changed')
        folder = self.responses / 'images' / ident / camera
        folder.mkdir(parents=True, exist_ok=True)
        missing = sorted({f for f in frames if f'{ident}/{camera}/{f:06d}.png' not in self.served})
        # Only the host constructs paths. No policy-supplied file is ever used
        # as a write destination or opened by HDF5.
        if missing:
            if shutil.disk_usage(self.responses).free < self.reserve_bytes + len(missing)*640*480*3*2:
                raise RuntimeError('Insufficient storage for reader output')
            with open(source, 'rb') as raw:
                s = os.fstat(raw.fileno())
                if [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns] != signature:
                    raise RuntimeError('Source replaced')
                with h5py.File(raw, 'r') as h:
                    rgb = h[f'cameras/{camera}/rgb']
                    for frame, png in zip(missing, encode_frames((bytes(rgb[f]) for f in missing), 4)):
                        path = folder / f'{frame:06d}.png'
                        with path.open('xb') as out:
                            out.write(png)
                        self.served[f'{ident}/{camera}/{frame:06d}.png'] = hashlib.sha256(png).hexdigest()
            if source_signature(source) != signature:
                raise RuntimeError('Source changed during request')
        return {'ok': True, 'images': [
            {'frame': frame, 'path': f'/workspace/.demo_responses/images/{ident}/{camera}/{frame:06d}.png',
             'sha256': self.served[f'{ident}/{camera}/{frame:06d}.png']}
            for frame in frames]}

    def _request(self, name):
        fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=self.request_fd)
        with os.fdopen(fd, 'rb') as f:
            s = os.fstat(f.fileno())
            if not stat.S_ISREG(s.st_mode) or s.st_nlink != 1 or s.st_size > MAX_REQUEST_BYTES:
                raise ValueError('Invalid request file')
            data = f.read(MAX_REQUEST_BYTES + 1)
        if len(data) > MAX_REQUEST_BYTES:
            raise ValueError('Request too large')
        return json.loads(data)

    def _serve(self):
        try:
            while not self.stop.is_set():
                for name in sorted(os.listdir(self.request_fd)):
                    if self.stop.is_set(): break
                    if not re.fullmatch(r'[a-f0-9]{32}\.json', name) or name in self.handled:
                        continue
                    self.handled.add(name)
                    start = time.monotonic()
                    request = None
                    try:
                        request = self._request(name)
                        self.validate(request)
                    except (ValueError, TypeError, OSError):
                        reply = {'ok': False, 'error': 'Invalid request; use an approved demo, camera and frame range.'}
                    else:
                        try:
                            reply = self.images(request)
                        except Exception as exc:
                            # Private exception details must never enter the model boundary.
                            self.failure = repr(exc)
                            reply = {'ok': False, 'error': 'Trusted reader failed; preparation cannot be frozen.'}
                    self.log.write(json.dumps({'id': name, 'request': request, 'reply': reply,
                        'seconds': time.monotonic()-start}, ensure_ascii=True) + '\n')
                    self.log.flush()
                    write_json(self.responses / 'replies' / name, reply)
                    if self.failure:
                        self.stop.set()
                        break
                self.stop.wait(0.05)
        except BaseException as exc:
            self.failure = repr(exc)
            self.stop.set()

    def close(self):
        self.stop.set()
        if self.thread is not None:
            self.thread.join()
        if self.request_fd is not None:
            os.close(self.request_fd)
            self.request_fd = None
        if not self.log.closed:
            self.log.close()

    def finish(self):
        self.close()
        if self.failure:
            raise RuntimeError('Trusted reader failed: ' + self.failure)
        self.verify_sources()
        files = tree_hashes(self.responses)
        for name, expected in self.served.items():
            if files.get('images/' + name) != expected:
                raise ValueError('Delivered image changed')
        write_json(self.private / 'demo_reader_audit.json', {
            'access_mode': MODE, 'state': 'verified', 'all_sources_checked_before_and_after': True,
            'source_count': len(self.sources), 'requests': len(self.handled),
            'unique_images': len(self.served), 'public_files': files,
            'request_log_sha256': hashlib.sha256((self.private / 'demo_reader_requests.jsonl').read_bytes()).hexdigest()})
