"""Policy-safe URDF kinematics. No simulator imports, task logic or execution."""
import json
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
from scipy.optimize import least_squares


def transform(xyz, rpy):
    result = np.eye(4)
    result[:3, :3] = Rotation.from_euler("xyz", rpy).as_matrix()
    result[:3, 3] = xyz
    return result


def root_link(joints):
    roots = {j["parent"]["link"] for j in joints} - {j["child"]["link"] for j in joints}
    if len(roots) != 1:
        raise ValueError("Expected one connected robot root")
    return roots.pop()


class RobotKinematics:
    def __init__(self, card):
        self.card = card
        self.names = list(card["active_joint_names"])
        self.indices = {n: i for i, n in enumerate(self.names)}
        self.joints = card["kinematics"]["joints"]
        self.mapping = card["kinematics"].get("urdf_to_runtime_joint_names", {})
        self.root = root_link(self.joints)
        self.limits = np.asarray(card["position_limits"], dtype=float)
        self.defaults = card.get("inactive_joint_positions", {})
        self.origins = {}
        for joint in self.joints:
            origin = joint.get("origin", {})
            xyz = np.fromstring(origin.get("xyz", "0 0 0"), sep=" ")
            rpy = np.fromstring(origin.get("rpy", "0 0 0"), sep=" ")
            self.origins[joint["name"]] = transform(xyz, rpy)

    @classmethod
    def from_file(cls, path="/workspace/input/robot.json"):
        return cls(json.loads(Path(path).read_text()))

    def fk(self, q):
        q = np.asarray(q, dtype=float)
        if q.shape != (len(self.names),) or not np.isfinite(q).all():
            raise ValueError("Expected finite active joint vector")
        values = dict(self.defaults)
        values.update(zip(self.names, q))
        pending = list(self.joints)
        poses = {self.root: np.eye(4)}
        while pending:
            progress = False
            for joint in list(pending):
                name = joint["name"]
                runtime_name = self.mapping.get(name, name)
                parent = joint["parent"]["link"]
                mimic = joint.get("mimic")
                if parent not in poses:
                    continue
                if mimic:
                    source = self.mapping.get(mimic["joint"], mimic["joint"])
                    if source not in values:
                        continue
                    values[runtime_name] = values[source] * float(mimic.get("multiplier", 1)) + float(mimic.get("offset", 0))
                motion = np.eye(4)
                if joint["type"] != "fixed":
                    if runtime_name not in values:
                        raise ValueError(f"Missing inactive joint position: {runtime_name}")
                    axis = np.fromstring(joint["axis"]["xyz"], sep=" ")
                    axis = axis / np.linalg.norm(axis)
                    if joint["type"] in ("revolute", "continuous"):
                        motion[:3, :3] = Rotation.from_rotvec(axis * values[runtime_name]).as_matrix()
                    elif joint["type"] == "prismatic":
                        motion[:3, 3] = axis * values[runtime_name]
                    else:
                        raise ValueError(f"Unsupported joint type: {joint['type']}")
                poses[joint["child"]["link"]] = poses[parent] @ self.origins[name] @ motion
                pending.remove(joint)
                progress = True
            if not progress:
                raise ValueError("Unresolved kinematic tree or mimic dependency")
        return poses

    def ik(self, q, link, target, joint_names, max_nfev=200):
        """Local bounded pose IK. Candidate only: caller must check success.

        target is T_robot_base_from_link. Only explicitly selected joints move.
        No random restarts, collision checking, grasp planning, or simulator calls.
        """
        q = np.asarray(q, dtype=float).copy()
        self.fk(q)  # Validate state/tree, including inactive values.
        target = np.asarray(target, dtype=float)
        if target.shape != (4, 4) or not np.isfinite(target).all():
            raise ValueError("Expected finite 4x4 target")
        if not np.allclose(target[3], [0, 0, 0, 1]) or not np.allclose(target[:3, :3].T @ target[:3, :3], np.eye(3), atol=1e-6) or not np.isclose(np.linalg.det(target[:3, :3]), 1, atol=1e-6):
            raise ValueError("Target is not a rigid transform")
        indices = [self.indices[n] for n in joint_names]
        if not indices or len(set(indices)) != len(indices):
            raise ValueError("Select distinct active joints")
        lower, upper = self.limits[indices].T
        if not np.all(lower < upper):
            raise ValueError("Selected joints must have nonzero ranges")
        initial = np.clip(q[indices], lower, upper)
        def residual(x):
            candidate = q.copy()
            candidate[indices] = x
            actual = self.fk(candidate)[link]
            return np.r_[actual[:3, 3] - target[:3, 3],
                         Rotation.from_matrix(target[:3, :3].T @ actual[:3, :3]).as_rotvec()]
        solution = least_squares(residual, initial, bounds=(lower, upper), method="trf",
                                 jac="2-point", ftol=1e-10, xtol=1e-10, gtol=1e-10,
                                 x_scale=1.0, max_nfev=max_nfev)
        q[indices] = solution.x
        error = residual(solution.x)
        position_error = float(np.linalg.norm(error[:3]))
        orientation_error = float(np.linalg.norm(error[3:]))
        return {"qpos": q.tolist(), "success": position_error <= 1e-3 and orientation_error <= 1e-2,
                "position_error_m": position_error, "orientation_error_rad": orientation_error,
                "solver_status": int(solution.status), "nfev": int(solution.nfev)}
