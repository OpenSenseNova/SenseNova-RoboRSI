"""Install released frozen ICL packages without repeating model preparation."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import tempfile
import zipfile

from .cli import ROOT, ROBOTS, load_config
from .knowledge import SETTING, contract, file_hash, verify_package

MAX_ARCHIVE_BYTES = 512 * 1024 * 1024
MAX_PACKAGE_BYTES = 1024 * 1024 * 1024
MAX_FILES = 10000


def read_catalog(path):
    if not path.is_file():
        raise ValueError('Release catalog missing; use a complete public source release')
    catalog = json.loads(path.read_text())
    if catalog.get('schema_version') != 1 or catalog.get('setting') != SETTING:
        raise ValueError('Unsupported package catalog')
    rows = catalog.get('packages')
    if not isinstance(rows, list) or not rows:
        raise ValueError('Empty package catalog')
    seen = set()
    for row in rows:
        task = row.get('task_id')
        if type(task) is not int or task not in ROBOTS or task in seen:
            raise ValueError('Unknown or duplicate catalog task')
        seen.add(task)
        if row.get('archive') != f'packages/task_{task:02d}.zip':
            raise ValueError('Unexpected archive location')
        for key in ('sha256', 'manifest_sha256'):
            if not isinstance(row.get(key), str) or not re.fullmatch('[0-9a-f]{64}', row[key]):
                raise ValueError('Invalid catalog digest')
        for key, maximum in (('archive_bytes', MAX_ARCHIVE_BYTES), ('package_bytes', MAX_PACKAGE_BYTES)):
            if type(row.get(key)) is not int or not 0 < row[key] <= maximum:
                raise ValueError('Invalid catalog size')
    return catalog


def extract_verified(archive, target, row):
    """Check the trusted digest, then extract only bounded ordinary package files."""
    if archive.stat().st_size != row['archive_bytes'] or file_hash(archive) != row['sha256']:
        raise ValueError(f'Archive size/hash mismatch for task {row["task_id"]}')
    with zipfile.ZipFile(archive) as bundle:
        members = bundle.infolist()
        if len(members) > MAX_FILES or sum(m.file_size for m in members) != row['package_bytes']:
            raise ValueError('Archive expanded size or file count mismatch')
        seen = set()
        for member in members:
            name = member.filename
            parts = PurePosixPath(name).parts
            mode = member.external_attr >> 16
            if (not parts or name.startswith('/') or '\\' in name or ':' in name
                    or any(part in {'', '.', '..'} for part in name.split('/'))
                    or name in seen or member.is_dir()
                    or stat.S_IFMT(mode) not in {0, stat.S_IFREG}
                    or member.flag_bits & 1
                    or not (name == 'manifest.json' or (len(parts) > 1 and parts[0] == 'payload'))):
                raise ValueError('Unsafe or unexpected archive member')
            seen.add(name)
        if 'manifest.json' not in seen:
            raise ValueError('Archive has no package manifest')
        target.mkdir()
        for member in members:
            output = target.joinpath(*PurePosixPath(member.filename).parts)
            output.parent.mkdir(parents=True, exist_ok=True)
            with bundle.open(member) as source, output.open('xb') as destination:
                shutil.copyfileobj(source, destination, length=1024 * 1024)


def verify_installed(root):
    config = load_config(root / 'config.json')
    if config.get('evaluation_setting') != SETTING:
        raise ValueError('Expected an ICL configuration')
    for task, ref in config['task_packages'].items():
        verify_package(Path(ref['path']), ref['sha256'], int(task), config)
    return sorted(map(int, config['task_packages']))


def install(catalog_path, output, tasks=None, source=None, repo_id=None, revision='main'):
    catalog = read_catalog(catalog_path)
    config = load_config(ROOT / 'configs/icl_base.json')
    if catalog.get('contract') != contract(config):
        raise ValueError('Package catalog and evaluation software contract differ')
    selected = set(tasks) if tasks else {row['task_id'] for row in catalog['packages']}
    rows = [row for row in catalog['packages'] if row['task_id'] in selected]
    if selected != {row['task_id'] for row in rows}:
        raise ValueError('Requested task is not included in this release')
    output = output.absolute()
    if output.exists() or output.is_symlink():
        raise ValueError('Output already exists; verify it or choose a new directory')
    if source is None and not repo_id:
        raise ValueError('Supply --source for downloaded archives or --repo-id for Hugging Face')
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.icl-install-', dir=output.parent) as temporary:
        staging = Path(temporary) / 'installed'
        staging.mkdir()
        refs = {}
        for row in rows:
            if source is not None:
                archive = source / row['archive']
            else:
                try:
                    from huggingface_hub import hf_hub_download
                except ImportError as exc:
                    raise ValueError('Install this evaluation package with the [data] extra') from exc
                archive = Path(hf_hub_download(repo_id=repo_id, repo_type='dataset',
                                              revision=revision, filename=row['archive']))
            name = f'task_{row["task_id"]:02d}'
            extract_verified(archive, staging / name, row)
            verify_package(staging / name, row['manifest_sha256'], row['task_id'], config)
            refs[str(row['task_id'])] = {'path': name, 'sha256': row['manifest_sha256']}
        config.update(schema_version=3, evaluation_setting=SETTING, task_packages=refs)
        (staging / 'config.json').write_text(json.dumps(config, indent=2) + '\n')
        verify_installed(staging)
        # Exclusive creation avoids overwriting any pre-existing user directory.
        output.mkdir()
        try:
            for path in staging.iterdir():
                os.replace(path, output / path.name)
        except BaseException:
            shutil.rmtree(output)
            raise
    return output / 'config.json'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    download = commands.add_parser('install', help='Install selected tasks and write a portable config')
    origin = download.add_mutually_exclusive_group(required=True)
    origin.add_argument('--source', type=Path, help='Local downloaded dataset root containing packages/')
    origin.add_argument('--repo-id', help='Published Hugging Face dataset ID, e.g. organization/dataset')
    download.add_argument('--revision', default='main', help='HF revision; archive hashes remain pinned by the local catalog')
    download.add_argument('--catalog', type=Path, default=ROOT / 'configs/icl_packages.json',
                          help='Trusted release catalog (use the copy shipped with the code)')
    download.add_argument('--task', type=int, action='append', help='Repeat to select tasks; default: all')
    download.add_argument('--output', type=Path, required=True, help='New installation directory')
    verify = commands.add_parser('verify', help='Recheck installed package files and manifest hashes')
    verify.add_argument('root', type=Path)
    args = parser.parse_args()
    try:
        if args.command == 'verify':
            print(json.dumps({'passed': True, 'tasks': verify_installed(args.root)}, indent=2))
        else:
            path = install(args.catalog, args.output, args.task, args.source, args.repo_id, args.revision)
            print(json.dumps({'passed': True, 'config': str(path)}, indent=2))
    except (OSError, ValueError, zipfile.BadZipFile) as exc:
        parser.exit(1, f'Package installation/verification failed: {exc}\n')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
