"""Download task-26 testing assets plus the complete upstream randomization pool.

Uses the HF CLI and a pinned revision; no demonstrations/policy checkpoints.
Run with the IsaacLab Python containing huggingface_hub and PyYAML.
"""
import argparse
import fnmatch
import json
import os
from pathlib import Path
import subprocess
import sys

import yaml

from .core import write_json
from .cli import hash_file, load_task, ROBOTS, git, ROOT

REVISION = "bf65215f844d1fca30750e4cc70d7266650abf0a"


def selection(upstream, all_tasks=False):
    general = yaml.safe_load((upstream / "configs/scene/generalization.yaml").read_text())
    # iTHOR scene layers reference separate furniture/prop bundles here.
    # Downloading scenes/ithor alone leaves renderable but incomplete rooms.
    patterns = {"textures/*", "scenes/ithor/*", "Objects/thor/*"}
    def visit(value):
        if isinstance(value, dict):
            for item in value.values():
                visit(item)
        elif isinstance(value, list):
            for item in value:
                visit(item)
        elif isinstance(value, str) and "dex2bench_dataset/Objects/" in value:
            relative = value.split("dex2bench_dataset/", 1)[1]
            patterns.add("/".join(relative.split("/")[:2]) + "/*")
    if all_tasks:
        maps = yaml.safe_load((upstream / "robots/active_dof_maps.yml").read_text())["robots"]
        for task_id in sorted(ROBOTS):
            _, task, robot = load_task(upstream, task_id)
            visit(task)
            asset_dir = maps[robot]["asset_dir"].removeprefix("Bench2Dex/")
            if not asset_dir.startswith("Robots_p/") or ".." in Path(asset_dir).parts:
                raise ValueError(f"Unexpected robot asset directory: {asset_dir}")
            patterns.add(asset_dir + "/*")
    else:
        task = yaml.safe_load((upstream / "scenes/26_canned_food_tray_line_arrangement.yaml").read_text())
        visit(task)
        patterns.add("Robots_p/kuka+sharpa/*")
    visit(general)
    return sorted(patterns)


def verify_inventory(destination, inventory):
    missing = []
    for record in inventory:
        path = destination / record["path"]
        if not path.is_file() or path.stat().st_size != record["bytes"]:
            missing.append(record["path"])
        elif record.get("sha256") and hash_file(path) != record["sha256"]:
            missing.append(record["path"] + " (SHA256 mismatch)")
    if missing:
        raise RuntimeError(f"Incomplete asset download: {len(missing)} missing/invalid files; first: {missing[0]}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--upstream", type=Path, required=True)
    parser.add_argument("--destination", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--plan-only", action="store_true")
    parser.add_argument("--all-tasks", action="store_true",
                        help="Select all 26 released tasks and their robot bundles")
    parser.add_argument("--download-workers", type=int, default=2,
                        help="Concurrent asset downloads (unrelated to evaluation workers)")
    parser.add_argument("--log", type=Path, help="Append CLI download diagnostics to this file")
    args = parser.parse_args()
    if args.download_workers < 1:
        parser.error("--download-workers must be positive")
    if args.all_tasks:
        expected = json.loads((ROOT / "configs/default.json").read_text())["upstream_commit"]
        if git(args.upstream, "rev-parse", "HEAD") != expected or git(args.upstream, "status", "--porcelain"):
            raise ValueError("All-task selection requires the clean pinned upstream checkout")
    patterns = selection(args.upstream, all_tasks=args.all_tasks)
    command = [str(Path(sys.executable).with_name("hf")), "download", "Bench2Dex/Assets",
               "--repo-type", "dataset", "--revision", REVISION,
               "--local-dir", str(args.destination.resolve()), "--max-workers", str(args.download_workers),
               "--include", *patterns]
    write_json(args.manifest, {"repo_id": "Bench2Dex/Assets", "revision": REVISION,
                              "include": patterns, "command": command,
                              "task_ids": sorted(ROBOTS) if args.all_tasks else [26],
                              "download_environment": {"HF_HUB_DISABLE_XET": os.environ.get("HF_HUB_DISABLE_XET", "0")},
                              "purpose": "Testing asset bundles plus full upstream generalization pool; no demonstrations or policy checkpoints. Bundle selection is conservative, not a minimal dependency closure."})
    print(json.dumps({"patterns": patterns, "manifest": str(args.manifest)}, indent=2), flush=True)
    if not args.plan_only:
        from huggingface_hub import HfApi
        # Fail closed if Hub metadata is unavailable. Older HF clients can
        # report success after returning an incomplete existing local folder.
        files = HfApi().list_repo_tree("Bench2Dex/Assets", repo_type="dataset",
                                       revision=REVISION, recursive=True)
        inventory = []
        for file in files:
            if not hasattr(file, "size") or not any(fnmatch.fnmatchcase(file.path, p) for p in patterns):
                continue
            lfs = getattr(file, "lfs", None)
            sha = lfs.get("sha256") if isinstance(lfs, dict) else getattr(lfs, "sha256", None)
            inventory.append({"path": file.path, "bytes": file.size, "sha256": sha})
        inventory.sort(key=lambda f: f["path"])
        if not inventory:
            raise RuntimeError("Empty remote asset selection")
        write_json(args.manifest.with_name(args.manifest.stem + ".inventory.json"), inventory)
        print(f"Selected {len(inventory)} files, {sum(f['bytes'] for f in inventory) / 2**30:.2f} GiB total (including already installed files)", flush=True)
        if args.log:
            args.log.parent.mkdir(parents=True, exist_ok=True)
            with args.log.open("ab") as log:
                subprocess.run(command, check=True, stdout=log, stderr=subprocess.STDOUT)
        else:
            subprocess.run(command, check=True)
        verify_inventory(args.destination, inventory)
        print(f"Verified {len(inventory)} pinned asset files", flush=True)


if __name__ == "__main__":
    main()
