"""User-authorized, post-episode pruning of this extension's intermediate PNGs."""
import json
import os
from pathlib import Path
import re
import stat

from .core import CAMERAS, canonical, write_json
from .extension import SETTING, read, require

PROFILE = 'named_results_and_decision_images_v1'


def prune_intermediate_images(root):
    root = Path(root).resolve(strict=True)
    spec = read(root / 'private/extension_spec.json')
    require(spec.get('setting') == SETTING and spec.get('image_retention') == PROFILE,
            'No explicit new-extension image retention authorization')
    source = Path(spec['source']).resolve(strict=True)
    require(not root.is_relative_to(source) and not source.is_relative_to(root),
            'Never prune an original source archive')
    destination = root / 'private/intermediate_image_retention'
    require(not destination.exists(), 'Prior pruning intention requires explicit reconciliation')
    episode = root / 'episode_0000'
    private = episode / 'private'
    telemetry = read(private / 'telemetry.json')
    require(telemetry.get('finalized') is True, 'Policy must be finalized before image pruning')
    keep = {spec['standard_policy_steps']}
    keep.update(read(path)['policy_step'] for path in (private / 'decisions').glob('*.json'))
    bases = [episode / 'policy/input/observations', private / 'observations']
    folders = []
    for base in bases:
        if not base.exists():
            continue
        require(base.resolve(strict=True) == base, 'Unexpected observation base symlink')
        for folder in base.iterdir():
            if folder.is_symlink() or not re.fullmatch(r'\d{6}', folder.name):
                continue
            require(folder.is_dir() and folder.resolve(strict=True) == folder, 'Unexpected observation directory')
            index = int(folder.name)
            require(index >= spec['standard_policy_steps'], 'Unexpected copied original prefix images')
            folders.append(folder)
    if folders:
        keep.add(max(int(folder.name) for folder in folders))
    planned = []
    for folder in folders:
        if int(folder.name) in keep:
            continue
        observation = read(folder / 'observation.json')
        require(observation['policy_step'] == int(folder.name), 'Observation clock mismatch')
        cameras = {camera['name']: camera for camera in observation['cameras']}
        require(set(cameras) in (set(value) for value in CAMERAS.values()), 'Unexpected camera set')
        for name, camera in cameras.items():
            path = folder / (name + '.png')
            info = path.lstat()
            require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_uid == os.getuid(),
                    'Refuse linked/foreign intermediate image')
            planned.append({'path': str(path.relative_to(root)), 'device': info.st_dev, 'inode': info.st_ino,
                            'bytes': info.st_size, 'mtime_ns': info.st_mtime_ns, 'ctime_ns': info.st_ctime_ns,
                            'allocated_bytes': info.st_blocks * 512, 'recorded_png_sha256': camera['sha256']})
    destination.mkdir()
    plan = destination / 'planned.json'
    with plan.open('xb') as stream:
        stream.write(canonical({'profile': PROFILE, 'kept_policy_steps': sorted(keep), 'files': planned,
                                'scope': 'Only newly generated intermediate extension camera PNGs; no source images'}))
        stream.flush()
        os.fsync(stream.fileno())
    descriptor = os.open(destination, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    deleted = 0
    allocated = 0
    with (destination / 'deleted.jsonl').open('xb') as ledger:
        for row in planned:
            path = root / row['path']
            info = path.lstat()
            require([info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns]
                    == [row[key] for key in ('device', 'inode', 'bytes', 'mtime_ns', 'ctime_ns')]
                    and info.st_nlink == 1 and stat.S_ISREG(info.st_mode), 'Image changed after pruning plan')
            path.unlink()
            ledger.write(canonical(row))
            deleted += 1
            allocated += row['allocated_bytes']
        ledger.flush()
        os.fsync(ledger.fileno())
    for folder in {(root / row['path']).parent for row in planned}:
        descriptor = os.open(folder, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    summary = {'profile': PROFILE, 'state': 'complete', 'files_deleted': deleted,
               'allocated_bytes_reclaimed': allocated, 'kept_policy_steps': sorted(keep),
               'originals_untouched': True, 'png_content_rehashed': False,
               'basis': 'New disposable-image scope, recorded SHA256, exact path/owner/link/inode identity; not a named-data integrity certification'}
    write_json(destination / 'complete.json', summary)
    return summary
