"""Extract only reset metadata from setup demonstrations into private anchors."""
import argparse
from pathlib import Path
import json

import h5py

from .core import write_json
from .cli import hash_file


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("sources", type=Path, nargs="+")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    manifest = []
    for path in sorted(args.sources):
        target = args.output / path.name
        with h5py.File(path, "r") as source:
            sample = source["meta/scene_generalization_sample"][()]
        # Validate JSON without adding any trajectory or RGB data.
        json.loads(sample)
        with h5py.File(target, "x") as dest:
            dest.create_dataset("meta/scene_generalization_sample", data=sample)
        manifest.append({"source": path.name, "source_sha256": hash_file(path),
                         "anchor": target.name, "anchor_sha256": hash_file(target)})
    write_json(args.output / "manifest.json", manifest)


if __name__ == "__main__":
    main()
