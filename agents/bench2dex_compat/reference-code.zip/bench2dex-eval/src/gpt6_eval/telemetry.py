"""Private accounting: never expose measurements or privileged paths to policy."""
from __future__ import annotations

from datetime import datetime, timezone
import json
import time

from .core import write_json

TOKEN_FIELDS = ("input_tokens", "cached_input_tokens", "cache_write_input_tokens",
                "output_tokens", "reasoning_output_tokens", "total_tokens")


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def jsonl(path):
    """Keep complete records even when the last write was interrupted."""
    if path.is_file():
        with path.open("rb") as stream:
            for line_number, line in enumerate(stream, 1):
                try:
                    value = json.loads(line)
                except (ValueError, UnicodeError):
                    continue
                if isinstance(value, dict):
                    yield line_number, value


def normalize_usage(raw):
    values = {key: raw.get(key) for key in TOKEN_FIELDS}
    for key, value in values.items():
        if value is not None and (type(value) is not int or value < 0):
            raise ValueError(f"Invalid reported token count: {key}")
    if values["input_tokens"] is None or values["output_tokens"] is None:
        raise ValueError("Usage lacks input/output counts")
    # Cached input and reasoning output are breakdowns, not additional tokens.
    values["total_tokens"] = values["input_tokens"] + values["output_tokens"]
    return values


def token_usage(private, mode, *, process_started=True, returncode=None):
    if mode != "codex" or not process_started:
        return {"status": "complete", "source": "no_model_process",
                **dict.fromkeys(TOKEN_FIELDS, 0)}
    finals = [(line, event["usage"]) for line, event in jsonl(private / "codex.events.jsonl")
              if event.get("type") == "turn.completed" and isinstance(event.get("usage"), dict)]
    snapshots = []
    sessions = sorted((private / "codex-home/sessions").rglob("*.jsonl"))
    for path in sessions:
        for line, event in jsonl(path):
            payload = event.get("payload", {})
            if event.get("type") != "event_msg" or not isinstance(payload, dict):
                continue
            info = payload.get("info")
            if payload.get("type") == "token_count" and isinstance(info, dict):
                raw = info.get("total_token_usage")
                if isinstance(raw, dict):
                    snapshots.append((path, line, raw))
    unknown = {"status": "unavailable", "source": None, **dict.fromkeys(TOKEN_FIELDS)}
    # One fresh CLI turn/session is the protocol. Never silently sum duplicated
    # cumulative snapshots, or guess across unexpected resumed/forked sessions.
    if len(sessions) > 1 or len(finals) > 1:
        return {**unknown, "error": "Unexpected multiple sessions or completed turns"}
    try:
        if finals:
            counts = normalize_usage(finals[-1][1])
            if snapshots and normalize_usage(snapshots[-1][2])["total_tokens"] > counts["total_tokens"]:
                finals = []  # A later partial request exists; use the cumulative lower bound.
            else:
                return {**counts, "status": "complete" if returncode == 0 else "partial",
                        "source": "codex.events.jsonl", "line": finals[-1][0]}
        if snapshots:
            path, line, raw = snapshots[-1]
            return {**normalize_usage(raw), "status": "partial",
                    "source": str(path.relative_to(private)), "line": line}
    except ValueError as exc:
        return {**unknown, "error": str(exc)}
    return unknown


def sum_usage(records):
    """Do not disguise missing/partial episodes as a complete run total."""
    complete = all(r["status"] == "complete" for r in records)
    totals = {key: (sum(r[key] for r in records) if all(r.get(key) is not None for r in records)
                    else None) for key in TOKEN_FIELDS}
    known = {key: sum(r.get(key) or 0 for r in records) for key in TOKEN_FIELDS}
    return {**totals, "status": "complete" if complete else "partial",
            "known_reported_tokens": known,
            "incomplete_episodes": sum(r["status"] != "complete" for r in records)}


class EpisodeTelemetry:
    def __init__(self, private, mode):
        self.private, self.mode = private, mode
        self.started, self.started_at = time.monotonic(), utc_now()
        self.decisions = []
        self.ended = None
        self.ended_at = None
        self.model_process_started = False
        self.codex_returncode = None
        self.flush()

    def decision(self, index, policy_step, started, started_at, accepted, error):
        record = {"decision": index, "policy_step": policy_step,
                  "started_at": started_at, "ended_at": utc_now(),
                  "wall_seconds": time.monotonic() - started,
                  "accepted": accepted, "error": error}
        self.decisions.append(record)
        write_json(self.private / "timing" / f"{index:06d}.json", record)
        self.flush()

    def usage(self):
        return token_usage(self.private, self.mode,
                           process_started=self.model_process_started,
                           returncode=self.codex_returncode)

    def flush(self, *, finished=False):
        if finished and self.ended is None:
            self.ended, self.ended_at = time.monotonic(), utc_now()
        usage = self.usage()
        write_json(self.private / "telemetry.json", {
            "schema_version": 1, "mode": self.mode,
            "started_at": self.started_at, "ended_at": self.ended_at,
            "finalized": self.ended is not None, "tokens": usage,
            "timing": {
                "episode_wall_seconds": (self.ended or time.monotonic()) - self.started,
                "policy_inference_wall_seconds": (sum(d["wall_seconds"] for d in self.decisions)
                                                   if self.mode == "codex" else 0.0),
                "action_request_wall_seconds": sum(d["wall_seconds"] for d in self.decisions),
                "model_server_inference_seconds": None,
                "definition": "Action RPC entry through acceptance/error; includes observation archiving, "
                              "first-decision startup, Codex reasoning, tools and transport. Excludes "
                              "simulator stepping and final Codex shutdown. Server-only latency unavailable."},
            "decision_count": len(self.decisions), "codex_returncode": self.codex_returncode})


def summarize_run(root, mode, started, started_at, simulator_seconds, rows, *, error=None):
    episodes = []
    for path in sorted(root.glob("episode_*/private/telemetry.json")):
        record = json.loads(path.read_text())
        episodes.append({"episode": path.parent.parent.name,
                         "path": str(path.relative_to(root)), **record})
    trajectories = [str(p.relative_to(root)) for p in
                    sorted((root / "private/trajectories").rglob("*.hdf5"))]
    summary = {"schema_version": 1, "mode": mode, "started_at": started_at,
               "ended_at": utc_now(), "error": error,
               "tokens": sum_usage([e["tokens"] for e in episodes]),
               "timing": {"run_wall_seconds": time.monotonic() - started,
                          "simulator_process_wall_seconds": simulator_seconds,
                          "policy_inference_wall_seconds": sum(
                              e["timing"]["policy_inference_wall_seconds"] for e in episodes),
                          "model_server_inference_seconds": None,
                          "simulated_seconds_from_official_results": sum(r.get("steps", 0) for r in rows) / 60,
                          "definition": "Run entry through summary collection, excluding final integrity "
                                        "hashing. Simulator process includes startup, rendering and policy waits. "
                                        "Simulated duration covers available official rows only."},
               "episodes": episodes, "trajectories": trajectories}
    write_json(root / "telemetry.json", summary)
    return summary
