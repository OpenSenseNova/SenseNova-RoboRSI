"""Read-only checks before evaluation; never starts simulation or model inference."""
from __future__ import annotations
import argparse
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

from .cli import ROOT, ROBOTS, git, load_config, load_task
from .knowledge import SETTING, verify_package


def check_source():
    config = load_config(ROOT / 'configs/default.json')
    for name in ('prompts/policy.md', 'prompts/policy_icl.md', 'prompts/preparation.md',
                 'prompts/preparation_reader.md', 'prompts/calibrated_deployment.md',
                 'src/gpt6_eval/simulator.py', 'README.md', 'AGENTS.md',
                 'RELEASE_CONTENTS.json', 'RELEASE_AUDIT.md', 'pyproject.toml'):
        if not (ROOT / name).is_file():
            raise ValueError(f'Missing packaged resource: {name}')
    return {'catalog_tasks': len(ROBOTS), 'model': config['model'],
            'codex_version': config['codex_version']}


def check_repository(path, commit):
    if path is None:
        raise ValueError('Set the corresponding path option or environment variable')
    if git(path, 'rev-parse', 'HEAD') != commit or git(path, 'status', '--porcelain'):
        raise ValueError('Checkout must be clean at the pinned commit')
    return {'commit': commit, 'clean': True}


def check_assets(upstream, assets, task):
    if upstream is None or assets is None or not assets.is_dir():
        raise ValueError('Set upstream/assets paths to installed directories')
    # Pinned upstream USD references are relative to the checkout, not --assets.
    expected = upstream.parent / 'dex2bench_dataset'
    if not expected.exists() or not expected.samefile(assets):
        raise ValueError('dex2bench_dataset beside Bench2Dex must resolve to --assets')
    scene, data, _ = load_task(upstream, task)
    missing = [item['path'] for item in data['assets'].values()
               if not (scene.parent / item['path']).resolve().is_file()]
    if missing:
        raise ValueError(f'Missing {len(missing)} task USD files; download pinned assets')
    return {'task': task, 'layout': 'passed',
            'scope': 'Top-level USD presence only; runtime still audits transitive assets'}


def check_python(executable, packages):
    if executable is None:
        raise ValueError('Set the Python executable path')
    code = ('import importlib.metadata as m,json; '
            'print(json.dumps({p:m.version(p) for p in ' + repr(packages) + '}))')
    proc = subprocess.run([str(executable), '-c', code], capture_output=True, text=True, timeout=30)
    if proc.returncode:
        raise ValueError('Python runtime or required packages unavailable: ' + ', '.join(packages))
    return json.loads(proc.stdout.strip().splitlines()[-1])


def check_policy_python():
    versions = check_python('/usr/bin/python3', ['numpy', 'scipy', 'Pillow', 'PyYAML'])
    # Frozen task helpers use OpenCV in the isolated system Python environment.
    proc = subprocess.run(['/usr/bin/python3', '-c', 'import cv2; print(cv2.__version__)'],
                          capture_output=True, text=True, timeout=30)
    if proc.returncode:
        raise ValueError('Install OpenCV for /usr/bin/python3 (for example python3-opencv)')
    versions['OpenCV'] = proc.stdout.strip().splitlines()[-1]
    return versions


def check_simulator_python(executable):
    versions = check_python(executable, ['isaacsim', 'torch', 'numpy', 'h5py', 'PyYAML', 'Pillow', 'scipy'])
    if versions['isaacsim'] not in {'5.1.0', '5.1.0.0'}:
        raise ValueError('The evaluation requires Isaac Sim 5.1.0')
    if versions['torch'] != '2.7.0+cu128':
        raise ValueError('The evaluation requires PyTorch 2.7.0 with the CUDA 12.8 wheel')
    return versions


def check_codex(config, auth):
    binary = shutil.which('codex')
    if not binary or not Path(binary).resolve().with_name('codex-code-mode-host').is_file():
        raise ValueError('Install the pinned standalone Codex CLI and companion on PATH')
    version = subprocess.check_output([binary, '--version'], text=True, timeout=15).strip()
    if version != config['codex_version']:
        raise ValueError('Codex CLI version differs from the pinned config')
    if not auth.is_file():
        raise ValueError('Authenticate locally or supply --auth; credentials are never bundled')
    return {'version': version, 'auth_file_present': True,
            'model_access': 'Not contacted; use doctor --model-smoke to verify'}


def check_task_package(config, task):
    if config.get('evaluation_setting') != SETTING:
        return {'setting': 'zero-shot', 'package_required': False}
    ref = config['task_packages'].get(str(task))
    if ref is None:
        raise ValueError(f'Config has no frozen package for task {task}')
    verify_package(Path(ref['path']), ref['sha256'], task, config)
    return {'task': task, 'manifest_sha256': ref['sha256'], 'verified': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-only', action='store_true', help='Check installed source resources only')
    parser.add_argument('--require-model', action='store_true', help='Also check pinned CLI and auth-file presence')
    parser.add_argument('--task', type=int, choices=sorted(ROBOTS), default=26)
    parser.add_argument('--config', type=Path, default=ROOT / 'configs/default.json')
    parser.add_argument('--auth', type=Path, default=Path.home() / '.codex/auth.json')
    for name, env in [('upstream', 'BENCH2DEX_ROOT'), ('isaaclab', 'ISAACLAB_ROOT'),
                      ('assets', 'BENCH2DEX_ASSETS'), ('python', 'ISAACLAB_PYTHON')]:
        parser.add_argument('--' + name, type=Path, default=os.environ.get(env))
    args = parser.parse_args()
    checks = []
    def check(name, operation):
        try:
            checks.append({'check': name, 'passed': True, 'details': operation()})
        except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as exc:
            checks.append({'check': name, 'passed': False, 'error': str(exc)})
    check('source', check_source)
    config = None
    def selected_config():
        nonlocal config
        config = load_config(args.config)
        return {'schema': config['schema_version']}
    check('config', selected_config)
    if config is not None:
        check('task_package', lambda: check_task_package(config, args.task))
    if not args.source_only and config is not None:
        check('upstream', lambda: check_repository(args.upstream, config['upstream_commit']))
        check('isaaclab', lambda: check_repository(args.isaaclab, config['isaaclab_commit']))
        check('assets', lambda: check_assets(args.upstream, args.assets, args.task))
        check('simulator_python', lambda: check_simulator_python(args.python))
        check('policy_python', check_policy_python)
        def bubblewrap():
            if not shutil.which('bwrap'):
                raise ValueError('Install bubblewrap; run doctor to test namespace permissions')
            return 'present; namespace execution is checked by doctor'
        check('bubblewrap', bubblewrap)
    if args.require_model and config is not None:
        check('codex', lambda: check_codex(config, args.auth))
    passed = all(row['passed'] for row in checks)
    print(json.dumps({'passed': passed, 'checks': checks,
                      'scope': 'Read-only setup checks, not an end-to-end evaluation'}, indent=2))
    return 0 if passed else 1


if __name__ == '__main__':
    sys.exit(main())
