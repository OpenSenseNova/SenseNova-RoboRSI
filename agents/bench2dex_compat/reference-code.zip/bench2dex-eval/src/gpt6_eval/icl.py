"""Task preparation: sanitized demonstrations -> isolated research -> frozen knowledge.

No scored evaluations are started by this command. Existing outputs are immutable.
"""
import argparse
import importlib.metadata
import json
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

import numpy as np
import yaml

from . import isolation
from .cli import ROOT, git, load_config, load_task
from .core import CAMERAS, MODEL, canonical, digest, verify_model_rollouts, write_json
from .knowledge import SETTING, contract, file_hash, tree_hashes, verify_package
from .robot import kinematics, kinematic_urdf
from .telemetry import token_usage, utc_now
from .throughput import encode_frames, wait_for_export_space, content_hashes


def scalar(f, name):
    value = f[name][()]
    return value.decode('utf-8') if isinstance(value, bytes) else value.item() if isinstance(value, np.generic) else value


def strings(ds):
    return [s.decode() if isinstance(s, bytes) else str(s) for s in ds[:]]


def export_demo(source, output, active_names, instruction, robot, cameras, scene_name, *, encoding_workers=4, include_images=True, legacy_provenance=None, scene_alias=None):
    """Reconstruct safe RGB/state/action files; no HDF5 metadata/groups copied."""
    import h5py
    if legacy_provenance is not None:
        from .task51_legacy_provenance import validate_source
        validate_source(source, legacy_provenance, scene_name, robot)
    with h5py.File(source, 'r') as f:
        sample = json.loads(scalar(f, 'meta/scene_generalization_sample'))
        if sample.get('_generalization_split') != 'seen':
            raise ValueError('Only explicitly seen demonstrations are permitted')
        if legacy_provenance is None:
            if scalar(f, 'meta/seed_namespace') != 'collection':
                raise ValueError('Demonstration is not from the collection seed namespace')
            seed_provenance = {'collection_seed': scalar(f, 'meta/episode_seed')}
        else:
            from .task51_legacy_provenance import validate_metadata
            seed_provenance = validate_metadata(f['meta'], scalar)
        recorded_scene = scalar(f, 'meta/scene_name')
        if scalar(f, 'meta/robot_key') != robot:
            raise ValueError('Demonstration scene/robot mismatch')
        if scene_alias is None:
            if recorded_scene != scene_name:
                raise ValueError('Demonstration scene/robot mismatch')
        else:
            from .task62_scene_alias import validate_recorded_scene
            validate_recorded_scene(scene_name, robot, recorded_scene, scene_alias)
        recorded_instruction = scalar(f, 'meta/instruction')
        if not isinstance(recorded_instruction, str) or not recorded_instruction.strip():
            raise ValueError('Missing recorded demonstration instruction')
        # Robot state and action may have different recorded orderings.
        joints, actions = strings(f['robot/joint_names']), strings(f['action/action_names'])
        if len(set(joints)) != len(joints) or len(set(actions)) != len(actions):
            raise ValueError('Duplicate joint names')
        qi, ai = [joints.index(n) for n in active_names], [actions.index(n) for n in active_names]
        q = np.asarray(f['robot/qpos'][:], dtype=np.float32)[:, qi]
        full_actions = np.asarray(f['action/commanded'][:], dtype=np.float32)
        a = full_actions[:, ai]
        if q.shape != a.shape or not len(q) or not np.isfinite(q).all():
            raise ValueError('Invalid demonstration arrays')
        # Match upstream ACT's NaN-action fallback, without filling infinities.
        fallback = np.isnan(full_actions).any(axis=1)
        a[fallback] = q[fallback]
        if not np.isfinite(a).all():
            raise ValueError('Non-finite demonstration actions')
        stride, fps = int(scalar(f, 'meta/step_stride')), float(scalar(f, 'meta/effective_fps'))
        if stride != 3 or fps != 20:
            raise ValueError('Expected released 20 Hz demonstrations')
        # Exclude the post-task homing suffix just as the baseline loader does.
        count = len(q)
        if 'meta/homing_start_sim_step' in f and 'time/sim_step' in f:
            homing = int(scalar(f, 'meta/homing_start_sim_step'))
            if homing >= 0:
                count = int(np.count_nonzero(f['time/sim_step'][:] < homing))
        if count < 1:
            raise ValueError('No pre-homing frames')
        output.mkdir(parents=True)
        np.save(output / 'qpos.npy', q[:count], allow_pickle=False)
        np.save(output / 'actions.npy', a[:count], allow_pickle=False)
        for camera in cameras:
            rgb = f[f'cameras/{camera}/rgb']
            if len(rgb) != len(q):
                raise ValueError('RGB/state length mismatch')
            if not include_images:
                continue
            folder = output / camera
            folder.mkdir()
            raw_frames = (bytes(rgb[index]) for index in range(count))
            for index, png in enumerate(encode_frames(raw_frames, encoding_workers)):
                (folder / f'{index:06d}.png').write_bytes(png)
        write_json(output / 'demo.json', {'frames': count, 'sample_hz': fps,
                   'joint_names': active_names, 'camera_order': list(cameras),
                   'recorded_instruction': recorded_instruction,
                   'instruction_matches_current_task': recorded_instruction == instruction,
                   'action_semantics': 'absolute active-joint targets',
                   'nan_action_rows_replaced_by_qpos': int(fallback[:count].sum())})
        # Private provenance: deliberately not placed in public demo.json.
        return {**seed_provenance,
                'split': 'seen', 'frames': count,
                'instruction_matches_current_task': recorded_instruction == instruction,
                **({'recorded_scene_name': recorded_scene} if scene_alias is not None else {})}


def preparation_config(path):
    config = load_config(path)
    if config['schema_version'] != 2 or config['reasoning_effort'] != 'max':
        raise ValueError('Preparation uses calibrated schema-2 Astra/max config')
    return config


def training_robot_card(upstream, assets, robot):
    mapping = yaml.safe_load((upstream / 'robots/active_dof_maps.yml').read_text())['robots'][robot]
    names = mapping['active_joint_names']
    geometry = kinematics(assets / mapping['urdf_path'].removeprefix('Bench2Dex/'))
    geometry['urdf_to_runtime_joint_names'] = mapping.get('name_sanitize', {})
    rename = geometry['urdf_to_runtime_joint_names']
    joints = {rename.get(j['name'], j['name']): j for j in geometry['joints']}
    inactive = {n: 0.0 for n in mapping['full_joint_names'] if n not in names and 'mimic' not in joints.get(n, {})}
    return {'robot_key': robot, 'active_joint_names': names, 'kinematics': geometry,
            'inactive_joint_positions': inactive,
            'position_limits': [[float(joints[n]['limit']['lower']), float(joints[n]['limit']['upper'])] for n in names],
            'resolved_joint_units': ['metre' if joints[n]['type']=='prismatic' else 'radian' for n in names]}


def prepare(args):
    started, started_at = time.monotonic(), utc_now()
    config = preparation_config(args.config)
    if git(args.upstream, 'rev-parse', 'HEAD') != config['upstream_commit'] or git(args.upstream, 'status', '--porcelain'):
        raise ValueError('Upstream must be clean and pinned')
    scene, task, robot = load_task(args.upstream, args.task)
    inventory = json.loads((args.dataset / '.download_logs/inventory.json').read_text())
    if (inventory['repo'] != 'Bench2Dex/teleopdata'
            or inventory['revision'] != 'b195787c65046083e6a43776b67bdf1389dfa3eb'):
        raise ValueError('Not the pinned official demonstration inventory')
    # Choose all replay-generalization variants for the task, never by outcomes.
    selected = [e for e in inventory['files'] if e['path'].startswith(f'dataset/{args.task:02d}_')
                and '/replay-generalization/' in e['path'] and e['path'].endswith('.hdf5')]
    if len(selected) != 100 or len({e['path'] for e in selected}) != 100:
        raise ValueError('Expected all 100 released task replay files, including variants')
    scene_alias = None
    if args.task == 62:
        from .task62_scene_alias import validate_selection
        scene_alias = validate_selection(args.task, inventory['repo'], inventory['revision'],
                                         scene.stem, robot, selected)
    legacy = None
    if getattr(args, 'task51_legacy_provenance', False):
        if getattr(args, 'access_mode', 'export') != 'trusted_reader_v1':
            raise ValueError('Task51 legacy exception requires trusted-reader source rehash gates')
        from .task51_legacy_provenance import validate_selection
        exception = validate_selection(args.task, inventory['repo'], inventory['revision'],
                                       scene.stem, robot, selected)
        legacy = {'task_id': args.task, 'repo': inventory['repo'],
                  'revision': inventory['revision'], 'dataset_root': str(args.dataset),
                  'entries': selected}
    if args.output.exists():
        raise ValueError('Use a new training export directory')
    card = training_robot_card(args.upstream, args.assets, robot)
    names = card['active_joint_names']
    public = args.output / 'public'
    public.mkdir(parents=True)
    from .suite import freeze_source
    source_hashes = freeze_source(args.output / 'private/source')
    record = {'setting': SETTING, 'task_id': args.task, 'contract': contract(config),
              'robot_key': robot, 'instruction_sha256': digest(task['description'].encode()),
              'dataset_repo': inventory['repo'], 'dataset_revision': inventory['revision'],
              'state': 'exporting', 'started_at': started_at, 'demonstrations': [],
              'source_hashes': source_hashes, 'host_python': sys.version,
              'dependencies': {p: importlib.metadata.version(p) for p in ('numpy','Pillow','h5py','PyYAML')},
              'host_export': {'encoding_workers': getattr(args, 'encoding_workers', 4),
                              'ordered_io': True, 'max_pending_frames_per_worker': 2}}
    lazy = getattr(args, 'access_mode', 'export') == 'trusted_reader_v1'
    if legacy is not None:
        record.update(provenance_exception=exception, scene_name=scene.stem)
    if scene_alias is not None:
        record.update(scene_alias=scene_alias, scene_name=scene.stem)
    if lazy:
        record.update(access_mode='trusted_reader_v1', dataset_root=str(args.dataset),
                      scene_name=scene.stem)
    write_json(args.output / 'manifest.json', record)
    try:
        write_json(public / 'task.json', {'instruction': task['description'], 'robot_key': robot,
                    'observation_profile': config['observation_profile']})
        write_json(public / 'robot.json', card)
        (public / 'robot.urdf').write_text(kinematic_urdf(card))
        for index, entry in enumerate(sorted(selected, key=lambda e:e['path'])):
            rel = Path(entry['path'])
            if rel.is_absolute() or '..' in rel.parts:
                raise ValueError('Unsafe demonstration path')
            source = args.dataset / rel
            if lazy:
                from .demo_reader import source_signature
                signature = source_signature(source)
            if not source.is_file() or source.stat().st_size != entry['bytes'] or not entry.get('sha256') or file_hash(source) != entry['sha256']:
                raise ValueError(f'Demonstration missing/incomplete/checksum mismatch: {rel}')
            if not lazy:
                import h5py
                with h5py.File(source, 'r') as f:
                    wait_frames = len(f['robot/qpos'])
                wait_for_export_space(args.output, wait_frames)
            else:
                if source_signature(source) != signature:
                    raise ValueError('Source changed during hashing')
            provenance = export_demo(source, public / 'demos' / f'{index:04d}', names,
                        task['description'], robot, CAMERAS[config['observation_profile']], scene.stem,
                        encoding_workers=getattr(args, 'encoding_workers', 4), include_images=not lazy,
                        legacy_provenance=legacy, scene_alias=scene_alias)
            if lazy:
                if source_signature(source) != signature:
                    raise ValueError('Source changed during indexing')
                provenance['source_signature'] = signature
            record['demonstrations'].append({**entry, **provenance, 'public_id': f'{index:04d}'})
            write_json(args.output / 'manifest.json', record)
            print(f'{"Indexed" if lazy else "Exported"} {index+1}/{len(selected)}', flush=True)
        record.update(state='complete', public_files=tree_hashes(public), completed_at=utc_now())
    except BaseException as exc:
        record.update(state='failed', error=f'{type(exc).__name__}: {exc}')
        raise
    finally:
        record['wall_seconds'] = time.monotonic()-started
        write_json(args.output / 'manifest.json', record)


def verify_training(public, expected):
    print('Verifying all training files before crossing the preparation boundary...', flush=True)
    actual = content_hashes(public, progress=lambda row:
        print('Training verification: '+json.dumps(row), flush=True))
    if actual != expected:
        raise ValueError('Training export changed')


def explore(args):
    started, started_at = time.monotonic(), utc_now()
    config = preparation_config(args.config)
    training = json.loads((args.training / 'manifest.json').read_text())
    if training.get('state') != 'complete' or training['contract'] != contract(config):
        raise ValueError('Training export incomplete or incompatible')
    from .task51_legacy_provenance import validate_training
    validate_training(training)
    from .task62_scene_alias import validate_training as validate_task62_training
    validate_task62_training(training)
    verify_training(args.training / 'public', training['public_files'])
    binary = Path(shutil.which('codex') or '/missing')
    if subprocess.check_output([str(binary), '--version'], text=True).strip() != config['codex_version']:
        raise ValueError('Pinned Codex CLI required')
    if args.output.exists():
        raise ValueError('Use a new preparation run')
    workspace, private = args.output / 'workspace', args.output / 'private'
    (workspace / 'input').mkdir(parents=True)
    (workspace / 'package').mkdir()
    home, interface = private / 'codex-home', private / 'interface'
    interface.mkdir(parents=True)
    shutil.copyfile(ROOT / 'src/gpt6_eval/kinematics_tool.py', interface / 'kinematics_tool.py')
    lazy = training.get('access_mode') == 'trusted_reader_v1'
    prompt = (ROOT / ('prompts/preparation_reader.md' if lazy else 'prompts/preparation.md')).read_text()
    reader = None
    if lazy:
        from .demo_reader import DemoReader
        shutil.copyfile(ROOT / 'src/gpt6_eval/demo_reader_client.py', interface / 'demo_reader.py')
        reader = DemoReader(training, args.training / 'public', private)
    (private / 'prompt.md').write_text(prompt)
    write_json(private / 'training_manifest.json', training)
    from .suite import freeze_source
    source_hashes = freeze_source(private / 'source')
    cmd = isolation.command(workspace, home, interface, binary, config, preparation=True,
                            input_source=args.training / 'public')
    record = {'setting': SETTING, 'state': 'preparing', 'task_id': training['task_id'],
              'contract': contract(config), 'training_manifest_sha256': file_hash(args.training / 'manifest.json'),
              'source_hashes': source_hashes, 'prompt_sha256': digest(prompt.encode()),
              'binary_sha256': file_hash(binary.resolve()), 'argv': cmd,
              'started_at': started_at, 'web_search': 'live', 'tool_network': False,
              'simulator_practice': False}
    if 'provenance_exception' in training:
        record['provenance_exception'] = training['provenance_exception']
    if 'scene_alias' in training:
        record['scene_alias'] = training['scene_alias']
    write_json(args.output / 'preparation.json', record)
    inference_started, inference_ended, proc = None, None, None
    try:
        if reader is not None:
            reader.start()
        isolation.prepare_auth(home, args.auth)
        packages = subprocess.check_output(isolation.mounts(workspace, home, interface, binary,
                    numerical_runtime=True, input_source=args.training / 'public') +
                    ['--', '/usr/bin/python3', '-c',
                     "import importlib.metadata as m,json,sys;print(sys.version);print(json.dumps(sorted((d.metadata['Name'],d.version) for d in m.distributions())))"])
        (private / 'policy-packages.txt').write_bytes(packages)
        with (private / 'codex.events.jsonl').open('wb') as out, (private / 'codex.stderr.log').open('wb') as err:
            proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=out, stderr=err, start_new_session=True)
            inference_started = time.monotonic()
            proc.communicate(prompt.encode())
            inference_ended = time.monotonic()
        if proc.returncode != 0:
            raise RuntimeError(f'Preparation Codex exited {proc.returncode}; no package admitted')
        evidence = verify_model_rollouts(home)
        # Required markers must be regular files inside the workspace.
        tree_hashes(workspace / 'package')
        ready_path = workspace / 'ready.json'
        if ready_path.is_symlink() or not ready_path.is_file():
            raise ValueError('Missing regular readiness record')
        ready = json.loads(ready_path.read_text())
        if set(ready) != {'ready', 'summary'} or ready['ready'] is not True or not isinstance(ready['summary'], str) or not ready['summary'].strip():
            raise ValueError('Model has not declared preparation complete')
        verify_training(args.training / 'public', training['public_files'])
        if reader is not None:
            reader.finish()
        record.update(state='ready', model_evidence=evidence, readiness=ready)
        frozen = args.output / 'frozen'
        frozen.mkdir()
        shutil.copytree(workspace / 'package', frozen / 'payload')
        files = tree_hashes(frozen / 'payload')
        if not all(files.get(k) for k in ('TASK.md', 'SOURCES.md')):
            raise ValueError('Preparation must produce TASK.md and SOURCES.md')
        manifest = {'setting': SETTING, 'task_id': training['task_id'], 'contract': contract(config),
                    'robot_key': training['robot_key'], 'instruction_sha256': training['instruction_sha256'],
                    'preparation_model': MODEL, 'ready': True, 'files': files,
                    'training_manifest_sha256': record['training_manifest_sha256'],
                    'preparation_prompt_sha256': record['prompt_sha256'],
                    'model_evidence': evidence,
                    'preparation_tokens': token_usage(private, 'codex', returncode=proc.returncode),
                    'preparation_inference_tool_wall_seconds': inference_ended-inference_started,
                    'web_events_sha256': file_hash(private / 'codex.events.jsonl')}
        if reader is not None:
            manifest.update(demonstration_access='trusted_reader_v1',
                            reader_audit_sha256=file_hash(private / 'demo_reader_audit.json'))
        if 'provenance_exception' in training:
            manifest['provenance_exception'] = training['provenance_exception']
        if 'scene_alias' in training:
            manifest['scene_alias'] = training['scene_alias']
        write_json(frozen / 'manifest.json', manifest)
        sha = file_hash(frozen / 'manifest.json')
        verify_package(frozen, sha, training['task_id'], config)
        record['package'] = {'path': str(frozen.resolve()), 'sha256': sha}
    except BaseException as exc:
        record.update(state='failed', error=f'{type(exc).__name__}: {exc}')
        raise
    finally:
        if reader is not None:
            reader.close()
        if proc is not None and proc.poll() is None:
            proc.terminate()
            try: proc.wait(timeout=10)
            except subprocess.TimeoutExpired: proc.kill(); proc.wait()
        (home / 'auth.json').unlink(missing_ok=True)
        record.update(ended_at=utc_now(), wall_seconds=time.monotonic()-started,
            inference_tool_wall_seconds=(inference_ended or time.monotonic())-inference_started if inference_started is not None else 0,
            tokens=token_usage(private, 'codex', process_started=proc is not None,
                               returncode=proc.returncode if proc is not None else None))
        write_json(args.output / 'preparation.json', record)


def make_config(args):
    config = preparation_config(args.config)
    refs = {}
    for run in args.preparation:
        record = json.loads((run / 'preparation.json').read_text())
        if record.get('state') != 'ready' or record['contract'] != contract(config):
            raise ValueError('Preparation did not complete successfully')
        task = record['task_id']
        if str(task) in refs:
            raise ValueError('Duplicate task preparation')
        ref = record['package']
        verify_package(Path(ref['path']), ref['sha256'], task, config)
        refs[str(task)] = ref
    if args.output.exists():
        raise ValueError('Refusing to overwrite configuration')
    write_json(args.output, {**config, 'schema_version': 3, 'evaluation_setting': SETTING,
                            'task_packages': refs})
    load_config(args.output)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    subs = parser.add_subparsers(dest='command', required=True)
    p = subs.add_parser('prepare', help='Export only permitted seen-demonstration fields; no model')
    for name in ('config', 'upstream', 'assets', 'dataset', 'output'):
        p.add_argument('--'+name, type=Path, required=True)
    p.add_argument('--task', type=int, required=True)
    p.add_argument('--encoding-workers', type=int, choices=range(1, 9), default=4)
    p.add_argument('--access-mode', choices=('export', 'trusted_reader_v1'), default='export')
    p.add_argument('--task51-legacy-provenance', action='store_true',
                   help='Explicit Task51-only pinned legacy exception; unknown seeds remain private/null')
    p.set_defaults(func=prepare)
    p = subs.add_parser('explore', help='Run Astra/max with demonstrations and live web search; freeze when ready')
    for name in ('config', 'training', 'output'):
        p.add_argument('--'+name, type=Path, required=True)
    p.add_argument('--auth', type=Path, default=Path.home()/'.codex/auth.json')
    p.set_defaults(func=explore)
    p = subs.add_parser('config', help='Build explicit ICL test config from completed preparations')
    p.add_argument('--config', type=Path, required=True)
    p.add_argument('--preparation', type=Path, action='append', required=True)
    p.add_argument('--output', type=Path, required=True)
    p.set_defaults(func=make_config)
    args = parser.parse_args()
    for key, value in vars(args).items():
        if isinstance(value, Path): setattr(args, key, value.resolve())
    def interrupted(signum, frame): raise KeyboardInterrupt(f'Received signal {signum}')
    signal.signal(signal.SIGTERM, interrupted)
    args.func(args)


if __name__ == '__main__':
    main()
