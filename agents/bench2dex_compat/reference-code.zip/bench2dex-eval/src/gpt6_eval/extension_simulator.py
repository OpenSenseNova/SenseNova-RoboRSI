"""Private replay validation hooks; no evaluator state enters the policy mount."""
from __future__ import annotations

from functools import partial
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from .core import write_json
from .extension import TOLERANCES, load_source, numeric_digest, read, require
from .trajectory import TrajectoryRecorder


class PrefixValidator:
    def __init__(self, source, destination):
        self.source = source
        self.destination = Path(destination)
        self.index = 0
        self.maximum_errors = {}
        self.metric_checked = False

    def fail(self, message):
        write_json(self.destination, {'state': 'diverged', 'error': message,
                   'validated_samples': self.index, 'maximum_errors': self.maximum_errors,
                   'tolerances': TOLERANCES, 'exact_checkpoint_restore': False})
        raise ValueError(message)

    def compare(self, name, actual, expected):
        actual = np.asarray(actual)
        expected = np.asarray(expected)
        if actual.shape != expected.shape or not np.isfinite(actual).all():
            self.fail('Replay shape/nonfinite mismatch: ' + name)
        if name.startswith('cameras/'):
            tolerance = TOLERANCES['calibration']
        elif name.endswith(('qvel', 'lin_vel_world', 'ang_vel_world')):
            tolerance = TOLERANCES['velocity']
        else:
            tolerance = TOLERANCES['joint_position']
        difference = np.abs(actual - expected)
        if name.endswith(('pose_world', 'root_state_world')):
            if actual.ndim != 1 or len(actual) not in (7, 13):
                self.fail('Unsupported replay pose: ' + name)
            difference = difference.copy()
            if np.dot(actual[3:7], expected[3:7]) < 0:
                difference[3:7] = np.abs(actual[3:7] + expected[3:7])
            limits = np.full(actual.shape, TOLERANCES['position'])
            limits[3:7] = TOLERANCES['quaternion']
            limits[7:] = TOLERANCES['velocity']
        else:
            limits = tolerance
        maximum = float(difference.max(initial=0))
        self.maximum_errors[name] = max(self.maximum_errors.get(name, 0), maximum)
        if np.any(difference > limits):
            self.fail(f'Replay divergence at sample {self.index}: {name}, maximum error {maximum}')

    def sample(self, values):
        expected_arrays = self.source['arrays']
        require(self.index < self.source['baseline']['standard_policy_steps'], 'Replay exceeded prefix')
        for name, expected in expected_arrays.items():
            if name.startswith(('time/', 'action/')):
                continue
            if name not in values:
                self.fail('Missing replay state: ' + name)
            self.compare(name, values[name], expected[self.index])
        if not np.array_equal(values['action/commanded'], expected_arrays['action/commanded'][self.index]):
            self.fail('Replay applied a different saved action')
        self.index += 1

    def boundary(self, metric):
        original = self.source['official']
        if self.index != self.source['baseline']['standard_policy_steps']:
            self.fail('Incomplete prefix before metric boundary')
        if metric.stable_success or abs(metric.latched_stage_completion_rate
                                        - original['latched_stage_completion_rate']) > 1e-12:
            self.fail('Replay 1x SR/LSCR differs from the original')
        for name in ('stage_completion', 'current_stage_completion', 'stage_first_completion_step'):
            if name not in original or getattr(metric, name) != original[name]:
                self.fail('Replay 1x stage history mismatch: ' + name)
        self.metric_checked = True
        write_json(self.destination, {'state': 'verified', 'validated_samples': self.index,
                   'maximum_errors': self.maximum_errors, 'tolerances': TOLERANCES,
                   'baseline_lscr': metric.latched_stage_completion_rate,
                   'stage_completion': metric.stage_completion,
                   'exact_checkpoint_restore': False, 'terminal_frame_comparison_available': False,
                   'method': 'Every archived pre-action numeric state and action; original reset metadata; exact 1x stage history and SR/LSCR. Final three physics steps have no archived terminal state.'})


class ExtensionRecorder(TrajectoryRecorder):
    def __init__(self, *args, validator, **kwargs):
        super().__init__(*args, **kwargs)
        self.validator = validator
        self.context['policy_step_offset'] = validator.source['baseline']['standard_policy_steps']

    def start_episode(self, *args, metadata=None, **kwargs):
        if (metadata or {}).get('scene_generalization_sample') != self.validator.source['reset_metadata']:
            self.validator.fail('Reset/generalization metadata differs from original')
        super().start_episode(*args, metadata=metadata, **kwargs)

    def record_step(self, qpos, action, object_states, camera_frames):
        if self.validator.index < self.validator.source['baseline']['standard_policy_steps']:
            robot = self.context['robot']
            values = {'robot/qpos': qpos, 'action/commanded': np.asarray(action, dtype=np.float32),
                      'robot/qvel': robot.data.joint_vel[0].detach().cpu().numpy(),
                      'robot/root_state_world': robot.data.root_state_w[0].detach().cpu().numpy()}
            for object_id, state in object_states.items():
                for name in ('pose_world', 'lin_vel_world', 'ang_vel_world', 'qpos', 'qvel'):
                    if state.get(name) is not None:
                        values[f'objects/{object_id}/{name}'] = state[name]
            for camera_id, camera in self.context.get('camera_frames', {}).items():
                for name in ('intrinsic', 'extrinsic_world_from_cam', 'cam_pos_w', 'cam_quat_wxyz',
                             'distortion_coefficients', 'fisheye_camera_matrix', 'clipping_range'):
                    value = camera.get(name) if isinstance(camera, dict) else getattr(camera, name, None)
                    if value is not None:
                        values[f'cameras/{camera_id}/{name}'] = value
            self.validator.sample(values)
            return
        require(self.validator.metric_checked, 'Extension recording before verified 1x boundary')
        return super().record_step(qpos, action, object_states, camera_frames)


def boundary_metrics(tracker, snapshot):
    stages = tracker._stage_tracker._result() if tracker._stage_tracker is not None else None
    return SimpleNamespace(stable_success=snapshot.stable_success,
                           latched_stage_completion_rate=stages.latched_stage_completion_rate if stages else 0.0,
                           stage_completion=dict(stages.completed) if stages else {},
                           current_stage_completion=dict(stages.current_completed) if stages else {},
                           stage_first_completion_step=dict(stages.first_completed_step) if stages else {})


def install(spec_path, context, recorder_module):
    from benchmark import metric_tracker
    spec = read(spec_path)
    source = load_source(spec['source'], task_id=spec['task_id'])
    require(source['evidence'] == spec['source_evidence'], 'Source changed between host and simulator')
    require(numeric_digest(source['arrays']) == spec['source_evidence']['numeric_trajectory_sha256'],
            'Source numeric trajectory changed')
    validator = PrefixValidator(source, Path(spec_path).parent / 'replay_validation.json')
    original_tracker = metric_tracker.MetricTracker

    class ExtensionMetricTracker(original_tracker):
        def update(self, object_states, **kwargs):
            snapshot = super().update(object_states, **kwargs)
            step = kwargs['sim_step']
            boundary = source['baseline']['standard_policy_steps'] * 3
            if step < boundary and snapshot.stable_success:
                validator.fail('Replay succeeded before the original 1x failure endpoint')
            if step + 1 == boundary:
                validator.boundary(boundary_metrics(self, snapshot))
            return snapshot

    metric_tracker.MetricTracker = ExtensionMetricTracker
    recorder_module.InferenceRecorder = partial(ExtensionRecorder, context=context, validator=validator)
    return validator
