"""One-time drain of a pre-graceful-stop scheduler (Linux pidfd required)."""
import argparse
import json
import os
from pathlib import Path
import select
import signal

from .telemetry import utc_now


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batch-pid", type=int, required=True)
    parser.add_argument("--episode-pid", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.output.resolve()
    # Pin identities before signaling; never target a process group or GPU owner.
    batch_fd = os.pidfd_open(args.batch_pid)
    episode_fd = os.pidfd_open(args.episode_pid)
    batch_argv = Path(f"/proc/{args.batch_pid}/cmdline").read_bytes().split(b"\0")
    episode_argv = Path(f"/proc/{args.episode_pid}/cmdline").read_bytes().split(b"\0")
    if b"gpt6_eval.batch" not in batch_argv or str(root).encode() not in batch_argv:
        raise RuntimeError("Scheduler identity/output mismatch")
    if b"gpt6_eval.cli" not in episode_argv or str(root / "episode_0000").encode() not in episode_argv:
        raise RuntimeError("Episode identity/output mismatch")
    status = Path(f"/proc/{args.episode_pid}/status").read_text()
    parent = next(line.split()[1] for line in status.splitlines() if line.startswith("PPid:"))
    if int(parent) != args.batch_pid:
        raise RuntimeError("Episode is not a child of this scheduler")
    signal.pidfd_send_signal(batch_fd, signal.SIGSTOP)
    record = {"requested_at": utc_now(), "batch_pid": args.batch_pid,
              "episode_pid": args.episode_pid, "state": "draining",
              "reason": "User requested stopping after the first evaluation",
              "method": "pause legacy scheduler; wait for episode exit; SIGTERM then SIGCONT scheduler"}
    path = root / "legacy-stop.json"
    def save():
        path.write_text(json.dumps(record, indent=2) + "\n")
        print(json.dumps(record), flush=True)
    save()
    try:
        select.select([episode_fd], [], [])
        # Child has finished result/telemetry/trajectory finalization. Pending
        # TERM is handled before the scheduler can admit another episode.
        signal.pidfd_send_signal(batch_fd, signal.SIGTERM)
        signal.pidfd_send_signal(batch_fd, signal.SIGCONT)
        select.select([batch_fd], [], [])
        record.update(state="stopped_after_episode_exit", ended_at=utc_now())
        save()
    finally:
        os.close(episode_fd)
        os.close(batch_fd)


if __name__ == "__main__":
    main()
