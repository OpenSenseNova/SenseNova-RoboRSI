"""Policy-side early failure declaration for the separate extension setting."""
import json
from pathlib import Path
import sys

from step import submit


if __name__ == '__main__':
    reason = ' '.join(sys.argv[1:]).strip()
    if not reason or len(reason) > 2000:
        raise SystemExit('Provide a short failure reason based only on your observations')
    path = Path('/workspace/extension_give_up.json')
    path.write_text(json.dumps({'give_up': reason}))
    print(json.dumps(submit(path)))
