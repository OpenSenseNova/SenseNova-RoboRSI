"""Private, explicitly opted-in Task51 legacy-provenance amendment.

Not evidence of collection namespace: unknown fields remain unknown. No value
from this module or the original private seed metadata is policy-visible.
"""
import hashlib
import json
from pathlib import Path

TASK = 51
REPO = 'Bench2Dex/teleopdata'
REVISION = 'b195787c65046083e6a43776b67bdf1389dfa3eb'
SCENE = '51_toilet_lid_cleaner_pour'
ROBOT = 'multi_xarm7_with_leap'
SET_SHA256 = '42ba69e4a4864371d12111b308a25f00bf347203344e4a861ccbcb3b406cbe56'
EXCEPTION = 'task51_pinned_seen_legacy_unknown_seed_v1'


def entries_digest(entries):
    rows = []
    for entry in entries:
        row = {k: entry[k] for k in ('path', 'bytes', 'sha256')}
        if (not isinstance(row['path'], str) or type(row['bytes']) is not int
                or not isinstance(row['sha256'], str)):
            raise ValueError('Invalid legacy source inventory fields')
        rows.append(row)
    if len(rows) != 100 or len({r['path'] for r in rows}) != 100:
        raise ValueError('Legacy exception requires exactly100 distinct pinned files')
    return hashlib.sha256(json.dumps(sorted(rows, key=lambda r:r['path']),
                          sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def validate_selection(task, repo, revision, scene, robot, entries):
    if (type(task) is not int or task != TASK or repo != REPO or revision != REVISION
            or scene != SCENE or robot != ROBOT):
        raise ValueError('Task51 legacy exception identity mismatch')
    if entries_digest(entries) != SET_SHA256:
        raise ValueError('Task51 legacy exception source-set mismatch')
    return disclosure()


def disclosure():
    return {'id': EXCEPTION, 'task_id': TASK, 'dataset_repo': REPO,
            'dataset_revision': REVISION, 'source_set_sha256': SET_SHA256,
            'source_count': 100, 'collection_namespace': None, 'episode_seed': None,
            'provenance_status': 'UNKNOWN', 'explicit_split': 'seen',
            'authorization': 'User-approved Task51-only legacy provenance exception, 2026-09-29',
            'limitation': 'Released pinned seen data lacks original collection namespace and episode seeds; neither is inferred.'}


def validate_source(source, context, scene, robot):
    """Revalidate host-only context and independently hash bytes before export."""
    validate_selection(context['task_id'], context['repo'], context['revision'],
                       scene, robot, context['entries'])
    root = Path(context['dataset_root'])
    path = Path(source)
    if not root.is_absolute() or path.resolve() != path or path.is_symlink():
        raise ValueError('Unsafe legacy source path')
    relative = str(path.relative_to(root))
    matches = [row for row in context['entries'] if row['path'] == relative]
    if len(matches) != 1:
        raise ValueError('Legacy source not in authorized cohort')
    row = matches[0]
    if not path.is_file() or path.stat().st_size != row['bytes']:
        raise ValueError('Legacy source size mismatch')
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(4 * 1024**2), b''):
            h.update(chunk)
    if h.hexdigest() != row['sha256']:
        raise ValueError('Legacy source content mismatch')


def validate_metadata(meta, scalar):
    """Pinned legacy files must not contain contradictory/new seed fields."""
    for key in ('seed_namespace', 'episode_seed', 'base_seed', 'task_seed_id',
                'task_base_seed', 'episode_index', 'seed_policy'):
        if key in meta:
            raise ValueError('Legacy exception requires absent seed-context fields')
    if scalar(meta, 'schema_version') != 'raw_hdf5_v2' or scalar(meta, 'seed') != 0:
        raise ValueError('Unexpected legacy metadata schema')
    return {'collection_seed': None, 'collection_namespace': None,
            'collection_provenance': 'UNKNOWN', 'provenance_exception': EXCEPTION}


def validate_training(training):
    """Recheck complete private index before any preparation/reader access."""
    value = training.get('provenance_exception')
    if value is None:
        if training.get('task_id') == TASK:
            raise ValueError('Task51 legacy exception disclosure missing')
        if any(row.get('provenance_exception') for row in training.get('demonstrations', [])):
            raise ValueError('Undisclosed legacy exception')
        return
    if value != disclosure():
        raise ValueError('Legacy exception disclosure changed')
    if training.get('access_mode') != 'trusted_reader_v1':
        raise ValueError('Legacy exception requires trusted-reader source rehashes')
    rows = training['demonstrations']
    validate_selection(training['task_id'], training['dataset_repo'],
                       training['dataset_revision'], training['scene_name'],
                       training['robot_key'], rows)
    for row in rows:
        if (row.get('split') != 'seen' or row.get('collection_seed', 'missing') is not None
                or row.get('collection_namespace', 'missing') is not None
                or row.get('collection_provenance') != 'UNKNOWN'
                or row.get('provenance_exception') != EXCEPTION):
            raise ValueError('Legacy source provenance changed or invented')
