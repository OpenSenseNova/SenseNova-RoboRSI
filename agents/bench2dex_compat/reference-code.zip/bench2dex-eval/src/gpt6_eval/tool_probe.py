"""Executed inside the Codex tool sandbox, not by the supervisor."""
from pathlib import Path
import socket
import json
import subprocess

assert not Path("/data").exists()
assert set(Path("/home").iterdir()) == {Path("/home/policy")}
Path("/workspace/probe.txt").write_text("permitted reasoning workspace")
try:
    Path("/workspace/input/forbidden-write").write_text("invalid")
except OSError:
    pass
else:
    raise AssertionError("Policy can modify evaluator-owned inputs")
try:
    Path("/codex-home/forbidden-write").write_text("invalid")
except (PermissionError, OSError):
    pass
else:
    raise AssertionError("Policy can modify model-evidence directory")
try:
    with socket.socket() as connection:
        connection.connect(("127.0.0.1", 9))
except PermissionError:
    pass
except OSError as error:
    if error.errno not in (1, 13):
        raise AssertionError("Network was not blocked by the tool sandbox") from error
else:
    raise AssertionError("Policy has network access")
payload = Path("/workspace/action.json")
original = '{"actions":[[0.0,0.0]]}'
payload.write_text(original)
reply = subprocess.check_output(["/usr/bin/python3", "/interface/step.py", str(payload)], text=True)
assert json.loads(reply) == {"episode_done": True}
assert payload.read_text() == original
request = json.loads(Path("/workspace/.action_transport/request.json").read_text())
assert request == {"decision": 0, "payload": json.loads(original)}
print("tool isolation passed")
