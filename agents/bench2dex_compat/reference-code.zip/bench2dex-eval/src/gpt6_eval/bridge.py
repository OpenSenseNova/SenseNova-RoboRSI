"""Private RPC server and one persistent, isolated Codex process per episode."""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor

import numpy as np

from .core import (canonical, digest, save_observation, validate_actions,
                   verify_model_rollouts, write_json)
from . import isolation
from .telemetry import EpisodeTelemetry, utc_now
from .calibration import PROFILE
from .robot import kinematic_urdf


class PolicyError(RuntimeError):
    """A policy submission/termination failure, rather than a broken evaluator."""


class Episode:
    def __init__(self, root, config, instruction, robot_key, kinematic_card,
                 policy_budget, binary, auth, prompt, mode="codex", replay=None):
        self.root, self.config, self.instruction = root, config, instruction
        self.robot_key, self.kinematic_card, self.budget = robot_key, kinematic_card, policy_budget
        self.binary, self.auth, self.prompt, self.mode = binary, auth, prompt, mode
        self.replay = replay
        self.workspace = root / "policy"
        self.inputs = self.workspace / "input"
        self.private = root / "private"
        self.home = self.private / "codex-home"
        self.interface = self.private / "interface"
        # Separate transport from model scratch filenames such as action.json.
        self.action_transport = self.private / "action-transport"
        for p in (self.inputs, self.private, self.interface, self.home, self.action_transport):
            p.mkdir(parents=True)
        shutil.copyfile(Path(__file__).with_name("step.py"), self.interface / "step.py")
        self.index = 0
        self.decision = 0
        self.last_decision_index = 0
        self.proc = None
        self.logs = []
        self.failure = None
        self.card = None
        self.stopped = threading.Event()
        self.finished = False
        self.encoder = ThreadPoolExecutor(max_workers=2, thread_name_prefix='observation-png')
        self.telemetry = EpisodeTelemetry(self.private, mode)
        self.calibrated = config.get("deployment_profile") == PROFILE
        if self.calibrated:
            shutil.copyfile(Path(__file__).with_name("kinematics_tool.py"), self.interface / "kinematics_tool.py")

    def observe(self, raw):
        if raw["language"] != self.instruction:
            raise RuntimeError("Task instruction changed unexpectedly")
        card = raw["robot_metadata"]
        expected_keys = {"robot_key", "active_joint_names", "position_limits", "action_semantics",
                         "joint_units", "physics_hz", "policy_hz"}
        if set(card) != expected_keys or card["robot_key"] != self.robot_key:
            raise RuntimeError("Invalid robot metadata")
        if self.card is None:
            self.card = json.loads(canonical(card))
            self.card["kinematics"] = self.kinematic_card
            if self.calibrated:
                self.card["inactive_joint_positions"] = self.kinematic_card["inactive_joint_positions"]
                kinds = {self.kinematic_card.get("urdf_to_runtime_joint_names", {}).get(j["name"], j["name"]): j["type"] for j in self.kinematic_card["joints"]}
                self.card["resolved_joint_units"] = ["metre" if kinds[n] == "prismatic" else "radian" for n in self.card["active_joint_names"]]
                urdf = kinematic_urdf(self.card)
                (self.inputs / "robot.urdf").write_text(urdf)
                (self.private / "robot.urdf").write_text(urdf)
            write_json(self.inputs / "robot.json", self.card)
            write_json(self.private / "robot.json", self.card)
        elif {k: self.card[k] for k in expected_keys} != card:
            raise RuntimeError("Robot interface metadata changed within episode")
        public = save_observation(self.inputs, self.index, raw,
                                  self.config["observation_profile"],
                                  len(self.card["active_joint_names"]), self.budget - self.index,
                                  path_prefix="input/", calibrated=self.calibrated, encoder=self.encoder)
        source = self.inputs / "observations" / f"{self.index:06d}"
        shutil.copytree(source, self.private / "observations" / source.name)
        if self.replay:
            expected = self.replay / "private/observations" / source.name / "observation.json"
            if expected.read_bytes() != canonical(public):
                raise RuntimeError(f"Replay observation mismatch at policy step {self.index}")
        self.index += 1
        return public

    def start(self):
        isolation.prepare_auth(self.home, self.auth)
        isolation.probe(self.workspace, self.home, self.interface, self.binary, self.private)
        package_probe = "import importlib.metadata as m,json,sys; print(sys.version); print(json.dumps(sorted((d.metadata['Name'],d.version) for d in m.distributions())))"
        if self.calibrated:
            package_probe = "import sys; sys.path.insert(0, '/interface'); from kinematics_tool import RobotKinematics; " + package_probe
        packages = subprocess.check_output(isolation.mounts(self.workspace, self.home,
                                           self.interface, self.binary, numerical_runtime=self.calibrated) +
                                           ["--", "/usr/bin/python3", "-c", package_probe])
        (self.private / "policy-packages.txt").write_bytes(packages)
        cmd = self.policy_command()
        write_json(self.private / "invocation.json", {"argv": cmd})
        (self.private / "prompt.md").write_text(self.prompt)
        self.logs = [(self.private / "codex.events.jsonl").open("wb"),
                     (self.private / "codex.stderr.log").open("wb")]
        self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=self.logs[0],
                                     stderr=self.logs[1], start_new_session=True)
        self.telemetry.model_process_started = True
        self.telemetry.flush()
        self.proc.stdin.write(self.prompt.encode())
        self.proc.stdin.close()

    def policy_command(self):
        return isolation.command(self.workspace, self.home, self.interface, self.binary, self.config)

    def model_evidence(self):
        return verify_model_rollouts(self.home)

    def validate_submission(self, payload, remaining, dof):
        return validate_actions(payload, dof, remaining)

    def action(self, raw):
        started, started_at = time.monotonic(), utc_now()
        decision, policy_step = self.decision, self.index
        accepted, error = False, None
        try:
            actions = self._action(raw)
            accepted = True
            return actions
        except BaseException as exc:
            error = f"{type(exc).__name__}: {exc}"
            raise
        finally:
            self.telemetry.decision(decision, policy_step, started, started_at, accepted, error)

    def _action(self, raw):
        public = self.observe(raw)
        if self.index == 1 and getattr(self, 'on_ready', None):
            self.on_ready()
        current_index = self.index - 1
        remaining = self.budget - current_index
        if self.mode == "hold":
            # Explicit infrastructure smoke policy; never a GPT score.
            count = min(16, remaining)
            actions = np.tile(public["qpos"], (count, 1)).astype(np.float32)
            write_json(self.private / "actions" / f"{self.decision:06d}.json",
                       {"decision": self.decision, "policy_step": current_index,
                        "actions": actions.tolist(), "policy": "development_hold"})
            self.decision += 1
            return actions
        if self.mode == "replay":
            record = json.loads((self.replay / "private/actions" / f"{self.decision:06d}.json").read_text())
            if record["policy_step"] != current_index:
                raise RuntimeError("Replay action timing mismatch")
            actions = validate_actions({"actions": record["actions"]}, len(public["qpos"]), remaining)
            write_json(self.private / "actions" / f"{self.decision:06d}.json", record)
            self.decision += 1
            return actions
        public.update(decision=self.decision,
                      history_start_policy_step=self.last_decision_index,
                      history_end_policy_step=current_index)
        self.last_decision_index = current_index + 1
        write_json(self.inputs / "observation.json", public)
        write_json(self.private / "decisions" / f"{self.decision:06d}.json", public)
        if self.proc is None:
            self.start()
        started = time.monotonic()
        action_path = self.action_transport / "request.json"
        while not self.stopped.is_set():
            if action_path.exists():
                try:
                    fd = os.open(action_path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
                except OSError as exc:
                    raise PolicyError("Action submission is not a readable regular file") from exc
                with os.fdopen(fd, "rb") as stream:
                    if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
                        raise PolicyError("Action submission must be a regular file")
                    request_bytes = stream.read(16 * 1024 * 1024 + 1)
                if len(request_bytes) > 16 * 1024 * 1024:
                    raise PolicyError("Oversized action submission")
                request_dir = self.private / "requests"
                request_dir.mkdir(exist_ok=True)
                (request_dir / f"{self.decision:06d}.json").write_bytes(request_bytes)
                action_path.unlink()
                try:
                    request = json.loads(request_bytes)
                except (ValueError, UnicodeError) as exc:
                    raise RuntimeError("Action transport envelope is not JSON") from exc
                if not isinstance(request, dict):
                    raise RuntimeError("Action transport envelope must be an object")
                if set(request) != {"decision", "payload"} or request["decision"] != self.decision:
                    raise RuntimeError("Stale or malformed action transport envelope")
                evidence = self.model_evidence()
                try:
                    actions = self.validate_submission(request["payload"], remaining, len(public["qpos"]))
                except (TypeError, ValueError, OverflowError) as exc:
                    raise PolicyError("Invalid policy action") from exc
                record = {"decision": self.decision, "policy_step": current_index,
                          "actions": actions.tolist(), "model_evidence": evidence,
                          "request_sha256": digest(request_bytes),
                          "reasoning_wall_seconds": time.monotonic() - started}
                write_json(self.private / "actions" / f"{self.decision:06d}.json", record)
                self.decision += 1
                return actions
            returncode = self.proc.poll()
            if returncode is not None:
                if returncode != 0:
                    raise RuntimeError(f"Codex process failed with exit code {returncode}")
                raise PolicyError("Codex ended before episode completion")
            timeout = self.config["decision_timeout_s"]
            if timeout is not None and time.monotonic() - started > timeout:
                raise RuntimeError("Configured infrastructure watchdog expired")
            time.sleep(0.05)
        raise RuntimeError("Evaluator stopped")

    def finish(self):
        if self.finished:
            return
        self.stopped.set()
        self.encoder.shutdown(wait=True, cancel_futures=True)
        write_json(self.inputs / "episode_done.json", {"episode_done": True})
        if self.proc:
            try:
                self.proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.proc.terminate()
                try:
                    self.proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self.proc.kill()
                    self.proc.wait()
            self.telemetry.codex_returncode = self.proc.returncode
        for log in self.logs:
            log.close()
        # Auth is a disposable copy, never part of a result artifact.
        (self.home / "auth.json").unlink(missing_ok=True)
        self.telemetry.flush(finished=True)
        self.finished = True


def serve(listener, stop, make_episode, recv_message, send_message, state):
    listener.settimeout(0.2)
    episode = None
    episode_index = -1
    try:
        while not stop.is_set():
            try:
                connection, _ = listener.accept()
            except TimeoutError:
                continue
            except OSError:
                if stop.is_set():
                    break
                raise
            with connection:
                while not stop.is_set():
                    message = recv_message(connection)
                    if message is None:
                        break
                    command = message.get("command")
                    try:
                        if command == "reset":
                            if episode:
                                episode.finish()
                            episode = make_episode()
                            episode_index += 1
                            state["episode"] = episode
                            result = None
                        elif command == "get_action_chunk":
                            if episode is None:
                                raise RuntimeError("Reset required")
                            result = episode.action(message["observation"])
                        elif command == "update_after_action":
                            episode.observe(message["observation"])
                            result = None
                        elif command == "close":
                            send_message(connection, {"result": None})
                            break
                        else:
                            raise RuntimeError("Unknown RPC command")
                        send_message(connection, {"result": result})
                    except Exception as exc:
                        state.setdefault("episode_errors", {})[episode_index] = {
                            "error": f"{type(exc).__name__}: {exc}",
                            "policy_failure": isinstance(exc, PolicyError)}
                        send_message(connection, {"error": "Policy infrastructure failure"})
    except Exception as exc:
        state["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        if episode:
            episode.finish()
