"""Host-only bounded encoding and streaming inventory; no policy-visible changes."""
from collections import deque
from concurrent.futures import ThreadPoolExecutor
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import time
import shutil
import fcntl

import numpy as np
from PIL import Image


def encode_rgb(rgb):
    target = io.BytesIO()
    Image.fromarray(rgb).save(target, format='PNG', compress_level=6, optimize=False)
    return target.getvalue()


def encode_png(raw):
    """Exactly the original RGB sanitation and Pillow PNG level 6 encoding."""
    with Image.open(io.BytesIO(raw)) as image:
        image = image.convert('RGB')
        if image.size != (640, 480):
            raise ValueError('Unexpected demonstration image size')
        clean = Image.fromarray(np.asarray(image))
        target = io.BytesIO()
        clean.save(target, format='PNG', compress_level=6)
        return target.getvalue()


def encode_frames(raw_frames, workers=4):
    """Read HDF5 only on the caller thread; bound resident images to 2*workers.

    Results are yielded in source order. The caller alone writes files, so
    parallel compression does not create competing random disk writers.
    """
    if type(workers) is not int or not 1 <= workers <= 8:
        raise ValueError('Encoding workers must be an integer from 1 to 8')
    if workers == 1:
        for raw in raw_frames:
            yield encode_png(raw)
        return
    source = iter(raw_frames)
    pending = deque()
    with ThreadPoolExecutor(max_workers=workers) as pool:
        try:
            for _ in range(2 * workers):
                try:
                    pending.append(pool.submit(encode_png, next(source)))
                except StopIteration:
                    break
            while pending:
                yield pending.popleft().result()
                try:
                    pending.append(pool.submit(encode_png, next(source)))
                except StopIteration:
                    pass
        finally:
            for future in pending:
                future.cancel()


def export_space_bound(frames):
    # Same uncompressed RGB bound as v1, applied to the next atomic demo.
    return int(frames * 4 * 640 * 480 * 3 * 1.1) + 50 * 1024**3


def wait_for_export_space(destination, frames):
    """Per-demo backpressure with the original 50 GiB safety headroom."""
    required = export_space_bound(frames)
    while True:
        free = shutil.disk_usage(destination).free
        inodes = os.statvfs(destination).f_favail
        if free >= required and inodes > frames * 4 + 100000:
            return
        print(f'Waiting for export storage: free={free}, required={required}, '
              f'inodes={inodes}; outputs retained', flush=True)
        time.sleep(30)


def content_hashes(root, *, strict=True, exclude=(), progress=None):
    """Hash every byte, directory by directory, without a whole-tree stat pass.

    Strict mode rejects links, hardlinks and special files, as knowledge trees
    require. Asset mode retains the legacy regular-file symlink semantics but
    never traverses linked directories. No metadata-only checksum cache.
    """
    root = Path(root)
    if root.is_symlink() or not root.is_dir():
        raise ValueError('Expected a real directory')
    result = {}
    total = 0
    started = last = time.monotonic()

    def walk(folder):
        with os.scandir(folder) as stream:
            entries = sorted(stream, key=lambda e: e.name)
        for entry in entries:
            if entry.name in exclude:
                continue
            info = entry.stat(follow_symlinks=False)
            if stat.S_ISDIR(info.st_mode):
                yield from walk(Path(entry.path))
            elif strict:
                if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                    raise ValueError(f'Only independent regular files allowed: {entry.name}')
                yield Path(entry.path), info
            elif entry.is_file():
                yield Path(entry.path), entry.stat()

    for path, info in walk(root):
        h = hashlib.sha256()
        flags = os.O_RDONLY | (os.O_NOFOLLOW if strict else 0) | os.O_NONBLOCK
        fd = os.open(path, flags)
        with os.fdopen(fd, 'rb') as stream:
            before = os.fstat(stream.fileno())
            if (not stat.S_ISREG(before.st_mode)
                    or (strict and before.st_nlink != 1)
                    or (info.st_dev, info.st_ino) != (before.st_dev, before.st_ino)):
                raise ValueError(f'File changed during verification: {path}')
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                h.update(block)
            after = os.fstat(stream.fileno())
            if ((before.st_size, before.st_mtime_ns, before.st_ctime_ns)
                    != (after.st_size, after.st_mtime_ns, after.st_ctime_ns)):
                raise ValueError(f'File changed during verification: {path}')
        result[str(path.relative_to(root))] = h.hexdigest()
        total += after.st_size
        tick = time.monotonic()
        if progress and tick - last >= 15:
            progress({'files': len(result), 'bytes': total, 'seconds': tick - started})
            last = tick
    if progress:
        progress({'files': len(result), 'bytes': total, 'seconds': time.monotonic() - started})
    return dict(sorted(result.items()))


def cached_asset_hashes(root, cache_path, *, exclude=(), max_age_s=6 * 3600, progress=None):
    """Reuse a full asset hash only while every file's identity/metadata matches.

    The first worker hashes all bytes. Later workers stat the same tree; a
    changed tree is rehashed and rejected if any content hash differs. A full
    refresh is also required every six hours. This is a disclosed host-side
    throughput optimization, never a policy-visible input.
    """
    root = Path(root)
    if root.is_symlink() or not root.is_dir():
        raise ValueError('Expected a real asset directory')
    root = root.resolve()
    cache_path = Path(cache_path)
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    excluded = tuple(sorted(exclude))

    def fingerprints():
        result = {}
        def walk(folder):
            with os.scandir(folder) as stream:
                entries = sorted(stream, key=lambda entry: entry.name)
            for entry in entries:
                if entry.name in exclude:
                    continue
                link = entry.stat(follow_symlinks=False)
                if stat.S_ISDIR(link.st_mode):
                    yield from walk(Path(entry.path))
                elif entry.is_file():
                    target = entry.stat()
                    yield Path(entry.path), link, target
        for path, link, target in walk(root):
            result[str(path.relative_to(root))] = [
                link.st_mode, link.st_dev, link.st_ino, link.st_size,
                link.st_mtime_ns, link.st_ctime_ns,
                target.st_dev, target.st_ino, target.st_size,
                target.st_mtime_ns, target.st_ctime_ns,
            ]
        return result

    lock_path = cache_path.with_suffix(cache_path.suffix + '.lock')
    with lock_path.open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        previous = None
        if cache_path.is_file():
            previous = json.loads(cache_path.read_text())
            if (previous.get('schema_version') != 1 or previous.get('root') != str(root)
                    or previous.get('exclude') != list(excluded)):
                raise ValueError('Asset cache identity mismatch')
        current = fingerprints()
        if previous and set(current) != set(previous['hashes']):
            raise ValueError('Asset file set changed since full verification')
        if (previous and current == previous['fingerprints']
                and time.time() - previous['verified_at_epoch'] < max_age_s):
            return previous['hashes'], {'mode': 'metadata_reuse',
                'full_verified_at_epoch': previous['verified_at_epoch'],
                'cache_sha256': hashlib.sha256(cache_path.read_bytes()).hexdigest(),
                'file_count': len(current)}
        hashes = content_hashes(root, strict=False, exclude=exclude, progress=progress)
        after = fingerprints()
        if set(hashes) != set(after) or current != after:
            raise ValueError('Asset tree changed during verification')
        if previous and hashes != previous['hashes']:
            raise ValueError('Asset content changed since prior full verification')
        record = {'schema_version': 1, 'root': str(root), 'exclude': list(excluded),
                  'hashes': hashes, 'fingerprints': after,
                  'verified_at_epoch': time.time()}
        temp = cache_path.with_name(cache_path.name + f'.{os.getpid()}.tmp')
        with temp.open('x') as stream:
            json.dump(record, stream, sort_keys=True, separators=(',', ':'))
            stream.flush(); os.fsync(stream.fileno())
        os.replace(temp, cache_path)
        return hashes, {'mode': 'full_hash',
            'full_verified_at_epoch': record['verified_at_epoch'],
            'cache_sha256': hashlib.sha256(cache_path.read_bytes()).hexdigest(),
            'file_count': len(after)}
