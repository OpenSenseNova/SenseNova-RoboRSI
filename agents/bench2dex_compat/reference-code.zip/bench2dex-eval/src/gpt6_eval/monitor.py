"""Terminal status and cooperative stop requests; never modifies policy inputs."""
import argparse
import json
from pathlib import Path
import time

from .batch import STOP_FILE
from .telemetry import utc_now


def read_json(path):
    try:
        return json.loads(path.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return None  # Legacy writers may be between truncate/write.


def batch_root(root):
    root = root.resolve()
    if (root / "workflow.json").is_file():
        return root / "evaluation"
    return root


def status(root):
    batch = batch_root(root)
    suite = read_json(root / "suite_result.json")
    if suite is not None:
        report = {**suite, "output": str(root), "checked_at": utc_now(),
                  "stop_requested": (root / STOP_FILE).exists()}
        parallel = root / "evaluation"
        if (parallel / "result.json").is_file():
            report["episodes"] = status(parallel).get("episodes", [])
        else:
            report["episodes"] = [dict(e, task_id=t["task_id"])
                for t in suite.get("tasks", [])
                for e in status(root / Path(t["result_path"]).parent).get("episodes", [])]
        return report
    result = read_json(batch / "result.json")
    workflow = read_json(root / "workflow.json")
    if result is None:
        return {"output": str(batch), "state": (workflow or {}).get("state", "not_ready"),
                "message": "No readable batch report yet", "checked_at": utc_now()}
    report = {key: result.get(key) for key in (
        "state", "workers", "planned_episodes", "scored_episodes", "successes", "failures",
        "infrastructure_errors", "success_rate", "eligible_for_gpt6_score", "updated_at")}
    report.update(output=str(batch), checked_at=utc_now(),
                  stop_requested=(batch / STOP_FILE).exists(),
                  legacy_stop=read_json(batch / "legacy-stop.json"))
    if report["legacy_stop"]:
        report["stop_requested"] = True
    episodes = []
    for attempt in result.get("episodes", []):
        child = batch / attempt["directory"]
        observation = read_json(child / "episode_0000/policy/input/observation.json") or {}
        manifest = read_json(child / "private/manifest.json") or {}
        episodes.append({"episode": attempt.get("upstream_episode_index"),
                         "task_id": attempt.get("task_id"),
                         "pid": attempt.get("pid"), "returncode": attempt.get("returncode"),
                         "valid": attempt.get("valid") if attempt.get("returncode") is not None else None,
                         "policy_step": observation.get("policy_step"),
                         "policy_budget": manifest.get("executed_policy_budget"),
                         "configured_model": manifest.get("config", {}).get("model"),
                         "success_rate": (attempt.get("result") or {}).get("success_rate"),
                         "simulator_log": str(child / "private/simulator.log")})
    report["episodes"] = episodes
    return report


def request_stop(root):
    batch = batch_root(root)
    manifest = read_json(batch / "manifest.json")
    suite = read_json(batch / "suite.json")
    if not suite and (manifest is None or not manifest.get("cooperative_stop")):
        raise RuntimeError("This batch predates cooperative stopping (or has not started). "
                           "Do not assume a marker will stop it; legacy runs need a supervised drain.")
    path = batch / STOP_FILE
    record = {"requested_at": utc_now(), "reason": "terminal stop-after-current request",
              "semantics": "finish current wave; admit no later waves"}
    try:
        with path.open("x") as handle:
            json.dump(record, handle, indent=2)
            handle.write("\n")
    except FileExistsError:
        pass
    return {"stop_request": str(path), "message": "Current wave will finish; no later wave will start."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["status", "watch", "stop-after-current"])
    parser.add_argument("output", type=Path, help="Batch output or task-26 workflow output")
    parser.add_argument("--interval", type=float, default=5)
    args = parser.parse_args()
    if args.interval < 0.2:
        parser.error("--interval must be >= 0.2 seconds")
    if args.command == "stop-after-current":
        try:
            print(json.dumps(request_stop(args.output), indent=2))
        except RuntimeError as exc:
            parser.exit(1, str(exc) + "\n")
        return
    try:
        while True:
            report = status(args.output.resolve())
            print(json.dumps(report, indent=2), flush=True)
            if args.command == "status" or report["state"] in (
                    "completed", "stopped_by_request", "interrupted", "stopped_on_error",
                    "stopped_on_infrastructure_error", "blocked_on_resources"):
                return
            time.sleep(args.interval)
    except KeyboardInterrupt:
        pass  # Stopping the observer must never stop the experiment.


if __name__ == "__main__":
    main()
