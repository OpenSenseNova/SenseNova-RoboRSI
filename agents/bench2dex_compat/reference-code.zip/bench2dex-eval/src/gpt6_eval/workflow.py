"""Gate a task-26 pilot on verified assets and optional no-model reset checks."""
import argparse
import json
import os
from pathlib import Path
import select
import signal
import subprocess
import sys

from .cli import hash_file, load_config
from .core import write_json
from .telemetry import utc_now


def stages(args):
    common = [sys.executable, "-m", "gpt6_eval.batch", "--task", "26", "--workers", str(args.workers)]
    for key in ("config", "upstream", "isaaclab", "assets", "python", "auth"):
        common.extend(["--" + key, str(getattr(args, key))])
    plan = [
        ("verify_assets", [str(args.python), "-c",
            "import json,sys; from pathlib import Path; "
            "from gpt6_eval.prepare_task26_assets import verify_inventory; "
            "records=json.loads(Path(sys.argv[2]).read_text()); "
            "assert records, 'Empty asset inventory'; "
            "verify_inventory(Path(sys.argv[1]), records); "
            "print('Verified',len(records),'pinned asset files')",
            str(args.assets), str(args.inventory)]),
        ("smoke", common + ["--mode", "hold", "--smoke-steps", "4", "--output", str(args.output / "smoke")]),
        ("evaluation", common + ["--mode", "codex", "--output", str(args.output / "evaluation")]),
    ]
    return [(name, command) for name, command in plan
            if name != "smoke" or not args.skip_smoke]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ("config", "upstream", "isaaclab", "assets", "python", "inventory", "output"):
        parser.add_argument("--" + key, type=Path, required=True)
    parser.add_argument("--auth", type=Path, default=Path.home() / ".codex/auth.json")
    parser.add_argument("--workers", type=int, choices=[1, 2], default=1)
    parser.add_argument("--skip-smoke", action="store_true",
                        help="Skip optional no-model dry runs; retain asset and evaluation validity checks")
    parser.add_argument("--wait-for-download-pid", type=int,
                        help="Linux: wait for this downloader to exit, then independently verify all assets")
    args = parser.parse_args()
    for key, value in vars(args).items():
        if isinstance(value, Path):
            setattr(args, key, value.resolve())
    config = load_config(args.config)
    if config["num_episodes"] != 8 or config["start_episode"] != 0:
        parser.error("This pilot requires the frozen eight-episode schedule starting at 0")
    if args.output.exists():
        parser.error("Use a new workflow output directory")
    args.output.mkdir(parents=True)
    plan = stages(args)
    fingerprints = {str(p): hash_file(p) for p in (args.config, args.inventory)}
    record = {"schema_version": 1, "state": "waiting_for_download", "started_at": utc_now(),
              "argv": sys.argv, "config": config, "workers": args.workers, "fingerprints": fingerprints,
              "smoke_skipped": args.skip_smoke,
              "workflow_sha256": hash_file(Path(__file__)), "stages": [],
              "planned_commands": [{"stage": name, "argv": cmd} for name, cmd in plan]}
    def save():
        record["updated_at"] = utc_now()
        write_json(args.output / "workflow.json", record)
    def interrupted(signum, _frame):
        raise KeyboardInterrupt(f"Received signal {signum}")
    signal.signal(signal.SIGTERM, interrupted)
    child = None
    save()
    try:
        if args.wait_for_download_pid:
            try:
                fd = os.pidfd_open(args.wait_for_download_pid)
            except ProcessLookupError:
                fd = None  # Verification below still fails closed on incomplete assets.
            if fd is not None:
                try:
                    select.select([fd], [], [])
                finally:
                    os.close(fd)
        for path, expected in fingerprints.items():
            if hash_file(Path(path)) != expected:
                raise RuntimeError(f"Queued configuration/inventory changed: {path}")
        for name, command in plan:
            record["state"] = name
            entry = {"stage": name, "started_at": utc_now(), "returncode": None}
            record["stages"].append(entry)
            save()
            print(f"Starting {name}; log: {args.output / (name + '.log')}", flush=True)
            with (args.output / (name + ".log")).open("wb") as log:
                child = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
                entry["returncode"] = child.wait()
            child = None
            entry["ended_at"] = utc_now()
            child_report_path = args.output / name / "result.json"
            if child_report_path.is_file() and json.loads(child_report_path.read_text()).get("state") == "stopped_by_request":
                record["state"] = "stopped_by_request"
                break
            if entry["returncode"] != 0:
                record["state"] = "stopped_on_error"
                break
        else:
            record["state"] = "completed"
    except BaseException as exc:
        record["state"] = "interrupted" if isinstance(exc, KeyboardInterrupt) else "stopped_on_error"
        record["error"] = f"{type(exc).__name__}: {exc}"
        raise
    finally:
        if child is not None and child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=55)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait()
            record["stages"][-1]["returncode"] = child.returncode
        save()
    raise SystemExit(0 if record["state"] in ("completed", "stopped_by_request") else 1)


if __name__ == "__main__":
    main()
