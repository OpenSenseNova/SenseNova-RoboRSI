"""Policy-visible client; contains no raw paths, metadata, evaluator or server code."""
import argparse
import json
import os
from pathlib import Path
import time
import uuid


def frames(demo, camera, indices, timeout=600):
    """Return local read-only PNG paths, in requested order (at most 64 per call)."""
    name = uuid.uuid4().hex
    requests = Path('/workspace/.demo_requests')
    replies = Path('/workspace/.demo_responses/replies')
    pending = requests / (name + '.tmp')
    pending.write_text(json.dumps({'demo': demo, 'camera': camera, 'frames': list(indices)}))
    os.replace(pending, requests / (name + '.json'))
    deadline = time.monotonic() + timeout
    target = replies / (name + '.json')
    while not target.exists():
        if time.monotonic() > deadline:
            raise TimeoutError('Trusted demonstration reader did not respond')
        time.sleep(0.05)
    reply = json.loads(target.read_text())
    if not reply.get('ok'):
        raise RuntimeError(reply['error'])
    return [row['path'] for row in reply['images']]


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--demo', required=True, help='Four-digit demo ID, e.g. 0000')
    parser.add_argument('--camera', required=True)
    parser.add_argument('--frames', required=True, type=int, nargs='+')
    args = parser.parse_args()
    print(json.dumps(frames(args.demo, args.camera, args.frames)))
