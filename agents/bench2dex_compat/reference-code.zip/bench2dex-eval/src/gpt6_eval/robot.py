"""Static, deployment-accessible kinematic description; no scene geometry."""
import xml.etree.ElementTree as ET
from pathlib import Path


def kinematics(urdf: Path) -> dict:
    tree = ET.parse(urdf).getroot()
    joints = []
    for joint in tree.findall("joint"):
        item = {"name": joint.attrib["name"], "type": joint.attrib["type"]}
        for tag, keys in {
            "parent": ("link",), "child": ("link",), "origin": ("xyz", "rpy"),
            "axis": ("xyz",), "limit": ("lower", "upper", "effort", "velocity"),
            "mimic": ("joint", "multiplier", "offset"),
        }.items():
            element = joint.find(tag)
            if element is not None:
                item[tag] = {k: element.attrib[k] for k in keys if k in element.attrib}
        joints.append(item)
    return {"coordinate_frame": "URDF robot base (not simulator world)",
            "length_unit": "metre", "angle_unit": "radian", "joints": joints}


def kinematic_urdf(card):
    """Portable geometry-only URDF: no asset paths, objects, inertias or plugins."""
    root = ET.Element("robot", name="deployment_robot")
    joints = card["kinematics"]["joints"]
    links = {j[side]["link"] for j in joints for side in ("parent", "child")}
    for link in sorted(links):
        ET.SubElement(root, "link", name=link)
    allowed = {"parent", "child", "origin", "axis", "limit", "mimic"}
    for item in joints:
        joint = ET.SubElement(root, "joint", name=item["name"], type=item["type"])
        for tag in sorted(allowed & item.keys()):
            ET.SubElement(joint, tag, attrib=item[tag])
    return ET.tostring(root, encoding="unicode") + "\n"
