"""Separate fixed-index extension queue. Never modifies the primary evaluation."""
from __future__ import annotations

import argparse
from collections import Counter
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import shutil
import sys
import time

from .cli import ROOT, ROBOTS
from .core import write_json
from .extension import (SETTING, baseline_metrics, paired_summary, read, reference,
                         require, round_robin_slots, storage_admission)
from .knowledge import file_hash
from .telemetry import utc_now

SETTLED = ('carried', 'complete', 'diverged', 'source_unavailable')


def original_refs(campaign):
    state = read(campaign / 'state.json')
    plan = read(campaign / 'campaign.json')
    require(state['state'] == 'complete_pending_final_audit', 'Primary run must be finished')
    refs = {(int(task), row['episode_index']): {**row, 'task_id': int(task)}
            for task, record in state['tasks'].items() for row in record['valid_episodes']
            if 5 <= row['episode_index'] < 15}
    prerequisite = Path(plan['prerequisite_cohort']).with_name('cohort_result.json')
    require(file_hash(prerequisite) == state['prerequisite_result_sha256'], 'Task26 prerequisite changed')
    for row in read(prerequisite)['episodes']:
        if 5 <= row['episode_index'] < 15:
            refs[(26, row['episode_index'])] = {**row, 'task_id': 26}
    require(set(refs) == {(task, index) for task in ROBOTS for index in range(5, 15)},
            'Primary 26-task fixed-index cohort mismatch')
    return refs, plan


def select_source(original, control):
    slot = original['task_id'], original['episode_index']
    damaged = slot in {tuple(item) for item in control.get('damage_slots', [])}
    candidates = []
    for key, item in control.get('audits', {}).items():
        ref = item['ref']
        if item.get('state') != 'verified' or (ref['task_id'], ref['episode_index']) != slot:
            continue
        if damaged != key.startswith('replacement_'):
            continue
        if not damaged and (ref['result'] != original['result'] or ref['sha256'] != original['sha256']):
            continue
        candidates.append((key, item))
    if not candidates:
        return None
    key, selected = sorted(candidates)[0]
    require(file_hash(Path(selected['path'])) == selected['sha256'], 'Named source audit changed')
    proof = read(selected['path'])
    require(proof.get('named_results_verified') is True and proof.get('validity_verified') is True
            and proof.get('state') == 'verified' and not proof.get('errors'), 'Invalid source audit')
    ref = selected['ref']
    require(proof['result'] == ref['result'] and proof['result_sha256'] == ref['sha256'],
            'Named source audit result binding mismatch')
    return {'ref': ref, 'audit': {'path': selected['path'], 'sha256': selected['sha256']}, 'audit_key': key}


def source_summary(ref):
    path = Path(ref['result'])
    require(file_hash(path) == ref['sha256'], 'Baseline result reference changed')
    result = read(path)
    manifest = read(path.parent / 'private/manifest.json')
    rows = [json.loads(line) for line in (path.parent / result['official_results_path']).read_text().splitlines() if line.strip()]
    require(len(rows) == 1, 'Expected one baseline official result')
    return baseline_metrics(result, manifest, rows[0])


def build_plan(campaign, controller, status, output_root):
    refs, primary = original_refs(campaign)
    control = read(controller)
    slots = []
    for task, index in round_robin_slots(ROBOTS, 5):
        original = refs[(task, index)]
        selected = select_source(original, control)
        chosen = selected['ref'] if selected else original
        try:
            baseline = source_summary(chosen)
            summary_error = None
        except (OSError, ValueError, KeyError) as error:
            baseline = None
            summary_error = str(error)
        slots.append({'task_id': task, 'episode_index': index, 'original': original,
                      'source_snapshot': selected, 'baseline_snapshot': baseline,
                      'baseline_snapshot_error': summary_error,
                      'source_resolution': 'first named-certified replacement for damaged slots; otherwise named-certified original, never selected by outcome'})
    hashes = {str(path.relative_to(ROOT)): file_hash(path)
              for folder in ('src', 'prompts', 'configs') for path in (ROOT / folder).rglob('*')
              if path.is_file() and path.suffix in ('.py', '.md', '.json')}
    return {'schema': 1, 'setting': SETTING, 'created_at': utc_now(), 'runner_root': str(ROOT),
            'campaign': str(campaign), 'controller': str(controller), 'storage_status': str(status),
            'storage_probe': reference(controller.parents[2] / 'watchdog.py'),
            'storage_blocker': str(controller.parents[1] / 'external_blocker.json'),
            'output_root': str(output_root), 'runtime': primary['runtime'],
            'first_pass': {'episodes_per_task': 3, 'indices': [5, 6, 7], 'denominator': 78},
            'second_pass': {'episodes_per_task': 5, 'indices': [5, 6, 7, 8, 9], 'denominator': 130},
            'multiplier': 10, 'additional_multiplier': 9, 'slots': slots, 'runner_hashes': hashes,
            'selection_policy': 'Fixed indices include carried successes and non-timeout failures. No resampling or success-based replacement.',
            'storage_policy': 'No original data deletion; fresh healthy monitor and unchanged100GiB reserve required.',
            'first_gpu_validation': 'One replay-only no-inference probe must pass before scored continuation launches.'}


def storage_probe_module(plan):
    probe = plan['storage_probe']
    require(file_hash(Path(probe['path'])) == probe['sha256'], 'Read-only storage probe changed; review before using')
    spec = importlib.util.spec_from_file_location('extension_readonly_storage_probe', probe['path'])
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def refresh_storage(plan, control_root):
    probe = plan['storage_probe']
    module = storage_probe_module(plan)
    snapshot = {'checked_at': utc_now(), 'issues': [], 'read_only_probe': probe}
    module.inspect_storage(snapshot, shutil.disk_usage, True)
    blocker_path = Path(plan['storage_blocker'])
    if blocker_path.exists():
        blocker = read(blocker_path)
        if blocker.get('state') == 'external_action_required':
            snapshot['external_action_required'] = {'receipt': reference(blocker_path),
                                                    'reason': blocker.get('reason')}
    path = control_root / 'storage_status.json'
    write_json(path, snapshot)
    return path


def summarize(state, plan):
    output = {}
    for count in (3, 5):
        rows = []
        missing = []
        for slot in plan['slots']:
            if slot['episode_index'] >= 5 + count:
                continue
            key = f"{slot['task_id']:02d}_{slot['episode_index']:02d}"
            record = state['slots'].get(key, {})
            baseline = record.get('baseline')
            if baseline is None:
                missing.append([slot['task_id'], slot['episode_index']])
            else:
                rows.append({'task_id': slot['task_id'], 'episode_index': slot['episode_index'],
                             'baseline': baseline, 'extension': record.get('extension')})
        output[str(count)] = {'missing_certified_baselines': missing, 'planned': 26 * count,
                              'paired': paired_summary(rows, 26 * count) if not missing else None,
                              'per_task': {str(task): paired_summary([row for row in rows if row['task_id'] == task], count)
                                           for task in ROBOTS if sum(row['task_id'] == task for row in rows) == count}}
    return output


def original_gpu_queue_finished(controller, plan=None):
    if plan and plan.get('priority_hold'):
        pointer = Path(plan['controller']).parent / 'priority_hold.json'
        require(reference(pointer) == plan['priority_hold'], 'Priority hold changed')
        binding = storage_probe_module(plan).validated_priority_hold(controller, pointer.parent)
        require(binding and binding['authorization'] == plan['priority_authorization'], 'Invalid priority authorization')
        for job in controller['jobs']:
            if not job.get('ended_at') and not (Path(job['output']) / 'episode_0000/private/startup_ready.json').is_file():
                return False
        return True
    return (controller.get('state') == 'audits_finished_pending_final_recheck'
            and not controller.get('error')
            and all(job.get('ended_at') for job in controller.get('jobs', [])))


def supplemental_source(plan, controller, slot):
    if not plan.get('source_registry') or not Path(plan['source_registry']).exists():
        return None, None
    registry = read(plan['source_registry'])
    require(registry['authorization'] == plan['priority_authorization'], 'Source registry authorization changed')
    require(registry['certifier_release'] == plan['source_certifier_release'], 'Source certifier changed')
    key = f"{slot['task_id']:02d}_{slot['episode_index']:02d}"
    record = registry['slots'].get(key, {})
    if record.get('state') != 'source_ready':
        return None, record if record.get('state') == 'source_unavailable' else None
    source = record['source']
    entry = {'ref': source['ref'], 'state': 'verified', **source['audit']}
    selected = select_source(slot['original'], {**controller, 'audits': {source['audit_key']: entry}})
    require(selected == source, 'Supplemental source selection mismatch')
    return selected, None


def import_qualification(plan, state):
    if not plan.get('qualification_status') or state.get('qualification_imported'):
        return True
    qualification = read(plan['qualification_status'])
    require(qualification['authorization'] == plan['priority_authorization'], 'Qualification authority changed')
    if qualification['state'] in ('starting', 'running'):
        return False
    result_ref = qualification.get('result')
    require(result_ref and reference(Path(result_ref['path'])) == result_ref, 'No intact qualification result')
    result = read(result_ref['path'])
    source = qualification['source']
    require(source['ref']['task_id'] == 3 and source['ref']['episode_index'] == 5,
            'Unexpected qualification cohort')
    baseline = source_summary(source['ref'])
    require(result.get('evaluation_setting') == SETTING and result.get('baseline') == baseline
            and result.get('extension', {}).get('source_result') == {
                'path': source['ref']['result'], 'sha256': source['ref']['sha256']},
            'Qualification result is not bound to the original source')
    record = {'source': source, 'baseline': baseline, 'state': 'ready',
              'attempts': [{'probe': True, 'external_qualification': result_ref}]}
    if qualification['returncode'] == 0 and result.get('replay_probe_verified'):
        state['probe_verified'] = True
    elif result.get('extension', {}).get('replay_validation', {}).get('state') == 'diverged':
        record.update(state='diverged', extension=result['extension'])
    else:
        raise ValueError('Qualification failed for infrastructure reasons; diagnose before new attempts')
    state['slots']['03_05'] = record
    state['qualification_imported'] = result_ref
    return True


def run(plan_path, control_root, watch=False):
    plan = read(plan_path)
    require(plan['setting'] == SETTING and plan['multiplier'] == 10, 'Unknown extension plan')
    for name, expected in plan['runner_hashes'].items():
        require(file_hash(ROOT / name) == expected, 'Extension runner changed after planning')
    control_root.mkdir(parents=True, exist_ok=True)
    with (control_root / 'lock').open('a') as guard:
        fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
        state_path = control_root / 'state.json'
        state = read(state_path) if state_path.exists() else {
            'plan': reference(plan_path), 'slots': {}, 'probe_verified': False, 'started_at': utc_now()}
        require(state['plan'] == reference(plan_path), 'Queue plan changed')
        require(not state.get('active'), 'Previous attempt needs explicit reconciliation; no blind retry')
        stopped = False
        import signal
        def stop(signum, frame):
            nonlocal stopped
            stopped = True
        signal.signal(signal.SIGTERM, stop)
        def save(phase, error=None):
            state.update(state=phase, error=error, pid=os.getpid(), updated_at=utc_now())
            write_json(state_path, state)
            write_json(control_root / 'report.json', summarize(state, plan))
        while not stopped:
            try:
                storage_status = refresh_storage(plan, control_root)
                storage_admission(storage_status)
            except (ValueError, OSError, KeyError, subprocess.SubprocessError) as error:
                save('waiting_for_healthy_storage', str(error))
                if not watch:
                    return 2
                time.sleep(30)
                continue
            try:
                qualified = import_qualification(plan, state)
            except (OSError, ValueError, KeyError) as error:
                save('needs_diagnosis', str(error))
                return 2
            if not qualified:
                save('waiting_for_qualification')
                if not watch:
                    return 2
                time.sleep(15)
                continue
            controller = read(plan['controller'])
            progressed = False
            first_unresolved = any(state['slots'].get(f"{slot['task_id']:02d}_{slot['episode_index']:02d}", {}).get('state')
                                   not in SETTLED
                                   for slot in plan['slots'] if slot['episode_index'] < 8)
            for slot in plan['slots']:
                if stopped or first_unresolved and slot['episode_index'] >= 8:
                    break
                key = f"{slot['task_id']:02d}_{slot['episode_index']:02d}"
                record = state['slots'].get(key)
                if record and record.get('state') in SETTLED:
                    continue
                if record and record.get('state') == 'needs_diagnosis':
                    save('needs_diagnosis', 'Prior attempt remains unresolved: ' + key)
                    return 2
                selected = record.get('source') if record else None
                selected = selected or select_source(slot['original'], controller)
                if selected is None:
                    selected, unavailable = supplemental_source(plan, controller, slot)
                    if unavailable:
                        state['slots'][key] = {'state': 'source_unavailable', 'source_issue': unavailable}
                        progressed = True
                        save('running')
                        continue
                    if selected is None:
                        continue
                baseline = source_summary(selected['ref'])
                record = {**(record or {}), 'source': selected, 'baseline': baseline, 'state': 'ready'}
                state['slots'][key] = record
                progressed = True
                if not baseline['eligible_for_extension']:
                    record['state'] = 'carried'
                    save('running')
                    continue
                if not original_gpu_queue_finished(controller, plan):
                    save('waiting_for_existing_gpu_workers')
                    progressed = False
                    break
                from .resource_wait import snapshot
                resources = snapshot()
                if not resources['admitted'] or resources['ram_available_mib'] < 9216 + 4096:
                    save('waiting_for_resources')
                    progressed = False
                    break
                try:
                    storage_status = refresh_storage(plan, control_root)
                    storage_admission(storage_status)
                except (ValueError, OSError, KeyError, subprocess.SubprocessError) as error:
                    save('waiting_for_healthy_storage', str(error))
                    progressed = False
                    break
                runtime = plan['runtime']
                output = Path(plan['output_root']) / f"task_{slot['task_id']:02d}" / f"index_{slot['episode_index']:02d}"
                source_root = Path(selected['ref']['result']).parent
                config_path = control_root / 'configs' / (key + '.json')
                config = read(source_root / 'private/manifest.json')['config']
                require(file_hash(Path(selected['audit']['path'])) == selected['audit']['sha256'],
                        'Committed source audit changed')
                if config_path.exists():
                    require(read(config_path) == config, 'Frozen per-slot configuration changed')
                else:
                    write_json(config_path, config)
                probe = not state['probe_verified']
                attempt = output / ('probe_0001' if probe else 'attempt_0001')
                require(not attempt.exists(), 'An attempt already exists; reconcile before continuation')
                argv = [runtime['python'], '-u', '-m', 'gpt6_eval.cli', '--task', str(slot['task_id']),
                        '--config', str(config_path), '--output', str(attempt), '--extension-source', str(source_root),
                        '--extension-audit', selected['audit']['path'], '--storage-status', str(storage_status)]
                for name in ('python', 'upstream', 'isaaclab', 'assets'):
                    argv += ['--' + name, runtime[name]]
                if probe:
                    argv.append('--extension-probe')
                environment = {**os.environ, 'PYTHONPATH': str(ROOT / 'src'), 'PYTHONDONTWRITEBYTECODE': '1',
                               'PYTHONHASHSEED': '0', 'OMNI_KIT_ACCEPT_EULA': 'YES',
                               'GPT6_EVAL_WAIT_FOR_GPU': '1', 'GPT6_EVAL_WORKER_RESERVATION_MIB': '9216',
                               'GPT6_EVAL_RAM_HEADROOM_MIB': '4096',
                               'GPT6_EVAL_ASSET_CACHE': str(Path(plan['campaign']) / 'repairs/asset_cache_v9_20260929/cache.json')}
                state['active'] = {'slot': key, 'output': str(attempt), 'argv': argv, 'started_at': utc_now(), 'probe': probe}
                save('running_probe' if probe else 'running_extension')
                log = control_root / 'logs' / (key + ('.probe.log' if probe else '.log'))
                log.parent.mkdir(parents=True, exist_ok=True)
                with log.open('xb') as stream:
                    process = subprocess.Popen(argv, env=environment, stdout=stream, stderr=subprocess.STDOUT,
                                               start_new_session=True)
                    state['active']['pid'] = process.pid
                    save('running_probe' if probe else 'running_extension')
                    while process.poll() is None:
                        try:
                            refresh_storage(plan, control_root)
                        except (OSError, ValueError, KeyError, subprocess.SubprocessError) as error:
                            state['storage_probe_error'] = str(error)
                            save('active_worker_preserved_storage_probe_unavailable')
                        time.sleep(15)
                    code = process.returncode
                result_path = attempt / 'result.json'
                result = read(result_path) if result_path.exists() else {}
                record.setdefault('attempts', []).append({**state.pop('active'), 'returncode': code, 'ended_at': utc_now(),
                                                          'result': reference(result_path) if result_path.exists() else None})
                if probe and code == 0 and result.get('replay_probe_verified'):
                    state['probe_verified'] = True
                    record['state'] = 'ready'
                    save('first_probe_verified')
                    break
                if not probe and code == 0 and result.get('eligible_for_extension_score'):
                    record.update(state='complete', extension=result['extension'])
                elif result.get('extension', {}).get('replay_validation', {}).get('state') == 'diverged':
                    record.update(state='diverged', extension=result['extension'])
                else:
                    record['state'] = 'needs_diagnosis'
                    save('needs_diagnosis', 'Attempt did not produce a valid extension: ' + key)
                    return 2
                save('running')
            if all(state['slots'].get(f"{slot['task_id']:02d}_{slot['episode_index']:02d}", {}).get('state')
                   in SETTLED for slot in plan['slots']):
                save('coverage_finished' if any(row['state'] in ('diverged', 'source_unavailable')
                                               for row in state['slots'].values()) else 'complete')
                return 0
            if not progressed:
                if state['state'] not in ('waiting_for_healthy_storage', 'waiting_for_existing_gpu_workers', 'waiting_for_resources'):
                    save('waiting_for_sources_or_resources')
                if not watch:
                    return 2
                time.sleep(30)
        save('drained')
        return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    planning = commands.add_parser('plan')
    for name in ('campaign', 'controller', 'storage-status', 'output-root', 'destination'):
        planning.add_argument('--' + name, type=Path, required=True)
    execution = commands.add_parser('run')
    execution.add_argument('--plan', type=Path, required=True)
    execution.add_argument('--control', type=Path, required=True)
    execution.add_argument('--watch', action='store_true')
    args = parser.parse_args()
    if args.command == 'plan':
        require(not args.destination.exists(), 'Use a new immutable plan path')
        plan = build_plan(args.campaign.resolve(), args.controller.resolve(), args.storage_status.resolve(),
                          args.output_root.resolve())
        write_json(args.destination, plan)
        for count in (3, 5):
            rows = [slot for slot in plan['slots'] if slot['episode_index'] < 5 + count]
            totals = Counter('unknown' if slot['baseline_snapshot'] is None else
                             'eligible_timeouts' if slot['baseline_snapshot']['eligible_for_extension'] else
                             'carried_successes' if slot['baseline_snapshot']['success'] else 'carried_other_failures'
                             for slot in rows)
            print(json.dumps({'episodes_per_task': count, 'planned': len(rows), 'snapshot': totals,
                              'named_certified_sources': sum(slot['source_snapshot'] is not None for slot in rows)}))
    else:
        raise SystemExit(run(args.plan.resolve(), args.control.resolve(), args.watch))


if __name__ == '__main__':
    main()
