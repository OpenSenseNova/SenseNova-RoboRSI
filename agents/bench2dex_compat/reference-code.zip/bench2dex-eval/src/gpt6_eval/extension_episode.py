"""Replay the saved prefix without inference, then resume only its own policy."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil

import numpy as np

from . import isolation
from .bridge import Episode, PolicyError
from .core import MODEL, canonical, write_json
from .extension import read, require
from .telemetry import EpisodeTelemetry, TOKEN_FIELDS, jsonl, normalize_usage


def last_cumulative(events):
    latest = None
    for event in events:
        payload = event.get('payload', {})
        if event.get('type') == 'event_msg' and payload.get('type') == 'token_count':
            info = payload.get('info') or {}
            if isinstance(info.get('total_token_usage'), dict):
                latest = normalize_usage(info['total_token_usage'])
    return latest


def incremental_usage(before, after, process_started):
    if not process_started:
        return {'status': 'complete', 'source': 'no_new_model_process', **dict.fromkeys(TOKEN_FIELDS, 0)}
    unknown = {'status': 'unavailable', 'source': 'resumed_session_cumulative_delta',
               **dict.fromkeys(TOKEN_FIELDS)}
    if before is None or after is None:
        return {**unknown, 'error': 'Missing pre-resume or post-resume cumulative usage'}
    values = {key: after[key] - before[key] if before.get(key) is not None
              and after.get(key) is not None else None for key in TOKEN_FIELDS}
    if any(value is not None and value < 0 for value in values.values()):
        return {**unknown, 'error': 'Usage counters reset; do not invent a cumulative delta'}
    return {**values, 'status': 'partial', 'source': 'resumed_session_cumulative_delta',
            'interpretation': 'Observed additional reported usage only; original 1x usage is not charged twice. Exact billed cost and server latency remain unavailable.'}


class ExtensionTelemetry(EpisodeTelemetry):
    def __init__(self, private, session_path, baseline_size, baseline_usage):
        self.session_path = session_path
        self.baseline_size = baseline_size
        self.baseline_usage = baseline_usage
        super().__init__(private, 'codex')

    def appended_events(self):
        if not self.session_path.is_file():
            return []
        with self.session_path.open('rb') as stream:
            stream.seek(self.baseline_size)
            rows = stream.read().splitlines()
        events = []
        for row in rows:
            try:
                events.append(json.loads(row))
            except (ValueError, UnicodeError):
                continue
        return events

    def usage(self):
        try:
            latest = last_cumulative(self.appended_events())
            usage = incremental_usage(self.baseline_usage, latest, self.model_process_started)
        except (ValueError, KeyError) as error:
            usage = {'status': 'unavailable', 'error': str(error), **dict.fromkeys(TOKEN_FIELDS)}
        return usage


class ExtensionEpisode(Episode):
    def __init__(self, *args, source, probe=False, **kwargs):
        super().__init__(*args, **kwargs)
        self.source = source
        self.prefix_budget = source['baseline']['standard_policy_steps']
        self.probe = probe
        self.prefix_chunks = {row['policy_step']: row for row in source['chunks']}
        self.prior_inputs = source['root'] / 'episode_0000/policy/input'
        require(self.prior_inputs.resolve(strict=True) == self.prior_inputs, 'Unsafe prior policy input')
        for name, original in source['workspace_files'].items():
            target = self.workspace / name
            require(not target.exists(), 'Prior workspace collides with continuation input')
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(original, target)
        history = self.inputs / 'observations'
        history.mkdir()
        available_history = []
        for index in range(self.prefix_budget):
            name = f'{index:06d}'
            if (self.prior_inputs / 'observations' / name).is_dir():
                (history / name).symlink_to('/prior_input/observations/' + name, target_is_directory=True)
                available_history.append(index)
        session_relative = source['session'].relative_to(source['root'] / 'episode_0000/private/codex-home')
        session = self.home / session_relative
        session.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source['session'], session)
        baseline_bytes = session.read_bytes()
        self.initial_session_sha256 = hashlib.sha256(baseline_bytes).hexdigest()
        baseline_usage = last_cumulative([json.loads(line) for line in baseline_bytes.splitlines()])
        self.telemetry = ExtensionTelemetry(self.private, session, len(baseline_bytes), baseline_usage)
        shutil.copyfile(Path(__file__).with_name('extension_stop.py'), self.interface / 'stop.py')
        self.last_decision_index = self.prefix_budget
        write_json(self.private / 'continuation_context.json', {
            'source_evidence': source['evidence'], 'session_id': source['session_id'],
            'copied_session_sha256': self.initial_session_sha256,
            'copied_session_bytes': len(baseline_bytes), 'prefix_observation_directories_available': available_history,
            'history_note': 'Prior public input mounted read-only; missing original images are not reconstructed or passed off as exact.',
            'private_state_policy_access': False, 'source_1x_usage': read(source['root'] / 'result.json').get('tokens')})

    def observe(self, raw):
        if self.index >= self.prefix_budget:
            return super().observe(raw)
        require(raw['language'] == self.instruction, 'Replay instruction changed')
        for name, value in raw['robot_metadata'].items():
            require(self.source['robot'].get(name) == value, 'Replay robot metadata changed: ' + name)
        positions = np.asarray(raw['joint_action']['vector'])
        require(positions.shape == (len(self.source['robot']['active_joint_names']),)
                and np.isfinite(positions).all(), 'Invalid replay observation')
        self.index += 1
        return {'qpos': positions.tolist()}

    def action(self, raw):
        if self.index < self.prefix_budget:
            index = self.index
            self.observe(raw)
            if self.index == 1 and getattr(self, 'on_ready', None):
                self.on_ready()
            require(index in self.prefix_chunks, 'Replay query is not an original decision boundary')
            row = self.prefix_chunks[index]
            require(row['decision'] == self.decision, 'Replay decision order changed')
            write_json(self.private / 'replayed_actions' / f'{self.decision:06d}.json', row)
            self.decision += 1
            return np.asarray(row['actions'], dtype=np.float32)
        if self.proc is None:
            validation = read(self.root.parent / 'private/replay_validation.json')
            require(validation.get('state') == 'verified'
                    and validation.get('validated_samples') == self.prefix_budget,
                    'No validated endpoint: refusing new model inference')
            if self.probe:
                write_json(self.private / 'probe_complete.json', {'replay_validated': True, 'new_model_calls': 0})
                raise PolicyError('Replay-only probe completed; not an extended scored outcome')
        return super().action(raw)

    def policy_command(self):
        base = Path(os.environ['GPT6_EVAL_EXTENSION_SQLITE_ROOT'])
        require(base.is_absolute() and base.resolve(strict=True) == base
                and base.is_dir() and base.stat().st_dev == Path('/').stat().st_dev,
                'Extension SQLite root must be a real directory on the system volume')
        require(shutil.disk_usage(base).free >= 2 * 1024 ** 3, 'System volume reserve below 2GiB')
        directory = base / hashlib.sha256(str(self.root.resolve()).encode()).hexdigest()
        directory.mkdir(mode=0o700, exist_ok=False)
        write_json(self.private / 'cli_storage.json', {
            'sqlite_home': str(directory), 'namespace_path': '/codex-runtime',
            'attempt': str(self.root.resolve()), 'retained_after_exit': True,
            'session_transcripts': str(self.home / 'sessions'),
            'other_episode_access': False})
        command = isolation.command(self.workspace, self.home, self.interface, self.binary, self.config,
                                    resume_session=self.source['session_id'], prior_inputs=self.prior_inputs)
        boundary = command.index('--')
        command[boundary:boundary] = ['--bind', str(directory), '/codex-runtime']
        boundary = command.index('resume')
        command[boundary:boundary] = ['-c', 'sqlite_home="/codex-runtime"']
        return command

    def model_evidence(self):
        with self.telemetry.session_path.open('rb') as stream:
            prefix = stream.read(self.telemetry.baseline_size)
        require(hashlib.sha256(prefix).hexdigest() == self.initial_session_sha256,
                'Copied source session prefix changed')
        evidence = []
        for event in self.telemetry.appended_events():
            if event.get('type') == 'turn_context':
                require(event['payload'].get('model') == MODEL
                        and event['payload'].get('effort', 'max') == 'max', 'Resumed model identity mismatch')
                evidence.append({'file': str(self.telemetry.session_path.relative_to(self.home)),
                                 'model': MODEL, 'event_sha256': hashlib.sha256(canonical(event)).hexdigest()})
        require(evidence, 'No new CLI-authored Astra turn context after resume')
        return evidence

    def validate_submission(self, payload, remaining, dof):
        if isinstance(payload, dict) and set(payload) == {'give_up'}:
            reason = payload['give_up']
            require(isinstance(reason, str) and 1 <= len(reason.strip()) <= 2000,
                    'A short observable failure reason is required')
            write_json(self.private / 'policy_stop.json', {'reason': reason, 'policy_step': self.index - 1,
                       'decision': self.decision, 'classification': 'policy_declared_failure'})
            raise PolicyError('Policy declared irrecoverable failure: ' + reason)
        return super().validate_submission(payload, remaining, dof)
