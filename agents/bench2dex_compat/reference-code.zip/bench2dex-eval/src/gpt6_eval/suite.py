"""Frozen-source multi-task suite with setup gates and aggregate results."""
import argparse
import csv
import json
import math
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

import yaml

from .cli import ROOT, hash_file, load_config, load_task
from .core import write_json
from .telemetry import sum_usage, utc_now


def validate_plan(plan, config):
    if 'startup_policy' in plan:
        if (plan['startup_policy'] != 'first_validated_observation'
                or type(plan.get('startup_timeout_s')) is not int
                or plan['startup_timeout_s'] < 60):
            raise ValueError('Invalid staggered startup policy')
    ids = plan['task_ids']
    parallel = plan.get('scheduler') == 'fixed_ordered_episode_waves'
    valid_workers = plan['workers'] == 6 if parallel else plan['workers'] == 1
    if (not ids or len(ids) != len(set(ids)) or len(ids) != len(plan['task_names'])
            or not valid_workers or plan['episodes_per_task'] != config['num_episodes']
            or plan['episode_indices'] != list(range(max(1, config['start_episode']),
                 max(1, config['start_episode']) + config['num_episodes']))
            or plan['smoke_episode_index'] in plan['episode_indices']
            or plan['smoke_steps'] < 1):
        raise ValueError('Invalid suite schedule')


def validate_resource_evidence(plan, evidence):
    reservation = plan.get('ram_mib_per_worker', 10240)
    if reservation == 10240:
        return
    if reservation not in (9216, 9472) or plan['workers'] != 6:
        raise ValueError('Unsupported RAM admission plan')
    peak = (evidence or {}).get('peak_tree_rss_mib', 0)
    if (not evidence or evidence.get('returncode') != 0 or evidence.get('samples', 0) < 1
            or not isinstance(peak, (int, float)) or not math.isfinite(peak)
            or peak <= 0 or peak * 1.2 > reservation):
        raise ValueError('Reduced RAM reservation requires successful measured smoke with 20% RSS headroom')


def collect_results(root, plan, state, started_at, wall_seconds):
    tasks, usages, preparation_costs = [], [], {}
    for task_id, name in zip(plan['task_ids'], plan['task_names']):
        path = root / f'evaluation/task_{task_id:02d}/result.json'
        try:
            r = json.loads(path.read_text())
        except FileNotFoundError:
            r = {}
        valid = (r.get('state') == 'completed' and r.get('eligible_for_gpt6_score') is True
                 and r.get('planned_episodes') == plan['episodes_per_task']
                 and r.get('scored_episodes') == plan['episodes_per_task'])
        tasks.append({'task_id': task_id, 'task': name,
                      'state': r.get('state', 'not_started'), 'complete_valid': valid,
                      'planned': plan['episodes_per_task'], 'scored': r.get('scored_episodes', 0),
                      'successes': r.get('successes', 0), 'failures': r.get('failures', 0),
                      'infrastructure_errors': r.get('infrastructure_errors', 0),
                      'success_rate': r.get('success_rate') if valid else None,
                      'batch_wall_seconds': r.get('batch_wall_seconds'),
                      'result_path': str(path.relative_to(root))})
        if r.get('tokens_for_available_episode_reports'):
            usages.append(r['tokens_for_available_episode_reports'])
        preparation_costs.update(r.get('preparation_cost_by_package', {}))
    complete = state == 'completed' and all(t['complete_valid'] for t in tasks)
    successes = sum(t['successes'] for t in tasks)
    planned = len(tasks) * plan['episodes_per_task']
    report = {'schema_version': 1, 'state': state, 'started_at': started_at,
              'updated_at': utc_now(), 'suite_wall_seconds': wall_seconds,
              'workers': plan.get('workers', 1), 'planned_episodes': planned,
              'scored_episodes': sum(t['scored'] for t in tasks), 'successes': successes,
              'failures': sum(t['failures'] for t in tasks),
              'infrastructure_errors': sum(t['infrastructure_errors'] for t in tasks),
              'eligible_for_gpt6_score': complete,
              'success_rate': successes / planned if complete else None,
              'tokens_for_available_episode_reports': sum_usage(usages), 'tasks': tasks}
    report['preparation_cost_by_package'] = preparation_costs
    config_path = root / 'config.json'
    if config_path.is_file():
        report['evaluation_setting'] = json.loads(config_path.read_text()).get('evaluation_setting', 'zero_shot')
    write_json(root / 'suite_result.json', report)
    with (root / 'task_results.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(tasks[0]))
        writer.writeheader()
        writer.writerows(tasks)
    return report


def freeze_source(output):
    hashes = {}
    for folder in ('src', 'prompts', 'configs', 'docs', 'scripts'):
        for path in sorted((ROOT / folder).rglob('*')):
            if path.is_file() and path.suffix in {'.py', '.md', '.json', '.sh'}:
                target = output / path.relative_to(ROOT)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(path, target)
                hashes[str(path.relative_to(ROOT))] = hash_file(target)
    for name in ('README.md', 'AGENTS.md', 'RELEASE_CONTENTS.json', 'RELEASE_AUDIT.md', 'LICENSE_NOTICE.md', 'pyproject.toml', 'setup.py', 'MANIFEST.in'):
        shutil.copyfile(ROOT / name, output / name)
        hashes[name] = hash_file(output / name)
    return hashes


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('plan', 'config', 'upstream', 'isaaclab', 'assets', 'python', 'inventory', 'output'):
        parser.add_argument('--' + key, type=Path, required=True)
    parser.add_argument('--auth', type=Path, default=Path.home() / '.codex/auth.json')
    parser.add_argument('--resource-validation', type=Path,
                        help='Measured no-model RAM probe required for reduced RAM reservations')
    args = parser.parse_args()
    for key, value in vars(args).items():
        if isinstance(value, Path): setattr(args, key, value.resolve())
    config = load_config(args.config)
    plan = json.loads(args.plan.read_text())
    validate_plan(plan, config)
    evidence = json.loads(args.resource_validation.read_text()) if args.resource_validation else None
    validate_resource_evidence(plan, evidence)
    roots = set()
    maps = yaml.safe_load((args.upstream / 'robots/active_dof_maps.yml').read_text())['robots']
    for task_id in plan['task_ids']:
        _, task, robot = load_task(args.upstream, task_id)
        roots.add(args.assets / maps[robot]['usd_path'].split('dex2bench_dataset/', 1)[1])
        roots.update(args.assets / a['path'].split('dex2bench_dataset/', 1)[1]
                     for a in task['assets'].values())
    if args.output.exists(): parser.error('Use a new suite output directory; existing outputs are immutable')
    args.output.mkdir(parents=True)
    from .knowledge import snapshot_packages
    config = snapshot_packages(config, plan['task_ids'], args.output / 'task_packages')
    frozen = args.output / 'runner'
    source_hashes = freeze_source(frozen)
    write_json(args.output / 'plan.json', plan)
    if evidence:
        write_json(args.output / 'resource_validation.json', evidence)
    write_json(args.output / 'config.json', config)
    smoke = {**config, 'num_episodes': 1, 'start_episode': plan['smoke_episode_index']}
    write_json(args.output / 'smoke_config.json', smoke)
    shutil.copyfile(args.inventory, args.output / 'asset_inventory.json')
    env = {**os.environ, 'PYTHONPATH': str(frozen / 'src'), 'PYTHONHASHSEED': '0'}
    common = []
    for key in ('upstream', 'isaaclab', 'assets', 'python', 'auth'):
        common.extend(['--' + key, str(getattr(args, key))])
    verify = [str(args.python), '-c',
        'import json,sys; from pathlib import Path; '
        'from gpt6_eval.prepare_task26_assets import verify_inventory; '
        'rows=json.loads(Path(sys.argv[2]).read_text()); '
        'assert rows, "Empty inventory"; verify_inventory(Path(sys.argv[1]),rows); '
        'print("Verified",len(rows),"pinned asset files")',
        str(args.assets), str(args.output / 'asset_inventory.json')]
    audit = [str(args.python), '-m', 'gpt6_eval.audit_scene_assets', '--assets', str(args.assets)]
    root_args = [arg for root in sorted(roots) for arg in ('--scene', str(root))]
    stages = [('verify_assets', verify),
              ('audit_backgrounds', audit + ['--output', str(args.output / 'background_audit.json')]),
              ('audit_task_roots', audit + root_args + ['--output', str(args.output / 'task_asset_audit.json')])]
    stages.extend(episode_stages(args.output, plan, common))
    started, started_at = time.monotonic(), utc_now()
    record = {'schema_version': 1, 'state': 'preparing', 'started_at': started_at,
              'argv': sys.argv, 'plan': plan, 'config': config, 'source_hashes': source_hashes,
              'inventory_sha256': hash_file(args.output / 'asset_inventory.json'),
              'planned_stages': [{'stage': name, 'argv': cmd} for name, cmd in stages], 'stages': []}
    def save():
        record['updated_at'] = utc_now()
        write_json(args.output / 'suite.json', record)
        return collect_results(args.output, plan, record['state'], started_at, time.monotonic() - started)
    def interrupted(signum, frame): raise KeyboardInterrupt(f'Received signal {signum}')
    signal.signal(signal.SIGTERM, interrupted)
    child = None
    save()
    try:
        for name, cmd in stages:
            if (args.output / 'stop-after-current.json').exists():
                record['state'] = 'stopped_by_request'
                break
            record['state'] = name
            entry = {'stage': name, 'started_at': utc_now(), 'returncode': None, 'argv': cmd}
            record['stages'].append(entry)
            log = args.output / 'logs' / (name.replace('/', '_') + '.log')
            log.parent.mkdir(parents=True, exist_ok=True)
            print(f'{utc_now()} Starting {name}; log: {log}', flush=True)
            with log.open('wb') as stream:
                child = subprocess.Popen(cmd, env=env, stdout=stream, stderr=subprocess.STDOUT)
                entry['pid'] = child.pid
                save()
                while child.poll() is None:
                    try: child.wait(timeout=10)
                    except subprocess.TimeoutExpired: pass
                    if (args.output / 'stop-after-current.json').exists() and (('/' in name) or name in ('smoke', 'evaluation')):
                        batch_root = args.output / name
                        if batch_root.exists(): write_json(batch_root / 'stop-after-current.json', {'requested_at': utc_now(), 'source': 'suite'})
                    save()
                entry.update(returncode=child.returncode, ended_at=utc_now())
            child = None
            if entry['returncode'] != 0:
                record['state'] = 'stopped_on_infrastructure_error'
                break
            if '/' in name or name in ('smoke', 'evaluation'):
                batch_report = json.loads((args.output / name / 'result.json').read_text())
                if batch_report['state'] != 'completed':
                    record['state'] = 'stopped_by_request' if batch_report['state'] == 'stopped_by_request' else 'stopped_on_infrastructure_error'
                    break
        else: record['state'] = 'completed'
    except BaseException as exc:
        record['state'] = 'interrupted' if isinstance(exc, KeyboardInterrupt) else 'stopped_on_infrastructure_error'
        record['error'] = f'{type(exc).__name__}: {exc}'
        raise
    finally:
        if child is not None and child.poll() is None:
            child.terminate()
            try: child.wait(timeout=55)
            except subprocess.TimeoutExpired: child.kill(); child.wait()
            record['stages'][-1].update(returncode=child.returncode, ended_at=utc_now())
        report = save()
        print(json.dumps(report, indent=2), flush=True)
    raise SystemExit(0 if record['state'] == 'completed' else 1)


def episode_stages(output, plan, common):
    stages = []
    for phase, mode, cfg in [('smoke', 'hold', 'smoke_config.json'), ('evaluation', 'codex', 'config.json')]:
        if plan['workers'] == 6:
            cmd = [sys.executable, '-u', '-m', 'gpt6_eval.parallel_batch',
                   '--plan', str(output / 'plan.json'), '--mode', mode,
                   '--config', str(output / cfg), '--output', str(output / phase), *common]
            if plan.get('ram_mib_per_worker', 10240) != 10240:
                cmd.extend(['--resource-validation', str(output / 'resource_validation.json')])
            stages.append((phase, cmd))
        else:
            for task_id in plan['task_ids']:
                name = f'{phase}/task_{task_id:02d}'
                cmd = [sys.executable, '-u', '-m', 'gpt6_eval.batch', '--task', str(task_id),
                       '--workers', '1', '--mode', mode, '--smoke-steps', str(plan['smoke_steps']),
                       '--config', str(output / cfg), '--output', str(output / name), *common]
                stages.append((name, cmd))
    return stages


if __name__ == '__main__': main()
