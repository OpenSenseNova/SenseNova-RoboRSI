"""CPU-only recursive USD audit of installed background scenes.

Run with IsaacLab's Python. Loads its bundled USD libraries, not a second USD
installation. Does not start Kit, physics, a GPU renderer, or a model.
"""
import argparse
import json
import os
from pathlib import Path
import sys

from .core import write_json
from .rendering import dependency_report


def load_usd():
    try:
        from pxr import UsdUtils
        return UsdUtils
    except ImportError:
        if os.environ.get("GPT6_EVAL_USD_BOOTSTRAPPED") == "1":
            raise
        candidates = sorted({p.resolve() for p in Path(sys.prefix).glob(
            "lib/python*/site-packages/isaacsim/extscache/omni.usd.libs*/pxr")})
        if len(candidates) != 1:
            raise RuntimeError("Use the configured IsaacLab Python; bundled USD runtime is ambiguous/missing")
        package = candidates[0].parent
        env = dict(os.environ)
        env["PYTHONPATH"] = str(package) + os.pathsep + env.get("PYTHONPATH", "")
        env["LD_LIBRARY_PATH"] = os.pathsep.join(
            [str(package / "bin"), str(Path(sys.prefix) / "lib"), env.get("LD_LIBRARY_PATH", "")])
        env["GPT6_EVAL_USD_BOOTSTRAPPED"] = "1"
        os.execve(sys.executable, [sys.executable, "-m", "gpt6_eval.audit_scene_assets", *sys.argv[1:]], env)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--assets", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--scene", type=Path, action="append",
                        help="Specific USD root(s); default: all installed iTHOR scene.usda files")
    args = parser.parse_args()
    usd = load_usd()
    # Use the installed Kit's declared MDL module directories, not guessed
    # missing-asset exemptions (e.g. OmniPBR.mdl is an actual installed module).
    kits = {p.resolve() for p in Path(sys.prefix).glob("lib/python*/site-packages/isaacsim/kit")}
    search_paths = []
    if len(kits) == 1:
        kit = kits.pop()
        settings = json.loads((kit / "kernel/config/kit-core.json").read_text())
        for value in settings["renderer"]["mdl"]["searchPaths"].values():
            search_paths.extend(p.replace("${kit}", str(kit)) for p in value.split(";") if p)
    roots = sorted(p.resolve() for p in (args.scene or list((args.assets / "scenes/ithor").glob("*/scene.usda"))))
    if not roots or any(not p.is_file() for p in roots):
        raise FileNotFoundError("No scene roots, or a requested root is missing")
    reports = {}
    for root in roots:
        reports[str(root)] = dependency_report(str(root), usd.ComputeAllDependencies,
                                               search_paths=search_paths)
    unresolved = sorted({p for report in reports.values() for p in report["unresolved"]})
    report = {"schema_version": 1, "status": "failed" if unresolved else "passed",
              "scene_count": len(roots), "unresolved_count": len(unresolved),
              "scenes": reports, "mdl_search_paths": search_paths}
    write_json(args.output, report)
    print(json.dumps({k: v for k, v in report.items() if k != "scenes"}))
    raise SystemExit(1 if unresolved else 0)


if __name__ == "__main__":
    main()
