"""Host-only contract for paired, replay-reconstructed 10x extensions."""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import numpy as np

from .core import MODEL, canonical, validate_actions
from .knowledge import file_hash, portable_config

SETTING = 'task_icl_v3_replay_extension_10x_v1'
MULTIPLIER = 10
COHORTS = (3, 5)
TOLERANCES = {'position': 0.001, 'joint_position': 0.001,
              'quaternion': 0.001, 'velocity': 0.01, 'calibration': 0.00001}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_bytes())


def reference(path):
    path = Path(path).resolve(strict=True)
    return {'path': str(path), 'sha256': file_hash(path)}


def checked_path(root, name):
    relative = Path(name)
    require(not relative.is_absolute() and '..' not in relative.parts, 'Unsafe archive path')
    path = root / relative
    require(path.resolve(strict=True) == path, 'Archive symlink is not accepted: ' + str(path))
    require(path.is_file(), 'Missing archive file: ' + str(path))
    return path


def baseline_metrics(result, manifest, official):
    rows = result.get('episodes', [])
    require(result.get('complete') is True and result.get('eligible_for_gpt6_score') is True
            and not result.get('infrastructure_error') and len(rows) == 1,
            'A valid completed 1x episode is required')
    require(result.get('evaluation_setting') == 'task_icl_v3', 'Not a standard ICL source')
    row = rows[0]
    limit = manifest['official_policy_budget']
    require(type(limit) is int and limit > 0 and manifest['executed_policy_budget'] == limit,
            'Source is not a standard 1x budget')
    require(row['episode_index'] == official['episode_index']
            == manifest['config']['start_episode'], 'Source index mismatch')
    require(row['official_success'] == official['success'], 'Source outcome mismatch')
    require(row['outcome'] in ('success', 'failure'), 'Invalid source outcome')
    require((row['outcome'] == 'success') == official['success'], 'Source score mismatch')
    progress = official['latched_stage_completion_rate']
    require(isinstance(progress, (int, float)) and math.isfinite(progress)
            and 0 <= progress <= 1, 'Invalid official LSCR')
    steps = official['steps']
    require(type(steps) is int and 0 <= steps <= 3 * limit, 'Invalid source step count')
    eligible = (row['outcome'] == 'failure' and not row.get('error')
                and row['terminated_reason'] == official['terminated_reason'] == 'max_steps'
                and steps == 3 * limit)
    return {'success': row['outcome'] == 'success', 'lscr': float(progress),
            'eligible_for_extension': eligible, 'standard_policy_steps': limit,
            'total_policy_steps': MULTIPLIER * limit, 'additional_policy_steps': 9 * limit,
            'termination': row['terminated_reason'], 'episode_index': row['episode_index']}


def round_robin_slots(task_ids, count):
    require(count in COHORTS, 'Only fixed first-three or first-five cohorts are supported')
    tasks = sorted(task_ids)
    require(len(tasks) == len(set(tasks)), 'Duplicate task')
    return [(task, index) for index in range(5, 5 + count) for task in tasks]


def paired_summary(rows, expected_count):
    require(len(rows) == expected_count, 'Never shrink the planned denominator')
    require(len({(row['task_id'], row['episode_index']) for row in rows}) == expected_count,
            'Duplicate cohort slot')
    baseline = [row['baseline'] for row in rows]
    settled = []
    unresolved = []
    eligible = 0
    rescued = 0
    for row in rows:
        original = row['baseline']
        if not original['eligible_for_extension']:
            settled.append(original)
            continue
        eligible += 1
        extension = row.get('extension')
        if not extension or extension.get('state') != 'verified':
            unresolved.append([row['task_id'], row['episode_index']])
            continue
        require(extension.get('setting') == SETTING
                and extension.get('replay_validated') is True, 'Unvalidated extension score')
        require(type(extension.get('success')) is bool
                and isinstance(extension.get('lscr'), (int, float))
                and math.isfinite(extension['lscr']) and 0 <= extension['lscr'] <= 1,
                'Invalid extension metrics')
        require(extension['lscr'] + 1e-12 >= original['lscr'], 'Latched progress decreased')
        settled.append(extension)
        rescued += int(extension['success'])
    complete = not unresolved
    return {'setting': SETTING, 'planned': expected_count, 'resolved': len(settled),
            'pending_or_invalid': unresolved, 'extension_eligible': eligible,
            'new_successes': rescued,
            'baseline_sr': sum(row['success'] for row in baseline) / expected_count,
            'baseline_lscr': sum(row['lscr'] for row in baseline) / expected_count,
            'extended_sr': sum(row['success'] for row in settled) / expected_count if complete else None,
            'extended_lscr': sum(row['lscr'] for row in settled) / expected_count if complete else None,
            'known_success_lower_bound': sum(row['success'] for row in settled) / expected_count,
            'extension_rescue_rate': rescued / eligible if complete and eligible else None,
            'complete': complete}


def numeric_digest(arrays):
    digest = hashlib.sha256()
    for name, values in sorted(arrays.items()):
        values = np.ascontiguousarray(values)
        digest.update(canonical({'name': name, 'shape': values.shape, 'dtype': values.dtype.str}))
        digest.update(values.tobytes())
    return digest.hexdigest()


def storage_admission(status_path, data_path=None):
    from datetime import datetime, timezone
    import shutil
    import subprocess
    import os
    status = read(status_path)
    checked = datetime.fromisoformat(status['checked_at'].replace('Z', '+00:00'))
    age = (datetime.now(timezone.utc) - checked).total_seconds()
    require(0 <= age <= 180, 'A fresh storage monitor status is required')
    require(not status.get('external_action_required'), 'Storage hardware warning requires resolution')
    require(not any('storage' in issue.get('kind', '')
                    or issue.get('kind', '').startswith('low_disk')
                    or issue.get('kind') in ('data_mount_not_expected_rw', 'disk_unavailable')
                    for issue in status.get('issues', [])), 'Storage monitor has an unresolved issue')
    attributes = status.get('extended_disk_attributes', {})
    require(attributes.get('197') == 0 and attributes.get('198') == 0,
            'Storage sector health is unknown or unhealthy')
    if data_path is None:
        require(bool(os.environ.get('BENCH2DEX_EVAL_DISK')),
                'Set BENCH2DEX_EVAL_DISK to the monitored evaluation filesystem mount')
        data_path = Path(os.environ['BENCH2DEX_EVAL_DISK'])
    mount = subprocess.check_output(['findmnt', '-no', 'FSTYPE,OPTIONS', str(data_path)], text=True).split()
    require(len(mount) == 2 and mount[0] == 'ext4' and 'rw' in mount[1].split(','),
            'Expected writable evaluation filesystem')
    require(shutil.disk_usage(data_path).free >= 100 * 1024**3
            and shutil.disk_usage('/').free >= 2 * 1024**3, 'Evaluation disk reserve is not available')
    return {'status': reference(status_path), 'sector_health': attributes, 'checked_at': status['checked_at']}


def verify_source_audit(path, source):
    proof = read(path)
    require(proof.get('state') == 'verified' and proof.get('named_results_verified') is True
            and proof.get('validity_verified') is True and not proof.get('errors'),
            'A verified named-result source is required')
    require(proof.get('result') == str(source['root'] / 'result.json')
            and proof.get('result_sha256') == source['evidence']['source_result']['sha256']
            and proof.get('task_id') == source['manifest']['task_id']
            and proof.get('episode_index') == source['baseline']['episode_index'],
            'Source audit binding mismatch')
    return reference(path)


def load_source(root, *, task_id=None, config=None):
    import h5py
    root = Path(root).resolve(strict=True)
    integrity = read(root / 'integrity.json')
    verified = {}

    def checked(name):
        path = checked_path(root, name)
        expected = integrity.get(name)
        require(expected and file_hash(path) == expected, 'Source hash mismatch: ' + name)
        verified[name] = expected
        return path

    result = read(checked('result.json'))
    manifest = read(checked('private/manifest.json'))
    official_rows = [json.loads(line) for line in checked(result['official_results_path']).read_text().splitlines() if line.strip()]
    require(len(official_rows) == 1, 'Expected one official source row')
    official = official_rows[0]
    baseline = baseline_metrics(result, manifest, official)
    require(baseline['eligible_for_extension'], 'Only complete step-limit failures may be extended')
    require(manifest['config']['model'] == MODEL and manifest['config']['reasoning_effort'] == 'max',
            'Source policy identity changed')
    if task_id is not None:
        require(manifest['task_id'] == task_id, 'Wrong source task')
    if config is not None:
        require(portable_config(manifest['config']) == portable_config(config),
                'Continuation must retain the original configuration and package')
    private = root / 'episode_0000/private'
    robot = read(checked('episode_0000/private/robot.json'))
    actions = []
    chunks = []
    for decision, path in enumerate(sorted((private / 'actions').glob('*.json'))):
        require(path.name == f'{decision:06d}.json', 'Noncontiguous source decisions')
        row = read(checked(str(path.relative_to(root))))
        require(row['decision'] == decision and row['policy_step'] == len(actions), 'Source action timing mismatch')
        chunk = validate_actions({'actions': row['actions']}, len(robot['active_joint_names']),
                                 baseline['standard_policy_steps'] - len(actions))
        request = checked('episode_0000/private/requests/' + path.name)
        require(file_hash(request) == row['request_sha256'], 'Source request binding mismatch')
        envelope = read(request)
        require(envelope['decision'] == decision
                and np.array_equal(validate_actions(envelope['payload'], len(robot['active_joint_names']),
                                                   baseline['standard_policy_steps'] - len(actions)), chunk),
                'Source request/action mismatch')
        require(row.get('model_evidence') and all(item['model'] == MODEL for item in row['model_evidence']),
                'Missing source action model evidence')
        chunks.append(row)
        actions.extend(chunk)
    require(len(actions) == baseline['standard_policy_steps'], 'Incomplete recorded action prefix')
    sessions = sorted((private / 'codex-home/sessions').rglob('*.jsonl'))
    require(len(sessions) == 1, 'Resume requires exactly one source policy session')
    session = checked(str(sessions[0].relative_to(root)))
    session_id = None
    model_evidence = set()
    for line in session.read_text().splitlines():
        event = json.loads(line)
        if event.get('type') == 'session_meta':
            session_id = event['payload']['id']
        if event.get('type') == 'turn_context':
            require(event['payload'].get('model') == MODEL
                    and event['payload'].get('effort', 'max') == 'max', 'Source session model mismatch')
            model_evidence.add(hashlib.sha256(canonical(event)).hexdigest())
    import uuid
    require(session_id and str(uuid.UUID(session_id)) == session_id and model_evidence,
            'Missing source session identity')
    require(all(item['event_sha256'] in model_evidence for chunk in chunks for item in chunk['model_evidence']),
            'Source actions are not bound to their session')
    require(len(result['trajectories']) == 1, 'Expected one source trajectory')
    trajectory = checked_path(root, result['trajectories'][0])
    before = trajectory.stat()
    arrays = {}
    with h5py.File(trajectory, 'r') as archive:
        require(bool(archive.attrs.get('finalized')) and not bool(archive.attrs.get('official_success')),
                'Source trajectory is not a finalized failure')
        require(int(archive['meta/frame_count'][()]) == baseline['standard_policy_steps']
                and int(archive['meta/episode_index'][()]) == baseline['episode_index'], 'Source trajectory clock mismatch')
        names = archive['action/action_names'].asstr()[:].tolist()
        require(names == robot['active_joint_names'], 'Source trajectory joint order mismatch')
        def collect(name, dataset):
            if (isinstance(dataset, h5py.Dataset) and dataset.dtype.kind in 'fiu'
                    and name.startswith(('robot/', 'objects/', 'action/', 'time/', 'cameras/'))
                    and not name.endswith('/rgb')):
                values = dataset[:]
                require(values.shape and values.shape[0] == baseline['standard_policy_steps']
                        and np.isfinite(values).all(), 'Invalid numeric source trajectory: ' + name)
                arrays[name] = values
        archive.visititems(collect)
        reset_metadata = json.loads(archive['meta/scene_generalization_sample'].asstr()[()])
    after = trajectory.stat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
            == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
            'Source trajectory changed during numeric validation')
    require(all(name in arrays for name in ('robot/qpos', 'robot/qvel', 'robot/root_state_world', 'action/commanded')),
            'Source lacks robot state')
    require(any(name.startswith('objects/') for name in arrays), 'Source lacks object state')
    require(np.array_equal(arrays['action/commanded'], np.asarray(actions, dtype=np.float32)),
            'Recorded trajectory differs from accepted actions')
    require(np.array_equal(arrays['time/physics_step'], np.arange(len(actions)) * 3), 'Noncontiguous source clock')
    workspace_files = {}
    for name in integrity:
        if name.startswith('episode_0000/policy/'):
            suffix = name.removeprefix('episode_0000/policy/')
            if not suffix.startswith(('input/', '.cache/', '.action_transport/')):
                workspace_files[suffix] = str(checked(name))
    return {'root': root, 'baseline': baseline, 'manifest': manifest, 'official': official,
            'robot': robot, 'chunks': chunks, 'arrays': arrays, 'reset_metadata': reset_metadata,
            'session': session, 'session_id': session_id, 'workspace_files': workspace_files,
            'evidence': {'source_result': reference(root / 'result.json'),
                         'integrity_manifest': reference(root / 'integrity.json'),
                         'verified_files': verified, 'numeric_trajectory_sha256': numeric_digest(arrays),
                         'source_trajectory': str(trajectory), 'terminal_checkpoint_available': False}}
