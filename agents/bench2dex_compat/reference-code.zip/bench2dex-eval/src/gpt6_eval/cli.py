"""Private experiment orchestration. Never mount this module into the policy."""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import re
import shutil
import signal
import socket
import subprocess
import sys
import threading
import time

import yaml

from .bridge import Episode, serve
from .core import MODEL, CAMERAS, budget, classify_result, digest, write_json, verify_model_rollouts
from .robot import kinematics
from .transport import recv_message, send_message
from .telemetry import jsonl, summarize_run, utc_now
from .calibration import PROFILE

# Wheels contain a complete source snapshot for run provenance and subprocesses.
ROOT = Path(__file__).resolve().parents[2]
if not (ROOT / "configs/default.json").is_file():
    ROOT = Path(__file__).resolve().parent / "_release"
ROBOTS = {
    3: "multi_xarm7_with_ability", 6: "multi_ur5_rh56dfx_with_flange",
    7: "multi_ur5_rh5dg2_with_flange", 8: "multi_ur5_schunk_hand_with_flange",
    9: "multi_xarm7_with_leap", 12: "multi_ur5_rh56dfx_with_flange",
    21: "multi_ur5_wuji_with_flange", 22: "multi_panda_with_orca",
    24: "multi_rm_65_with_revo2", 26: "multi_iiwa7_with_sharpa",
    27: "multi_ur5_wuji_with_flange", 32: "multi_iiwa7_with_sharpa",
    34: "multi_ur5_rh5dg2_with_flange", 42: "multi_ur5_rh56dfx_with_flange",
    43: "multi_ur5_shadow_hand_with_flange", 44: "multi_ur5_schunk_hand_with_flange",
    51: "multi_xarm7_with_leap", 60: "multi_ur5_rh5dg2_with_flange",
    61: "multi_panda_with_orca", 62: "multi_xarm7_with_leap",
    64: "multi_panda_with_allegro", 67: "multi_rm_65_with_revo2",
    73: "multi_iiwa7_with_sharpa", 76: "multi_ur5_shadow_hand_with_flange",
    79: "multi_xarm7_with_ability", 80: "multi_jaka_zu7_dexhand021_with_flange",
}


def git(repo, *args):
    return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()


def hash_file(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_task(repo, task_id):
    catalog = (repo / "scenes/task.md").read_text()
    matches = re.findall(r"\|\s*(\d+)\s*\|[^\n]*?`([^`]+\.yaml)`", catalog)
    tasks = {int(i): filename for i, filename in matches}
    if len(tasks) != 26 or task_id not in tasks:
        raise ValueError("Task must belong to the pinned 26-task release catalog")
    path = repo / "scenes" / tasks[task_id]
    task = yaml.safe_load(path.read_text())
    return path, task, ROBOTS[task_id]


def load_config(path):
    config = json.loads(path.read_text())
    expected = set(json.loads((ROOT / "configs/default.json").read_text()))
    if config.get("schema_version") in (2, 3):
        expected.add("deployment_profile")
        if config.get("deployment_profile") != PROFILE:
            raise ValueError("Schema 2 requires the calibrated deployment profile")
        if config['schema_version'] == 3:
            expected.update(('evaluation_setting', 'task_packages'))
            from .knowledge import validate_config
            validate_config(config)
    elif config.get("schema_version") != 1:
        raise ValueError("Unknown configuration schema version")
    if set(config) != expected:
        raise ValueError("Configuration fields must exactly match the versioned default schema")
    if config["model"] != MODEL:
        raise ValueError("This evaluation requires exactly gpt-6-astra")
    if config["observation_profile"] not in CAMERAS:
        raise ValueError("Unknown sensor profile")
    if config["generalization_profile"] not in {"none", "cov_only", "inv_only", "inv_cov"}:
        raise ValueError("Unknown generalization profile")
    if config["generalization_config"] not in {
        "configs/scene/generalization.yaml", "configs/scene/no_generalization.yaml"
    }:
        raise ValueError("Use a pinned upstream generalization configuration")
    if config["generalization_split"] not in {"seen", "unseen", "all"}:
        raise ValueError("Unknown generalization split")
    if config["reasoning_effort"] not in {"low", "medium", "high", "xhigh", "max"}:
        raise ValueError("Unknown reasoning effort")
    for key in ("seed", "inv_cov_seed", "warmup_steps", "start_episode", "num_episodes"):
        if type(config[key]) is not int or config[key] < 0:
            raise ValueError(f"Invalid {key}")
    if config["num_episodes"] < 1:
        raise ValueError("An explicit positive episode count is required")
    timeout = config["decision_timeout_s"]
    if timeout is not None and (not isinstance(timeout, (int, float)) or timeout <= 0):
        raise ValueError("Watchdog must be null or positive")
    if config.get('schema_version') == 3:
        for ref in config['task_packages'].values():
            ref['path'] = str((path.parent / ref['path']).absolute())
    return config


def runtime_command(args, config, scene, robot, steps, port, output):
    policy_name = {"codex": MODEL, "hold": "development_hold",
                   "replay": "recorded_action_replay"}[args.mode]
    cmd = [str(args.python), "-m", "gpt6_eval.simulator", "--upstream", str(args.upstream),
           "--task", str(scene), "--robot-key", robot, "--policy-type", "REMOTE",
           "--remote-port", str(port), "--enable-rgb", "--headless", "--active-dof",
           "--early-stop", "--episode-steps", str(steps),
           "--warmup-steps", str(config["warmup_steps"]),
           "--num-episodes", str(config["num_episodes"]),
           "--start-episode", str(config["start_episode"]),
           "--seed", str(config["seed"]), "--inv-cov-seed", str(config["inv_cov_seed"]),
           "--generalization-profile", config["generalization_profile"],
           "--generalization-config", str(args.upstream / config["generalization_config"]),
           "--generalization-split", config["generalization_split"],
           "--output-dir", str(output), "--policy-name", policy_name,
           "--record-dir", str(output.parent / "trajectories"), "--record-all"]
    if config["generalization_profile"] != "none":
        cmd.append("--enable-generalization")
    if args.anchor:
        cmd.extend(["--anchor-dir" if args.anchor.is_dir() else "--anchor-hdf5", str(args.anchor)])
    if config.get("deployment_profile") == PROFILE:
        cmd.extend(["--deployment-profile", PROFILE,
                    "--camera-profile", config["observation_profile"]])
    return cmd


def run(args):
    args._created_output = False
    args._evaluation_setting = None
    started, started_at = time.monotonic(), utc_now()
    try:
        return _run(args, started, started_at)
    except BaseException as exc:
        # Preserve accounting even for setup errors or Ctrl-C after output creation.
        # Never touch a pre-existing run rejected by the immutable-output check.
        if getattr(args, "_created_output", False):
            rows = [row for _, row in jsonl(args.output / "private/benchmark/per_episode.jsonl")]
            summarize_run(args.output, args.mode, started, started_at, None, rows,
                          error=f"{type(exc).__name__}: {exc}")
            write_json(args.output / "result.json", {
                "complete": False, "mode": args.mode, "eligible_for_gpt6_score": False,
                "evaluation_setting": args._evaluation_setting,
                "success_rate": None, "infrastructure_error": f"{type(exc).__name__}: {exc}",
                "telemetry_path": "telemetry.json"})
        raise


def _run(args, started, started_at):
    config = load_config(args.config)
    args._evaluation_setting = config.get('evaluation_setting', 'zero_shot')
    scene, task, robot = load_task(args.upstream, args.task)
    official_budget = budget(float(task["metrics"]["expert_time_step"]))
    extension = None
    extension_admission = None
    if getattr(args, 'extension_source', None):
        from .extension import SETTING as EXTENSION_SETTING, load_source, storage_admission, verify_source_audit
        if args.mode != 'codex' or args.replay or not args.extension_audit or not args.storage_status:
            raise ValueError('Extension requires codex mode, a source audit and fresh storage status; no replay-mode mixing')
        extension_admission = storage_admission(args.storage_status)
        extension = load_source(args.extension_source, task_id=args.task, config=config)
        if args.output.is_relative_to(extension['root']) or extension['root'].is_relative_to(args.output):
            raise ValueError('Extension outputs must be separate from original source archives')
        extension['audit'] = verify_source_audit(args.extension_audit, extension)
        if (extension['baseline']['standard_policy_steps'] != official_budget
                or extension['manifest']['scene_sha256'] != hash_file(scene)):
            raise ValueError('Source scene or official budget differs from the current pinned task')
        args._evaluation_setting = EXTENSION_SETTING
    elif getattr(args, 'extension_probe', False):
        raise ValueError('Extension probe requires an extension source')
    if config["generalization_profile"] != "inv_cov" and not args.anchor:
        raise ValueError("This profile requires private anchor metadata")
    if args.output.exists():
        raise ValueError("Use a new output directory; existing runs are immutable")
    for repo, expected in ((args.upstream, config["upstream_commit"]),
                           (args.isaaclab, config["isaaclab_commit"])):
        if git(repo, "rev-parse", "HEAD") != expected or git(repo, "status", "--porcelain"):
            raise ValueError(f"Upstream must be clean at the pinned commit: {repo}")
    binary = Path(shutil.which("codex") or "")
    if args.mode == "codex":
        actual = subprocess.check_output([str(binary), "--version"], text=True).strip()
        if actual != config["codex_version"]:
            raise ValueError(f"CLI version mismatch: {actual}")
        if extension and (hash_file(binary.resolve()) != extension['manifest']['codex_binary_sha256']
                or hash_file(binary.resolve().with_name('codex-code-mode-host'))
                != extension['manifest']['code_mode_host_sha256']):
            raise ValueError('Continuation requires the source episode CLI and code-host binaries')
        if not args.auth.is_file() and not getattr(args, 'extension_probe', False):
            raise ValueError("Provide a Codex auth.json path via --auth")
    if args.mode == "replay":
        if not args.replay:
            raise ValueError("Replay requires an original run")
        from .audit import audit
        audit(args.replay)
    maps = yaml.safe_load((args.upstream / "robots/active_dof_maps.yml").read_text())
    urdf = args.assets / maps["robots"][robot]["urdf_path"].removeprefix("Bench2Dex/")
    card = kinematics(urdf)
    card["urdf_to_runtime_joint_names"] = maps["robots"][robot].get("name_sanitize", {})
    if config.get("deployment_profile") == PROFILE:
        mapping = maps["robots"][robot]
        # Upstream expand_to_full zero-fills non-actuated, non-mimic joints.
        active = set(mapping["active_joint_names"])
        mimics = {card["urdf_to_runtime_joint_names"].get(j["name"], j["name"]) for j in card["joints"] if "mimic" in j}
        card["inactive_joint_positions"] = {n: 0.0 for n in mapping["full_joint_names"] if n not in active and n not in mimics}
    for item in task["assets"].values():
        if not (scene.parent / item["path"]).resolve().is_file():
            raise FileNotFoundError("Missing task asset: " + item["path"])
    args.output.mkdir(parents=True)
    args._created_output = True
    (args.output / "private").mkdir()
    from .knowledge import SETTING, snapshot_packages, verify_package
    config = snapshot_packages(config, [args.task], args.output / 'private/task_packages')
    task_package = None
    if config.get('evaluation_setting') == SETTING:
        task_package = config['task_packages'][str(args.task)]
        info = verify_package(Path(task_package['path']), task_package['sha256'], args.task, config)
        if info['robot_key'] != robot or info['instruction_sha256'] != digest(task['description'].encode()):
            raise ValueError('Knowledge package belongs to a different task/robot instruction')
    (args.output / "private/task.yaml").write_bytes(scene.read_bytes())
    snapshot = args.output / "private/source"
    source_hashes = {}
    for folder in ("src", "prompts", "configs", "docs", "scripts"):
        for path in sorted((ROOT / folder).rglob("*")):
            if path.is_file() and path.suffix in {".py", ".md", ".json", ".sh"}:
                rel = path.relative_to(ROOT)
                dest = snapshot / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(path, dest)
                source_hashes[str(rel)] = hash_file(path)
    for name in ("README.md", "AGENTS.md", "RELEASE_CONTENTS.json", "RELEASE_AUDIT.md", "LICENSE_NOTICE.md", "pyproject.toml", "setup.py", "MANIFEST.in"):
        shutil.copyfile(ROOT / name, snapshot / name)
        source_hashes[name] = hash_file(ROOT / name)
    from .throughput import content_hashes, cached_asset_hashes
    cache = os.environ.get('GPT6_EVAL_ASSET_CACHE')
    if cache:
        assets, cache_evidence = cached_asset_hashes(args.assets, Path(cache),
            exclude=('.cache', '.git'),
            progress=lambda row: print('Asset verification: '+json.dumps(row), flush=True))
        write_json(args.output / 'private/asset_cache_use.json', cache_evidence)
        print('Asset verification: '+json.dumps(cache_evidence), flush=True)
    else:
        print("Hashing installed testing assets for the private run manifest...", flush=True)
        assets = content_hashes(args.assets, strict=False, exclude=('.cache', '.git'),
            progress=lambda row: print('Asset verification: '+json.dumps(row), flush=True))
    write_json(args.output / "private/assets.json", assets)
    env = dict(os.environ)
    env["PYTHONPATH"] = str(ROOT / "src")
    env["PYTHONHASHSEED"] = "0"
    env["DEX2BENCH_DATASET_ROOT"] = str(args.assets)
    env["SAVE_STEP_IMAGES"] = ""
    env["SAVE_INFERENCE_PREFLIGHT"] = ""
    steps = min(official_budget, args.smoke_steps) if args.mode == "hold" else official_budget
    if extension:
        steps = official_budget + 1 if args.extension_probe else official_budget * 10
    listener = socket.socket()
    listener.bind(("127.0.0.1", 0))
    listener.listen(1)
    cmd = runtime_command(args, config, scene, robot, steps,
                          listener.getsockname()[1], args.output / "private/benchmark")
    if extension:
        from .extension_retention import PROFILE as RETENTION_PROFILE
        extension_spec = args.output / 'private/extension_spec.json'
        write_json(extension_spec, {'source': str(extension['root']), 'task_id': args.task,
                                   'source_evidence': extension['evidence'], 'source_audit': extension['audit'],
                                   'storage_admission': extension_admission, 'setting': EXTENSION_SETTING,
                                   'image_retention': RETENTION_PROFILE,
                                   'standard_policy_steps': official_budget, 'total_policy_steps': 10 * official_budget})
        cmd.extend(['--extension-spec', str(extension_spec)])
    prompt = (ROOT / "prompts/policy.md").read_text()
    if task_package:
        prompt = (ROOT / 'prompts/policy_icl.md').read_text()
    if config.get("deployment_profile") == PROFILE:
        prompt += "\n" + (ROOT / "prompts/calibrated_deployment.md").read_text()
    if extension:
        prompt = (ROOT / 'prompts/extension.md').read_text()
    manifest = {"schema_version": 1, "config": config, "mode": args.mode,
                "evaluation_setting": args._evaluation_setting,
                "task_package": task_package,
                "intended_for_gpt6_score": args.mode == "codex", "task_id": args.task,
                "robot_key": robot, "official_policy_budget": official_budget,
                "executed_policy_budget": steps, "source_hashes": source_hashes,
                "asset_manifest_sha256": hash_file(args.output / "private/assets.json"),
                "scene_sha256": hash_file(scene), "prompt_sha256": digest(prompt.encode()),
                "generalization_config_sha256": hash_file(args.upstream / config["generalization_config"]),
                "simulator_argv": cmd, "host_python": sys.version,
                "platform": platform.platform(),
                "dependencies": {p: importlib.metadata.version(p) for p in ("numpy", "Pillow", "PyYAML")},
                "baseline_camera_profile": config["observation_profile"],
                "trajectory_recording": {"schema_version": 1, "sample_hz": 20,
                                         "phase": "pre_action", "all_outcomes": True,
                                         "rgb": "all simulator cameras, JPEG quality90, original resolution",
                                         "policy_access": False},
                "codex_binary_sha256": hash_file(binary.resolve()) if binary.is_file() else None,
                "code_mode_host_sha256": (hash_file(binary.resolve().with_name("codex-code-mode-host"))
                                          if binary.is_file() else None),
                "eula_environment": env.get("OMNI_KIT_ACCEPT_EULA"),
                "anchor_hashes": ({str(p): hash_file(p) for p in sorted(args.anchor.glob("*.hdf5"))}
                                  if args.anchor and args.anchor.is_dir() else
                                  {str(args.anchor): hash_file(args.anchor)} if args.anchor else {})}
    if extension:
        manifest['extension'] = {'setting': EXTENSION_SETTING, 'source': extension['evidence'],
                                 'source_audit': extension['audit'], 'total_multiplier': 10,
                                 'additional_multiplier': 9, 'probe_only': args.extension_probe,
                                 'policy_context': 'Explicit same-episode copied-session resume',
                                 'exact_checkpoint_restore': False, 'trajectory_policy_step_offset': official_budget}
        manifest['intended_for_gpt6_score'] = False
        manifest['intended_for_extension_score'] = not args.extension_probe
    if args.mode == "replay":
        if not args.replay:
            raise ValueError("Replay requires --replay pointing to an original run")
        original = json.loads((args.replay / "private/manifest.json").read_text())
        for field in ("config", "task_id", "source_hashes", "asset_manifest_sha256", "scene_sha256"):
            from .knowledge import portable_config
            before = portable_config(original[field]) if field == 'config' else original[field]
            after = portable_config(manifest[field]) if field == 'config' else manifest[field]
            if before != after:
                raise ValueError(f"Replay manifest mismatch: {field}")
        manifest["replay_source"] = str(args.replay)
    write_json(args.output / "private/manifest.json", manifest)
    (args.output / "private/runtime-packages.txt").write_bytes(
        subprocess.check_output([str(args.python), "-m", "pip", "freeze"], env=env))
    gpu = subprocess.run(["nvidia-smi"], capture_output=True, check=False)
    (args.output / "private/gpu.txt").write_bytes(gpu.stdout)
    state, stop = {}, threading.Event()
    episode_number = 0

    def make_episode():
        nonlocal episode_number
        episode_class = Episode
        extra = {}
        if extension:
            from .extension_episode import ExtensionEpisode
            episode_class = ExtensionEpisode
            extra = {'source': extension, 'probe': args.extension_probe}
        episode = episode_class(args.output / f"episode_{episode_number:04d}", config,
                          task["description"], robot, card, steps, binary,
                          args.auth, prompt, args.mode,
                          args.replay / f"episode_{episode_number:04d}" if args.replay else None, **extra)
        if task_package:
            from .knowledge import attach_package
            attach_package(Path(task_package['path']), task_package['sha256'], args.task,
                           config, episode.inputs, episode.private)
        def ready():
            write_json(args.output / 'private/startup_ready.json',
                       {'ready_at': utc_now(), 'task_id': args.task,
                        'phase': 'first_validated_observation'})
            release = os.environ.get('GPT6_EVAL_SMOKE_RELEASE')
            if release:
                if args.mode != 'hold':
                    raise RuntimeError('Startup residency barrier is restricted to no-model smokes')
                while not Path(release).is_file():
                    if stop.wait(0.2):
                        raise RuntimeError('Startup residency barrier interrupted')
        episode.on_ready = ready
        episode_number += 1
        return episode

    server = threading.Thread(target=serve, args=(listener, stop, make_episode,
                              recv_message, send_message, state), daemon=True)
    server.start()
    print(f"Running task {args.task:02d}; private simulator log: {args.output / 'private/simulator.log'}", flush=True)
    simulator_started = time.monotonic()
    returncode = None
    try:
        with (args.output / "private/simulator.log").open("wb") as log:
            from .resource_wait import before_simulator
            before_simulator(args.output)
            # Asset/source verification above is preparation, not simulator startup.
            # Host-private evidence; never mounted into the policy workspace.
            write_json(args.output / 'private/startup_started.json',
                       {'phase': 'simulator_launch', 'started_at': utc_now(),
                        'monotonic': time.monotonic(), 'worker_pid': os.getpid()})
            if extension:
                storage_admission(args.storage_status)
            proc = subprocess.Popen(cmd, cwd=args.upstream, env=env, stdout=log, stderr=subprocess.STDOUT)
            returncode = proc.wait()
    except (Exception, KeyboardInterrupt) as exc:
        state["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        if 'proc' in locals() and proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
        simulator_seconds = time.monotonic() - simulator_started
        stop.set()
        if state.get("episode"):
            state["episode"].stopped.set()
        listener.close()
        server.join(timeout=15)
        if server.is_alive():
            state["error"] = "Policy server did not terminate cleanly"
    if args.mode == "codex":
        for index, home in enumerate(sorted(args.output.glob("episode_*/private/codex-home"))):
            try:
                if extension:
                    if not args.extension_probe:
                        state['episode'].model_evidence()
                else:
                    verify_model_rollouts(home)
            except RuntimeError as exc:
                state.setdefault("episode_errors", {})[index] = {
                    "error": str(exc), "policy_failure": False}
    rows_path = args.output / "private/benchmark/per_episode.jsonl"
    rows = [row for _, row in jsonl(rows_path)]
    try:
        rendering = json.loads((args.output / "private/rendering.json").read_text())
        if rendering.get("status") != "passed" or rendering.get("dependencies", {}).get("unresolved"):
            raise ValueError("Rendering dependency preflight did not pass")
    except (OSError, ValueError) as exc:
        if not state.get("error"):
            state["error"] = f"Rendering validation unavailable/failed: {exc}"
    if len(rows) != config["num_episodes"] and not state.get("error"):
        state["error"] = (f"Expected {config['num_episodes']} episode results, got {len(rows)}; "
                          "inspect private/simulator.log")
    results = []
    for index, row in enumerate(rows):
        outcome = classify_result(row)
        if args.mode == "hold":
            outcome = "development_smoke"
        if state.get("error") or returncode != 0:
            outcome = "infrastructure_error"
        episode_error = state.get("episode_errors", {}).get(index)
        if episode_error:
            outcome = "failure" if episode_error["policy_failure"] else "infrastructure_error"
        results.append({"episode_index": row.get("episode_index"), "outcome": outcome,
                        "official_success": row.get("success"),
                        "error": episode_error,
                        "terminated_reason": row.get("terminated_reason")})
    complete = (len(rows) == config["num_episodes"] and
                not state.get("error") and returncode == 0 and
                all(r["outcome"] != "infrastructure_error" for r in results))
    if args.mode == "replay":
        expected_rows = [json.loads(line) for line in
                         (args.replay / "private/benchmark/per_episode.jsonl").read_text().splitlines()]
        # Timing and output-path metadata can differ; compare scoring semantics.
        for before, after in zip(expected_rows, rows):
            for key in ("success", "steps", "terminated_reason", "stable_success_step"):
                if before.get(key) != after.get(key):
                    complete = False
                    state["error"] = f"Replay metric mismatch: {key}"
    result = {"complete": complete, "mode": args.mode, "episodes": results,
              "evaluation_setting": args._evaluation_setting,
              "task_package_sha256": task_package['sha256'] if task_package else None,
              "infrastructure_error": state.get("error"), "simulator_returncode": returncode,
              "official_results_path": "private/benchmark/per_episode.jsonl"}
    eligible = (args.mode == "codex" and complete and
                all(row["outcome"] in {"success", "failure"} for row in results))
    result["eligible_for_gpt6_score"] = eligible
    result["success_rate"] = (sum(r["outcome"] == "success" for r in results) / len(results)
                              if eligible else None)
    if extension:
        from .extension import require
        validation_path = args.output / 'private/replay_validation.json'
        validation = json.loads(validation_path.read_text()) if validation_path.is_file() else {}
        replay_valid = validation.get('state') == 'verified' and validation.get('validated_samples') == official_budget
        probe_valid = (args.extension_probe and replay_valid and
                       (args.output / 'episode_0000/private/probe_complete.json').is_file())
        extension_valid = complete and replay_valid and not args.extension_probe
        if extension_valid:
            require(len(rows) == 1 and rows[0]['episode_index'] == extension['baseline']['episode_index']
                    and official_budget * 3 <= rows[0]['steps'] <= official_budget * 30,
                    'Extension scoring clock mismatch')
            require(rows[0]['episode_seed'] == extension['official']['episode_seed'], 'Extension seed mismatch')
            require(rows[0]['latched_stage_completion_rate'] + 1e-12 >= extension['baseline']['lscr'],
                    'Continuation lost latched source progress')
        result.update(eligible_for_gpt6_score=False, success_rate=None,
                      eligible_for_extension_score=extension_valid,
                      replay_probe_verified=bool(probe_valid), baseline=extension['baseline'],
                      extension={'state': 'verified' if extension_valid else 'probe_verified' if probe_valid else 'unresolved',
                                 'setting': EXTENSION_SETTING, 'replay_validated': replay_valid,
                                 'success': results[0]['outcome'] == 'success' if extension_valid else None,
                                 'lscr': rows[0]['latched_stage_completion_rate'] if extension_valid else None,
                                 'termination': ('policy_declared_failure' if
                                     (args.output / 'episode_0000/private/policy_stop.json').is_file() else
                                     rows[0]['terminated_reason'] if rows else None),
                                 'source_result': extension['evidence']['source_result'],
                                 'replayed_policy_steps': official_budget,
                                 'additional_executed_physics_steps': max(0, rows[0]['steps'] - official_budget * 3) if rows else None,
                                 'cost_scope': 'New replay/setup and extension run only; original 1x tokens/time remain separate',
                                 'replay_validation': validation, 'exact_checkpoint_restore': False})
    telemetry = summarize_run(args.output, args.mode, started, started_at,
                              simulator_seconds, rows, error=state.get("error"))
    result["telemetry_path"] = "telemetry.json"
    result["tokens"] = telemetry["tokens"]
    if task_package:
        result['preparation_cost'] = {task_package['sha256']: {
            'task_id': args.task, 'tokens': info.get('preparation_tokens'),
            'inference_tool_wall_seconds': info.get('preparation_inference_tool_wall_seconds')}}
    result["timing"] = telemetry["timing"]
    result["trajectories"] = telemetry["trajectories"]
    if extension and (result['eligible_for_extension_score'] or result['replay_probe_verified']):
        from .extension_retention import prune_intermediate_images
        try:
            result['image_retention'] = prune_intermediate_images(args.output)
        except (OSError, ValueError, KeyError) as error:
            result['image_retention'] = {'state': 'needs_review', 'error': str(error),
                                         'rule': 'Preserve remaining files; no automatic pruning retry'}
    write_json(args.output / "result.json", result)
    integrity = {str(p.relative_to(args.output)): hash_file(p)
                 for p in sorted(args.output.rglob("*"))
                 if not p.is_symlink() and p.is_file() and p.name != "auth.json"}
    write_json(args.output / "integrity.json", integrity)
    print(json.dumps(result, indent=2))
    if extension:
        return 0 if result['eligible_for_extension_score'] or result['replay_probe_verified'] else 1
    return 0 if complete and all(r["outcome"] != "infrastructure_error" for r in results) else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=ROOT / "configs/default.json")
    parser.add_argument("--upstream", type=Path, required=True)
    parser.add_argument("--isaaclab", type=Path, required=True)
    parser.add_argument("--assets", type=Path, required=True)
    parser.add_argument("--python", type=Path, required=True, help="IsaacLab runtime Python")
    parser.add_argument("--task", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--anchor", type=Path)
    parser.add_argument("--auth", type=Path, default=Path.home() / ".codex/auth.json")
    parser.add_argument("--mode", choices=("codex", "hold", "replay"), default="codex")
    parser.add_argument("--replay", type=Path, help="Original run for strict action/observation replay")
    parser.add_argument('--extension-source', type=Path, help='Named-certified 1x timeout run to extend via validated action replay')
    parser.add_argument('--extension-audit', type=Path, help='Verified source named-results audit receipt')
    parser.add_argument('--storage-status', type=Path, help='Fresh healthy monitor status; mandatory for extensions')
    parser.add_argument('--extension-probe', action='store_true', help='Validate replay endpoint without any new Astra inference')
    parser.add_argument("--smoke-steps", type=int, default=4,
                        help="Short budget for hold-mode infrastructure checks only")
    args = parser.parse_args()
    for name in ("config", "upstream", "isaaclab", "assets", "python", "output", "anchor", "auth", "replay",
                 'extension_source', 'extension_audit', 'storage_status'):
        value = getattr(args, name)
        if value is not None:
            setattr(args, name, value.resolve())
    if args.smoke_steps < 1:
        parser.error("--smoke-steps must be positive")
    def interrupted(signum, _frame):
        raise KeyboardInterrupt(f"Received signal {signum}")
    signal.signal(signal.SIGTERM, interrupted)
    raise SystemExit(run(args))


if __name__ == "__main__":
    main()
