"""Frozen paired ICL versus calibrated zero-shot tests; no retries or learning."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

from .batch import STOP_FILE
from .cli import load_config, load_task, budget
from .core import write_json
from .knowledge import snapshot_packages, verify_package
from .suite import freeze_source
from .telemetry import utc_now


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def make_configs(base, package, sha, task, first, count):
    if (base['schema_version'] != 2 or base['model'] != 'gpt-6-astra'
            or base['reasoning_effort'] != 'max' or base['generalization_profile'] != 'inv_cov'
            or base['generalization_split'] != 'unseen' or first < 1 or count < 1):
        raise ValueError('Require calibrated Astra/max Full/unseen and positive episode schedule')
    zero = {**base, 'start_episode': first, 'num_episodes': count}
    icl = {**zero, 'schema_version': 3, 'evaluation_setting': 'task_icl_v3',
           'task_packages': {str(task): {'path': str(package), 'sha256': sha}}}
    return {'icl': icl, 'zero_shot': zero}


def episode_evidence(root, attempt):
    result = attempt.get('result')
    if not attempt.get('valid') or not result:
        return {'valid': False, 'status': 'running' if attempt.get('returncode') is None else 'invalid'}
    path = root / attempt['directory']
    rows = [json.loads(s) for s in (path / 'private/benchmark/per_episode.jsonl').read_text().splitlines() if s]
    if len(rows) != 1:
        raise ValueError('Expected exactly one official episode row')
    row = rows[0]
    observation = path / 'episode_0000/private/observations/000000'
    obs = json.loads((observation / 'observation.json').read_text())
    # Paths are packaging metadata, not sensor values; compare original PNG bytes separately.
    state = {k: v for k, v in obs.items() if k != 'cameras'}
    images = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(observation.glob('*.png'))}
    if len(images) != 4:
        raise ValueError('Paired baseline_4cam requires four archived initial images')
    manifest = json.loads((path / 'private/manifest.json').read_text())
    config = manifest['config']
    return {'valid': True, 'status': 'scored', 'episode_index': row['episode_index'],
            'episode_seed': row['episode_seed'], 'success': row['success'],
            'termination': row['terminated_reason'], 'physics_steps': row['steps'],
            'randomization_sha256': digest(row['scene_generalization_sample']),
            'initial_state_sha256': digest(state), 'initial_rgb_sha256': images,
            'common_config_sha256': digest({k: v for k, v in config.items()
                if k not in ('schema_version', 'evaluation_setting', 'task_packages')}),
            'asset_manifest_sha256': manifest['asset_manifest_sha256'],
            'scene_sha256': manifest['scene_sha256'],
            'official_policy_budget': manifest['official_policy_budget'],
            'executed_policy_budget': manifest['executed_policy_budget'],
            'setting': result.get('evaluation_setting', 'zero_shot'),
            'package_sha256': result.get('task_package_sha256'),
            'tokens': result['tokens'], 'timing': result['timing'],
            'result_path': str(path / 'result.json')}


def pair_rows(indices, conditions, package_sha):
    pairs = []
    for index in indices:
        a = conditions['icl'].get(index, {'valid': False, 'status': 'unattempted'})
        b = conditions['zero_shot'].get(index, {'valid': False, 'status': 'unattempted'})
        complete = a['valid'] and b['valid']
        matched = complete and all(a[k] == b[k] for k in (
            'episode_index', 'episode_seed', 'randomization_sha256', 'common_config_sha256',
            'asset_manifest_sha256', 'scene_sha256', 'official_policy_budget', 'executed_policy_budget'))
        matched = bool(matched and a['setting'] == 'task_icl_v3'
                       and a['package_sha256'] == package_sha
                       and b['setting'] == 'zero_shot' and b['package_sha256'] is None)
        pairs.append({'episode_index': index, 'icl': a, 'zero_shot': b,
                      'matched_protocol': matched,
                      'initial_state_exact_match': a['initial_state_sha256'] == b['initial_state_sha256'] if complete else None,
                      'initial_rgb_exact_match': a['initial_rgb_sha256'] == b['initial_rgb_sha256'] if complete else None})
    valid = bool(pairs) and all(p['matched_protocol'] for p in pairs)
    scores = {name: sum(p[name].get('success', False) for p in pairs) for name in conditions}
    return {'pairs': pairs, 'complete_valid_comparison': valid,
            'successes': scores if valid else None,
            'success_rates': {k: v / len(pairs) for k, v in scores.items()} if valid else None,
            'icl_minus_zero_shot_percentage_points': 100*(scores['icl']-scores['zero_shot'])/len(pairs) if valid else None,
            'paired_outcomes': {label: sum(p['icl']['success'] == x and p['zero_shot']['success'] == y for p in pairs)
                for label, x, y in [('both_success', True, True), ('icl_only', True, False),
                                    ('zero_shot_only', False, True), ('both_failure', False, False)]} if valid else None}


def report(output, indices, sha):
    conditions, batches = {'icl': {}, 'zero_shot': {}}, {}
    for name in conditions:
        path = output / name / 'result.json'
        if not path.is_file():
            continue
        batch = json.loads(path.read_text())
        batches[name] = {k: v for k, v in batch.items() if k != 'episodes'}
        for attempt in batch['episodes']:
            index = attempt['upstream_episode_index']
            if index not in indices or index in conditions[name]:
                raise ValueError('Unexpected/duplicate episode index')
            evidence = episode_evidence(output / name, attempt)
            if evidence['valid'] and evidence['episode_index'] != index:
                raise ValueError('Official index does not match planned index')
            conditions[name][index] = evidence
    result = {**pair_rows(indices, conditions, sha), 'updated_at': utc_now(), 'batches': batches,
              'planned_pairs': len(indices), 'planned_scored_episodes': len(indices)*2,
              'note': 'Same seeded conditions; initial RGB/state byte equality is audited, not assumed. '
                      'Later observations diverge with actions. No aggregate comparison if incomplete/invalid.'}
    write_json(output / 'comparison.json', result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('config', 'package', 'upstream', 'isaaclab', 'assets', 'python', 'output'):
        parser.add_argument('--'+name, type=Path, required=True)
    parser.add_argument('--package-sha256', required=True)
    parser.add_argument('--task', type=int, required=True)
    parser.add_argument('--start-episode', type=int, required=True)
    parser.add_argument('--pairs', type=int, default=6)
    parser.add_argument('--auth', type=Path, default=Path.home()/'.codex/auth.json')
    args = parser.parse_args()
    for key, value in vars(args).items():
        if isinstance(value, Path): setattr(args, key, value.resolve())
    configs = make_configs(load_config(args.config), args.package, args.package_sha256,
                           args.task, args.start_episode, args.pairs)
    if configs['zero_shot']['observation_profile'] != 'baseline_4cam':
        raise ValueError('This comparison requires baseline_4cam')
    verify_package(args.package, args.package_sha256, args.task, configs['icl'])
    _, task, robot = load_task(args.upstream, args.task)
    args.output.mkdir(parents=True, exist_ok=False)
    source = args.output / 'runner'
    hashes = freeze_source(source)
    configs['icl'] = snapshot_packages(configs['icl'], [args.task], args.output/'task_packages')
    for name, config in configs.items(): write_json(args.output/(name+'_config.json'), config)
    indices = list(range(args.start_episode, args.start_episode+args.pairs))
    common = [part for key in ('upstream','isaaclab','assets','python','auth')
              for part in ('--'+key, str(getattr(args,key)))]
    base = [sys.executable, '-u', '-m']
    plan = [('isolation', base+['gpt6_eval.doctor','--config',str(args.output/'zero_shot_config.json'),
                              '--output',str(args.output/'isolation')])]
    plan += [(name, base+['gpt6_eval.batch','--config',str(args.output/(name+'_config.json')),
              '--task',str(args.task),'--workers','1','--mode','codex',
              '--output',str(args.output/name), *common]) for name in ('icl','zero_shot')]
    started = time.monotonic()
    record = {'state':'starting','started_at':utc_now(),'task_id':args.task,'robot_key':robot,
              'official_policy_budget':budget(task['metrics']['expert_time_step']),
              'episode_indices':indices,'planned_pairs':args.pairs,'workers':1,
              'condition_order':['icl','zero_shot'],'planned_stages':plan,'stages':[],
              'source_hashes':hashes,'package_sha256':args.package_sha256,'argv':sys.argv}
    def save():
        record.update(updated_at=utc_now(),wall_seconds=time.monotonic()-started)
        write_json(args.output/'workflow.json',record)
    def interrupted(signum, frame): raise KeyboardInterrupt(f'Received signal {signum}')
    signal.signal(signal.SIGTERM,interrupted)
    env = {**os.environ,'PYTHONPATH':str(source/'src'),'PYTHONHASHSEED':'0'}
    env.pop('GPT6_EVAL_SMOKE_RELEASE',None)
    child = None
    save()
    try:
        for name, cmd in plan:
            if (args.output/STOP_FILE).exists():
                record['state']='stopped_by_request'
                break
            record['state']=name
            stage={'stage':name,'started_at':utc_now(),'returncode':None}
            record['stages'].append(stage)
            print(f'{utc_now()} Starting {name}',flush=True)
            with (args.output/(name+'.log')).open('wb') as stream:
                child=subprocess.Popen(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT)
                stage['pid']=child.pid
                save()
                while child.poll() is None:
                    try: child.wait(timeout=10)
                    except subprocess.TimeoutExpired: pass
                    if (args.output/STOP_FILE).exists() and name != 'isolation':
                        write_json(args.output/name/STOP_FILE,{'requested_at':utc_now()})
                    save()
                stage.update(returncode=child.returncode,ended_at=utc_now())
            child=None
            if stage['returncode'] != 0: raise RuntimeError(f'{name} exited {stage["returncode"]}; inspect stage log')
            row=json.loads((args.output/name/'result.json').read_text())
            if name == 'isolation':
                if row.get('tool_probe') != 'passed': raise RuntimeError('Isolation failed')
            elif row.get('state') != 'completed' or not row.get('eligible_for_gpt6_score'):
                if (args.output/STOP_FILE).exists():
                    record['state']='stopped_by_request'
                    break
                raise RuntimeError(f'{name} batch incomplete or invalid; no next condition')
            report(args.output,indices,args.package_sha256)
        else:
            final=report(args.output,indices,args.package_sha256)
            if not final['complete_valid_comparison']: raise RuntimeError('Paired protocol verification failed')
            record['state']='completed'
    except BaseException as exc:
        record.update(state='interrupted' if isinstance(exc,KeyboardInterrupt) else 'stopped_on_error',
                      error=f'{type(exc).__name__}: {exc}')
    finally:
        if child is not None and child.poll() is None:
            child.terminate()
            try: child.wait(timeout=55)
            except subprocess.TimeoutExpired: child.kill(); child.wait()
            record['stages'][-1].update(returncode=child.returncode,ended_at=utc_now())
        try: report(args.output,indices,args.package_sha256)
        except Exception as exc: record['report_error']=str(exc)
        save()
    return 0 if record['state']=='completed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
