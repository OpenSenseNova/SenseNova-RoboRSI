"""Bounded parallel evaluation; fresh simulator and policy per episode."""
import argparse
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

from .cli import ROOT, hash_file, load_config
from .core import write_json
from .telemetry import sum_usage, utc_now


STOP_FILE = "stop-after-current.json"

def worker_reservations(ram_mib_per_worker=10240):
    if 'GPT6_EVAL_WORKER_RESERVATION_MIB' in os.environ:
        from .resource_wait import worker_reservation_mib
        reservation = worker_reservation_mib()
        return reservation, reservation
    return 6144, ram_mib_per_worker


def stop_requested(output):
    return (output / STOP_FILE).exists()


def startup_options(args, wave_index):
    """Opt-in readiness staggering; never a model inference deadline."""
    timeout = getattr(args, 'startup_timeout_s', None)
    resident = getattr(args, 'hold_until_resident', False)
    if timeout is not None and (not math.isfinite(timeout) or timeout <= 0):
        raise ValueError('Startup timeout must be finite and positive')
    if resident and (args.mode != 'hold' or timeout is None):
        raise ValueError('Resident barrier requires hold mode and readiness staggering')
    options = {} if timeout is None else {'startup_timeout_s': timeout}
    if resident:
        options['smoke_release'] = args.output / 'startup' / f'wave_{wave_index:04d}.json'
    return options


def episode_configs(config):
    # Upstream start=0 and start=1 both begin at episode 1.
    first = max(1, config["start_episode"])
    return [{**config, "num_episodes": 1, "start_episode": first + i}
            for i in range(config["num_episodes"])]


def summarize(root, planned, mode, started, started_at, attempts, state, workers=1):
    outcomes, usage = [], []
    for attempt in attempts:
        path = root / attempt["directory"] / "result.json"
        # Do not race a still-running child's non-atomic result write.
        result = json.loads(path.read_text()) if attempt["returncode"] is not None and path.is_file() else None
        valid = (attempt["returncode"] == 0 and result is not None and result.get("complete")
                 and (mode == "hold" or result.get("eligible_for_gpt6_score")))
        outcomes.append({**attempt, "valid": bool(valid), "result": result})
        if result and "tokens" in result:
            usage.append(result["tokens"])
    eligible = mode == "codex" and len(outcomes) == planned and all(r["valid"] for r in outcomes)
    successes = sum(r["valid"] and r["result"].get("success_rate") == 1.0 for r in outcomes)
    scored = sum(r["valid"] for r in outcomes) if mode == "codex" else 0
    report = {"schema_version": 1, "state": state, "mode": mode, "workers": workers,
              "stop_requested": stop_requested(root),
              "planned_episodes": planned, "attempted_episodes": len(outcomes),
              "not_attempted_episodes": planned - len(outcomes),
              "scored_episodes": scored, "successes": successes,
              "failures": scored - successes,
              "infrastructure_errors": sum(r["returncode"] is not None and not r["valid"] for r in outcomes),
              "running_episodes": sum(r["returncode"] is None for r in outcomes),
              "eligible_for_gpt6_score": eligible,
              "success_rate": successes / planned if eligible else None,
              "started_at": started_at, "updated_at": utc_now(),
              "batch_wall_seconds": time.monotonic() - started,
              "tokens_for_available_episode_reports": sum_usage(usage), "episodes": outcomes}
    settings = {r['result'].get('evaluation_setting', 'zero_shot') for r in outcomes if r['result']}
    report['evaluation_setting'] = next(iter(settings)) if len(settings) == 1 else None
    if len(settings) > 1:
        report.update(eligible_for_gpt6_score=False, success_rate=None,
                      protocol_error='Mixed evaluation settings')
    # Deduplicate by frozen package hash: preparation is not charged per test.
    report['preparation_cost_by_package'] = {key: cost for row in outcomes if row['result']
        for key, cost in row['result'].get('preparation_cost', {}).items()}
    write_json(root / "result.json", report)
    return report


def resource_snapshot(workers, ram_mib_per_worker=10240):
    """Conservative admission check, not a claim of measured peak allocation."""
    raw = subprocess.check_output(["nvidia-smi", "--id=0", "--query-gpu=memory.free",
                                   "--format=csv,noheader,nounits"], text=True)
    gpu_free = int(raw.strip())
    memory = dict(line.split(":", 1) for line in Path("/proc/meminfo").read_text().splitlines())
    ram_free = int(memory["MemAvailable"].split()[0]) // 1024
    if ram_mib_per_worker not in (9216, 9472, 10240):
        raise ValueError('Unsupported RAM admission reservation')
    gpu_each, ram_each = worker_reservations(ram_mib_per_worker)
    required_gpu, required_ram = workers * gpu_each, workers * ram_each
    return {"checked_at": utc_now(), "gpu_free_mib": gpu_free, "ram_available_mib": ram_free,
            "required_gpu_mib": required_gpu, "required_ram_mib": required_ram,
            "admitted": gpu_free >= required_gpu and ram_free >= required_ram}


def run_wave(jobs, attempts, output, env, updated, *, startup_timeout_s=None, smoke_release=None):
    """Launch a fixed wave concurrently; cancel peers on infrastructure failure."""
    processes = []
    measure = smoke_release is not None and env.get('GPT6_EVAL_WORKER_RESERVATION_MIB') == '9216'
    memory_samples = []
    last_sample = 0
    def sample_memory():
        from .resource_wait import memory_sample
        row = memory_sample()
        row['ready_workers'] = sum(bool(a.get('startup_ready_at')) for a, _ in processes)
        memory_samples.append(row)
        write_json(smoke_release.with_suffix('.memory.json'), {
            'samples': memory_samples, 'peak_gpu_used_mib': max(r['gpu_used_mib'] for r in memory_samples),
            'min_gpu_free_mib': min(r['gpu_free_mib'] for r in memory_samples),
            'min_ram_available_mib': min(r['ram_available_mib'] for r in memory_samples)})
    try:
        def launch(attempt):
            attempts.append(attempt)
            attempt["started_at"] = utc_now()
            with (output / (attempt["directory"] + ".log")).open("wb") as log:
                try:
                    proc = subprocess.Popen(attempt["argv"], env=env, stdout=log, stderr=subprocess.STDOUT)
                except BaseException:
                    attempt["returncode"] = -1
                    raise
            processes.append((attempt, proc))
            attempt["pid"] = proc.pid
            updated()
        pending = list(jobs)
        if startup_timeout_s is None:
            while pending:
                launch(pending.pop(0))
        last_update = time.monotonic()
        while processes or pending:
            if measure and time.monotonic()-last_sample >= 2:
                sample_memory(); last_sample = time.monotonic()
            for attempt, proc in list(processes):
                code = proc.poll()
                if code is None:
                    continue
                attempt.update(returncode=code, ended_at=utc_now())
                processes.remove((attempt, proc))
                report = updated()
                outcome = next(r for r in report["episodes"] if r["index"] == attempt["index"])
                if not outcome["valid"]:
                    return False
            if startup_timeout_s is not None:
                for attempt, proc in processes:
                    launch_marker = output / attempt['directory'] / 'private/startup_started.json'
                    if 'simulator_started_monotonic' not in attempt and launch_marker.is_file():
                        evidence = json.loads(launch_marker.read_text())
                        tick = evidence.get('monotonic')
                        if (evidence.get('phase') != 'simulator_launch'
                                or evidence.get('worker_pid') != proc.pid
                                or not isinstance(tick, (float, int))
                                or not math.isfinite(tick) or tick < 0
                                or tick > time.monotonic()):
                            raise RuntimeError('Invalid simulator launch evidence')
                        attempt['simulator_started_monotonic'] = tick
                        attempt['simulator_started_at'] = evidence['started_at']
                        updated()
                    marker = output / attempt['directory'] / 'private/startup_ready.json'
                    # The worker can publish both files between these reads.
                    # Defer readiness until launch evidence is consumed next poll.
                    if (not attempt.get('startup_ready_at')
                            and 'simulator_started_monotonic' in attempt and marker.is_file()):
                        readiness = json.loads(marker.read_text())
                        if (readiness.get('phase') != 'first_validated_observation'
                                or 'simulator_started_monotonic' not in attempt):
                            raise RuntimeError('Invalid startup readiness evidence')
                        attempt['startup_ready_at'] = readiness['ready_at']
                        updated()
                    if (not attempt.get('startup_ready_at')
                            and 'simulator_started_monotonic' in attempt
                            and time.monotonic() - attempt['simulator_started_monotonic'] > startup_timeout_s):
                        attempt['startup_error'] = 'Simulator startup readiness timeout; no inference timeout'
                        raise RuntimeError(attempt['startup_error'])
                if pending and all(a.get('startup_ready_at') for a, _ in processes):
                    attempt = pending.pop(0)
                    launch(attempt)
                if (smoke_release is not None and not pending and
                        all(a.get('startup_ready_at') for a, _ in processes)):
                    if len(processes) != len(jobs) and not smoke_release.exists():
                        raise RuntimeError('Smoke worker exited before concurrent residency validation')
                    if not smoke_release.exists():
                        memory = None
                        if measure:
                            sample_memory()
                            memory = memory_samples[-1]
                            # Preserve at least OS headroom at the residency barrier.
                            if memory['ram_available_mib'] < 4096 or memory['gpu_free_mib'] < 2048:
                                raise RuntimeError('Smoke left insufficient memory headroom')
                        write_json(smoke_release, {'released_at': utc_now(),
                                   'resident_workers': len(processes),
                                   'pids': [p.pid for _, p in processes],
                                   **({'memory_at_residency':memory} if memory is not None else {})})
            if processes or pending:
                if time.monotonic() - last_update >= 10:
                    updated()
                    last_update = time.monotonic()
                time.sleep(0.2)
        return True
    finally:
        # Signal all siblings together, then share one shutdown grace period.
        for attempt, proc in processes:
            if proc.poll() is None:
                attempt["cancellation_reason"] = "batch interrupted or peer infrastructure failure"
                proc.terminate()
        deadline = time.monotonic() + 45
        for attempt, proc in processes:
            try:
                proc.wait(timeout=max(0, deadline - time.monotonic()))
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
            attempt.update(returncode=proc.returncode, ended_at=utc_now())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    for key in ("upstream", "isaaclab", "assets", "python", "output"):
        parser.add_argument("--" + key, type=Path, required=True)
    parser.add_argument("--task", type=int, required=True)
    parser.add_argument("--workers", type=int, choices=range(1, 7), default=1,
                        help="Maximum simultaneous episodes, in fixed ordered waves")
    parser.add_argument('--startup-timeout-s', type=float,
                        help='Stagger on first validated observation; timeout from simulator launch, excluding asset verification and inference')
    parser.add_argument('--hold-until-resident', action='store_true',
                        help='No-model smoke: hold first observations until every wave worker is resident')
    parser.add_argument("--mode", choices=["codex", "hold"], default="codex")
    parser.add_argument("--smoke-steps", type=int, default=4)
    parser.add_argument("--anchor", type=Path)
    parser.add_argument("--auth", type=Path, default=Path.home() / ".codex/auth.json")
    args = parser.parse_args()
    for key, value in vars(args).items():
        if isinstance(value, Path):
            setattr(args, key, value.resolve())
    config = load_config(args.config)
    startup_options(args, 0)  # Validate before creating any run output.
    configs = episode_configs(config)
    if args.output.exists():
        parser.error("Use a new batch output directory")
    args.output.mkdir(parents=True)
    from .knowledge import snapshot_packages
    config = snapshot_packages(config, [args.task], args.output / 'task_packages')
    configs = episode_configs(config)
    started, started_at = time.monotonic(), utc_now()
    gpu_each, ram_each = worker_reservations()
    write_json(args.output / "manifest.json", {"schema_version": 1, "workers": args.workers,
        "cooperative_stop": True,
        "scheduler": "fixed_ordered_waves", "admission_gpu_mib_per_worker": gpu_each,
        "admission_ram_mib_per_worker": ram_each,
        "fresh_simulator_per_episode": True, "config": config, "task_id": args.task,
        "startup_policy": 'first_validated_observation' if args.startup_timeout_s else 'simultaneous',
        "startup_timeout_s": args.startup_timeout_s, "hold_until_resident": args.hold_until_resident,
        "startup_clock_origin": "simulator_launch_after_asset_verification",
        "mode": args.mode, "episode_schedule": [c["start_episode"] for c in configs],
        "started_at": started_at, "runner_sha256": hash_file(Path(__file__)),
        "argv": sys.argv, "config_sha256": hash_file(args.config)})
    attempts, state = [], "running"
    def updated():
        return summarize(args.output, len(configs), args.mode, started, started_at,
                         attempts, state, args.workers)
    def interrupted(signum, _frame):
        raise KeyboardInterrupt(f"Received signal {signum}")
    signal.signal(signal.SIGTERM, interrupted)
    try:
        for first in range(0, len(configs), args.workers):
            if stop_requested(args.output):
                state = "stopped_by_request"
                break
            wave = configs[first:first + args.workers]
            resources = resource_snapshot(len(wave))
            write_json(args.output / "resources" / f"wave_{first // args.workers:04d}.json", resources)
            if not resources["admitted"]:
                state = "blocked_on_resources"
                break
            jobs = []
            for offset, child in enumerate(wave):
                index = first + offset
                cfg_path = args.output / "configs" / f"episode_{index:04d}.json"
                write_json(cfg_path, child)
                directory = f"episode_{index:04d}"
                cmd = [sys.executable, "-m", "gpt6_eval.cli", "--config", str(cfg_path),
                       "--task", str(args.task), "--mode", args.mode,
                       "--smoke-steps", str(args.smoke_steps), "--output", str(args.output / directory)]
                for key in ("upstream", "isaaclab", "assets", "python", "auth", "anchor"):
                    value = getattr(args, key)
                    if value is not None:
                        cmd.extend(["--" + key, str(value)])
                jobs.append({"index": index, "worker_index": offset,
                             "upstream_episode_index": child["start_episode"],
                             "directory": directory, "returncode": None, "argv": cmd})
            env = {**os.environ, "PYTHONPATH": str(ROOT / "src")}
            env.pop('GPT6_EVAL_SMOKE_RELEASE', None)
            options = startup_options(args, first // args.workers)
            if 'smoke_release' in options:
                env['GPT6_EVAL_SMOKE_RELEASE'] = str(options['smoke_release'])
            if stop_requested(args.output):
                state = "stopped_by_request"
                break
            print(f"Starting episodes {first + 1}–{first + len(wave)} with {len(wave)} workers", flush=True)
            if not run_wave(jobs, attempts, args.output, env, updated, **options):
                state = "stopped_on_infrastructure_error"
                break
        else:
            state = "completed"
    except BaseException:
        state = "interrupted"
        raise
    finally:
        report = updated()
        print(json.dumps({key: value for key, value in report.items() if key != "episodes"}, indent=2), flush=True)
    # Incomplete original schedules still have no aggregate benchmark score.
    raise SystemExit(0 if state in ("completed", "stopped_by_request") else 1)


if __name__ == "__main__":
    main()
