"""Frozen, fail-closed single-task ICL preparation and testing; no retries."""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

from .batch import resource_snapshot, startup_options
from .cli import load_config, load_task, budget
from .core import write_json
from .suite import freeze_source
from .telemetry import utc_now


def stages(args):
    output = args.output
    base = [sys.executable, '-u', '-m']
    config = str(output / 'base_config.json')
    common = []
    for key in ('upstream', 'isaaclab', 'assets', 'python', 'auth'):
        common += ['--' + key, str(getattr(args, key))]
    workers = getattr(args, 'workers', 1)
    startup = getattr(args, 'startup_timeout_s', None)
    startup_args = [] if startup is None else ['--startup-timeout-s', str(startup)]
    smoke_module = 'gpt6_eval.cli' if workers == 1 else 'gpt6_eval.batch'
    smoke_options = [] if workers == 1 else ['--workers', str(workers), *startup_args,
                                            '--hold-until-resident']
    return [
        ('isolation', base + ['gpt6_eval.doctor', '--config', config,
                             '--output', str(output / 'isolation')]),
        ('smoke', base + [smoke_module, '--config', str(output / 'smoke_config.json'),
                         '--task', str(args.task), '--mode', 'hold', '--smoke-steps', '4',
                         '--output', str(output / 'smoke'), *smoke_options, *common]),
        ('training', base + ['gpt6_eval.icl', 'prepare', '--config', config,
                            '--task', str(args.task), '--dataset', str(args.dataset),
                            '--assets', str(args.assets), '--upstream', str(args.upstream),
                            '--output', str(output / 'training')]),
        ('preparation', base + ['gpt6_eval.icl', 'explore', '--config', config,
                               '--training', str(output / 'training'), '--auth', str(args.auth),
                               '--output', str(output / 'preparation')]),
        ('test_config', base + ['gpt6_eval.icl', 'config', '--config', config,
                               '--preparation', str(output / 'preparation'),
                               '--output', str(output / 'test_config.json')]),
        ('evaluation', base + ['gpt6_eval.batch', '--config', str(output / 'test_config.json'),
                              '--task', str(args.task), '--workers', str(workers), '--mode', 'codex',
                              '--output', str(output / 'evaluation'), *startup_args, *common]),
    ]


def smoke_config(config, workers, first):
    if workers not in (1, 2, 3) or first < 1:
        raise ValueError('Invalid worker count or smoke index')
    test_ids = set(range(config['start_episode'], config['start_episode'] + config['num_episodes']))
    smoke_ids = set(range(first, first + workers))
    if test_ids & smoke_ids:
        raise ValueError('Test indices overlap unscored smoke indices')
    return {**config, 'start_episode': first, 'num_episodes': workers}


def validate_stage(output, name):
    paths = {'isolation': 'isolation/result.json', 'smoke': 'smoke/result.json',
             'training': 'training/manifest.json', 'preparation': 'preparation/preparation.json',
             'evaluation': 'evaluation/result.json'}
    if name == 'test_config':
        if load_config(output / 'test_config.json')['schema_version'] != 3:
            raise RuntimeError('Test config is not ICL')
        return
    row = json.loads((output / paths[name]).read_text())
    valid = {
        'isolation': lambda: row.get('tool_probe') == 'passed',
        'smoke': lambda: ((row.get('complete') and not row.get('infrastructure_error'))
                         if 'planned_episodes' not in row else
                         row.get('state') == 'completed' and row.get('mode') == 'hold'
                         and len(row.get('episodes', [])) == row['planned_episodes']
                         and all(e.get('valid') for e in row['episodes'])
                         and not row.get('infrastructure_errors')),
        'training': lambda: row.get('state') == 'complete' and len(row.get('demonstrations', [])) == 100,
        'preparation': lambda: row.get('state') == 'ready' and bool(row.get('package')),
        'evaluation': lambda: row.get('state') == 'completed' and row.get('eligible_for_gpt6_score')
                              and row.get('evaluation_setting') == 'task_icl_v3',
    }[name]()
    if not valid:
        raise RuntimeError(f'{name} did not pass its completion gate')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('config', 'upstream', 'isaaclab', 'assets', 'python', 'dataset', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--task', type=int, required=True)
    parser.add_argument('--workers', type=int, choices=[1, 2, 3], default=1)
    parser.add_argument('--startup-timeout-s', type=float,
                        help='Required for multiple workers; simulator startup only, never inference')
    parser.add_argument('--smoke-start-episode', type=int, default=1002)
    parser.add_argument('--auth', type=Path, default=Path.home()/'.codex/auth.json')
    args = parser.parse_args()
    for key, value in vars(args).items():
        if isinstance(value, Path): setattr(args, key, value.resolve())
    config = load_config(args.config)
    if (config['schema_version'] != 2 or config['reasoning_effort'] != 'max'
            or config['generalization_profile'] != 'inv_cov'
            or config['generalization_split'] != 'unseen'):
        raise ValueError('Use a calibrated Astra/max Full/unseen base config')
    # Reuse batch validation; multiple workers must use the measured readiness strategy.
    args.mode, args.hold_until_resident = 'hold', args.workers > 1
    startup_options(args, 0)
    smoke = smoke_config(config, args.workers, args.smoke_start_episode)
    if args.output.exists(): raise ValueError('Use a new workflow directory')
    _, task, robot = load_task(args.upstream, args.task)
    args.output.mkdir(parents=True)
    source = args.output / 'runner'
    hashes = freeze_source(source)
    write_json(args.output / 'base_config.json', config)
    smoke_index = args.smoke_start_episode
    write_json(args.output / 'smoke_config.json', smoke)
    plan = stages(args)
    started = time.monotonic()
    record = {'state': 'starting', 'started_at': utc_now(), 'task_id': args.task,
              'robot_key': robot, 'official_policy_budget': budget(task['metrics']['expert_time_step']),
              'planned_scored_episodes': config['num_episodes'], 'episode_index': config['start_episode'],
              'episode_indices': list(range(config['start_episode'], config['start_episode'] + config['num_episodes'])),
              'workers': args.workers, 'startup_timeout_s': args.startup_timeout_s,
              'smoke_episode_indices': list(range(smoke_index, smoke_index + args.workers)),
              'smoke_episode_index': smoke_index, 'config': config, 'source_hashes': hashes,
              'argv': sys.argv, 'planned_stages': plan, 'stages': []}
    def save():
        record.update(updated_at=utc_now(), wall_seconds=time.monotonic()-started)
        write_json(args.output / 'workflow.json', record)
    def interrupted(signum, frame): raise KeyboardInterrupt(f'Received signal {signum}')
    signal.signal(signal.SIGTERM, interrupted)
    env = {**os.environ, 'PYTHONPATH': str(source / 'src'), 'PYTHONHASHSEED': '0'}
    env.pop('GPT6_EVAL_SMOKE_RELEASE', None)
    child = None
    save()
    try:
        for name, cmd in plan:
            if (args.output / 'stop-after-current.json').exists():
                record['state'] = 'stopped_by_request'
                break
            if name in ('smoke', 'evaluation'):
                resources = resource_snapshot(args.workers)
                write_json(args.output / f'{name}_resources.json', resources)
                if not resources['admitted']: raise RuntimeError('Insufficient resources; no worker started')
            record['state'] = name
            stage = {'stage': name, 'started_at': utc_now(), 'returncode': None}
            record['stages'].append(stage)
            log = args.output / f'{name}.log'
            print(f'{utc_now()} Starting {name}; log: {log}', flush=True)
            with log.open('wb') as stream:
                child = subprocess.Popen(cmd, env=env, stdout=stream, stderr=subprocess.STDOUT)
                stage['pid'] = child.pid
                save()
                while child.poll() is None:
                    try: child.wait(timeout=10)
                    except subprocess.TimeoutExpired: pass
                    save()
                stage.update(returncode=child.returncode, ended_at=utc_now())
            child = None
            if stage['returncode'] != 0:
                raise RuntimeError(f'{name} exited {stage["returncode"]}; inspect {log}')
            validate_stage(args.output, name)
        else:
            record['state'] = 'completed'
            record['result'] = json.loads((args.output / 'evaluation/result.json').read_text())
    except BaseException as exc:
        record.update(state='interrupted' if isinstance(exc, KeyboardInterrupt) else 'stopped_on_error',
                      error=f'{type(exc).__name__}: {exc}')
    finally:
        if child is not None and child.poll() is None:
            child.terminate()
            try: child.wait(timeout=55)
            except subprocess.TimeoutExpired: child.kill(); child.wait()
            record['stages'][-1].update(returncode=child.returncode, ended_at=utc_now())
        save()
    return 0 if record['state'] == 'completed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
