"""Check nested isolation and optionally authenticate the exact evaluation model."""
import argparse
from pathlib import Path
import shutil
import subprocess

from .cli import ROOT, load_config, hash_file
from .core import verify_model_rollouts, write_json
from . import isolation


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--config", type=Path, default=ROOT / "configs/default.json")
    parser.add_argument("--auth", type=Path, default=Path.home() / ".codex/auth.json")
    parser.add_argument("--model-smoke", action="store_true")
    args = parser.parse_args()
    root = args.output.resolve()
    root.mkdir(parents=True, exist_ok=False)
    workspace, home, interface = (root / x for x in ("workspace", "codex-home", "interface"))
    for path in (workspace, home, interface):
        path.mkdir()
    (workspace / "input").mkdir()
    (root / "action-transport").mkdir()
    write_json(workspace / "input/observation.json", {"decision": 0})
    write_json(workspace / "input/episode_done.json", {"episode_done": True})
    shutil.copyfile(Path(__file__).with_name("tool_probe.py"), interface / "tool_probe.py")
    shutil.copyfile(Path(__file__).with_name("step.py"), interface / "step.py")
    binary = Path(shutil.which("codex"))
    config = load_config(args.config)
    version = subprocess.check_output([str(binary), "--version"], text=True).strip()
    if version != config["codex_version"]:
        raise RuntimeError(f"CLI version mismatch: {version}")
    result = {"codex_version": version, "codex_binary_sha256": hash_file(binary.resolve())}
    result["mount_probe"] = isolation.probe(workspace, home, interface, binary, root)
    cmd = isolation.mounts(workspace, home, interface, binary) + [
        "--", "/opt/codex", "sandbox", "-c", 'sandbox_mode="workspace-write"',
        "-c", 'sandbox_workspace_write.network_access=false', "--",
        "/usr/bin/python3", "/interface/tool_probe.py"]
    checked = subprocess.run(cmd, capture_output=True, text=True)
    (root / "sandbox.stdout").write_text(checked.stdout)
    (root / "sandbox.stderr").write_text(checked.stderr)
    if checked.returncode or "tool isolation passed" not in checked.stdout:
        raise RuntimeError("Nested Codex tool isolation failed; inspect sandbox.stderr")
    result["tool_probe"] = "passed"
    result["action_transport_probe"] = "passed"
    if args.model_smoke:
        isolation.prepare_auth(home, args.auth)
        prompt = (ROOT / "prompts/doctor.md").read_text()
        (root / "prompt.md").write_text(prompt)
        cmd = isolation.command(workspace, home, interface, binary, config)
        write_json(root / "invocation.json", {"argv": cmd})
        try:
            with (root / "events.jsonl").open("wb") as out, (root / "stderr.log").open("wb") as err:
                proc = subprocess.run(cmd, input=prompt.encode(), stdout=out, stderr=err)
            if proc.returncode:
                raise RuntimeError("Model smoke failed; inspect stderr.log")
            result["model_evidence"] = verify_model_rollouts(home)
            if not (workspace / "probe.txt").is_file():
                raise RuntimeError("Model did not exercise the tool sandbox")
        finally:
            (home / "auth.json").unlink(missing_ok=True)
    write_json(root / "result.json", result)
    print(result)


if __name__ == "__main__":
    main()
