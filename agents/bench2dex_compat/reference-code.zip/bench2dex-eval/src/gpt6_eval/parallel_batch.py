"""Global six-worker episode waves across tasks; no retries or replacement samples."""
import argparse
import json
import os
from pathlib import Path
import signal
import sys
import time

from .batch import resource_snapshot, run_wave, stop_requested, summarize
from .cli import ROOT, load_config
from .core import write_json
from .suite import validate_plan, validate_resource_evidence
from .telemetry import utc_now


def schedule(plan, config, mode):
    check_config = config if mode == 'codex' else {
        **config, 'start_episode': plan['episode_indices'][0],
        'num_episodes': plan['episodes_per_task']}
    validate_plan(plan, check_config)
    if plan['workers'] != 6:
        raise ValueError('This scheduler requires the explicit six-worker plan')
    if mode == 'hold' and (config['start_episode'] != plan['smoke_episode_index']
                           or config['num_episodes'] != 1):
        raise ValueError('Smoke config must use the separate unscored smoke index')
    indices = plan['episode_indices'] if mode == 'codex' else [plan['smoke_episode_index']]
    jobs = []
    for task_id in plan['task_ids']:
        for local_index, episode_index in enumerate(indices):
            index = len(jobs)
            jobs.append({'index': index, 'task_id': task_id, 'task_episode_index': local_index,
                         'worker_index': index % plan['workers'],
                         'wave_index': index // plan['workers'],
                         'upstream_episode_index': episode_index,
                         'directory': f'task_{task_id:02d}/episode_{local_index:04d}',
                         'returncode': None})
    return jobs


def reports(root, plan, mode, started, started_at, attempts, state):
    per_task = plan['episodes_per_task'] if mode == 'codex' else 1
    overall = summarize(root, len(plan['task_ids']) * per_task, mode,
                        started, started_at, attempts, state, plan['workers'])
    for task_id in plan['task_ids']:
        selected = [{**a, 'directory': Path(a['directory']).name}
                    for a in attempts if a['task_id'] == task_id]
        task_state = state
        if not selected:
            task_state = 'not_started'
        elif all(a['returncode'] is not None for a in selected) and len(selected) == per_task:
            valid = all(a['valid'] for a in overall['episodes'] if a['task_id'] == task_id)
            task_state = 'completed' if valid else 'stopped_on_infrastructure_error'
        summarize(root / f'task_{task_id:02d}', per_task, mode, started, started_at,
                  selected, task_state, plan['workers'])
    return overall


def run(args, plan, config):
    jobs = schedule(plan, config, args.mode)
    validation_path = getattr(args, 'resource_validation', None)
    evidence = json.loads(validation_path.read_text()) if validation_path else None
    validate_resource_evidence(plan, evidence)
    if args.output.exists():
        raise ValueError('Use a new parallel batch output directory')
    args.output.mkdir(parents=True)
    from .knowledge import snapshot_packages
    config = snapshot_packages(config, plan['task_ids'], args.output / 'task_packages')
    started, started_at = time.monotonic(), utc_now()
    attempts, state = [], 'running'
    write_json(args.output / 'manifest.json', {
        'schema_version': 1, 'cooperative_stop': True, 'workers': plan['workers'],
        'scheduler': 'fixed_ordered_episode_waves', 'config': config, 'plan': plan,
        'mode': args.mode, 'episode_schedule': jobs, 'started_at': started_at,
        'fresh_simulator_per_episode': True, 'admission_gpu_mib_per_worker': 6144,
        'admission_ram_mib_per_worker': plan.get('ram_mib_per_worker', 10240),
        'resource_validation': evidence})

    def updated():
        return reports(args.output, plan, args.mode, started, started_at, attempts, state)

    def interrupted(signum, frame):
        raise KeyboardInterrupt(f'Received signal {signum}')

    signal.signal(signal.SIGTERM, interrupted)
    env = {**os.environ, 'PYTHONPATH': str(ROOT / 'src'), 'PYTHONHASHSEED': '0'}
    updated()
    try:
        for first in range(0, len(jobs), plan['workers']):
            if stop_requested(args.output):
                state = 'stopped_by_request'
                break
            wave = jobs[first:first + plan['workers']]
            resources = resource_snapshot(len(wave), plan.get('ram_mib_per_worker', 10240))
            write_json(args.output / 'resources' / f'wave_{first // plan["workers"]:04d}.json', resources)
            if not resources['admitted']:
                state = 'blocked_on_resources'
                break
            for job in wave:
                cfg_path = args.output / 'configs' / f'episode_{job["index"]:04d}.json'
                write_json(cfg_path, {**config, 'num_episodes': 1,
                                     'start_episode': job['upstream_episode_index']})
                (args.output / job['directory']).parent.mkdir(parents=True, exist_ok=True)
                cmd = [sys.executable, '-u', '-m', 'gpt6_eval.cli', '--config', str(cfg_path),
                       '--task', str(job['task_id']), '--mode', args.mode,
                       '--smoke-steps', str(plan['smoke_steps']),
                       '--output', str(args.output / job['directory'])]
                for key in ('upstream', 'isaaclab', 'assets', 'python', 'auth'):
                    cmd.extend(['--' + key, str(getattr(args, key))])
                job['argv'] = cmd
            if stop_requested(args.output):
                state = 'stopped_by_request'
                break
            print(f'{utc_now()} Starting wave {first // plan["workers"] + 1}: '
                  f'{[(j["task_id"], j["upstream_episode_index"]) for j in wave]}', flush=True)
            options = {}
            wave_env = dict(env)
            wave_env.pop('GPT6_EVAL_SMOKE_RELEASE', None)
            if plan.get('startup_policy') == 'first_validated_observation':
                options['startup_timeout_s'] = plan['startup_timeout_s']
                if args.mode == 'hold':
                    release = args.output / 'startup' / f'wave_{first // plan["workers"]:04d}.json'
                    wave_env['GPT6_EVAL_SMOKE_RELEASE'] = str(release)
                    options['smoke_release'] = release
            if not run_wave(wave, attempts, args.output, wave_env, updated, **options):
                state = 'stopped_on_infrastructure_error'
                break
        else:
            state = 'completed'
    except BaseException:
        state = 'interrupted'
        raise
    finally:
        updated()
    return state


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('plan', 'config', 'upstream', 'isaaclab', 'assets', 'python', 'output', 'auth'):
        parser.add_argument('--' + key, type=Path, required=True)
    parser.add_argument('--mode', choices=['codex', 'hold'], default='codex')
    parser.add_argument('--resource-validation', type=Path)
    args = parser.parse_args()
    for key, value in vars(args).items():
        if isinstance(value, Path):
            setattr(args, key, value.resolve())
    state = run(args, json.loads(args.plan.read_text()), load_config(args.config))
    raise SystemExit(0 if state in ('completed', 'stopped_by_request') else 1)


if __name__ == '__main__':
    main()
