# Rendering and assets

Use the pinned testing asset download helper in [setup](SETUP.md). It includes
task object/robot bundles, iTHOR scenes, transitive iTHOR object bundles and the
complete randomization pool. Upstream relative USD references still require the
`dex2bench_dataset` sibling layout. A directory's presence is not proof that the
asset download is complete: verify the recorded inventory and checksums.

The simulator adapter checks unresolved composed USD dependencies before policy
access and archives effective renderer settings. Missing assets are infrastructure
errors. Run a no-model `hold` smoke on the target embodiment before evaluating.
The source-only release audit does not certify successful rendering on every GPU
or task. Earlier exploratory runs with incomplete background assets cannot be
relabeled as validated results by installing this package.
