# Trusted on-demand demonstration reader

`prepare --access-mode trusted_reader_v1` indexes all 100 selected pinned
seen/collection files. It preserves camera selection, pre-homing frames,
active-joint remapping, NaN fallback, action timing and nominal robot metadata.
Only permitted arrays and demo metadata are exported up front.

A trusted service outside the policy namespace decodes permitted frames on
request. Requests accept demo IDs, approved cameras and 1–64 integer frame
indices, with unlimited sequential requests. The exact sanitized PNG bytes are
cached read-only. Raw HDF5 files, server code and private provenance remain
outside the policy namespace. Paths and arbitrary dataset keys are not inputs.

Source SHA256 is checked at indexing and before/after preparation. Delivered
outputs are verified before freezing; requests, images and integrity evidence
are archived privately. Source/output changes and unsafe links fail admission.
The reader retains a 50 GiB free-space reserve. Test episodes receive only the
frozen task package, not the reader cache or preparation scratch state.

The access interface is recorded in package provenance. Having the same
available information does not guarantee the same stochastic exploration.
See [setup](SETUP.md#task-icl-v3) and [protocol](IN_CONTEXT_LEARNING.md).
