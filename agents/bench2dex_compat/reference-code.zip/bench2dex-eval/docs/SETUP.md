# Installation and use

Commands below run from the extracted source folder. Choose your own paths and
new output directories. No desktop session is needed. Download/setup commands
use the network; `explore`, `--mode codex` and `doctor --model-smoke` make model
requests and consume your account's inference allowance.

## Pinned dependencies

| Component | Evaluation revision/version |
| --- | --- |
| Bench2Dex | `f96a8b2b4eb475483af66e9e03916b35bc43f1be` |
| Isaac Lab | `37ddf626871758333d6ed89cf64ad702aef127d0` (v2.3.2) |
| Isaac Sim | `5.1.0`, Python 3.11 |
| PyTorch / torchvision | `2.7.0` / `0.22.0`, CUDA 12.8 wheels |
| Codex CLI | `0.154.0`, standalone binary with sibling `codex-code-mode-host` |
| Model / reasoning | `gpt-6-astra` / `max` |
| Testing assets | `Bench2Dex/Assets`, `bf65215f844d1fca30750e4cc70d7266650abf0a` |
| Demonstrations | `Bench2Dex/teleopdata`, `b195787c65046083e6a43776b67bdf1389dfa3eb` |

Python package pins for this public installation are in `pyproject.toml`. These
are installation pins, not a recovered full lockfile of every historical run.
Use Linux with NVIDIA drivers suitable for Isaac Sim 5.1.0, working user
namespaces and bubblewrap. Resource admission is checked again at runtime;
plan at least 10 GiB available host RAM and 6 GiB free VRAM for a basic single
worker (campaign schedulers use larger reservations). These are admission minima,
not measured peak requirements. Assets, demos and frame archives need substantial
disk space. The full demo corpus is about 406 GB before derived data.

## Checkouts and simulator

Create sibling checkouts and an asset directory:

```text
work/
  gpt6_eval_public/
  Bench2Dex/
  IsaacLab/
  dex2bench_dataset/
  teleopdata/
```

```bash
# Run in your chosen work directory, outside this source folder.
git clone https://github.com/Bench2Dex/Bench2Dex.git Bench2Dex
git -C Bench2Dex checkout f96a8b2b4eb475483af66e9e03916b35bc43f1be
git clone https://github.com/isaac-sim/IsaacLab.git IsaacLab
git -C IsaacLab checkout 37ddf626871758333d6ed89cf64ad702aef127d0
```

Both checkouts must remain clean. Follow the pinned Bench2Dex README for the
simulator installation. Its core commands are:

```bash
conda create -n bench2dex-sim python=3.11 -y
conda activate bench2dex-sim
python -m pip install 'isaacsim[all,extscache]==5.1.0' --extra-index-url https://pypi.nvidia.com
python -m pip install torch==2.7.0 torchvision==0.22.0 --index-url https://download.pytorch.org/whl/cu128
python -m pip install -e /path/to/IsaacLab/source/isaaclab
# From this public evaluation folder:
python -m pip install --upgrade 'pip>=23' 'setuptools>=68'
python -m pip install -e '.[data,test]'
python -m pip install Flask==3.1.2
```

Review and accept NVIDIA's license through its normal installation flow. Set
`OMNI_KIT_ACCEPT_EULA=YES` only after accepting it. The harness does not accept
that agreement for you. Do not copy an existing virtual environment to another
machine; reinstall it. The evaluator may run in a separate Python 3.10–3.12
environment with this package installed; the simulator environment also needs
the package dependencies listed above.

The isolated policy runs **`/usr/bin/python3`** with only system libraries. On
Ubuntu, install `bubblewrap`, `python3-numpy`, `python3-scipy`, `python3-pil` and
`python3-yaml` and `python3-opencv` using your normal system package manager. A host venv alone does
not install libraries into the policy sandbox. Library versions are recorded per
run; exact comparison needs the archived policy versions too.

Install the pinned standalone Codex distribution through your normal trusted
installation source. Put its `codex` on PATH and keep `codex-code-mode-host`
beside the resolved executable. Verify `codex --version` prints
`codex-cli 0.154.0`; authenticate locally using that CLI. Public availability of
this exact distribution and model is an external prerequisite. There is no
model fallback. `--auth` can select your local auth file; never put it in this
source tree or mount your entire Codex home into a policy.

## Runtime paths and data

From the public source folder:

```bash
export BENCH2DEX_ROOT="$(cd ../Bench2Dex && pwd)"
export ISAACLAB_ROOT="$(cd ../IsaacLab && pwd)"
export BENCH2DEX_ASSETS="$BENCH2DEX_ROOT/../dex2bench_dataset"
export ISAACLAB_PYTHON="/path/to/bench2dex-sim/bin/python"
export BENCH2DEX_DEMOS="/path/to/teleopdata"
export PYTHONPATH="$PWD/src${PYTHONPATH:+:$PYTHONPATH}"

# All catalog tasks plus the shared randomization assets; hashes are verified.
bash scripts/download_all_assets.sh
# Only needed to prepare NEW ICL packages; skip this for released frozen packages.
"$ISAACLAB_PYTHON" scripts/download_demonstrations.py --output "$BENCH2DEX_DEMOS" --workers 2
```

Pinned upstream scene files expect `dex2bench_dataset` beside `Bench2Dex`.
If data lives elsewhere, create that sibling symlink to the installed assets
without replacing an existing directory. `--assets` alone cannot relocate
upstream USD references. Keep demos outside policy workspaces; export only the
sanitized fields using the commands below. No policy checkpoints are required.

```bash
python -m gpt6_eval.preflight --task 26 --require-model
python -m gpt6_eval.doctor --output runs/isolation-check
# Small model-access test, separate from any benchmark score:
python -m gpt6_eval.doctor --output runs/model-check --model-smoke
bash scripts/evaluate.sh --task 26 --config configs/default.json \
  --mode hold --smoke-steps 4 --output runs/task26-smoke
```

Preflight checks configuration, pins, package availability and asset layout. It
does not establish full scene dependency resolution, namespace isolation, GPU
compatibility or model access. The doctor and simulator checks cover those
separate stages. Missing assets/model access are infrastructure failures.

## Task ICL v3

For ready-made packages, use [frozen package installation](FROZEN_PACKAGES.md).
The remaining commands in this section are only for new preparation.

`configs/icl_base.json` fixes Full/unseen reset settings, seeds 100000000 and
200000000, index 5 and one test episode. It is a schema-2 **preparation base**;
it becomes schema 3 only after a verified preparation package exists. To choose
a different fixed index/count, copy the config before preparation/evaluation and
record that plan. Set `--task` to any of the 26 catalog IDs. Example for task 26:

```bash
"$ISAACLAB_PYTHON" -m gpt6_eval.icl prepare \
  --config configs/icl_base.json --task 26 \
  --upstream "$BENCH2DEX_ROOT" --assets "$BENCH2DEX_ASSETS" \
  --dataset "$BENCH2DEX_DEMOS" --access-mode trusted_reader_v1 \
  --output runs/task26-training

# Hosted inference and live web research; no fixed time/token cap.
python -m gpt6_eval.icl explore --config configs/icl_base.json \
  --training runs/task26-training --output runs/task26-preparation

# Verify/freeze reference and emit the schema-3 test configuration.
python -m gpt6_eval.icl config --config configs/icl_base.json \
  --preparation runs/task26-preparation --output runs/task26-icl.json

bash scripts/evaluate.sh --task 26 --config runs/task26-icl.json \
  --mode codex --output runs/task26-evaluation
```

Preparation requires all 100 pinned replay-generalization files for that task.
The default strict source validation remains enabled. Task 51 has a separately
implemented historical provenance exception, opt-in with
`prepare --task51-legacy-provenance`; preserve and disclose its exception record.
Task 62 has a narrowly validated historical scene-name alias. Neither mechanism
permits unverified datasets. See the source tests for the exact admission rules.

For multiple isolated simulator processes, use `python -m gpt6_eval.batch`
with the same config/path/task arguments, plus `--workers 1` (increase only after
resource checks). Set `num_episodes` in the base config before freezing the plan.
Repeat preparation separately for other tasks, with separate output directories.
A generated config can combine task packages by repeating `--preparation`.
Historical campaign continuation scripts require their original archived plans;
they are not the entry point for a new public run.

## Zero-shot, anchors, replay and outputs

For legacy zero-shot evaluation use `configs/default.json` with `--mode codex`.
For calibrated zero-shot use a schema-2 config. Keep all three conditions separate.
`inv_cov` uses seeded randomization without reset anchors. Other reset profiles
require private reset metadata extracted with `gpt6_eval.extract_anchors` and
passed via `--anchor`; they are separate experiments.

Use `--mode replay --replay /path/to/original/run` with the same task, config,
assets and software and a new output. It makes no model request and fails on
observation/action/scoring divergence; GPU physics can diverge despite seeds.

A completed valid result records the score in `result.json`, with original
metrics in `private/benchmark/` and trajectories under `private/trajectories/`.
`telemetry.json` records tokens and overlapping wall-time categories. Missing or
partial accounting stays explicit. An incomplete run has no aggregate score;
never count missing episodes as failures or retry a valid scored failure.

## Historical continuation tools

The archived campaign/10x continuation tools require their original plans, source
runs and storage monitor. They are not needed for new single-task evaluation.
For those tools, set `BENCH2DEX_EVAL_DISK` to the monitored writable ext4 mount;
the original storage-health and reserve gates still apply. No workstation mount
location is assumed.
