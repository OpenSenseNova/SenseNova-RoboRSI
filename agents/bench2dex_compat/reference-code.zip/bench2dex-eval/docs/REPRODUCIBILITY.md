# Reproducibility and release scope

This is a portable copy of the evaluation source, not a release of historical
experiment results. Scoring, model identity checks, prompts, sensor boundaries,
reset seeds and original schedules are preserved. `RELEASE_CONTENTS.json`
records included paths, original file hashes and the changed/added files.
`SHA256SUMS` verifies the final public source tree.

The copy changes workstation paths, source snapshot metadata, package-resource
installation and optional test discovery. It adds a portable launcher, preflight,
release checker and generic ICL base config. The original source remains separate.
All policy/preparation prompt bytes are unchanged from the supplied harness.

## What is included

All original runtime Python modules, all original regression tests, reusable
launch/download/export/audit scripts, all prompt templates, evaluation/suite
configs and public protocol documentation. Historical maintenance/continuation
scripts are retained as source for audit tests. They require archived campaign
plans and qualified original outputs, which this source release does not supply;
use the documented per-task CLI/ICL/batch path for a new experiment. Extension
campaign modules additionally require an external storage controller and probe.
The separate 10x replay-extension condition is not the default official budget.

Generated asset selection manifests are excluded; download helpers regenerate
them with current operator paths while pinning the same upstream data revisions.
The package excludes runs, raw demos/assets, frozen historical task packages,
transcripts, account metadata, host repair records, credentials, databases,
previews, generated reports, environments and Git history. Optional media export
helpers require the `media` extra and FFmpeg/ffprobe on PATH; they do not affect evaluation scoring.

## Reproduce a new experiment

Install the pinned revisions, verify assets, declare the task IDs, index/count,
reset profile/split, seeds and sensor setting before testing. For ICL, prepare
one package per task, freeze it and reuse its exact hash across the cohort.
Preserve the emitted run config, source/prompt hashes, dependency/GPU versions,
asset checksums, task-package hashes, model/session metadata, exact RGB/joint
observations, action arrays and official metrics. Model reasoning has no default
wall-time or token cap; simulation pauses during inference.

A source release plus new preparation reproduces the procedure. It does not
reproduce the bytes of a historical task package. Reproducing a reported cohort
would additionally require its original immutable plan, frozen runner hash,
package hashes and separately reviewed artifacts. None is implied present here.
Original historical sample counts and caveats must not be reconstructed from
example configs and called an exact published-results reproduction.

Fresh hosted model calls, live preparation web search and GPU contact physics
can vary. The service-managed model alias is not a dated model snapshot. Exact
input/action archival is supported; strict action replay detects divergence.
The dependency pins in this release establish an installable environment, not
an exact lockfile of the historical policy or simulator environment. Compare
archived per-run versions for that purpose.

## Validation boundary

`RELEASE_AUDIT.md` distinguishes checks actually performed from external runtime
requirements. Pure/synthetic tests establish code behavior, not complete GPU
simulation on every embodiment. The model smoke and simulator hold example
must pass on the recipient's machine before a scored run. No hosted inference
is required to run the regression suite.
