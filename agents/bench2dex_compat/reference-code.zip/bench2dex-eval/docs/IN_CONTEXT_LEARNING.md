# Task preparation + isolated testing (v3)

Latest approved setting: **task_icl_v3**, not zero-shot. No GPT weight updates.
Both preparation and testing use exactly **gpt-6-astra / max**, through pinned
Codex CLI 0.154.0. No fallback, secondary model or automatic delegation.

1. **Export training data.** For each task, take all 100 released
   `replay-generalization` files (including variants; not necessarily 100
   independent demonstrations) at pinned revision
   `b195787c65046083e6a43776b67bdf1389dfa3eb`. Check hashes and require
   `seen` / `collection` metadata. Reconstruct only the chosen camera RGBs,
   measured active joints, demonstrated active-joint targets and timing.
   Remove post-task homing; NaN action rows use recorded qpos, as in ACT.
   Robot/action joint ordering is explicitly remapped by name. No object state,
   labels, tactile/depth, scores, seed values or raw HDF5 metadata enter the
   public export. Nominal robot geometry, limits and FK/IK are provided.
   Scene and robot identity must match. Recorded language is retained separately
   and differences from the current task instruction are flagged (observed in
   task 03); demonstrations are not assumed to solve the current instruction.
2. **Prepare freely.** One fresh isolated Astra session per task can analyze
   all exported demonstrations, write scripts, inspect images, and use live
   hosted web search. Shell networking stays disabled. There is no token/time
   cap. This implementation provides dataset exploration, not live simulator
   practice. Preparation receives no prior test results or simulator internals.
   Recorded-demo camera calibration is not currently exported; live test
   calibration remains available as in v2.
3. **Freeze when ready.** Astra creates `package/TASK.md`, `SOURCES.md`, and
   any needed skills, scripts, arrays or reference images. It writes
   `ready.json` and ends its turn. A successful process exit, exact-model
   evidence and readiness declaration are required. Only regular independent
   files are accepted; links and special files fail closed. Host hashes and
   freezes the package. Scratch files/conversation are not test input.
4. **Test independently.** Every test gets a fresh simulator, Codex session,
   writable workspace and separate read-only `input/task_knowledge/` copy of
   the same task package. No live web, preparation scratch files, raw corpus,
   other test episodes or private scores. Episode-local adaptations are allowed
   but never update the frozen task package. Suite/batch/individual runners
   verify and snapshot packages before use; package hashes appear in results.

Test sensors, exact camera calibration and robot tools remain calibrated-v2.
Actions remain absolute active-joint chunks at 20 Hz, with paused simulation
during reasoning. Full/unseen reset distribution, official success metrics
and budgets remain unchanged. Exhaustion is failure; infrastructure errors
invalidate completion. Legacy schema-1/2 configs, prompts and results remain
zero-shot and must not be pooled with v3.

## On-demand access amendment — authorized 2026-09-28

For new preparations, `prepare --access-mode trusted_reader_v1` retains all100
selected files and performs the same source/split/robot/instruction, homing,
joint-order, action-fallback and timing checks. It exports only small permitted
arrays and metadata. A trusted host service outside Astra's namespace decodes
requested permitted frames to exactly the same sanitized PNG bytes. Source
content is fully hashed at indexing and before/after exploration, and delivered
outputs and requests are archived. No arbitrary paths/HDF5 fields are accepted.
The raw corpus, private metadata and host server code are never policy-mounted.
The policy client and a dedicated preparation prompt describe the new interface.
The model can request every frame, without a total request quota. Numeric arrays
are available immediately. Images are cached read-only; package freezing requires
source/output integrity and normal readiness/model verification. Test-time
packages, observations, isolation and scoring remain unchanged. Existing packages
are reused without regeneration. Disclose access-interface version as a scaffold
change; identical available information does not guarantee identical exploration.
See [trusted reader](TRUSTED_READER.md) for the access contract.

## Usage and reproducibility

See [setup and ICL commands](SETUP.md) and [reproducibility](REPRODUCIBILITY.md).
Fresh preparation uses a hosted model and live search, so regenerating a package
does not guarantee the same bytes. Preserve and reuse its content hash for all
episodes in a declared cohort. Preparation costs are recorded separately.
