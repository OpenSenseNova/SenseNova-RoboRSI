# Codex / GPT-6 Astra Bench2Dex protocol, version 1

The latest user-approved protocol is [task in-context learning v3](IN_CONTEXT_LEARNING.md):
seen-demonstration/web preparation, frozen per-task knowledge and isolated tests.
The zero-shot rules below describe legacy schema-1/2 experiments only; v3
explicitly permits preparation-derived task scripts/data but retains the
test-time sensor boundary, model identity, action semantics and scoring rules.

The original version-1 input contract is preserved below. The user-approved
**calibrated deployment v2** condition adds robot-only FK/IK and calibrated
camera information; its exact scope and comparison caveats are specified in
[CALIBRATED_DEPLOYMENT.md](CALIBRATED_DEPLOYMENT.md). It requires a schema-2
config and is never enabled implicitly for legacy runs. Common model-isolation,
action execution, scoring and archival rules below apply to both conditions.

This experiment measures task-zero-shot GPT-6 Astra with Codex reasoning tools.
The central fairness condition is comparable sensory information. Static robot
knowledge and reasoning compute are declared differences from trained policies.
It is not a comparison of equal training data, latency, or inference FLOPs.

## Policy information contract

| Information | Policy access | Provenance / reason |
|---|---|---|
| Stereo pair and two wrist RGB images | Default, ordered stereo L/R then wrist L/R | Baseline `4cam` sensor set |
| Overhead plus two wrist images | Explicit `baseline_3cam` variant only | GR00T `3cam` sensor set |
| RGB pixels | uint8 RGB, 640x480, lossless PNG | No synthetic annotations, depth, or segmentation |
| Active measured joint positions | Yes, float32 serialization | Baseline proprioception |
| Task description | Exact task YAML `description` only | Language task specification; no metric hints |
| Robot name, active joint names/order/limits, action units and timing | Yes | Deployment-accessible interface description |
| Static kinematic joint tree, axes, origins, mimic rules and limits | Yes | Whitelist extracted from robot URDF; no visual/collision asset paths |
| Observation history and own actions/scripts | Current episode only | Previously available sensors and self-generated computation |
| Elapsed/remaining policy steps | Yes | Controller-owned clock, not latent scene state |
| Object poses, velocities, identities, contact forces, articulation state | No | Private simulator state |
| Depth, point clouds, tactile maps, segmentation | No in versions 1 and 2 | Not in the selected RGB baseline interface |
| Success, reward, stage completion, thresholds, goal coordinates | No during episode | Private scoring |
| Scene YAML, evaluator source, simulator logs, randomization samples/seeds | No | Privileged evaluator context |
| Demonstrations, checkpoints, prior episodes | No | Task-zero-shot protocol |

Static robot kinematics use robot-base coordinates, not simulator-world object
coordinates. Camera calibration may be reasonable deployment information, but
version 1 does not export randomized runtime camera extrinsics. Any future
calibration addition needs a declared, versioned protocol and comparable
availability to baselines.

ACT and DP may encode task identity in task-specific trained weights rather
than a runtime language input. GPT-6 receives the task description to specify
its objective. Report this distinction, as well as the static embodiment card.
Matching sensor views does not imply identical learned image preprocessing:
baseline encoders and the hosted vision model can resize/crop internally.

## Evidence in the pinned upstream repository

Commit: `f96a8b2b4eb475483af66e9e03916b35bc43f1be`.

- `run_policy.py::_build_remote_policy_obs`: RGB camera aliases,
  `joint_action.vector`, and `language`; pointcloud is None. The transport
  includes five distinct rendered cameras, but adapters select a subset.
- `policy/ACT/deploy_policy.yml::camera_names`: two wrists and stereo pair.
- `policy/DP/deploy_policy.yml::camera_names`: two wrists and stereo pair.
- `policy/GR00T_n15/deploy_policy.yml::camera_mode`: `4cam` default;
  `deploy_policy.py::_CAMERA_MODES` also exposes `3cam`.
- `policy/pi05/deploy_policy.py::encode_obs`: stereo pair and two wrists,
  plus active joint state.
- `robots/active_dof_utils.py`: active joint ordering must be remapped to the
  Isaac runtime joint order. The trusted wrapper uses the actual remapped order.
- `script/eval_budget.sh`: 1.5 times expert physics steps, rounded up to the
  three-step policy stride. `run_policy.py` itself defaults to 400 policy steps;
  the custom launcher supplies the calculated task-specific budget explicitly.

Before comparing to published numbers, inspect the exact evaluated checkpoint
configuration, generalization profile/split, seeds, action horizon, early-stop
setting and modalities. A tactile baseline is a different sensor condition;
do not label an RGB-only comparison as identical inputs to a tactile model.

## Actions and reasoning

The policy runs as one fresh `codex exec` session per episode with explicit
`gpt-6-astra`, pinned CLI, `max` reasoning, no inherited config/rules or previous
session memory, and no additional model calls. The policy prompt is maintained
in `prompts/policy.md`. `ultra` is excluded because the local model catalog
describes automatic delegation; this protocol isolates one model agent.

The policy can use the shell, image viewer, Python and installed general-purpose
libraries to reason, analyze images, build numerical controllers, and write
scripts. It can compute FK/IK from the static robot card. No task-specific
grasping oracle, hidden object localization, or externally trained controller
is supplied. General-purpose robot helpers can be added later if they only
consume the same public inputs and are frozen and disclosed before scoring.

An action is `[T, active_dof]` absolute joint targets. Each row is held for
three physics steps at 60 Hz. No automatic interpolation or action clipping
is added; upstream actuator and mimic handling remain authoritative. GPT-6
can choose T from 1 through the remaining policy-step budget and generate its
own interpolation. Every intermediate 20 Hz observation is saved and becomes
available at the next decision. Actions are open-loop within a chunk, just as
with upstream chunked remote policies. Chunk size and decision count are part
of the reported scaffold and may differ from a fixed-horizon trained policy.

There is no default token, reasoning-time, or number-of-tool-call cap. Simulation
pauses while Codex reasons. `decision_timeout_s=null` means no watchdog; a finite
watchdog, if configured, is recorded and produces an infrastructure failure,
not a simulation timeout. Latency must be reported separately; this setup does
not demonstrate real-time robot control.

## Isolation and model identity

The evaluator, source code, scene files, assets, anchor metadata, and score logs
remain in the trusted host process. Codex runs in a bubblewrap mount/PID namespace
with only the episode workspace, a read-only observation/input subdirectory,
an interface script, a clean Codex home, its
runtime binaries, and system libraries. The Codex tool sandbox allows writes
only in the workspace and blocks tool network access. Codex itself retains the
network connection needed for inference. Plugins, browser/search, external
models, subagents, hooks, memories, and automatic model approval review are off.

`doctor` tests that host data is invisible, tool networking is denied, and the
policy cannot modify the directory holding CLI-authored model evidence. Every
action requires a saved CLI `turn_context` whose model is exactly `gpt-6-astra`.
Model-written text claiming an identity does not qualify. There is no fallback.
This verifies the client-selected model; undisclosed service-side internals
cannot be independently proved from CLI logs.

An auth.json copy is used only for the isolated CLI and removed after exit.
Do not publish raw Codex-home databases without checking for credentials and
account identifiers. Model transcripts and workspace scripts remain auditable.

## Scoring

Use the original evaluator with active DOF, 60 Hz physics/metric updates, and
reach-and-stop (`--early-stop`). Policy budget is
`ceil(1.5 * expert_time_step / 3)`, with three physics steps per policy step.
Stable success at any permitted physics step, including the final one, counts.
Reaching the budget without stable success is failure. Partial stage progress
does not change this outcome. Do not allow the model to stop or reset the
simulator, declare success, inspect scores, or choose seeds.

The private upstream output retains success, stage, safety, and efficiency
metrics. The public policy receives only a generic episode-ended notification
after termination. Invalid model actions or ending before completion are
policy failures. Missing assets, identity mismatch, transport/simulator failures,
and watchdog expiry are infrastructure failures. Planned episode counts and
missing results must remain visible; an incomplete run is not a valid score.

## Reproducibility and artifacts

Terminal operation is specified in `TERMINAL.md`. An operator's graceful stop
finishes the current admitted wave without changing its inputs, reasoning or
simulation budget, then marks later episodes unattempted. Preserve the original
planned denominator: completed individual outcomes remain usable, but an
incomplete batch has no aggregate benchmark score. Stop requests and monitoring
stay outside the policy mount. A separately configured one-episode experiment
is distinct from stopping an eight-episode experiment after observing one trial.

The task-26 pilot can use two independent episode workers, with fixed waves
[1,2], [3,4], [5,6], [7,8]. Worker count changes wall-clock concurrency, not
inputs, per-episode seeds, model identity, or simulation budgets. Record worker
assignment, starts/exits, admission-resource checks and actual process overlap.
Concurrent GPU execution can change floating-point nondeterminism and resource
contention; do not claim identical physics solely because the seeds match.
Each policy still has its own isolated workspace and no cross-episode memory.

Record config, upstream and IsaacLab commits, source/prompt snapshots and hashes,
asset content hashes, anchor hashes, Python/packages/GPU information, simulator
argv, actual robot ordering, exact lossless observations, raw RGB hashes, action
arrays/timing, Codex events, session/model metadata, and official result files.
Wall-clock duration is provenance only and is not inserted into policy inputs.

```
run/
  result.json                  # aggregate validity and episode outcomes
  telemetry.json               # run/episode token totals and wall/simulation timing
  private/
    manifest.json              # effective config, versions, hashes, argv
    assets.json                # testing-asset content hashes
    source/                    # exact evaluation source/config/prompt snapshot
    task.yaml                  # private scene definition
    simulator.log
    runtime-packages.txt
    gpu.txt
    benchmark/                 # original Bench2Dex metric outputs
    trajectories/              # private 20 Hz HDF5 state + RGB; success/failure/partial
  episode_0000/
    policy/                    # only this episode is mounted into Codex
      input/                   # read-only to the policy
        robot.json
        observation.json
        observations/000000/   # RGB PNGs and state JSON
      ...                      # model scripts and notes
    private/
      observations/            # immutable-by-policy original input archive
      actions/                 # accepted action arrays and identity evidence
      decisions/               # exact decision-boundary inputs
      telemetry.json           # episode usage, completeness and timing
      timing/                  # every attempted decision, including errors
      prompt.md
      invocation.json
      codex.events.jsonl
      codex.stderr.log
      codex-home/sessions/     # full CLI transcript and model metadata
```

All policy-controlled scripts and notes persist within that episode. The next
episode gets a fresh workspace and session. Generalization anchor metadata is
private and does not constitute a model-visible demonstration. The extraction
command copies only `meta/scene_generalization_sample`, never actions or images.
Full official anchor coverage requires the appropriate complete reset-metadata
set; one setup anchor is only an infrastructure smoke test.

Reproducibility has three levels: exact archival of delivered inputs/actions;
reconstruction of the same seeded software configuration; and strict action
replay with observation/hash and scoring comparisons. Fresh model outputs and
GPU contact physics may vary. Codex can also add service-controlled instructions,
image preprocessing, and compaction behavior. Pin the CLI and record full exposed
transcripts; do not promise identical hidden service behavior. If a dated model
snapshot becomes available to Codex, pin it explicitly in a new protocol version.

## Validation scope

See [release audit](../RELEASE_AUDIT.md) for checks on this source package.
Simulation and hosted inference require the external runtime described in [setup](SETUP.md).
