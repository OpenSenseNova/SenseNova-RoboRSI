# Terminal operation

[Setup](SETUP.md) defines environment variables and portable launch commands.
Use a terminal multiplexer for long foreground runs. Each run needs a new output
directory; do not edit code, prompts or configurations during an active run.

```bash
python -m gpt6_eval.monitor status /path/to/run
python -m gpt6_eval.monitor watch /path/to/run --interval 5
python -m gpt6_eval.monitor stop-after-current /path/to/batch
```

Monitoring is read-only. Ctrl+C in `watch` stops the observer. A policy step may
remain unchanged while the model reasons; this is not proof of a stalled run.
`stop-after-current` applies to cooperative batch/workflow runners: it lets the
already admitted wave finish and prevents later waves. It is not a graceful-stop
interface for an individual `gpt6_eval.cli` process. An incomplete planned cohort
has no aggregate score; individual valid results remain visible. Interrupting a
foreground evaluation can invalidate the active attempt and preserves available
partial evidence.
