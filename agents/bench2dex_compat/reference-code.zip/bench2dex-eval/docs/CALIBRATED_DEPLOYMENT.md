# Calibrated deployment: protocol v2

Report label: **GPT-6 Astra + Codex, calibrated deployment, task-zero-shot**.
Config flag: `schema_version: 2`, `deployment_profile: calibrated_deployment_v2`.
This supplements the common execution/scoring rules in `PROTOCOL.md`. Version-1
configs and the completed first pilot keep their original uncalibrated inputs.
Never pool the two conditions without identifying the protocol difference.

## Scope and rationale

We give the policy ordinary setup information for an already-installed robot:
its nominal kinematic model, joint interface, and calibrated cameras. We do not
require it to reconstruct that setup during each manipulation task. This is
zero-shot with respect to task demonstrations and task-specific controllers,
not zero prior knowledge of the robot or its camera mounting.

Standard hand-eye calibration supports both fixed and wrist-mounted cameras:
[MoveIt calibration documentation](https://moveit.picknik.ai/main/doc/examples/hand_eye_calibration/hand_eye_calibration_tutorial.html).
Robot calibration is deployment work, not guaranteed factory information; we
assume it has been done. It is distinct from engineering a task-solving policy.

## Included: ordinary robot setup, not a custom manipulation stack

| Supplied item | Contents / purpose |
|---|---|
| `input/robot.json` | Runtime active-joint names/order and position limits, explicit joint units, nominal kinematic tree, and control timing |
| `input/robot.urdf` | Standalone **kinematic-only** URDF: links, joints, axes, origins, nominal limits and mimic relations; no external asset references |
| `/interface/kinematics_tool.py` | Generic FK and bounded numerical pose IK; read-only, no simulator access or task IDs |
| Observation `camera_calibration` | Intrinsics, projection/distortion model, and camera-optical-to-robot-base transform for each permitted camera |

The URDF describes both arms and fingers where present, including existing palm
and fingertip frames. It is reconstructed from allowlisted URDF fields, not a
mount of the simulator robot directory. It excludes meshes, inertias, force /
friction parameters, simulator plugins, object assets and scene metadata.
Nominal URDF effort/velocity limits remain labeled as nominal; they are not a
promise of effective simulator speed or torque. Runtime position limits and
active joint ordering in the JSON card are authoritative for the action interface.

FK supports fixed, revolute, continuous and prismatic joints, name mapping and
mimic relations. Unactuated non-mimic joints use upstream's zero command as a
**nominal assumption**, not an additional measured joint sensor; loaded joints
can deviate. This limitation matters especially for fingertips. Unsupported
trees or missing values fail explicitly instead of silently guessing poses.

IK uses SciPy bounded `least_squares` (`trf`, two-point numerical Jacobian,
unit position/rotation residual weights, `x_scale=1`, tolerances 1e-10, default
maximum 200 function evaluations). The initial guess is the supplied joint
vector, projected into selected joint bounds; there are no random restarts.
It returns a candidate plus position/orientation errors and solver status.
Success means <=1 mm position error and <=0.01 rad orientation error in the
nominal model, not successful physical motion. The caller chooses the link,
target pose and joints; the tool never chooses a grasp or executes a movement.
Library versions are archived in `policy-packages.txt`; no reproducibility
claim extends across arbitrary library versions or machines.
The isolated policy uses `/usr/bin/python3`, not the simulator virtual environment.
Install NumPy and SciPy for that interpreter as well as the host/simulator Python.
On the development workstation the policy uses SciPy 1.8.0 and the simulator
uses 1.15.3. The helper is tested against both; exact replication should retain
the recorded policy packages rather than assume the broad installation range
is an exact dependency lock.

Not included: custom grasp primitives, learned hand synergies, fingertip contact
optimization, object-specific templates, collision-aware planning, automatic
visual servoing, force-control tuning, trajectories learned from demonstrations,
or new dynamics/controller gains. The policy may implement its own reasoning
using permitted inputs. It chooses interpolation and submits ordinary joint
targets through the same step interface. There are no free simulator steps.

## Camera contract and coordinate conventions

Only the selected sensor profile is exported. The default remains stereo left,
stereo right, wrist left, wrist right; no overhead observation or calibration.
Each 20 Hz observation archives the matching calibration alongside the RGBs.

For a homogeneous point in camera optical coordinates:

```text
p_robot_base = T_robot_base_from_camera_optical @ p_camera_optical
```

The robot base is the root link of the supplied URDF, **not simulator world**.
Optical coordinates are x right, y down, z forward; translation is in metres.
The trusted exporter composes the inverse world-from-robot-base pose with
world-from-camera and the explicit Isaac-camera-to-optical axis conversion.
The world pose, global origin, table height and reset/randomization metadata
are never serialized into policy observations.

`image_size_wh` is [640,480]. `intrinsic_matrix` is calibrated for those exact
pixels. `camera_model=pinhole` currently has an empty distortion vector;
`camera_model=fisheye` uses OpenCV equidistant projection with [k1,k2,k3,k4].
Fisheye K comes from the calibrated fisheye matrix, not the pinhole matrix.
No distortion correction, crop, resizing or extra view is silently applied.
If the policy changes image coordinates, it must adjust its geometry accordingly.
Missing/invalid calibration stops the run rather than dropping back to a guessed
camera model. Calibration does not supply object depth, segmentation or poses.

Fixed cameras have a fixed base-relative transform within a fixed-base episode;
wrist camera poses change as the robot moves. We supply the current base-relative
pose, equivalent in purpose to a deployment camera transform tree using a
calibrated mounting transform and encoder-based FK. This implementation uses
the rendered camera pose relative to the runtime robot root, **not an independently
estimated hand-eye calibration**. RGB and transforms refer to the same capture.

## Explicit idealization and baseline-comparison limits

The calibration source is recorded as
`exact_simulator_calibration_after_reset_randomization`. We do not pretend these
are noisy measurements or that a real robot obtains perfect calibration for free.
After every randomized reset, this condition assumes the changed camera setup
is calibrated. It therefore does **not** measure robustness to unknown camera
displacement. Full (`inv_cov`, unseen) randomization remains enabled, but its
camera-placement challenge is partly reduced by supplying calibration.

This is additional explicit setup information compared with the checked released
RGB-plus-joints baseline adapters. It is a declared deployment-oriented comparison,
not identical model inputs or equal compute/training data. Exact object poses,
depth, contact data, task goals, rewards, evaluator source and demonstrations
remain excluded. No other learned model is invoked. Official physics, success
predicates, stable-success dwell, action cadence and task budget remain unchanged.

## Reproducibility and launching

Use `configs/task26_calibrated_single.json` explicitly; legacy launcher defaults
are unchanged to avoid silently changing old commands. The example schedules
upstream episode **2**, leaving the inspected first episode as an exploratory
pilot. It is a new run, not resumption of the stopped eight-episode batch.

```bash
bash scripts/run_task26.sh --workers 1 \
  --config configs/task26_calibrated_single.json \
  --output /path/to/new/task26-calibrated-run
```

Environment activation, runtime paths, monitoring and stopping are described
in `TERMINAL.md`. The workflow module is specifically for the legacy eight-episode
schedule; use the batch launcher for this one-episode config. No scored run is
automatically launched by implementing this protocol.

The effective config, original prompt plus calibrated supplement, helper source,
geometry-only URDF, JSON robot card and per-observation calibration are archived.
Model identity remains exact `gpt-6-astra`, CLI 0.154.0, max reasoning, with no
fallback or secondary model. Freeze code/config before a scored batch, and keep
setup checks free of task demonstrations or success-guided tuning.

Validation must distinguish synthetic geometry tests, real-robot-asset FK/IK
checks, and a simulator camera/interface smoke from full manipulation performance.
Do not claim that kinematic convergence guarantees collision-free paths, good
grasps, correct contact forces, or successful task execution.
