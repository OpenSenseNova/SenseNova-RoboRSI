# Using the released frozen ICL packages

The matching Hugging Face dataset has `catalog.json` and one ZIP per task under
`packages/`. The code's `configs/icl_packages.json` pins every ZIP and outer
manifest. Download just the tasks you need, or all 26. Install commands run from
the evaluation repository after `pip install -e '.[data]'`.

```bash
# Network download: set this to the dataset ID shown on its Hugging Face page.
export HF_ICL_REPO="YOUR_ORG/YOUR_DATASET"
python -m gpt6_eval.packages install --repo-id "$HF_ICL_REPO" \
  --task 26 --output data/icl

# Offline alternative: retain the snapshot's packages/task_26.zip layout.
python -m gpt6_eval.packages install --source /path/to/downloaded-dataset \
  --task 26 --output data/icl-offline

python -m gpt6_eval.packages verify data/icl
```

Installation checks the local trusted catalog, ZIP size/hash, extraction paths,
manifest hash, every payload hash and the exact evaluation contract. A mismatching
release fails; it never silently downloads a substitute. Hugging Face's revision
can be fixed with `--revision COMMIT`, but the local catalog pins content even
when downloading from `main`. The optional `--catalog` is for another trusted
release; do not replace it merely to bypass a checksum failure.

`data/icl/config.json` is a ready-to-use schema-3 config. Paths refer to neighboring
`task_XX` directories, so moving the whole installed directory preserves them.
Always point evaluation and preflight at this config. `configs/default.json`
selects the separate legacy zero-shot condition. Reusing a nonempty installation
output is refused; `verify` checks an existing installation.

The default schedule is one Full/unseen episode at index 5, with fixed seeds
100000000 and 200000000. It is a small reproducible starting point, not the full
historical multi-cohort campaign. Record your intended episode indices/counts
before running. Packages are task-specific and may be reused across a declared
cohort; they must remain unchanged across its episodes.

## What is preserved and removed

All 3,610 model-visible payload files are byte-identical to the frozen originals:
notes, helper code, arrays, reference images and internal integrity manifests.
The outer manifests omit internal preparation-session filenames. They retain
exact model/contract metadata, event hashes and preparation costs, and record the
original outer-manifest SHA-256. Public outer-manifest hashes therefore differ;
model inputs do not. Raw session logs are not distributed, so public event hashes
are provenance references rather than independently replayable identity evidence.

The package notes' scratch paths and isolated policy paths describe the fixed
sandbox interface. Historical preparation references are provenance, not host
paths that need to exist. Package selfchecks run with packages mounted read-only,
without demonstrations, network access or the preparation workspace. Keep the
original payload hashes when reporting this release.

Task 51 retains its disclosed unknown legacy seed/collection provenance exception.
Task 62 retains its historical scene-name alias. These are recorded in the outer
manifests and are not silently normalized. Reusing preparation bytes does not
make hosted model outputs or GPU simulation bit-identical.

## Dependencies and storage

You still need the pinned testing assets, simulator, NVIDIA GPU, system Python
libraries and model access described in [setup](SETUP.md). Frozen use needs no raw
demonstration corpus. Helpers use NumPy, SciPy, Pillow and OpenCV in the isolated
`/usr/bin/python3`; installing only a host virtual environment is insufficient.

Allow about 3 GB for a download cache plus an installed full package set, in
addition to simulator/assets and run outputs. The dataset catalog gives exact
per-task compressed and expanded sizes. Run outputs belong on a Linux filesystem
with working permissions and Unix sockets, outside the publication directories.

## Recreate the standard-budget 78-episode schedule

`configs/historical_78_schedule.json` records the checked schedule: all 26 tasks,
each at indices 5, 6 and 7, with the same base config and frozen payloads. The
source result digests and configs were checked against all 78 original runs.
To define this schedule after installing all packages:

```bash
python - <<'PYCONFIG'
import json
from pathlib import Path
folder = Path('data/icl')
config = json.loads((folder / 'config.json').read_text())
config.update(start_episode=5, num_episodes=3)
with (folder / 'config-three-episodes.json').open('x') as out:
    json.dump(config, out, indent=2)
PYCONFIG

# Set runtime paths and EVAL_RUNS as in the README before launching.
# This makes hosted model calls for 78 fresh episodes, with no inference cap.
for task in 3 6 7 8 9 12 21 22 24 26 27 32 34 42 43 44 51 60 61 62 64 67 73 76 79 80; do
  bash scripts/evaluate_batch.sh --task "$task" \
    --config data/icl/config-three-episodes.json --workers 1 --mode codex \
    --output "$EVAL_RUNS/historical78-task-$task" || break
done
```

The batch launcher gives each index a fresh simulator and policy session. This
recreates the declared standard-budget schedule with new inference, not original
outcomes. The separate historical 10x continuation experiment replayed original
actions and resumed original sessions. Its private source runs/transcripts are
excluded from this release, so a fresh longer-budget run is not an exact
reproduction of those paired continuations.
