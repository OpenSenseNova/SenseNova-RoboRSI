"""Bundle the source layout needed by immutable run snapshots in wheel installs."""
from pathlib import Path
import shutil
from setuptools import setup
from setuptools.command.build_py import build_py


class BuildWithSnapshot(build_py):
    def run(self):
        super().run()
        root = Path(__file__).parent
        output = Path(self.build_lib) / 'gpt6_eval' / '_release'
        for folder in ('src', 'prompts', 'configs', 'docs', 'scripts'):
            for source in sorted((root / folder).rglob('*')):
                if source.is_file() and source.suffix in {'.py', '.md', '.json', '.sh'}:
                    target = output / source.relative_to(root)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(source, target)
        for name in ('README.md', 'AGENTS.md', 'RELEASE_CONTENTS.json',
                     'RELEASE_AUDIT.md', 'LICENSE_NOTICE.md', 'pyproject.toml', 'setup.py', 'MANIFEST.in'):
            shutil.copyfile(root / name, output / name)


setup(cmdclass={'build_py': BuildWithSnapshot})
