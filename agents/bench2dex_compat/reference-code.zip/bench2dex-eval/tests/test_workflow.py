import argparse
import json
from pathlib import Path
import signal
import sys
import tempfile
import unittest
from unittest.mock import patch

from gpt6_eval.cli import ROOT
from gpt6_eval import workflow


class WorkflowTests(unittest.TestCase):
    def test_graceful_stop_does_not_start_later_stage(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            inventory = root / "inventory.json"
            inventory.write_text("[]")
            output = root / "output"
            argv = ["workflow", "--config", str(ROOT / "configs/task26_pilot8.json"),
                    "--inventory", str(inventory), "--output", str(output)]
            for key in ("upstream", "isaaclab", "assets", "python"):
                argv.extend(["--" + key, str(root)])
            script = ("import pathlib,sys; p=pathlib.Path(sys.argv[1]); p.mkdir(); "
                      "(p/'result.json').write_text('{\"state\":\"stopped_by_request\"}')")
            plan = [("smoke", [sys.executable, "-c", script, str(output / "smoke")]),
                    ("evaluation", ["must-not-run"])]
            with patch.object(sys, "argv", argv), patch.object(workflow, "stages", return_value=plan), \
                    patch.object(workflow.signal, "signal"):
                with self.assertRaises(SystemExit) as stopped:
                    workflow.main()
            self.assertEqual(stopped.exception.code, 0)
            result = json.loads((output / "workflow.json").read_text())
            self.assertEqual(result["state"], "stopped_by_request")
            self.assertFalse((output / "evaluation.log").exists())

    def test_order_and_two_workers(self):
        args = argparse.Namespace(**{key: Path("/fixture") / key for key in
            ("config", "upstream", "isaaclab", "assets", "python", "auth", "inventory", "output")})
        args.workers = 2
        args.skip_smoke = False
        plan = workflow.stages(args)
        self.assertEqual([name for name, _ in plan], ["verify_assets", "smoke", "evaluation"])
        for name, command in plan[1:]:
            self.assertEqual(command[command.index("--workers") + 1], "2")
            self.assertEqual(command[command.index("--mode") + 1], "hold" if name == "smoke" else "codex")
        args.skip_smoke = True
        direct = workflow.stages(args)
        self.assertEqual([name for name, _ in direct], ["verify_assets", "evaluation"])
        self.assertEqual(direct[0], plan[0])
        self.assertEqual(direct[1], plan[-1])

    def test_failed_prerequisite_stops_before_model_stage(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            inventory = root / "inventory.json"
            inventory.write_text("[]")
            output = root / "output"
            argv = ["workflow", "--config", str(ROOT / "configs/task26_pilot8.json"),
                    "--inventory", str(inventory), "--output", str(output)]
            for key in ("upstream", "isaaclab", "assets", "python"):
                argv.extend(["--" + key, str(root)])
            plan = [("verify_assets", [sys.executable, "-c", "raise SystemExit(1)"]),
                    ("evaluation", ["must-not-run"])]
            previous = signal.getsignal(signal.SIGTERM)
            try:
                with patch.object(sys, "argv", argv), patch.object(workflow, "stages", return_value=plan):
                    with self.assertRaises(SystemExit) as stopped:
                        workflow.main()
                self.assertEqual(stopped.exception.code, 1)
                result = json.loads((output / "workflow.json").read_text())
                self.assertEqual(result["state"], "stopped_on_error")
                self.assertEqual([s["stage"] for s in result["stages"]], ["verify_assets"])
                self.assertFalse((output / "evaluation.log").exists())
            finally:
                signal.signal(signal.SIGTERM, previous)
