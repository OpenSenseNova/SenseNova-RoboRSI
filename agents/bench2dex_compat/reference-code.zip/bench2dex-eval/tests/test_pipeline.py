import json
from pathlib import Path
import shutil
import socket
import subprocess
import tempfile
import threading
import time
import unittest
from types import SimpleNamespace

import numpy as np

from gpt6_eval import isolation
from gpt6_eval.audit import audit
from gpt6_eval.bridge import Episode, PolicyError, serve
from gpt6_eval.cli import ROOT, ROBOTS, load_config, load_task, hash_file, runtime_command
from gpt6_eval.core import (CAMERAS, budget, canonical, classify_result, sanitize_observation,
                            save_observation, validate_actions, verify_model_rollouts, write_json)
from gpt6_eval.robot import kinematics
from gpt6_eval.transport import recv_message, send_message


def observation(dof=2):
    return {"language": "Move the cup", "joint_action": {"vector": np.zeros(dof, np.float32)},
            "observation": {k: {"rgb": np.full((480, 640, 3), i, np.uint8),
                                "depth": "SECRET_DEPTH"}
                            for i, k in enumerate(set(sum(CAMERAS.values(), ())))},
            "object_poses": "SECRET_OBJECT_POSES", "success": "SECRET_SUCCESS",
            "robot_metadata": {"robot_key": "test_robot", "active_joint_names": ["j1", "j2"],
                               "position_limits": [[-1, 1], [-1, 1]],
                               "action_semantics": "absolute active-joint position targets",
                               "joint_units": ["radian", "radian"],
                               "physics_hz": 60, "policy_hz": 20}}


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_allowlist_removes_privileged_data_and_extra_camera(self):
        obs, imgs = sanitize_observation(observation(), "baseline_4cam", 2)
        self.assertEqual(set(obs), {"instruction", "qpos"})
        self.assertEqual(tuple(imgs), CAMERAS["baseline_4cam"])
        self.assertNotIn("SECRET", canonical(obs).decode())
        self.assertNotIn("cam_overhead", imgs)

    def test_no_missing_camera_fallback(self):
        raw = observation()
        del raw["observation"]["cam_stereo_left"]
        with self.assertRaises(KeyError):
            sanitize_observation(raw, "baseline_4cam", 2)

    def test_bad_state_and_images_fail_closed(self):
        for value in (np.array([np.nan, 0]), np.zeros(3)):
            raw = observation()
            raw["joint_action"]["vector"] = value
            with self.assertRaises(ValueError):
                sanitize_observation(raw, "baseline_4cam", 2)
        raw = observation()
        raw["observation"]["cam_stereo_left"]["rgb"] = np.zeros((1, 2, 3), np.uint8)
        with self.assertRaises(ValueError):
            sanitize_observation(raw, "baseline_4cam", 2)

    def test_serialization_and_png_reproducible(self):
        raw = observation()
        left = save_observation(self.root / "a", 0, raw, "baseline_4cam", 2, 10)
        right = save_observation(self.root / "b", 0, raw, "baseline_4cam", 2, 10)
        self.assertEqual(canonical(left), canonical(right))
        for image in left["cameras"]:
            self.assertEqual((self.root / "a" / image["path"]).read_bytes(),
                             (self.root / "b" / image["path"]).read_bytes())

    def test_chunk_shape_budget_and_nan(self):
        for payload in ({"actions": []}, {"actions": [[1]]},
                        {"actions": [[1, 2]] * 4}, {"actions": [[float('nan'), 0]]},
                        {"actions": [[0, 0]], "oracle": True}):
            with self.assertRaises(ValueError):
                validate_actions(payload, 2, 3)
        self.assertEqual(validate_actions({"actions": [[0, 0]]}, 2, 3).shape, (1, 2))

    def test_official_budget_rounding(self):
        self.assertEqual(budget(2164), 1082)
        self.assertEqual(budget(1185), 593)
        with self.assertRaises(ValueError):
            budget(float("nan"))

    def test_timeout_is_failure_even_if_partial_progress(self):
        self.assertEqual(classify_result({"terminated_reason": "max_steps", "success": False,
                                         "stage_completion_rate": 0.95}), "failure")
        self.assertEqual(classify_result({"terminated_reason": "stable_success", "success": True}), "success")
        self.assertEqual(classify_result({"terminated_reason": "error"}), "infrastructure_error")

    def test_model_gate_rejects_absent_wrong_and_fake_evidence(self):
        (self.root / "sessions").mkdir()
        path = self.root / "sessions/log.jsonl"
        for event in ({"type": "message", "model": "gpt-6-astra"},
                      {"type": "turn_context", "payload": {"model": "gpt-5.6"}}):
            path.write_bytes(canonical(event))
            with self.assertRaises(RuntimeError):
                verify_model_rollouts(self.root)
        path.write_bytes(canonical({"type": "turn_context", "payload": {"model": "gpt-6-astra"}}))
        self.assertEqual(verify_model_rollouts(self.root)[0]["model"], "gpt-6-astra")

    def test_config_rejects_model_substitution(self):
        cfg = json.loads((ROOT / "configs/default.json").read_text())
        cfg["model"] = "gpt-6"
        path = self.root / "config.json"
        write_json(path, cfg)
        with self.assertRaises(ValueError):
            load_config(path)

    def test_smoke_config_does_not_change_full_evaluation_asset_pools(self):
        default = load_config(ROOT / "configs/default.json")
        smoke = load_config(ROOT / "configs/smoke_task03.json")
        self.assertEqual(default["generalization_config"], "configs/scene/generalization.yaml")
        self.assertEqual(smoke["generalization_config"], "configs/scene/no_generalization.yaml")
        self.assertEqual(smoke["generalization_profile"], "none")

    def test_non_model_runs_are_not_named_gpt6_in_upstream_results(self):
        config = load_config(ROOT / "configs/smoke_task03.json")
        for mode, expected in (("hold", "development_hold"),
                               ("replay", "recorded_action_replay"),
                               ("codex", "gpt-6-astra")):
            args = SimpleNamespace(python=Path("/python"), upstream=Path("/upstream"),
                                   mode=mode, anchor=None)
            cmd = runtime_command(args, config, Path("/scene"), "robot", 4, 123, Path("/output"))
            self.assertEqual(cmd[cmd.index("--policy-name") + 1], expected)
            self.assertIn("--record-all", cmd)
            self.assertEqual(cmd[cmd.index("--record-dir") + 1], "/trajectories")

    def test_all_26_tasks_use_official_catalog(self):
        upstream = ROOT.parent / "Bench2Dex"
        if not upstream.exists():
            self.skipTest("optional upstream integration")
        for task_id in ROBOTS:
            _, task, _ = load_task(upstream, task_id)
            self.assertGreater(budget(task["metrics"]["expert_time_step"]), 0)
        with self.assertRaises(ValueError):
            load_task(upstream, 86)

    def test_static_kinematics_drops_visuals_and_arbitrary_attributes(self):
        path = self.root / "robot.urdf"
        path.write_text('<robot name="x"><link name="x"><visual>SECRET</visual></link>'
                        '<joint name="j" type="revolute" secret="SECRET">'
                        '<parent link="a"/><child link="b"/><axis xyz="0 0 1"/>'
                        '<origin xyz="0 0 1" rpy="0 0 0"/></joint></robot>')
        self.assertNotIn("SECRET", canonical(kinematics(path)).decode())

    def test_rpc_numpy_and_fragmented_header(self):
        a, b = socket.socketpair()
        with a, b:
            b.settimeout(3)
            thread = threading.Thread(target=send_message, args=(a, {"x": np.arange(3, dtype=np.float32)}))
            thread.start()
            np.testing.assert_equal(recv_message(b)["x"], np.arange(3, dtype=np.float32))
            thread.join()
        class Fragmented:
            data = bytearray(b'\x00\x00\x00\x02{}')
            def recv(self, count):
                value = bytes(self.data[:1])
                del self.data[:1]
                return value
        self.assertEqual(recv_message(Fragmented()), {})

    def test_rpc_episode_sequence_and_private_archive(self):
        config = load_config(ROOT / "configs/default.json")
        ep = Episode(self.root / "episode", config, "Move the cup", "test_robot", {},
                     20, Path("/unused"), Path("/unused"), "", "hold")
        first = ep.action(observation())
        self.assertEqual(first.shape, (16, 2))
        recorded = json.loads((ep.private / "actions/000000.json").read_text())
        self.assertEqual(recorded["policy"], "development_hold")
        np.testing.assert_array_equal(recorded["actions"], first)
        for _ in range(15):
            ep.observe(observation())
        self.assertEqual(ep.action(observation()).shape, (4, 2))
        self.assertEqual(ep.index, 17)
        public_bytes = b"".join(p.read_bytes() for p in ep.workspace.rglob("*.json"))
        self.assertNotIn(b"SECRET", public_bytes)
        ep.finish()
        telemetry = json.loads((ep.private / "telemetry.json").read_text())
        self.assertEqual(telemetry["tokens"]["total_tokens"], 0)
        self.assertEqual(telemetry["decision_count"], 2)
        self.assertFalse((ep.inputs / "telemetry.json").exists())
        ep.finish()  # Finalization is idempotent.

    def test_robot_order_change_is_rejected(self):
        cfg = load_config(ROOT / "configs/default.json")
        ep = Episode(self.root / "ep", cfg, "Move the cup", "test_robot", {},
                     10, Path("/unused"), Path("/unused"), "", "hold")
        ep.observe(observation())
        raw = observation()
        raw["robot_metadata"]["active_joint_names"].reverse()
        with self.assertRaises(RuntimeError):
            ep.observe(raw)

    def test_model_action_exchange_and_archival(self):
        cfg = load_config(ROOT / "configs/default.json")
        ep = Episode(self.root / "ep", cfg, "Move the cup", "test_robot", {},
                     10, Path("/unused"), Path("/unused"), "", "codex")
        class Process:
            def poll(self):
                return None
        def start_fixture():
            ep.proc = Process()
            path = ep.home / "sessions/fixture.jsonl"
            path.parent.mkdir()
            path.write_bytes(canonical({"type": "turn_context", "payload": {"model": "gpt-6-astra"}}))
            write_json(ep.action_transport / "request.json", {"decision": 0, "payload": {"actions": [[0.1, 0.2]]}})
        ep.start = start_fixture
        result = ep.action(observation())
        np.testing.assert_allclose(result, [[0.1, 0.2]])
        record = json.loads((ep.private / "actions/000000.json").read_text())
        self.assertEqual(record["policy_step"], 0)
        self.assertEqual(record["model_evidence"][0]["model"], "gpt-6-astra")

    def test_model_service_error_is_not_a_policy_failure(self):
        config = load_config(ROOT / "configs/default.json")
        for returncode, expected in ((1, RuntimeError), (0, PolicyError)):
            ep = Episode(self.root / f"ep_{returncode}", config, "Move the cup", "test_robot", {},
                         10, Path("/unused"), Path("/unused"), "", "codex")
            class Process:
                def poll(self):
                    return returncode
            ep.proc = Process()
            with self.assertRaises(RuntimeError) as caught:
                ep.action(observation())
            self.assertIs(type(caught.exception), expected)

    def test_rpc_server_end_to_end_hold(self):
        cfg = load_config(ROOT / "configs/default.json")
        listener = socket.socket()
        listener.bind(("127.0.0.1", 0))
        listener.listen()
        stop, state = threading.Event(), {}
        def make():
            return Episode(self.root / "ep", cfg, "Move the cup", "test_robot", {},
                           2, Path("/unused"), Path("/unused"), "", "hold")
        thread = threading.Thread(target=serve, args=(listener, stop, make,
                                                     recv_message, send_message, state))
        thread.start()
        with socket.create_connection(listener.getsockname(), timeout=3) as connection:
            send_message(connection, {"command": "reset", "seed": 1234})
            self.assertIsNone(recv_message(connection)["result"])
            send_message(connection, {"command": "get_action_chunk", "observation": observation()})
            self.assertEqual(recv_message(connection)["result"].shape, (2, 2))
            send_message(connection, {"command": "update_after_action", "observation": observation()})
            self.assertIsNone(recv_message(connection)["result"])
            send_message(connection, {"command": "close"})
            recv_message(connection)
        stop.set()
        listener.close()
        thread.join(timeout=5)
        self.assertFalse(thread.is_alive())
        self.assertNotIn("error", state)

    def test_mount_namespace_hides_host_and_other_episode(self):
        binary = Path(shutil.which("codex") or "/missing")
        if not shutil.which("bwrap") or not binary.resolve().with_name("codex-code-mode-host").is_file():
            self.skipTest("Linux bubblewrap and Codex required")
        for name in ("workspace", "home", "interface", "private"):
            (self.root / name).mkdir()
        (self.root / "workspace/input").mkdir()
        (self.root / "private/secret").write_text("PRIVILEGED_CANARY")
        result = isolation.probe(self.root / "workspace", self.root / "home",
                                 self.root / "interface", Path(shutil.which("codex")),
                                 self.root / "private")
        self.assertIn("passed", result)

    def test_strict_replay_detects_changed_observation(self):
        config = load_config(ROOT / "configs/default.json")
        original = self.root / "original"
        ep = Episode(original, config, "Move the cup", "test_robot", {}, 10,
                     Path("/unused"), Path("/unused"), "", "hold")
        ep.observe(observation())
        write_json(ep.private / "actions/000000.json", {"policy_step": 0, "actions": [[0.3, 0.4]]})
        replay = Episode(self.root / "replay", config, "Move the cup", "test_robot", {},
                         10, Path("/unused"), Path("/unused"), "", "replay", original)
        np.testing.assert_allclose(replay.action(observation()), [[0.3, 0.4]])
        bad = Episode(self.root / "bad", config, "Move the cup", "test_robot", {},
                      10, Path("/unused"), Path("/unused"), "", "replay", original)
        raw = observation()
        raw["joint_action"]["vector"][0] = 0.5
        with self.assertRaisesRegex(RuntimeError, "Replay observation mismatch"):
            bad.action(raw)

    def test_integrity_detects_modified_archive(self):
        folder = self.root / "episode_0000/private"
        obs = save_observation(folder, 0, observation(), "baseline_4cam", 2, 10)
        manifest = {str(p.relative_to(self.root)): hash_file(p)
                    for p in self.root.rglob("*") if p.is_file()}
        write_json(self.root / "integrity.json", manifest)
        self.assertEqual(audit(self.root)["verified_observations"], 1)
        (folder / obs["cameras"][0]["path"]).write_bytes(b"modified")
        with self.assertRaises(ValueError):
            audit(self.root)


if __name__ == "__main__":
    unittest.main()
