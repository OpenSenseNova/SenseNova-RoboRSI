import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from finalize_campaign_task import stage_cost


class ReconciledStageAuditTests(unittest.TestCase):
    def test_unknown_exit_retains_record_and_unknown_duration(self):
        with tempfile.TemporaryDirectory() as directory:
            record = {'state': 'interrupted', 'tokens': {'status': 'partial'}}
            (Path(directory) / 'result.json').write_text(json.dumps(record))
            job = dict(stage='smoke', output=directory, started_at='2026-09-29T04:55:00+00:00',
                ended_at='2026-09-29T07:58:00+00:00', recovery='Filesystem failure; actual exit unknown',
                reconciliation_time_semantics='ended_at is reconciliation time, not observed child exit time')
            actual = stage_cost(job)
            self.assertIsNone(actual['returncode'])
            self.assertIsNone(actual['wall_seconds_including_finalization'])
            self.assertEqual(actual['record'], record)
            self.assertEqual(actual['reconciliation_at'], job['ended_at'])
            self.assertEqual(len(actual['record_sha256']), 64)
            del job['recovery']
            with self.assertRaises(ValueError):
                stage_cost(job)

    def test_unexplained_missing_exit_is_rejected(self):
        with self.assertRaises(ValueError):
            stage_cost(dict(stage='smoke', output='/nonexistent'))

    def test_normal_exit_keeps_measured_duration(self):
        with tempfile.TemporaryDirectory() as directory:
            job = dict(stage='smoke', output=directory, returncode=0,
                started_at='2026-09-29T04:55:00+00:00', ended_at='2026-09-29T04:56:00+00:00')
            actual = stage_cost(job)
            self.assertEqual(actual['returncode'], 0)
            self.assertEqual(actual['wall_seconds_including_finalization'], 60)
            self.assertNotIn('reconciliation_at', actual)
