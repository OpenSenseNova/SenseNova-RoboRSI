from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import Mock, patch

from gpt6_eval.bridge import Episode, PolicyError
from gpt6_eval.cli import ROOT, load_config
from gpt6_eval.core import write_json
from gpt6_eval.isolation import mounts
from gpt6_eval.step import submit


class ActionTransportTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.ep = Episode(self.root / 'episode', load_config(ROOT / 'configs/default.json'),
                          'instruction', 'robot', {}, 100, Path('/unused'), Path('/unused'), '')
        self.ep.proc = Mock()
        self.ep.proc.poll.return_value = None
        write_json(self.ep.home / 'sessions/evidence.jsonl',
                   {'type': 'turn_context', 'payload': {'model': 'gpt-6-astra'}})
        def observe(raw):
            self.ep.index += 1
            return {'qpos': [0.0, 0.0]}
        self.ep.observe = observe

    def test_action_json_scratch_is_not_consumed_and_helper_preserves_it(self):
        ep = self.ep
        payload = ep.workspace / 'action.json'
        write_json(payload, {'actions': [[0.1, 0.2]] * 46})
        original = payload.read_bytes()
        with ThreadPoolExecutor(max_workers=2) as pool:
            action = pool.submit(ep.action, {})
            try:
                deadline = time.monotonic() + 3
                while not (ep.inputs / 'observation.json').exists():
                    self.assertLess(time.monotonic(), deadline)
                    time.sleep(.01)
                time.sleep(.15)  # The old watcher would already consume action.json.
                self.assertFalse(action.done())
                self.assertEqual(payload.read_bytes(), original)
                helper = pool.submit(submit, payload, ep.workspace, ep.action_transport)
                result = action.result(timeout=3)
                self.assertEqual(result.shape, (46, 2))
                write_json(ep.inputs / 'episode_done.json', {'episode_done': True})
                self.assertEqual(helper.result(timeout=3), {'episode_done': True})
            finally:
                ep.stopped.set()
                write_json(ep.inputs / 'episode_done.json', {'episode_done': True})
        self.assertEqual(payload.read_bytes(), original)
        self.assertFalse((ep.action_transport / 'submission.lock').exists())
        self.assertFalse((ep.action_transport / 'request.json').exists())
        archive = json.loads((ep.private / 'requests/000000.json').read_text())
        self.assertEqual(set(archive), {'decision', 'payload'})

    def test_envelope_errors_are_infrastructure_not_policy_failures(self):
        for request in ({'actions': [[0, 0]]}, {'decision': 99, 'payload': {'actions': [[0, 0]]}}):
            write_json(self.ep.action_transport / 'request.json', request)
            with self.assertRaises(RuntimeError) as caught:
                self.ep.action({})
            self.assertNotIsInstance(caught.exception, PolicyError)

    def test_bad_model_actions_still_count_as_policy_errors(self):
        write_json(self.ep.action_transport / 'request.json',
                   {'decision': 0, 'payload': {'actions': [[0]]}})
        with self.assertRaises(PolicyError):
            self.ep.action({})

    def test_model_identity_gate_is_not_bypassed(self):
        write_json(self.ep.home / 'sessions/evidence.jsonl',
                   {'type': 'turn_context', 'payload': {'model': 'gpt-5.6'}})
        write_json(self.ep.action_transport / 'request.json',
                   {'decision': 0, 'payload': {'actions': [[0, 0]]}})
        with self.assertRaises(RuntimeError):
            self.ep.action({})
        self.assertFalse((self.ep.private / 'actions/000000.json').exists())

    def test_helper_rejects_duplicate_and_reserved_path(self):
        ep = self.ep
        write_json(ep.inputs / 'observation.json', {'decision': 0})
        payload = ep.workspace / 'action.json'
        write_json(payload, {'actions': [[0, 0]]})
        (ep.action_transport / 'submission.lock').touch()
        with self.assertRaises(FileExistsError):
            submit(payload, ep.workspace, ep.action_transport)
        self.assertTrue((ep.action_transport / 'submission.lock').exists())
        with self.assertRaises(ValueError):
            submit(ep.action_transport / 'request.json', ep.workspace, ep.action_transport)

    def test_mount_exposes_only_transport_not_private_parent(self):
        binary = self.root / 'codex'
        binary.touch()
        binary.with_name('codex-code-mode-host').touch()
        with patch('gpt6_eval.isolation.shutil.which', return_value='/usr/bin/bwrap'):
            cmd = mounts(self.ep.workspace, self.ep.home, self.ep.interface, binary)
        i = cmd.index(str(self.ep.action_transport))
        self.assertEqual(cmd[i-1:i+2], ['--bind', str(self.ep.action_transport), '/workspace/.action_transport'])
        self.assertNotIn(str(self.ep.private), cmd)


if __name__ == '__main__':
    unittest.main()
