import copy
import unittest

from gpt6_eval.cli import ROOT, load_config
from gpt6_eval.paired import make_configs, pair_rows


class PairedTests(unittest.TestCase):
    def test_same_schedule_and_no_package_for_zero_shot(self):
        base = load_config(ROOT/'configs/task22_icl_pilot.json')
        configs = make_configs(base, '/frozen', 'a'*64, 22, 6, 6)
        self.assertEqual(configs['zero_shot'], {**base, 'start_episode':6,'num_episodes':6})
        self.assertNotIn('task_packages',configs['zero_shot'])
        icl=copy.deepcopy(configs['icl'])
        del icl['task_packages'],icl['evaluation_setting']
        icl['schema_version']=2
        self.assertEqual(icl,configs['zero_shot'])

    def test_invalid_base_rejected(self):
        base=load_config(ROOT/'configs/task22_icl_pilot.json')
        for key,value in [('reasoning_effort','high'),('model','gpt-5.6'),
                          ('generalization_split','seen'),('generalization_profile','none')]:
            with self.assertRaises(ValueError):make_configs({**base,key:value},'/p','a'*64,22,6,6)

    def examples(self):
        common={'valid':True,'success':False,'episode_index':6,'episode_seed':202200005,
                'randomization_sha256':'r','common_config_sha256':'c','asset_manifest_sha256':'a',
                'scene_sha256':'s','official_policy_budget':681,'executed_policy_budget':681,
                'initial_state_sha256':'o','initial_rgb_sha256':{'cam':'rgb'}}
        return {'icl':{6:{**common,'setting':'task_icl_v3','package_sha256':'p','success':True}},
                'zero_shot':{6:{**common,'setting':'zero_shot','package_sha256':None}}}

    def test_complete_pair_and_pixel_variation_disclosed(self):
        conditions=self.examples()
        conditions['zero_shot'][6]['initial_rgb_sha256']={'cam':'different'}
        r=pair_rows([6],conditions,'p')
        self.assertTrue(r['complete_valid_comparison'])
        self.assertFalse(r['pairs'][0]['initial_rgb_exact_match'])
        self.assertEqual(r['paired_outcomes']['icl_only'],1)
        self.assertEqual(r['icl_minus_zero_shot_percentage_points'],100)

    def test_no_aggregate_on_incomplete_invalid_or_mismatched_pairs(self):
        for mutation in ('missing','invalid','seed','package','leak','randomization'):
            conditions=self.examples()
            b=conditions['zero_shot'][6]
            if mutation=='missing':conditions['zero_shot']={}
            elif mutation=='invalid':b['valid']=False
            elif mutation=='seed':b['episode_seed']+=1
            elif mutation=='package':conditions['icl'][6]['package_sha256']='wrong'
            elif mutation=='leak':b['package_sha256']='p'
            else:b['randomization_sha256']='different'
            r=pair_rows([6],conditions,'p')
            self.assertFalse(r['complete_valid_comparison'],mutation)
            self.assertIsNone(r['success_rates'])


if __name__=='__main__':unittest.main()
