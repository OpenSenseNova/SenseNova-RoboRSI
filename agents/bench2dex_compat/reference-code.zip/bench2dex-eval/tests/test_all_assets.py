from pathlib import Path
import unittest
import yaml

from gpt6_eval.cli import ROOT, ROBOTS, load_task
from gpt6_eval.prepare_task26_assets import selection


class AllAssetsTests(unittest.TestCase):
    def setUp(self):
        self.upstream = ROOT.parent / "Bench2Dex"
        if not self.upstream.is_dir():
            self.skipTest("Pinned upstream checkout not installed")

    def test_all_release_objects_and_robots_are_selected(self):
        patterns = selection(self.upstream, all_tasks=True)
        maps = yaml.safe_load((self.upstream / "robots/active_dof_maps.yml").read_text())["robots"]
        self.assertEqual(len(ROBOTS), 26)
        self.assertNotIn(86, ROBOTS)
        for task_id in ROBOTS:
            _, task, robot = load_task(self.upstream, task_id)
            self.assertIn(maps[robot]["asset_dir"].removeprefix("Bench2Dex/") + "/*", patterns)
            for asset in task["assets"].values():
                relative = asset["path"].split("dex2bench_dataset/")[1]
                self.assertIn("/".join(relative.split("/")[:2]) + "/*", patterns)
        self.assertEqual(patterns, sorted(set(patterns)))

    def test_shared_assets_and_legacy_selection_preserved(self):
        patterns = selection(self.upstream, all_tasks=True)
        self.assertTrue(set(selection(self.upstream)).issubset(patterns))
        self.assertIn("Objects/thor/*", patterns)
        self.assertEqual(sum(p.startswith("Robots_p/") for p in patterns), 12)
        self.assertTrue(all(p.startswith(("Objects/", "Robots_p/", "textures/", "scenes/ithor/")) for p in patterns))


if __name__ == "__main__":
    unittest.main()
