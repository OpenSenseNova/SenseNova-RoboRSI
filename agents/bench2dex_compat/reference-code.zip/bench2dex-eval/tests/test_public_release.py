"""Portable source packaging and fail-closed setup checks, without GPU/model calls."""
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from gpt6_eval.cli import ROOT, load_config
from gpt6_eval.preflight import check_source, check_assets, check_simulator_python, main as preflight
from gpt6_eval.suite import freeze_source

spec = importlib.util.spec_from_file_location('release_checker', ROOT / 'scripts/check_release.py')
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)


class PublicReleaseTests(unittest.TestCase):
    def test_invalid_selected_config_fails_without_falling_back(self):
        with tempfile.TemporaryDirectory() as temporary:
            config = Path(temporary) / 'invalid.json'
            config.write_text('{}')
            output = io.StringIO()
            with patch('sys.argv', ['preflight', '--source-only', '--config', str(config)]), patch('sys.stdout', output):
                self.assertEqual(preflight(), 1)
            self.assertFalse(json.loads(output.getvalue())['passed'])

    def test_simulator_version_drift_is_reported_before_launch(self):
        for versions in ({'isaacsim': '5.0.0', 'torch': '2.7.0+cu128'},
                         {'isaacsim': '5.1.0.0', 'torch': '2.7.0+cpu'}):
            with patch('gpt6_eval.preflight.check_python', return_value=versions):
                with self.assertRaises(ValueError):
                    check_simulator_python(Path('python'))

    def test_source_snapshot_has_every_required_public_resource(self):
        self.assertEqual(check_source()['catalog_tasks'], 26)
        with tempfile.TemporaryDirectory() as temporary:
            target = Path(temporary) / 'snapshot'
            hashes = freeze_source(target)
            self.assertIn('RELEASE_CONTENTS.json', hashes)
            self.assertNotIn('PROJECT_MEMORY.md', hashes)
            self.assertEqual(load_config(target / 'configs/default.json')['model'], 'gpt-6-astra')
            for name in ('prompts/preparation_reader.md', 'scripts/evaluate.sh', 'src/gpt6_eval/simulator.py'):
                self.assertTrue((target / name).is_file())

    def test_asset_root_must_match_upstream_relative_layout(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / 'Bench2Dex').mkdir()
            (root / 'external_assets').mkdir()
            with self.assertRaisesRegex(ValueError, 'beside Bench2Dex'):
                check_assets(root / 'Bench2Dex', root / 'external_assets', 26)
            (root / 'dex2bench_dataset').symlink_to(root / 'external_assets')
            with patch('gpt6_eval.preflight.load_task', return_value=(root/'scene.yaml', {'assets': {}}, 'robot')):
                self.assertEqual(check_assets(root/'Bench2Dex', root/'external_assets',26)['layout'], 'passed')

    def test_release_scanner_detects_secrets_without_echoing_values(self):
        secret = 'sk-' + 'a' * 32
        result = checker.scan_content(secret)
        self.assertEqual(result[0]['kind'], 'provider credential')
        self.assertNotIn(secret, json.dumps(result))

    def test_release_scanner_rejects_private_artifacts_and_checksum_changes(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root/'runs').mkdir()
            (root/'auth.json').write_text('{}')
            (root/'README.md').write_text('changed')
            (root/'SHA256SUMS').write_text('0'*64+'  README.md\n')
            report = checker.audit(root)
            self.assertFalse(report['passed'])
            kinds = {item['kind'] for item in report['findings']}
            self.assertIn('excluded directory', kinds)
            self.assertIn('checksum mismatch', kinds)

    def test_launcher_preserves_paths_with_spaces(self):
        with tempfile.TemporaryDirectory(prefix='public release ') as temporary:
            root = Path(temporary)
            fake = root/'fake python'
            fake.write_text('#!/usr/bin/env python3\nimport json,sys\nprint(json.dumps(sys.argv[1:]))\n')
            fake.chmod(0o755)
            env = dict(os.environ, EVAL_PYTHON=str(fake), BENCH2DEX_ROOT=str(root/'upstream code'),
                       ISAACLAB_ROOT=str(root/'isaac lab'), BENCH2DEX_ASSETS=str(root/'assets here'),
                       ISAACLAB_PYTHON=str(root/'sim python'))
            run = subprocess.run(['bash', str(ROOT/'scripts/evaluate.sh'), '--task', '26',
                                  '--mode', 'hold', '--output', str(root/'new run')],
                                 env=env, capture_output=True, text=True, check=True)
            argv = json.loads(run.stdout)
            for flag, value in [('--upstream', env['BENCH2DEX_ROOT']), ('--python', env['ISAACLAB_PYTHON']), ('--output', str(root/'new run'))]:
                self.assertEqual(argv[argv.index(flag)+1], value)


if __name__ == '__main__':
    unittest.main()
