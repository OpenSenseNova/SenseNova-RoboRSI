"""Host-only audit guards; no model or simulator calls."""
import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / 'scripts'
sys.path.insert(0, str(SCRIPTS))
from finalize_task22_ten import require_indices, exact_invocation, check_hashes, sha


class FinalAuditTests(unittest.TestCase):
    def test_exact_unique_indices(self):
        require_indices(list(reversed(range(5, 15))))
        for indices in (list(range(5, 14)), list(range(5, 14)) + [13], list(range(6, 16))):
            with self.assertRaises(ValueError):
                require_indices(indices)

    def test_identity_and_effort(self):
        exact_invocation(['--model', 'gpt-6-astra', 'model_reasoning_effort="max"'])
        for argv in (['--model', 'gpt-6', 'model_reasoning_effort="max"'],
                     ['--model', 'gpt-6-astra', 'model_reasoning_effort="high"']):
            with self.assertRaises(AssertionError):
                exact_invocation(argv)

    def test_tampering_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            p = root / 'result.json'
            p.write_text('{}')
            hashes = {'result.json': sha(p)}
            check_hashes(root, hashes)
            p.write_text('{"changed": true}')
            with self.assertRaises(ValueError):
                check_hashes(root, hashes)


if __name__ == '__main__':
    unittest.main()
