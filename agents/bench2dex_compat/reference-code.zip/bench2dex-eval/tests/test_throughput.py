import io
import os
from pathlib import Path
import stat
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch
from types import SimpleNamespace

import numpy as np
from PIL import Image

from gpt6_eval.throughput import content_hashes, encode_frames, export_space_bound, wait_for_export_space
from gpt6_eval.knowledge import file_hash
from gpt6_eval.core import save_observation, CAMERAS


class ThroughputTests(unittest.TestCase):
    def test_storage_backpressure_keeps_safety_margin_and_waits_for_inodes(self):
        frames=1000; required=export_space_bound(frames)
        self.assertGreater(required,50*1024**3+frames*4*640*480*3)
        with patch('gpt6_eval.throughput.shutil.disk_usage',side_effect=[
                SimpleNamespace(free=required-1),SimpleNamespace(free=required),SimpleNamespace(free=required)]), \
             patch('gpt6_eval.throughput.os.statvfs',side_effect=[
                SimpleNamespace(f_favail=1000000),SimpleNamespace(f_favail=104000),SimpleNamespace(f_favail=104001)]), \
             patch('gpt6_eval.throughput.time.sleep') as sleep:
            wait_for_export_space('/unused',frames)
        self.assertEqual(sleep.call_count,2)

    def test_parallel_encoded_bytes_match_legacy_with_order_and_metadata_stripping(self):
        frames, expected = [], []
        for i in range(12):
            rgb = np.random.default_rng(i).integers(0, 256, (480, 640, 3), dtype=np.uint8)
            src = io.BytesIO()
            Image.fromarray(rgb).save(src, format='JPEG', comment=b'private metadata')
            frames.append(src.getvalue())
            with Image.open(io.BytesIO(frames[-1])) as image:
                clean = Image.fromarray(np.asarray(image.convert('RGB')))
                out = io.BytesIO(); clean.save(out, format='PNG', compress_level=6)
                expected.append(out.getvalue())
        self.assertEqual(list(encode_frames(iter(frames), 4)), expected)
        self.assertEqual(list(encode_frames(iter(frames), 1)), expected)

    def test_prefetch_is_bounded_and_bad_frames_fail(self):
        consumed = []
        def raw():
            for i in range(100):
                consumed.append(i)
                yield bytes([i])
        with patch('gpt6_eval.throughput.encode_png', side_effect=lambda x: x):
            stream = encode_frames(raw(), 4)
            self.assertEqual(next(stream), b'\x00')
            self.assertEqual(len(consumed), 8)
            stream.close()
        with self.assertRaises(Exception):
            list(encode_frames([b'not an image'], 4))
        for workers in (0, 9, 1.5, True):
            with self.assertRaises(ValueError): list(encode_frames([], workers))

    def test_stream_inventory_matches_legacy_and_rejects_all_link_types(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            for name in ('a/z.bin', 'a-a.bin', 'x/.hidden', 'x/deep/end', 'root.txt'):
                p = root/name; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(name.encode())
            expected = {str(p.relative_to(root)): file_hash(p) for p in sorted(root.rglob('*')) if p.is_file()}
            self.assertEqual(content_hashes(root), expected)
            for directory in (False, True):
                link = root/'link'; link.symlink_to(root/'a' if directory else root/'root.txt')
                with self.assertRaises(ValueError): content_hashes(root)
                link.unlink()
            link = root/'link'; link.hardlink_to(root/'root.txt')
            with self.assertRaises(ValueError): content_hashes(root)
            link.unlink(); os.mkfifo(link)
            with self.assertRaises(ValueError): content_hashes(root)

    def test_assets_keep_legacy_inventory_and_exclusions(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            for name in ('normal/a', '.cache/excluded', '.git/excluded'):
                p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(name)
            (root/'file_link').symlink_to(root/'normal/a')
            (root/'directory_link').symlink_to(root/'normal', target_is_directory=True)
            expected={str(p.relative_to(root)):file_hash(p) for p in sorted(root.rglob('*'))
                      if p.is_file() and '.cache' not in p.parts and '.git' not in p.parts}
            self.assertEqual(content_hashes(root,strict=False,exclude=('.cache','.git')),expected)

    def test_parallel_observations_match_original_serial_png_and_json(self):
        raw={'language':'instruction','joint_action':{'vector':np.array([1,2])},'observation':{}}
        for i,name in enumerate(CAMERAS['baseline_4cam']):
            raw['observation'][name]={'rgb':np.random.default_rng(i).integers(0,256,(480,640,3),dtype=np.uint8)}
        with tempfile.TemporaryDirectory() as d, ThreadPoolExecutor(max_workers=2) as pool:
            root=Path(d)
            serial=save_observation(root/'serial',0,raw,'baseline_4cam',2,10)
            parallel=save_observation(root/'parallel',0,raw,'baseline_4cam',2,10,encoder=pool)
            self.assertEqual(serial,parallel)
            self.assertEqual(content_hashes(root/'serial'),content_hashes(root/'parallel'))
            for camera in parallel['cameras']:
                expected=io.BytesIO()
                Image.fromarray(raw['observation'][camera['name']]['rgb']).save(expected,format='PNG',compress_level=6,optimize=False)
                self.assertEqual((root/'parallel'/camera['path']).read_bytes(),expected.getvalue())
