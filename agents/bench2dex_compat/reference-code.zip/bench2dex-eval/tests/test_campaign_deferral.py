import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('campaign_deferral', Path(__file__).resolve().parents[1]/'scripts/run_icl_campaign.py')
campaign = importlib.util.module_from_spec(spec)
spec.loader.exec_module(campaign)


class DeferralTests(unittest.TestCase):
    def task(self):
        return {'task_id':51, 'target_valid_count':10, 'new_episode_indices':list(range(5,15)), 'jobs':[]}

    def test_admission_skips_only_deferred_retains_priority_and_state(self):
        tasks = {'51':self.task(), '60':{'task_id':60}, '32':{'task_id':32}}
        tasks['51']['scheduling_deferral'] = {'path':'receipt.json','sha256':'hash'}
        before=copy.deepcopy(tasks)
        self.assertEqual([t['task_id'] for t in campaign.admission_tasks(tasks,[32,51,60])],[32,60])
        self.assertEqual(tasks,before)

    def test_deferral_never_satisfies_completion(self):
        tasks={'51':self.task(),'60':{'state':'complete_pending_final_audit'}}
        tasks['51']['scheduling_deferral']={}
        self.assertEqual(campaign.terminal_state(tasks),'blocked_on_deferred_tasks')
        tasks['60'].pop('state')
        self.assertIsNone(campaign.terminal_state(tasks))
        for t in tasks.values():t['state']='complete_pending_final_audit'
        self.assertEqual(campaign.terminal_state(tasks),'complete_pending_final_audit')

    def test_next_indices_and_denominator_remain_unchanged(self):
        task=self.task();task['scheduling_deferral']={}
        with patch.object(campaign,'collect',return_value={5:{},7:{}}):
            self.assertEqual(campaign.next_indices(task,5),[6])
        self.assertEqual(task['target_valid_count'],10)
        self.assertEqual(task['new_episode_indices'],list(range(5,15)))

    def test_receipt_hash_identity_and_plan_required(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);path=root/'receipt.json';task=self.task()
            receipt={'state':'user_authorized_deferral','task_id':51,'target_valid_count':10,
                     'new_episode_indices':list(range(5,15)),'preserve_protocol_gates':True}
            def install(value):
                path.write_text(json.dumps(value))
                task['scheduling_deferral']={'path':'receipt.json','sha256':campaign.sha(path)}
            install(receipt);campaign.validate_deferrals(root,{'51':task})
            path.write_text('{}')
            with self.assertRaises(ValueError):campaign.validate_deferrals(root,{'51':task})
            for key,value in [('state','unapproved'),('task_id',60),('target_valid_count',5),
                              ('new_episode_indices',[5]),('preserve_protocol_gates',False)]:
                bad=dict(receipt);bad[key]=value;install(bad)
                with self.assertRaises(ValueError):campaign.validate_deferrals(root,{'51':task})

    def test_malformed_deferrals_fail_closed(self):
        for value in (None,{},False,{'path':'x'}):
            task=self.task();task['scheduling_deferral']=value
            with self.assertRaises(ValueError):campaign.validate_deferrals(Path('.'),{'51':task})

    def test_original_campaign_needs_no_receipt(self):
        campaign.validate_deferrals(Path('.'),{'51':self.task()})
        self.assertIsNone(campaign.terminal_state({'51':self.task()}))


if __name__=='__main__':unittest.main()
