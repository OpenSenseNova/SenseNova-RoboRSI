import importlib.util
import json
import os
import subprocess
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from gpt6_eval import resource_wait

spec = importlib.util.spec_from_file_location('twenty', Path(__file__).resolve().parents[1] / 'scripts/run_task26_twenty.py')
twenty = importlib.util.module_from_spec(spec)
spec.loader.exec_module(twenty)


class RecoveryTests(unittest.TestCase):
    def test_fourteen_remaining_exact_indices_in_pairs(self):
        refs = dict.fromkeys(range(5, 11))
        waves = []
        while indices := twenty.next_indices(refs):
            waves.append(indices)
            refs.update(dict.fromkeys(indices))
        self.assertEqual(waves, [[11,12],[13,14],[15,16],[17,18],[19,20],[21,22],[23,24]])
        self.assertEqual(len(refs), 20)

    def test_partial_pair_preserves_valid_failure_and_retries_same_seed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); episode=root/'episode_0'; episode.mkdir()
            result={'complete':True,'eligible_for_gpt6_score':True,'success_rate':0,
                    'task_package_sha256':twenty.PACKAGE,'evaluation_setting':'task_icl_v3'}
            (episode/'result.json').write_text(json.dumps(result))
            (root/'result.json').write_text(json.dumps({'episodes':[
                {'valid':True,'upstream_episode_index':11,'directory':'episode_0'},
                {'valid':False,'upstream_episode_index':12,'directory':'episode_1'}]}))
            refs=twenty.collect({'inherited_episodes':[], 'attempts':[{'output':str(root)}]})
            refs.update(dict.fromkeys(range(5,11)))
            self.assertEqual(twenty.next_indices(refs), [12,13])
            self.assertIn(11, refs)

    def test_resource_error_only_from_trusted_simulator(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); private=root/'episode_0/private'; private.mkdir(parents=True)
            (root/'result.json').write_text(json.dumps({'state':'stopped_on_infrastructure_error'}))
            log=private/'simulator.log'
            log.write_text('[Error] arbitrary unexplained failure\n')
            self.assertFalse(twenty.resource_failure(root))
            log.write_text('[Error] PhysX: PxgCudaDeviceMemoryAllocator failed to allocate memory\n')
            self.assertTrue(twenty.resource_failure(root))

    def test_wait_then_admit_no_simulator_during_low_resources(self):
        with tempfile.TemporaryDirectory() as tmp:
            target=Path(tmp)/'resources.json'
            with patch.object(resource_wait,'snapshot',side_effect=[{'admitted':False},{'admitted':True}]), \
                    patch.object(resource_wait.time,'sleep') as sleep:
                self.assertTrue(resource_wait.wait_for_resources(target,2)['admitted'])
                sleep.assert_called_once_with(15)
            self.assertTrue(json.loads(target.read_text())['admitted'])

    def test_legacy_not_opted_in(self):
        with patch.dict(os.environ, {}, clear=True), patch.object(resource_wait,'wait_for_resources') as wait:
            resource_wait.before_simulator(Path('/unused'))
            wait.assert_not_called()

    def test_gpu_query_timeout_fails_closed_then_recovers(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'resources.json'
            timeout = subprocess.TimeoutExpired(['nvidia-smi'], 15)
            observed = []
            def inspect_wait(seconds):
                self.assertEqual(seconds, 15)
                observed.append(json.loads(target.read_text()))
            with patch.object(resource_wait, 'snapshot', side_effect=[
                    timeout, timeout, {'admitted': False}, {'admitted': True}]), \
                    patch.object(resource_wait.time, 'sleep', side_effect=inspect_wait):
                final = resource_wait.wait_for_resources(target, 2)
            self.assertEqual(len(observed), 3)
            self.assertTrue(all(not row['admitted'] for row in observed))
            self.assertIsNone(observed[0]['gpu_free_mib'])
            self.assertEqual(observed[0]['required_gpu_mib'], 20480)
            self.assertEqual(observed[0]['required_ram_mib'], 20480)
            self.assertIn('TimeoutExpired', observed[0]['query_error'])
            self.assertEqual(final['query_timeouts_this_wait'], 2)
            self.assertTrue(final['admitted'])
            self.assertNotIn('query_error', final)

    def test_unknown_probe_error_still_stops(self):
        with patch.object(resource_wait, 'snapshot', side_effect=ValueError('bad reading')), \
                patch.object(resource_wait.time, 'sleep') as sleep:
            with self.assertRaisesRegex(ValueError, 'bad reading'):
                resource_wait.wait_for_resources(Path('/unused'), 2)
            sleep.assert_not_called()

    def test_versioned_snapshot_checks_executed_supervisor_and_runner(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            version = root / 'repairs/v2'
            (version / 'runner').mkdir(parents=True)
            supervisor = version / 'supervisor.py'
            supervisor.write_text('version two')
            module = version / 'runner/module.py'
            module.write_text('frozen')
            report = {'snapshot_directory': 'repairs/v2',
                      'supervisor_sha256': twenty.digest(supervisor),
                      'source_hashes': {'module.py': twenty.digest(module)}}
            self.assertEqual(twenty.verify_snapshot(root, report, supervisor), version)
            old = root / 'supervisor.py'
            old.write_text('version one')
            with self.assertRaisesRegex(ValueError, 'Supervisor source changed'):
                twenty.verify_snapshot(root, report, old)
            module.write_text('modified')
            with self.assertRaisesRegex(ValueError, 'Frozen source changed'):
                twenty.verify_snapshot(root, report, supervisor)

    def test_legacy_snapshot_location_remains_supported(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            supervisor = root / 'supervisor.py'
            supervisor.write_text('original')
            report = {'supervisor_sha256': twenty.digest(supervisor), 'source_hashes': {}}
            self.assertEqual(twenty.verify_snapshot(root, report, supervisor), root)

    def test_completed_result_mutation_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'result.json'; path.write_text('{}')
            report={'inherited_episodes':[{'episode_index':5,'result':str(path),'sha256':'wrong'}], 'attempts':[]}
            with self.assertRaisesRegex(ValueError,'Completed result changed'):
                twenty.collect(report)


if __name__ == '__main__':
    unittest.main()
