import copy
import json
from pathlib import Path
import tempfile
import unittest

from gpt6_eval.core import write_json
from gpt6_eval.extension import reference
from gpt6_eval.extension_rolling import validate_retry_failure


class CapacityRetryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.output = Path(self.tmp.name) / 'attempt_0001'
        self.result_path = self.output / 'result.json'
        self.events_path = self.output / 'episode_0000/private/codex.events.jsonl'
        self.events_path.parent.mkdir(parents=True)
        message = 'Selected model is at capacity. Please try a different model.'
        self.events = [{'type': 'error', 'message': message},
                       {'type': 'turn.failed', 'error': {'message': message}}]
        self.events_path.write_text(''.join(json.dumps(row) + '\n' for row in self.events))
        self.result = {'complete': False, 'eligible_for_extension_score': False,
                       'eligible_for_gpt6_score': False, 'infrastructure_error': None,
                       'episodes': [{'outcome': 'infrastructure_error', 'terminated_reason': 'error',
                                     'official_success': False, 'error': {
                                         'error': 'RuntimeError: Codex process failed with exit code 1',
                                         'policy_failure': False}}],
                       'extension': {'state': 'unresolved', 'success': None, 'lscr': None,
                                     'replay_validated': True, 'replay_validation': {'state': 'verified'}}}
        self.approved = {'cause': 'codex_model_capacity', 'failed_events': reference(self.events_path)}

    def check(self, result=None, approved=None):
        write_json(self.result_path, self.result if result is None else result)
        return validate_retry_failure({'output': str(self.output), 'result': reference(self.result_path)},
                                      self.approved if approved is None else approved)

    def test_nested_runtime_infrastructure_error_requires_terminal_capacity_evidence(self):
        self.check()

    def test_no_complete_or_score_eligible_attempt_can_retry(self):
        for field in ('complete', 'eligible_for_extension_score', 'eligible_for_gpt6_score'):
            with self.subTest(field=field):
                result = copy.deepcopy(self.result)
                result[field] = True
                result['infrastructure_error'] = 'misleading aggregate error'
                with self.assertRaisesRegex(ValueError, 'Valid scored'):
                    self.check(result)

    def test_policy_failure_rejected_even_with_capacity_event(self):
        result = copy.deepcopy(self.result)
        result['episodes'][0]['error']['policy_failure'] = True
        with self.assertRaisesRegex(ValueError, 'infrastructure episode'):
            self.check(result)

    def test_replay_divergence_cannot_authorize_retry(self):
        result = copy.deepcopy(self.result)
        result['extension']['replay_validation']['state'] = 'diverged'
        result['infrastructure_error'] = 'service error after divergence'
        with self.assertRaisesRegex(ValueError, 'divergence'):
            self.check(result)

    def test_no_unknown_cause_or_generic_cli_exit_retry(self):
        with self.assertRaisesRegex(ValueError, 'Undiagnosed'):
            self.check(approved={})
        self.events[-1]['error']['message'] = 'Unknown failure'
        self.events_path.write_text(''.join(json.dumps(row) + '\n' for row in self.events))
        self.approved['failed_events'] = reference(self.events_path)
        with self.assertRaisesRegex(ValueError, 'terminal CLI'):
            self.check()

    def test_modified_or_other_attempt_evidence_rejected(self):
        other = self.output.parent / 'other.events.jsonl'
        other.write_bytes(self.events_path.read_bytes())
        with self.assertRaisesRegex(ValueError, 'evidence changed'):
            self.check(approved={**self.approved, 'failed_events': reference(other)})
        self.events_path.write_text(self.events_path.read_text() + '\n')
        with self.assertRaisesRegex(ValueError, 'evidence changed'):
            self.check()

    def test_recovered_or_scored_transcript_cannot_retry(self):
        with self.events_path.open('a') as stream:
            stream.write(json.dumps({'type': 'turn.completed'}) + '\n')
        self.approved['failed_events'] = reference(self.events_path)
        with self.assertRaisesRegex(ValueError, 'terminal CLI'):
            self.check()

    def test_missing_replay_and_known_outcomes_are_rejected(self):
        for field, value in [('replay_validated', False), ('state', 'verified'),
                             ('success', False), ('success', True), ('lscr', 0.25)]:
            with self.subTest(field=field, value=value):
                result = copy.deepcopy(self.result)
                result['extension'][field] = value
                with self.assertRaisesRegex(ValueError, 'replay or outcome'):
                    self.check(result)


if __name__ == '__main__':
    unittest.main()
