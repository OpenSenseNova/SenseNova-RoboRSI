import hashlib
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import h5py
import numpy as np

from gpt6_eval.core import canonical, write_json
from gpt6_eval.extension import (SETTING, baseline_metrics, load_source, numeric_digest,
                                 paired_summary, round_robin_slots, storage_admission)
from gpt6_eval.extension_episode import ExtensionEpisode, incremental_usage
from gpt6_eval.extension_simulator import PrefixValidator, boundary_metrics
from gpt6_eval.isolation import command
from gpt6_eval.knowledge import file_hash
from gpt6_eval.telemetry import TOKEN_FIELDS


class ExtensionFixture(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.root = self.directory / 'source'
        self.root.mkdir()
        self.private = self.root / 'episode_0000/private'
        self.config = {'model': 'gpt-6-astra', 'reasoning_effort': 'max',
                       'start_episode': 5, 'num_episodes': 1, 'observation_profile': 'baseline_4cam',
                       'decision_timeout_s': None, 'evaluation_setting': 'task_icl_v3', 'task_packages': {}}
        self.robot = {'robot_key': 'robot', 'active_joint_names': ['joint'], 'position_limits': [[-1, 1]],
                      'action_semantics': 'absolute active-joint position targets',
                      'joint_units': ['radian_or_metre_per_URDF_type'], 'physics_hz': 60, 'policy_hz': 20}
        self.result = {'complete': True, 'eligible_for_gpt6_score': True,
                       'evaluation_setting': 'task_icl_v3', 'infrastructure_error': None,
                       'official_results_path': 'private/benchmark/per_episode.jsonl',
                       'trajectories': ['private/trajectories/failure/episode_000005.hdf5'],
                       'episodes': [{'episode_index': 5, 'outcome': 'failure', 'official_success': False,
                                     'terminated_reason': 'max_steps', 'error': None}]}
        self.manifest = {'task_id': 3, 'official_policy_budget': 2, 'executed_policy_budget': 2,
                         'config': self.config}
        self.official = {'episode_index': 5, 'steps': 6, 'success': False,
                         'terminated_reason': 'max_steps', 'latched_stage_completion_rate': 0.5,
                         'stage_completion': {'one': True, 'two': False},
                         'current_stage_completion': {'one': False, 'two': False},
                         'stage_first_completion_step': {'one': 0, 'two': None}}
        write_json(self.root / 'result.json', self.result)
        write_json(self.root / 'private/manifest.json', self.manifest)
        write_json(self.root / self.result['official_results_path'], self.official)
        write_json(self.private / 'robot.json', self.robot)
        self.session = self.private / 'codex-home/sessions/2026/10/01/one.jsonl'
        self.session.parent.mkdir(parents=True)
        self.context = {'type': 'turn_context', 'payload': {'model': 'gpt-6-astra', 'effort': 'max', 'turn_id': 'old'}}
        usage = {'input_tokens': 100, 'output_tokens': 20}
        self.session.write_bytes(canonical({'type': 'session_meta', 'payload': {
            'id': '12345678-1234-1234-1234-123456789abc'}}) + canonical(self.context)
            + canonical({'type': 'event_msg', 'payload': {'type': 'token_count',
                         'info': {'total_token_usage': usage}}}))
        self.actions = np.asarray([[0.1], [0.2]], dtype=np.float32)
        request = {'decision': 0, 'payload': {'actions': self.actions.tolist()}}
        write_json(self.private / 'requests/000000.json', request)
        write_json(self.private / 'actions/000000.json', {'decision': 0, 'policy_step': 0,
            'actions': self.actions.tolist(), 'request_sha256': file_hash(self.private / 'requests/000000.json'),
            'model_evidence': [{'model': 'gpt-6-astra', 'event_sha256': hashlib.sha256(canonical(self.context)).hexdigest()}]})
        self.trajectory = self.root / self.result['trajectories'][0]
        self.trajectory.parent.mkdir(parents=True)
        with h5py.File(self.trajectory, 'w') as archive:
            archive.attrs['finalized'] = True
            archive.attrs['official_success'] = False
            archive['meta/frame_count'] = 2
            archive['meta/episode_index'] = 5
            archive['meta/scene_generalization_sample'] = '{}'
            archive['action/action_names'] = np.asarray(['joint'], dtype=h5py.string_dtype())
            archive['action/commanded'] = self.actions
            archive['robot/qpos'] = np.zeros((2, 1), dtype=np.float32)
            archive['robot/qvel'] = np.zeros((2, 1), dtype=np.float32)
            archive['robot/root_state_world'] = np.zeros((2, 13), dtype=np.float32)
            archive['objects/object/pose_world'] = np.zeros((2, 7), dtype=np.float32)
            archive['time/physics_step'] = np.array([0, 3])
        (self.root / 'episode_0000/policy/input/observations/000000').mkdir(parents=True)
        (self.root / 'episode_0000/policy/controller.py').write_text('print("same episode")\n')
        self.seal()

    def seal(self):
        write_json(self.root / 'integrity.json', {
            str(path.relative_to(self.root)): file_hash(path)
            for path in self.root.rglob('*') if path.is_file() and path.name != 'integrity.json'})

    def source(self):
        return load_source(self.root, task_id=3, config=self.config)

    def episode(self):
        source = self.source()
        episode = ExtensionEpisode(self.directory / 'new/episode_0000', self.config, 'task', 'robot', {},
                                   20, self.directory / 'binary', self.directory / 'auth', 'continue', source=source)
        self.addCleanup(episode.encoder.shutdown)
        return episode


class ContractTests(ExtensionFixture):
    def test_exact_1x_prefix_gets_only_nine_additional_budgets(self):
        baseline = baseline_metrics(self.result, self.manifest, self.official)
        self.assertTrue(baseline['eligible_for_extension'])
        self.assertEqual((baseline['standard_policy_steps'], baseline['additional_policy_steps'],
                          baseline['total_policy_steps']), (2, 18, 20))

    def test_success_is_never_extended_even_with_low_lscr(self):
        self.result['episodes'][0].update(outcome='success', official_success=True, terminated_reason='stable_success')
        self.official.update(success=True, terminated_reason='stable_success', steps=3, latched_stage_completion_rate=0)
        baseline = baseline_metrics(self.result, self.manifest, self.official)
        self.assertFalse(baseline['eligible_for_extension'])
        self.assertEqual(baseline['lscr'], 0)

    def test_early_policy_failure_is_carried_not_restarted(self):
        self.result['episodes'][0].update(terminated_reason='error', error={'policy_failure': True})
        self.official.update(steps=3, terminated_reason='error')
        self.assertFalse(baseline_metrics(self.result, self.manifest, self.official)['eligible_for_extension'])

    def test_invalid_or_nonstandard_source_refused(self):
        self.manifest['executed_policy_budget'] = 20
        with self.assertRaisesRegex(ValueError, '1x budget'):
            baseline_metrics(self.result, self.manifest, self.official)

    def test_round_robin_covers_every_task_before_next_index(self):
        self.assertEqual(round_robin_slots([26, 3], 3), [(3, 5), (26, 5), (3, 6), (26, 6), (3, 7), (26, 7)])
        self.assertEqual(round_robin_slots([3, 26], 5)[:6], round_robin_slots([3, 26], 3))
        with self.assertRaises(ValueError):
            round_robin_slots([3], 4)

    def test_paired_denominator_includes_carried_successes_and_failures(self):
        baseline = baseline_metrics(self.result, self.manifest, self.official)
        rows = [{'task_id': 3, 'episode_index': 5, 'baseline': baseline,
                 'extension': {'state': 'verified', 'setting': SETTING, 'replay_validated': True,
                               'success': True, 'lscr': 1.0}},
                {'task_id': 3, 'episode_index': 6, 'baseline': {**baseline, 'eligible_for_extension': False,
                                                             'success': True, 'lscr': 0.0}},
                {'task_id': 3, 'episode_index': 7, 'baseline': {**baseline, 'eligible_for_extension': False}}]
        summary = paired_summary(rows, 3)
        self.assertAlmostEqual(summary['baseline_sr'], 1 / 3)
        self.assertAlmostEqual(summary['extended_sr'], 2 / 3)
        self.assertAlmostEqual(summary['extended_lscr'], 0.5)
        self.assertEqual(summary['extension_rescue_rate'], 1)

    def test_divergent_or_missing_extension_never_counted_as_failure_or_dropped(self):
        baseline = baseline_metrics(self.result, self.manifest, self.official)
        row = {'task_id': 3, 'episode_index': 5, 'baseline': baseline, 'extension': {'state': 'diverged'}}
        summary = paired_summary([row], 1)
        self.assertFalse(summary['complete'])
        self.assertIsNone(summary['extended_sr'])
        self.assertEqual(summary['pending_or_invalid'], [[3, 5]])
        with self.assertRaises(ValueError):
            paired_summary([row], 3)

    def test_storage_warning_blocks_before_gpu_or_inference(self):
        from datetime import datetime, timezone
        path = self.directory / 'status.json'
        write_json(path, {'checked_at': datetime.now(timezone.utc).isoformat(),
                          'external_action_required': {'kind': 'smart_sector_warning'}})
        with self.assertRaisesRegex(ValueError, 'hardware warning'):
            storage_admission(path)

    def test_readonly_probe_preserves_unresolved_hardware_blocker(self):
        from gpt6_eval.extension_campaign import refresh_storage
        probe = self.directory / 'probe.py'
        probe.write_text('def inspect_storage(snapshot, disk_usage, kernel_check):\n'
                         '    snapshot["extended_disk_attributes"] = {"197": 0, "198": 0}\n')
        blocker = self.directory / 'blocker.json'
        write_json(blocker, {'state': 'external_action_required', 'reason': 'Diagnosis pending'})
        plan = {'storage_probe': {'path': str(probe), 'sha256': file_hash(probe)},
                'storage_blocker': str(blocker)}
        status = refresh_storage(plan, self.directory / 'control')
        with self.assertRaisesRegex(ValueError, 'hardware warning'):
            storage_admission(status)
        self.assertEqual(json.loads(blocker.read_text())['state'], 'external_action_required')

    def test_drained_repair_queue_is_not_finished(self):
        from gpt6_eval.extension_campaign import original_gpu_queue_finished
        self.assertFalse(original_gpu_queue_finished({'state': 'needs_repair', 'jobs': []}))
        self.assertFalse(original_gpu_queue_finished({'state': 'running', 'jobs': []}))
        finished = {'state': 'audits_finished_pending_final_recheck', 'jobs': [{'ended_at': 'now'}]}
        self.assertTrue(original_gpu_queue_finished(finished))
        self.assertFalse(original_gpu_queue_finished({**finished, 'error': 'Unresolved'}))
        self.assertFalse(original_gpu_queue_finished({**finished, 'jobs': [{}]}))


class PriorityCampaignTests(ExtensionFixture):
    def setup_registry(self):
        from gpt6_eval.extension import reference
        self.original = {'task_id': 3, 'episode_index': 5, 'result': str(self.root / 'result.json'),
                         'sha256': file_hash(self.root / 'result.json')}
        proof_path = self.directory / 'audit.json'
        write_json(proof_path, {'state': 'verified', 'named_results_verified': True, 'validity_verified': True,
                                'errors': [], 'result': self.original['result'], 'result_sha256': self.original['sha256']})
        self.selected = {'ref': self.original, 'audit': reference(proof_path), 'audit_key': 'original_03_05'}
        self.priority_plan = {'source_registry': str(self.directory / 'registry.json'),
                              'priority_authorization': {'identity': 'authorized'}, 'source_certifier_release': {'identity': 'frozen'}}
        self.registry = {'authorization': self.priority_plan['priority_authorization'],
                         'certifier_release': self.priority_plan['source_certifier_release'],
                         'slots': {'03_05': {'state': 'source_ready', 'source': self.selected}}}
        write_json(Path(self.priority_plan['source_registry']), self.registry)
        return {'task_id': 3, 'episode_index': 5, 'original': self.original}

    def test_priority_source_uses_named_certificate_without_waiting_for_clean260(self):
        from gpt6_eval.extension_campaign import supplemental_source
        slot = self.setup_registry()
        selected, unavailable = supplemental_source(self.priority_plan, {'damage_slots': []}, slot)
        self.assertEqual(selected, self.selected)
        self.assertIsNone(unavailable)

    def test_unavailable_source_is_explicit_not_a_new_rerun(self):
        from gpt6_eval.extension_campaign import supplemental_source
        slot = self.setup_registry()
        self.registry['slots']['03_05'] = {'state': 'source_unavailable', 'reason': 'damaged'}
        write_json(Path(self.priority_plan['source_registry']), self.registry)
        selected, unavailable = supplemental_source(self.priority_plan, {'damage_slots': []}, slot)
        self.assertIsNone(selected)
        self.assertEqual(unavailable['state'], 'source_unavailable')

    def test_source_registry_wrong_authority_is_refused(self):
        from gpt6_eval.extension_campaign import supplemental_source
        slot = self.setup_registry()
        self.priority_plan['priority_authorization'] = {'identity': 'changed'}
        with self.assertRaisesRegex(ValueError, 'authorization'):
            supplemental_source(self.priority_plan, {}, slot)

    def test_priority_admission_preserves_existing_startup_reservation(self):
        from gpt6_eval.extension import reference
        from gpt6_eval.extension_campaign import original_gpu_queue_finished
        control = self.directory / 'control'
        binding = {'authorization': {'identity': 'authorized'}}
        write_json(control / 'priority_hold.json', binding)
        plan = {'controller': str(control / 'controller.json'),
                'priority_hold': reference(control / 'priority_hold.json'),
                'priority_authorization': binding['authorization']}
        module = SimpleNamespace(validated_priority_hold=lambda state, folder: binding)
        controller = {'jobs': [{'output': str(self.directory / 'existing')}]}
        with patch('gpt6_eval.extension_campaign.storage_probe_module', return_value=module):
            self.assertFalse(original_gpu_queue_finished(controller, plan))
            write_json(self.directory / 'existing/episode_0000/private/startup_ready.json', {'ready': True})
            self.assertTrue(original_gpu_queue_finished(controller, plan))

    def qualification(self, divergent=False):
        from gpt6_eval.extension import reference
        self.setup_registry()
        path = self.directory / 'qualification.json'
        result_path = self.directory / 'probe_result.json'
        baseline = baseline_metrics(self.result, self.manifest, self.official)
        result = {'evaluation_setting': SETTING, 'baseline': baseline, 'replay_probe_verified': not divergent,
                  'extension': {'source_result': reference(self.root / 'result.json'),
                                'replay_validation': {'state': 'diverged' if divergent else 'verified'}}}
        write_json(result_path, result)
        write_json(path, {'authorization': self.priority_plan['priority_authorization'], 'source': self.selected,
                          'result': reference(result_path), 'state': 'needs_diagnosis' if divergent else 'verified',
                          'returncode': 1 if divergent else 0})
        self.priority_plan['qualification_status'] = str(path)
        return {'slots': {}, 'probe_verified': False}

    def test_verified_probe_is_imported_without_repeating_it(self):
        from gpt6_eval.extension_campaign import import_qualification
        state = self.qualification()
        self.assertTrue(import_qualification(self.priority_plan, state))
        self.assertTrue(state['probe_verified'])
        self.assertEqual(state['slots']['03_05']['state'], 'ready')

    def test_divergent_probe_is_unresolved_and_other_tasks_can_be_probed(self):
        from gpt6_eval.extension_campaign import import_qualification
        state = self.qualification(divergent=True)
        self.assertTrue(import_qualification(self.priority_plan, state))
        self.assertFalse(state['probe_verified'])
        self.assertEqual(state['slots']['03_05']['state'], 'diverged')

    def test_external_probe_in_progress_blocks_duplicate_gpu_admission(self):
        from gpt6_eval.extension_campaign import import_qualification
        state = self.qualification()
        path = Path(self.priority_plan['qualification_status'])
        record = json.loads(path.read_text())
        write_json(path, {**record, 'state': 'running'})
        self.assertFalse(import_qualification(self.priority_plan, state))
        self.assertEqual(state['slots'], {})


class SourceTests(ExtensionFixture):
    def test_source_load_checks_actions_session_and_numeric_trajectory(self):
        source = self.source()
        self.assertEqual(source['session_id'], '12345678-1234-1234-1234-123456789abc')
        self.assertEqual(source['evidence']['numeric_trajectory_sha256'], numeric_digest(source['arrays']))
        self.assertFalse(source['evidence']['terminal_checkpoint_available'])

    def test_changed_accepted_action_is_refused(self):
        (self.private / 'actions/000000.json').write_text('{}')
        with self.assertRaisesRegex(ValueError, 'hash mismatch'):
            self.source()

    def test_trajectory_action_corruption_is_refused(self):
        with h5py.File(self.trajectory, 'a') as archive:
            archive['action/commanded'][1] = [0.5]
        with self.assertRaisesRegex(ValueError, 'differs from accepted actions'):
            self.source()

    def test_multiple_sessions_and_cross_episode_configuration_refused(self):
        self.session.with_name('other.jsonl').write_bytes(self.session.read_bytes())
        with self.assertRaisesRegex(ValueError, 'exactly one'):
            self.source()
        self.session.with_name('other.jsonl').unlink()
        with self.assertRaisesRegex(ValueError, 'original configuration'):
            load_source(self.root, task_id=3, config={**self.config, 'start_episode': 6})

    def test_symlink_in_source_required_data_is_refused(self):
        target = self.private / 'robot.json'
        moved = self.directory / 'robot.json'
        target.rename(moved)
        target.symlink_to(moved)
        with self.assertRaisesRegex(ValueError, 'symlink'):
            self.source()


class ReplayTests(ExtensionFixture):
    def validator(self):
        return PrefixValidator(self.source(), self.directory / 'validation.json')

    def test_boundary_read_does_not_finalize_or_mutate_metric_trackers(self):
        stages = SimpleNamespace(latched_stage_completion_rate=0.5,
                                 completed={'one': True}, current_completed={'one': False},
                                 first_completed_step={'one': 2})
        tracker = SimpleNamespace(_stage_tracker=SimpleNamespace(_result=lambda: stages),
                                  finalize=Mock(side_effect=AssertionError('Do not finalize live metrics')))
        metric = boundary_metrics(tracker, SimpleNamespace(stable_success=False))
        self.assertEqual(metric.latched_stage_completion_rate, 0.5)
        metric.stage_completion['one'] = False
        self.assertTrue(stages.completed['one'])
        tracker.finalize.assert_not_called()

    def test_every_numeric_sample_and_metric_history_must_match(self):
        validator = self.validator()
        for index in range(2):
            validator.sample({name: value[index] for name, value in validator.source['arrays'].items()})
        metric = SimpleNamespace(stable_success=False, **{name: self.official[name] for name in (
            'latched_stage_completion_rate', 'stage_completion', 'current_stage_completion', 'stage_first_completion_step')})
        validator.boundary(metric)
        receipt = json.loads((self.directory / 'validation.json').read_text())
        self.assertEqual(receipt['state'], 'verified')
        self.assertFalse(receipt['terminal_frame_comparison_available'])

    def test_object_divergence_fails_without_issuing_new_actions(self):
        validator = self.validator()
        values = {name: value[0].copy() for name, value in validator.source['arrays'].items()}
        values['objects/object/pose_world'][0] = 0.01
        with self.assertRaisesRegex(ValueError, 'Replay divergence'):
            validator.sample(values)
        self.assertEqual(json.loads((self.directory / 'validation.json').read_text())['state'], 'diverged')

    def test_quaternion_sign_equivalence_and_velocity_threshold(self):
        validator = self.validator()
        before = np.zeros(13)
        before[3] = 1
        after = before.copy()
        after[3] = -1
        validator.compare('robot/root_state_world', after, before)
        after[7] = 0.1
        with self.assertRaises(ValueError):
            validator.compare('robot/root_state_world', after, before)

    def test_missing_object_state_is_not_silently_ignored(self):
        validator = self.validator()
        values = {name: value[0] for name, value in validator.source['arrays'].items()
                  if not name.startswith('objects/')}
        with self.assertRaisesRegex(ValueError, 'Missing replay state'):
            validator.sample(values)

    def test_prefix_uses_saved_chunks_without_starting_model(self):
        episode = self.episode()
        episode.start = Mock(side_effect=AssertionError('No model during prefix'))
        raw = {'language': 'task', 'robot_metadata': self.robot, 'joint_action': {'vector': np.zeros(1)}}
        np.testing.assert_array_equal(episode.action(raw), self.actions)
        episode.observe(raw)
        self.assertEqual(episode.index, 2)
        episode.start.assert_not_called()
        with self.assertRaises(FileNotFoundError):
            episode.action(raw)
        episode.start.assert_not_called()

    def test_new_model_identity_required_not_just_copied_old_context(self):
        episode = self.episode()
        with self.assertRaisesRegex(ValueError, 'No new CLI'):
            episode.model_evidence()
        with episode.telemetry.session_path.open('ab') as stream:
            stream.write(canonical({'type': 'turn_context', 'payload': {'model': 'gpt-6-astra', 'effort': 'max', 'turn_id': 'new'}}))
        self.assertEqual(len(episode.model_evidence()), 1)

    def test_only_same_episode_public_input_is_mounted_readonly(self):
        episode = self.episode()
        binary = self.directory / 'codex'
        binary.touch()
        binary.with_name('codex-code-mode-host').touch()
        with patch('gpt6_eval.isolation.shutil.which', return_value='/usr/bin/bwrap'):
            argv = command(episode.workspace, episode.home, episode.interface, binary, self.config,
                           resume_session=episode.source['session_id'], prior_inputs=episode.prior_inputs)
        self.assertEqual(argv[-3:], ['resume', episode.source['session_id'], '-'])
        offset = argv.index('/prior_input')
        self.assertEqual(argv[offset - 2], '--ro-bind')
        self.assertNotIn(str(self.root / 'private'), argv)
        self.assertNotIn(str(self.root), argv)

    def test_policy_can_give_up_but_not_declare_success(self):
        from gpt6_eval.bridge import PolicyError
        episode = self.episode()
        episode.index = 3
        with self.assertRaises(PolicyError):
            episode.validate_submission({'give_up': 'Object visibly fell out of reach'}, 18, 1)
        self.assertTrue((episode.private / 'policy_stop.json').is_file())
        with self.assertRaises(ValueError):
            episode.validate_submission({'success': True}, 18, 1)

    def test_source_bytes_are_unchanged_by_context_copy(self):
        before = {str(path): file_hash(path) for path in self.root.rglob('*') if path.is_file()}
        self.episode()
        self.assertEqual(before, {str(path): file_hash(path) for path in self.root.rglob('*') if path.is_file()})


class ResumedAccountingTests(unittest.TestCase):
    def test_only_added_tokens_are_reported(self):
        before = dict.fromkeys(TOKEN_FIELDS, 10)
        after = dict.fromkeys(TOKEN_FIELDS, 30)
        result = incremental_usage(before, after, True)
        self.assertEqual(result['input_tokens'], 20)
        self.assertEqual(result['status'], 'partial')

    def test_missing_or_reset_counters_are_not_zero(self):
        before = dict.fromkeys(TOKEN_FIELDS, 10)
        self.assertIsNone(incremental_usage(before, None, True)['total_tokens'])
        self.assertEqual(incremental_usage(before, dict.fromkeys(TOKEN_FIELDS, 2), True)['status'], 'unavailable')
        self.assertEqual(incremental_usage(before, None, False)['total_tokens'], 0)


class RetentionTests(unittest.TestCase):
    def setUp(self):
        from gpt6_eval.extension_retention import PROFILE
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.source = self.directory / 'source'
        self.source.mkdir()
        (self.source / 'kept.png').write_bytes(b'original image')
        self.root = self.directory / 'extension'
        self.private = self.root / 'episode_0000/private'
        write_json(self.root / 'private/extension_spec.json', {
            'setting': SETTING, 'source': str(self.source), 'image_retention': PROFILE,
            'standard_policy_steps': 2})
        write_json(self.private / 'telemetry.json', {'finalized': True})
        write_json(self.private / 'decisions/000001.json', {'policy_step': 4})
        self.folders = []
        from gpt6_eval.core import CAMERAS
        for base in (self.private / 'observations', self.root / 'episode_0000/policy/input/observations'):
            base.mkdir(parents=True)
            (base / '000000').symlink_to(self.source, target_is_directory=True)
            for index in (2, 3, 4, 5):
                folder = base / f'{index:06d}'
                folder.mkdir()
                self.folders.append(folder)
                cameras = []
                for camera in CAMERAS['baseline_4cam']:
                    image = folder / (camera + '.png')
                    image.write_bytes(b'new temporary image')
                    cameras.append({'name': camera, 'sha256': file_hash(image)})
                write_json(folder / 'observation.json', {'policy_step': index, 'cameras': cameras})
        (self.private / 'actions').mkdir()
        (self.private / 'actions/keep.json').write_text('{}')

    def test_only_new_intermediate_pngs_are_removed_after_finalization(self):
        from gpt6_eval.extension_retention import prune_intermediate_images
        summary = prune_intermediate_images(self.root)
        self.assertEqual(summary['files_deleted'], 8)
        self.assertEqual(summary['kept_policy_steps'], [2, 4, 5])
        for folder in self.folders:
            self.assertTrue((folder / 'observation.json').is_file())
            self.assertEqual(len(list(folder.glob('*.png'))), 0 if folder.name == '000003' else 4)
        self.assertEqual((self.source / 'kept.png').read_bytes(), b'original image')
        self.assertTrue((self.private / 'actions/keep.json').is_file())
        receipt = self.root / 'private/intermediate_image_retention'
        self.assertEqual(len((receipt / 'deleted.jsonl').read_text().splitlines()), 8)
        with self.assertRaisesRegex(ValueError, 'Prior pruning intention'):
            prune_intermediate_images(self.root)

    def test_active_episode_retains_every_image(self):
        from gpt6_eval.extension_retention import prune_intermediate_images
        write_json(self.private / 'telemetry.json', {'finalized': False})
        with self.assertRaisesRegex(ValueError, 'finalized'):
            prune_intermediate_images(self.root)
        self.assertEqual(sum(len(list(folder.glob('*.png'))) for folder in self.folders), 32)

    def test_hardlinked_original_or_named_file_is_never_pruned(self):
        import os
        from gpt6_eval.extension_retention import prune_intermediate_images
        image = next(folder for folder in self.folders if folder.name == '000003') / 'cam_stereo_left.png'
        image.unlink()
        os.link(self.source / 'kept.png', image)
        with self.assertRaisesRegex(ValueError, 'linked/foreign'):
            prune_intermediate_images(self.root)
        self.assertTrue(image.is_file())


class CampaignSelectionTests(ExtensionFixture):
    def test_first_certified_replacement_not_best_outcome_is_selected(self):
        from gpt6_eval.extension_campaign import select_source
        original = {'task_id': 3, 'episode_index': 5, 'result': str(self.root / 'result.json'),
                    'sha256': file_hash(self.root / 'result.json')}
        audits = {}
        for attempt in (2, 1):
            path = self.directory / f'audit_{attempt}.json'
            ref = {**original, 'result': f'/replacement_{attempt}/result.json'}
            write_json(path, {'state': 'verified', 'named_results_verified': True, 'validity_verified': True,
                              'errors': [], 'result': ref['result'], 'result_sha256': ref['sha256']})
            audits[f'replacement_03_05_{attempt:04d}'] = {
                'state': 'verified', 'path': str(path), 'sha256': file_hash(path), 'ref': ref}
        selected = select_source(original, {'damage_slots': [[3, 5]], 'audits': audits})
        self.assertEqual(selected['ref']['result'], '/replacement_1/result.json')

    def test_uncertified_source_does_not_start(self):
        from gpt6_eval.extension_campaign import select_source
        original = {'task_id': 3, 'episode_index': 5, 'result': str(self.root / 'result.json'),
                    'sha256': file_hash(self.root / 'result.json')}
        self.assertIsNone(select_source(original, {'damage_slots': [], 'audits': {}}))


if __name__ == '__main__':
    unittest.main()
