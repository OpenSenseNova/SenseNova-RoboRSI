import json
import os
import shutil
from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from gpt6_eval.extension_episode import ExtensionEpisode
from gpt6_eval.isolation import command


class SQLitePlacementTests(unittest.TestCase):
    def setUp(self):
        if not shutil.which('bwrap'):
            self.skipTest('Linux bubblewrap required')
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        # These tests write tiny fixtures; simulate capacity independently of the host disk.
        capacity = patch('gpt6_eval.extension_episode.shutil.disk_usage',
                         return_value=SimpleNamespace(free=4 * 1024 ** 3))
        capacity.start()
        self.addCleanup(capacity.stop)
        for name in ('sqlite', 'attempt/policy/input', 'attempt/home', 'attempt/interface', 'prior/policy/input'):
            (self.root / name).mkdir(parents=True)
        binary = self.root / 'bin/codex'
        binary.parent.mkdir()
        binary.touch()
        binary.with_name('codex-code-mode-host').touch()
        self.episode = SimpleNamespace(root=self.root / 'attempt', workspace=self.root / 'attempt/policy',
            home=self.root / 'attempt/home', interface=self.root / 'attempt/interface',
            private=self.root / 'attempt/private', binary=binary, config={'reasoning_effort': 'max'},
            source={'session_id': '12345678-1234-1234-1234-123456789abc'}, prior_inputs=self.root / 'prior/policy/input')
        environment = patch.dict(os.environ, {'GPT6_EVAL_EXTENSION_SQLITE_ROOT': str(self.root / 'sqlite')})
        environment.start()
        self.addCleanup(environment.stop)

    def test_only_storage_mount_and_option_change(self):
        episode = self.episode
        original = command(episode.workspace, episode.home, episode.interface, episode.binary, episode.config,
                           resume_session=episode.source['session_id'], prior_inputs=episode.prior_inputs)
        repaired = ExtensionEpisode.policy_command(episode)
        info = json.loads((episode.private / 'cli_storage.json').read_text())
        self.assertTrue(Path(info['sqlite_home']).is_dir())
        position = repaired.index(info['sqlite_home']) - 1
        self.assertEqual(repaired[position:position + 3], ['--bind', info['sqlite_home'], '/codex-runtime'])
        del repaired[position:position + 3]
        position = repaired.index('sqlite_home="/codex-runtime"') - 1
        del repaired[position:position + 2]
        self.assertEqual(original, repaired)
        with self.assertRaises(FileExistsError):
            ExtensionEpisode.policy_command(episode)

    def test_symlink_root_is_rejected(self):
        link = self.root / 'link'
        link.symlink_to(self.root / 'sqlite', target_is_directory=True)
        with patch.dict(os.environ, {'GPT6_EVAL_EXTENSION_SQLITE_ROOT': str(link)}):
            with self.assertRaisesRegex(ValueError, 'real directory'):
                ExtensionEpisode.policy_command(self.episode)

    def test_root_reserve_is_not_lowered(self):
        with patch('gpt6_eval.extension_episode.shutil.disk_usage', return_value=SimpleNamespace(free=2 * 1024 ** 3 - 1)):
            with self.assertRaisesRegex(ValueError, 'reserve'):
                ExtensionEpisode.policy_command(self.episode)

    def test_actual_mount_contains_only_own_sqlite_directory(self):
        if not shutil.which('bwrap'):
            self.skipTest('Linux bubblewrap required')
        argv = ExtensionEpisode.policy_command(self.episode)
        prefix = argv[:argv.index('--')]
        other = self.root / 'sqlite/other_episode'
        other.mkdir()
        (other / 'secret').write_text('private')
        code = ("import os; assert os.path.isdir('/codex-runtime'); assert not os.path.exists('/data'); "
                "assert not os.path.exists(" + repr(str(other)) + "); "
                "assert not os.path.exists('/codex-runtime/other_episode'); print('PASS')")
        result = subprocess.run(prefix + ['--', '/usr/bin/python3', '-c', code], capture_output=True, text=True, check=True)
        self.assertEqual(result.stdout.strip(), 'PASS')


if __name__ == '__main__':
    unittest.main()
