import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

spec=importlib.util.spec_from_file_location('campaign51',Path(__file__).resolve().parents[1]/'scripts/run_icl_campaign.py')
campaign=importlib.util.module_from_spec(spec);spec.loader.exec_module(campaign)

class Task51AdmissionTests(unittest.TestCase):
    def test_no_implicit_exception(self):
        self.assertEqual(campaign.task51_training_options(Path('.'),{}, {'task_id':51}),[])
        self.assertEqual(campaign.task51_training_options(Path('.'),{'task51_legacy_provenance_authorization':{}},{'task_id':60}),[])

    def test_hash_and_scope_required(self):
        task={'task_id':51,'target_valid_count':10,'new_episode_indices':list(range(5,15))}
        receipt={'state':'user_authorized_task51_legacy_exception','task_id':51,
                 'dataset_revision':'b195787c65046083e6a43776b67bdf1389dfa3eb',
                 'target_valid_count':10,'new_episode_indices':list(range(5,15)),
                 'missing_provenance':'unknown','test_protocol_unchanged':True}
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);path=root/'authorization.json'
            def state_for(value):
                path.write_text(json.dumps(value))
                return {'task51_legacy_provenance_authorization':{'path':path.name,'sha256':campaign.sha(path)}}
            state=state_for(receipt)
            self.assertEqual(campaign.task51_training_options(root,state,task),['--task51-legacy-provenance'])
            path.write_text('{}')
            with self.assertRaises(ValueError):campaign.task51_training_options(root,state,task)
            for key,value in [('task_id',60),('dataset_revision','new'),('target_valid_count',5),
                              ('new_episode_indices',[5]),('missing_provenance','collection'),
                              ('test_protocol_unchanged',False),('state','requested')]:
                bad={**receipt,key:value}
                with self.assertRaises(ValueError):campaign.task51_training_options(root,state_for(bad),task)

if __name__=='__main__':unittest.main()
