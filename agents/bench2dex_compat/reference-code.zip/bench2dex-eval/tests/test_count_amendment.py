import copy
import importlib.util
from pathlib import Path
import sys
import unittest

SCRIPTS=Path(__file__).resolve().parents[1]/'scripts'
sys.path.insert(0,str(SCRIPTS))
from amend_pending_episode_counts import revised_state
from finalize_campaign_task import planned_indices, require_indices


class CountAmendmentTests(unittest.TestCase):
    def fixture(self):
        tasks=[{'task_id':tid,'target_valid_count':10,'new_episode_indices':list(range(5,15))} for tid in (9,12)]
        before={'tasks':tasks,'planned_new_valid_episodes':20,'final_valid_episode_total_including_task26':40,'protocol':{'model':'unchanged'}}
        state={'tasks':{str(t['task_id']):{**copy.deepcopy(t),'jobs':[],'valid_episodes':[]} for t in tasks}}
        state['tasks']['9']['valid_episodes']=[{'episode_index':5}]
        state['tasks']['9']['jobs']=[{'stage':'evaluation','pid':123}]
        proposed=copy.deepcopy(before);proposed['tasks'][1].update(target_valid_count=5,new_episode_indices=list(range(5,10)))
        proposed.update(planned_new_valid_episodes=15,final_valid_episode_total_including_task26=35,amendments=[{'reason':'user'}],execution_note='user amendment')
        return state,before,proposed,{'task_ids':[12]}

    def test_only_untested_task_count_changes_and_inputs_are_immutable(self):
        state,before,proposed,request=self.fixture();old=copy.deepcopy(state)
        result=revised_state(state,before,proposed,request)
        self.assertEqual(state,old)
        self.assertEqual(result['tasks']['9'],old['tasks']['9'])
        self.assertEqual(result['tasks']['12']['new_episode_indices'],list(range(5,10)))

    def test_started_test_and_unrelated_changes_fail_closed(self):
        for valid in (True,False):
            state,before,proposed,request=self.fixture()
            state['tasks']['12']['jobs']=[{'stage':'evaluation','valid':valid}]
            with self.assertRaises(ValueError):revised_state(state,before,proposed,request)
        state,before,proposed,request=self.fixture();proposed['protocol']['model']='changed'
        with self.assertRaises(ValueError):revised_state(state,before,proposed,request)

    def test_preparation_is_not_a_test_and_remains_intact(self):
        state,before,proposed,request=self.fixture();state['tasks']['12']['jobs']=[{'stage':'preparation','package':'unchanged'}]
        result=revised_state(state,before,proposed,request)
        self.assertEqual(result['tasks']['12']['jobs'],state['tasks']['12']['jobs'])

    def test_separately_completed_task26_is_retained(self):
        state,before,proposed,request=self.fixture()
        prerequisite={'task_id':26,'target_valid_count':20,'new_episode_indices':[]}
        before['tasks'].append(prerequisite.copy());proposed['tasks'].append(prerequisite.copy())
        revised_state(state,before,proposed,request)

    def test_audit_denominators_and_duplicate_detection(self):
        for count in (5,10):
            task={'target_valid_count':count,'new_episode_indices':list(range(5,5+count))}
            indices=planned_indices(task,task)
            require_indices(indices[::-1],indices)
            with self.assertRaises(ValueError):require_indices(indices[:-1],indices)
            with self.assertRaises(ValueError):require_indices(indices[:-1]+[5],indices)
            with self.assertRaises(ValueError):planned_indices({**task,'target_valid_count':20},task)
