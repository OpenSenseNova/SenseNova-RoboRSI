"""Credit-failure recovery keeps terminal evidence and immutable attempt lineage."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from gpt6_eval.core import write_json
from gpt6_eval.extension import reference
from gpt6_eval import extension_rolling as rolling
from test_extension_capacity_retry import CapacityRetryTests

MESSAGE = ('stream disconnected before completion: You have no credits remaining. '
           'Add credits to continue using the API at https://platform.openai.com/settings/organization/billing/.')


class CreditRetryTests(CapacityRetryTests):
    def setUp(self):
        super().setUp()
        self.events = [{'type': 'error', 'message': MESSAGE},
                       {'type': 'turn.failed', 'error': {'message': MESSAGE}}]
        self.events_path.write_text(''.join(json.dumps(row) + '\n' for row in self.events))
        self.approved = {'cause': 'codex_api_credit_exhausted', 'failed_events': reference(self.events_path)}

    def test_service_causes_cannot_be_substituted(self):
        self.approved['cause'] = 'codex_model_capacity'
        with self.assertRaisesRegex(ValueError, 'terminal CLI'):
            self.check()

    def test_credit_event_does_not_mask_aggregate_infrastructure_error(self):
        self.result['infrastructure_error'] = 'unrelated storage failure'
        with self.assertRaisesRegex(ValueError, 'unexpected aggregate'):
            self.check()


class RetryLineageTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.record = {'state': 'needs_diagnosis', 'source': {'ref': {'result': '/original/result.json'}},
                       'attempts': []}
        for number in (1, 2):
            output = self.root / f'attempt_{number:04d}'
            result = {'complete': False, 'eligible_for_extension_score': False,
                      'eligible_for_gpt6_score': False, 'infrastructure_error': 'diagnosed setup error'}
            write_json(output / 'result.json', result)
            self.record['attempts'].append({'slot': '34_07', 'output': str(output),
                'returncode': 1, 'result': reference(output / 'result.json')})
        self.approved = {'next_attempt': 3}

    def test_second_invalid_attempt_can_retry_only_in_attempt_three(self):
        rolling.validate_retry_lineage(self.record, '34_07', self.approved)

    def test_skip_duplicate_boolean_and_reused_numbers_rejected(self):
        for number in (1, 2, 4, True):
            with self.subTest(number=number), self.assertRaisesRegex(ValueError, 'lineage'):
                rolling.validate_retry_lineage(self.record, '34_07', {'next_attempt': number})
        for outputs in ([self.record['attempts'][1]] * 2,
                        [self.record['attempts'][1], self.record['attempts'][0]]):
            with self.assertRaisesRegex(ValueError, 'history'):
                rolling.validate_retry_lineage({**self.record, 'attempts': outputs}, '34_07', self.approved)

    def test_changed_missing_other_slot_and_result_path_rejected(self):
        for field, value in [('slot', '43_07'), ('returncode', 0),
                             ('output', str(self.root / 'other/attempt_0001')),
                             ('result', self.record['attempts'][1]['result'])]:
            record = copy.deepcopy(self.record)
            record['attempts'][0][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                rolling.validate_retry_lineage(record, '34_07', self.approved)
        (self.root / 'attempt_0001/result.json').write_text('{}')
        with self.assertRaises(ValueError):
            rolling.validate_retry_lineage(self.record, '34_07', self.approved)

    def test_any_scored_or_divergent_prior_result_forbids_retry(self):
        for changed in ({'complete': True}, {'eligible_for_extension_score': True},
                        {'eligible_for_gpt6_score': True},
                        {'extension': {'replay_validation': {'state': 'diverged'}}}):
            path = self.root / 'attempt_0001/result.json'
            write_json(path, changed)
            self.record['attempts'][0]['result'] = reference(path)
            with self.subTest(changed=changed), self.assertRaisesRegex(ValueError, 'Scored or divergent'):
                rolling.validate_retry_lineage(self.record, '34_07', self.approved)

    def test_initializer_retains_both_attempts_source_and_every_unrelated_slot(self):
        previous = {'plan': {'path': '/old', 'sha256': 'old'}, 'probe_verified': True,
                    'qualification_imported': {'path': '/probe', 'sha256': 'probe'}, 'active': {},
                    'slots': {'34_07': self.record,
                              '03_05': {'state': 'complete', 'extension': {'success': False}},
                              '06_05': {'state': 'carried', 'baseline': {'success': True}},
                              '76_07': {'state': 'ready', 'source': {'fixed': 'original'}}}}
        snapshot = self.root / 'previous.json';write_json(snapshot, previous)
        identity = {'pid': -1}
        drain = self.root / 'drain.json'
        write_json(drain, {'signal': 'already_exited', 'identity': identity, 'snapshot': reference(snapshot)})
        approved = {**self.approved, 'source': self.record['source'],
                    'failed_result': self.record['attempts'][-1]['result']}
        resolution = self.root / 'resolution.json'
        write_json(resolution, {'state': 'verified', 'predecessor_state': reference(snapshot),
                               'retries': {'34_07': approved}})
        plan = {'predecessor': {'plan': previous['plan'], 'snapshot': reference(snapshot),
                               'identity': identity, 'drain_receipt': reference(drain)},
                'retry_resolution': reference(resolution)}
        path = self.root / 'plan.json';write_json(path, plan)
        with patch.object(rolling, 'live_identity', return_value=False):
            actual = rolling.initialize(path, plan)
        for key in ('03_05', '06_05', '76_07'):
            self.assertEqual(actual['slots'][key], previous['slots'][key])
        row = actual['slots']['34_07']
        self.assertEqual(row['source'], self.record['source'])
        self.assertEqual(row['attempts'], self.record['attempts'])
        self.assertEqual(row['next_attempt'], 3)
        self.assertEqual(row['state'], 'ready')


if __name__ == '__main__':unittest.main()
