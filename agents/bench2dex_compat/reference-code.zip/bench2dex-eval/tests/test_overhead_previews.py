import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest

import cv2
import h5py
import numpy as np

spec = importlib.util.spec_from_file_location('overhead_previews', Path(__file__).parents[1] / 'scripts/export_training_overhead.py')
preview = importlib.util.module_from_spec(spec)
spec.loader.exec_module(preview)


class OverheadPreviewTests(unittest.TestCase):
    def test_selection_is_one_first_training_file_per_task(self):
        entries = [{'path': path} for path in ('dataset/03_task/replay-generalization/episode_000001.hdf5',
                   'dataset/03_task/replay-generalization/episode_000000.hdf5',
                   'dataset/03_task/testing/episode_000000.hdf5')]
        self.assertEqual(preview.select_sources(entries, (3,))[3], entries[1])

    def test_missing_task_and_unsafe_path_are_rejected(self):
        with self.assertRaises(ValueError):
            preview.select_sources([], (3,))
        with self.assertRaises(ValueError):
            preview.select_sources([{'path': '../unsafe.hdf5'}], ())

    def test_invalid_frame_is_not_replaced_with_black(self):
        with self.assertRaises(ValueError):
            preview.decode_frame(np.array([1, 2, 3], dtype=np.uint8))

    def test_raw_rgb_is_converted_to_bgr(self):
        raw = np.array([[[10, 20, 30]]], dtype=np.uint8)
        np.testing.assert_array_equal(preview.decode_frame(raw), [[[30, 20, 10]]])

    @unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'), 'ffmpeg tools required')
    def test_real_encoding_preserves_fps_and_omits_homing(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source_path = root / 'dataset/03_task/replay-generalization/episode_000000.hdf5'
            source_path.parent.mkdir(parents=True)
            with h5py.File(source_path, 'w') as source:
                source['meta/scene_generalization_sample'] = json.dumps({'_generalization_split': 'seen'})
                source['meta/effective_fps'] = 20
                source['meta/homing_start_sim_step'] = 106
                source['meta/instruction'] = 'Example task'
                source['time/sim_step'] = [100, 103, 106]
                source['cameras/cam_overhead/rgb'] = np.full((3, 16, 16, 3), 127, dtype=np.uint8)
            output = root / 'output'
            output.mkdir()
            entry = {'path': str(source_path.relative_to(root)), 'bytes': source_path.stat().st_size, 'sha256': 'test-only'}
            record = preview.export_one(root, entry, output, 'Example task')
            self.assertEqual(record['frames'], 2)
            self.assertEqual(record['duration_seconds'], .1)
            self.assertTrue(record['instruction_wording_matches'])
            stream = preview.probe_video(output / record['video'])
            self.assertEqual(stream['avg_frame_rate'], '20/1')
            self.assertEqual(stream['nb_read_frames'], '2')
            self.assertTrue((output / record['poster']).is_file())


if __name__ == '__main__':
    unittest.main()
