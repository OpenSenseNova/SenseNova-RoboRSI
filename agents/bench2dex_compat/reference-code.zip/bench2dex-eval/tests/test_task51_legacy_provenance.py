"""Host fixtures only: no released raw files, policy/model, or simulator access."""
import copy
import json
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import h5py

from gpt6_eval import task51_legacy_provenance as legacy
from gpt6_eval.core import CAMERAS
from gpt6_eval.icl import export_demo
from gpt6_eval.knowledge import file_hash, tree_hashes
import test_icl


class LegacyTests(unittest.TestCase):
    def setUp(self):
        test_icl.ExportTests.setUp(self)
        with h5py.File(self.source, 'r+') as f:
            f['meta/scene_name'][()] = legacy.SCENE
            f['meta/robot_key'][()] = legacy.ROBOT
            f.create_dataset('meta/schema_version', data='raw_hdf5_v2')
            f.create_dataset('meta/seed', data=0)
        self.baseline = self.root / 'baseline'
        self.export(self.baseline)
        with h5py.File(self.source, 'r+') as f:
            del f['meta/seed_namespace']
            del f['meta/episode_seed']
        self.rows = [{'path': self.source.name, 'bytes': self.source.stat().st_size,
                      'sha256': file_hash(self.source)}]
        self.rows += [{'path': f'fixture/{i}.hdf5', 'bytes': 10, 'sha256': 'a'*64} for i in range(99)]
        self.addCleanup(patch.stopall)
        # Fixture-only source-set substitution; production constant is immutable.
        patch.object(legacy, 'SET_SHA256', legacy.entries_digest(self.rows)).start()
        self.context = {'task_id': 51, 'repo': legacy.REPO, 'revision': legacy.REVISION,
                        'dataset_root': str(self.root), 'entries': self.rows}

    def export(self, output, context=None, **kwargs):
        return export_demo(self.source, output, ['j2', 'j1'], 'instruction',
                           legacy.ROBOT, CAMERAS['baseline_4cam'], legacy.SCENE,
                           legacy_provenance=context, **kwargs)

    def training(self):
        rows = [{**r, 'split':'seen', 'collection_seed':None, 'collection_namespace':None,
                 'collection_provenance':'UNKNOWN', 'provenance_exception':legacy.EXCEPTION}
                for r in self.rows]
        return {'task_id':51, 'dataset_repo':legacy.REPO, 'dataset_revision':legacy.REVISION,
                'scene_name':legacy.SCENE, 'robot_key':legacy.ROBOT, 'demonstrations':rows,
                'access_mode':'trusted_reader_v1',
                'provenance_exception':legacy.disclosure()}

    def test_identical_sanitized_pixels_arrays_and_metadata(self):
        provenance = self.export(self.root/'legacy', self.context)
        self.assertEqual(tree_hashes(self.baseline), tree_hashes(self.root/'legacy'))
        self.assertIsNone(provenance['collection_seed'])
        self.assertIsNone(provenance['collection_namespace'])
        self.assertEqual(provenance['collection_provenance'], 'UNKNOWN')
        public = (self.root/'legacy/demo.json').read_text()
        self.assertNotIn('UNKNOWN', public)
        self.assertNotIn('seed', public)
        self.assertNotIn('provenance_exception', public)

    def test_reader_index_same_numeric_bytes(self):
        self.export(self.root/'lazy', self.context, include_images=False)
        for name in ('qpos.npy','actions.npy','demo.json'):
            self.assertEqual((self.baseline/name).read_bytes(), (self.root/'lazy'/name).read_bytes())
        self.assertEqual(len(list((self.root/'lazy').iterdir())), 3)

    def test_missing_metadata_without_optin_still_rejected(self):
        with self.assertRaises(KeyError): self.export(self.root/'rejected')

    def test_task_repo_revision_scene_robot_bound(self):
        args = [51, legacy.REPO, legacy.REVISION, legacy.SCENE, legacy.ROBOT, self.rows]
        for i, value in [(0,60),(0,'51'),(1,'other'),(2,'main'),(3,'other_scene'),(4,'other_robot')]:
            with self.subTest(field=i,value=value), self.assertRaises(ValueError):
                wrong = list(args); wrong[i] = value
                legacy.validate_selection(*wrong)

    def test_inventory_hash_size_path_missing_extra_duplicate_rejected(self):
        variants = [self.rows[:-1], self.rows+[self.rows[0]], self.rows[:-1]+[self.rows[0]]]
        for key,value in [('sha256','b'*64),('bytes',123),('path','elsewhere.hdf5')]:
            wrong=copy.deepcopy(self.rows);wrong[0][key]=value;variants.append(wrong)
        for wrong in variants:
            with self.subTest(wrong=wrong[0]), self.assertRaises(ValueError):
                legacy.validate_selection(51,legacy.REPO,legacy.REVISION,legacy.SCENE,legacy.ROBOT,wrong)

    def test_source_tamper_detected_even_with_same_size(self):
        with self.source.open('r+b') as handle:
            handle.seek(-1,2); original=handle.read(1);handle.seek(-1,2);handle.write(bytes([original[0]^1]))
        with self.assertRaisesRegex(ValueError,'content mismatch'):
            self.export(self.root/'rejected', self.context)

    def test_source_outside_cohort_rejected(self):
        wrong=copy.deepcopy(self.context);wrong['dataset_root']=str(self.root/'other')
        with self.assertRaises(ValueError):self.export(self.root/'rejected',wrong)

    def test_source_symlink_rejected(self):
        linked=self.root/'link.hdf5';linked.symlink_to(self.source)
        with self.assertRaises(ValueError):legacy.validate_source(linked,self.context,legacy.SCENE,legacy.ROBOT)

    def test_unseen_wrong_scene_wrong_robot_and_conflicting_namespace_rejected(self):
        # Bypass only byte hash/context for targeted metadata negative fixtures.
        for key,value in [('scene_generalization_sample',json.dumps({'_generalization_split':'unseen'})),
                          ('scene_name','wrong'),('robot_key','wrong'),('seed_namespace','eval')]:
            with self.subTest(key=key):
                with h5py.File(self.source,'r+') as f:
                    existed='meta/'+key in f
                    old=f['meta/'+key][()] if existed else None
                    if existed:f['meta/'+key][()]=value
                    else:f.create_dataset('meta/'+key,data=value)
                with patch.object(legacy,'validate_source'), self.assertRaises(ValueError):
                    self.export(self.root/'rejected',self.context)
                with h5py.File(self.source,'r+') as f:
                    if existed:f['meta/'+key][()]=old
                    else:del f['meta/'+key]

    def test_any_explicit_seed_context_is_not_reclassified_unknown(self):
        for key in ('seed_namespace','episode_seed','base_seed','task_seed_id','task_base_seed','episode_index','seed_policy'):
            with self.subTest(key=key):
                with h5py.File(self.source,'r+') as f:f.create_dataset('meta/'+key,data='collection' if key=='seed_namespace' else 1)
                with patch.object(legacy,'validate_source'),self.assertRaises(ValueError):self.export(self.root/'rejected',self.context)
                with h5py.File(self.source,'r+') as f:del f['meta/'+key]

    def test_training_disclosure_and_cohort_revalidated(self):
        legacy.validate_training(self.training())
        for key,value in [('task_id',60),('dataset_revision','new'),('scene_name','other'),
                          ('robot_key','other'),('provenance_exception',None),('access_mode','export')]:
            wrong=self.training();wrong[key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):legacy.validate_training(wrong)

    def test_missing_or_invented_row_provenance_rejected(self):
        for key,value in [('collection_seed',0),('collection_namespace','collection'),
                          ('collection_provenance','verified'),('provenance_exception',None),('split','unseen')]:
            wrong=self.training();wrong['demonstrations'][0][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):legacy.validate_training(wrong)
            wrong=self.training();del wrong['demonstrations'][0][key]
            with self.subTest(missing=key),self.assertRaises(ValueError):legacy.validate_training(wrong)

    def test_unrelated_training_unchanged(self):
        legacy.validate_training({'task_id':3})
        wrong=self.training();wrong['task_id']=3;del wrong['provenance_exception']
        with self.assertRaises(ValueError):legacy.validate_training(wrong)

    def test_disclosure_not_editable(self):
        wrong=self.training();wrong['provenance_exception']['collection_namespace']='collection'
        with self.assertRaises(ValueError):legacy.validate_training(wrong)

    def test_prepare_explicit_flag_requires_correct_task_and_reader_mode(self):
        from gpt6_eval.icl import prepare
        dataset=self.root/'dataset';(dataset/'.download_logs').mkdir(parents=True)
        entries=[dict(r,path=f'dataset/51_fake/replay-generalization/{i}.hdf5') for i,r in enumerate(self.rows)]
        inventory={'repo':legacy.REPO,'revision':legacy.REVISION,'files':entries}
        (dataset/'.download_logs/inventory.json').write_text(json.dumps(inventory))
        args=SimpleNamespace(config=Path('unused'),upstream=Path('unused'),assets=Path('unused'),
                             dataset=dataset,output=self.root/'out',task=51,
                             task51_legacy_provenance=True,access_mode='export')
        with patch('gpt6_eval.icl.preparation_config',return_value={'upstream_commit':'pin'}), \
             patch('gpt6_eval.icl.git',side_effect=['pin','']), \
             patch('gpt6_eval.icl.load_task',return_value=(Path(legacy.SCENE+'.yaml'),{},legacy.ROBOT)), \
             self.assertRaisesRegex(ValueError,'requires trusted-reader'):
            prepare(args)
        args.task=60;args.access_mode='trusted_reader_v1'
        for e in entries:e['path']=e['path'].replace('/51_fake/','/60_fake/')
        (dataset/'.download_logs/inventory.json').write_text(json.dumps(inventory))
        with patch('gpt6_eval.icl.preparation_config',return_value={'upstream_commit':'pin'}), \
             patch('gpt6_eval.icl.git',side_effect=['pin','']), \
             patch('gpt6_eval.icl.load_task',return_value=(Path(legacy.SCENE+'.yaml'),{},legacy.ROBOT)), \
             self.assertRaisesRegex(ValueError,'identity mismatch'):
            prepare(args)
        self.assertFalse(args.output.exists())

    def test_reader_rechecks_cohort_at_every_source_verification(self):
        from gpt6_eval.demo_reader import DemoReader
        reader=DemoReader.__new__(DemoReader)
        reader.training=self.training();reader.sources={}
        reader.verify_sources()
        reader.training['demonstrations'][0]['sha256']='b'*64
        with self.assertRaisesRegex(ValueError,'source-set mismatch'):reader.verify_sources()

    def test_mocked_preparation_archives_exception_only_in_private_manifest(self):
        from gpt6_eval.icl import explore
        from gpt6_eval.cli import ROOT, load_config
        from gpt6_eval.core import digest, write_json
        from gpt6_eval.knowledge import contract, verify_package
        base=load_config(ROOT/'configs/task26_calibrated_single.json')
        training=self.root/'training';(training/'public').mkdir(parents=True)
        (training/'public/task.json').write_text('{"instruction":"instruction"}')
        row=self.training()
        row.update(state='complete',contract=contract(base),instruction_sha256=digest(b'instruction'),
                   public_files=tree_hashes(training/'public'))
        write_json(training/'manifest.json',row)
        auth=self.root/'auth.json';auth.write_text('{"FAKE":"test-only"}')
        output=self.root/'preparation'
        class Reader:
            def __init__(self,*args):self.calls=[]
            def start(self):pass
            def close(self):pass
            def finish(self):write_json(output/'private/demo_reader_audit.json',{'test_only':True})
        class Process:
            returncode=0
            def __init__(self,cmd,**kwargs):self.out=kwargs['stdout']
            def communicate(self,prompt):
                self.out.write(b'{"type":"turn.completed","usage":{"input_tokens":10,"output_tokens":5}}\n')
                (output/'workspace/package/TASK.md').write_text('Task skill')
                (output/'workspace/package/SOURCES.md').write_text('demo 0000')
                write_json(output/'workspace/ready.json',{'ready':True,'summary':'Prepared'})
                session=output/'private/codex-home/sessions/session.jsonl'
                session.parent.mkdir(parents=True)
                session.write_text('{"type":"turn_context","payload":{"model":"gpt-6-astra"}}\n')
            def poll(self):return self.returncode
        args=SimpleNamespace(config=ROOT/'configs/task26_calibrated_single.json',training=training,output=output,auth=auth)
        with patch('gpt6_eval.icl.subprocess.check_output',side_effect=[base['codex_version'],b'test packages']), \
             patch('gpt6_eval.icl.subprocess.Popen',Process),patch('gpt6_eval.demo_reader.DemoReader',Reader):
            explore(args)
        manifest=json.loads((output/'frozen/manifest.json').read_text())
        self.assertEqual(manifest['provenance_exception'],legacy.disclosure())
        prep=json.loads((output/'preparation.json').read_text())
        self.assertEqual(prep['provenance_exception'],legacy.disclosure())
        self.assertNotIn('provenance', (output/'frozen/payload/TASK.md').read_text())
        verify_package(output/'frozen',file_hash(output/'frozen/manifest.json'),51,base)


if __name__ == '__main__':
    unittest.main()
