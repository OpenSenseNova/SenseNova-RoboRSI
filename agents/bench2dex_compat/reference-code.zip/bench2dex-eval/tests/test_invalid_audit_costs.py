import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from finalize_campaign_task import invalid_costs


class InvalidAuditCostsTests(unittest.TestCase):
    def test_canceled_peer_telemetry_preserved(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'telemetry.json'
            row = {'tokens': {'status': 'partial', 'total_tokens': 7174261},
                   'timing': {'policy_inference_wall_seconds': 1200.09}}
            path.write_text(json.dumps(row))
            actual = invalid_costs({}, path)
            self.assertEqual(actual['tokens'], row['tokens'])
            self.assertEqual(actual['timing'], row['timing'])
            self.assertEqual(len(actual['telemetry_sha256']), 64)
            self.assertEqual(invalid_costs(row, path), actual)
            with self.assertRaises(ValueError):
                invalid_costs({'tokens': {'total_tokens': 0}}, path)

    def test_missing_is_unavailable_not_zero(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'absent.json'
            actual = invalid_costs({}, path)
            self.assertEqual(actual['tokens'], {'status': 'unavailable'})
            self.assertEqual(actual['timing'], {})
            self.assertIsNone(actual['telemetry_sha256'])
