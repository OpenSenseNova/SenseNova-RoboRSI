import unittest

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))

from finalize_campaign_task import cohort_interpretation


class CampaignInterpretationTest(unittest.TestCase):
    def test_canceled_amendment_not_reported_as_applied(self):
        text = cohort_interpretation(10, list(range(5, 15)))
        self.assertIn('10 fixed new indices5–14', text)
        self.assertIn('canceled before application', text)
        self.assertNotIn('amendment applies', text)
        self.assertIn('trusted_reader_v1', text)
        self.assertIn('uncertified cohort must not enter certified pooled SR', text)
