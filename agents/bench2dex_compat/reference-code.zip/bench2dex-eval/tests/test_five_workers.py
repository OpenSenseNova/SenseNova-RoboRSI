import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

from gpt6_eval import resource_wait
from gpt6_eval.batch import resource_snapshot, worker_reservations, run_wave, summarize
from gpt6_eval.telemetry import utc_now
from test_campaign import campaign


class FiveWorkerTests(unittest.TestCase):
    def test_reservation_requires_explicit_supported_profile(self):
        with patch.dict(os.environ, {}, clear=True):
            self.assertEqual(resource_wait.worker_reservation_mib(), 10240)
            self.assertEqual(worker_reservations(), (6144, 10240))
        with patch.dict(os.environ, {'GPT6_EVAL_WORKER_RESERVATION_MIB':'9216'}):
            self.assertEqual(resource_wait.worker_reservation_mib(), 9216)
            self.assertEqual(worker_reservations(), (9216, 9216))
        for invalid in ('8192', '0', '-1', 'bad'):
            with patch.dict(os.environ, {'GPT6_EVAL_WORKER_RESERVATION_MIB':invalid}):
                with self.assertRaises(ValueError): resource_wait.worker_reservation_mib()

    def test_five_admission_retains_offline_and_os_reservations(self):
        self.assertEqual(campaign.capacity(46080, 58368, 1), 5)
        self.assertEqual(campaign.capacity(46079, 58368, 1), 4)
        self.assertEqual(campaign.capacity(46080, 58367, 1), 4)
        self.assertEqual(campaign.capacity(100000, 100000), 5)
        self.assertEqual(campaign.capacity(None, 100000), 0)
        self.assertEqual(campaign.offline_capacity(58368, 5*9216), 1)
        self.assertEqual(campaign.offline_capacity(58367, 5*9216), 0)

    def test_batch_and_worker_use_same_nine_gib_profile(self):
        with patch.dict(os.environ, {'GPT6_EVAL_WORKER_RESERVATION_MIB':'9216'}), \
             patch('subprocess.check_output', return_value='46080\n'), \
             patch.object(Path, 'read_text', return_value='MemAvailable: 60000000 kB\n'):
            for result in (resource_snapshot(5), resource_wait.snapshot(5)):
                self.assertEqual(result['required_gpu_mib'], 46080)
                self.assertEqual(result['required_ram_mib'], 46080)
                self.assertTrue(result['admitted'])

    def test_profile_timeout_remains_fail_closed(self):
        with tempfile.TemporaryDirectory() as tmp, \
             patch.dict(os.environ, {'GPT6_EVAL_WORKER_RESERVATION_MIB':'9216'}), \
             patch.object(resource_wait, 'snapshot', side_effect=[subprocess.TimeoutExpired('gpu',15), {'admitted':True}]), \
             patch.object(resource_wait.time, 'sleep'):
            p=Path(tmp)/'wait.json'
            self.assertTrue(resource_wait.wait_for_resources(p,5)['admitted'])
            self.assertEqual(json.loads(p.read_text())['query_timeouts_this_wait'], 1)

    def test_five_residency_barrier_records_measurements(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);release=root/'startup/wave_0000.json'
            script="""
import pathlib,json,sys,time,os
r=pathlib.Path(sys.argv[1]); i=int(sys.argv[2]); release=pathlib.Path(sys.argv[3])
p=r/f'episode_{i:04d}';(p/'private').mkdir(parents=True)
(p/'private/startup_started.json').write_text(json.dumps({'phase':'simulator_launch','worker_pid':os.getpid(),'started_at':'start','monotonic':time.monotonic()}))
q=p/'private/startup_ready.json';t=q.with_suffix('.tmp');t.write_text(json.dumps({'phase':'first_validated_observation','ready_at':'ready'}));t.replace(q)
while not release.exists(): time.sleep(.01)
assert json.loads(release.read_text())['resident_workers']==5
(p/'result.json').write_text(json.dumps({'complete':True}))
"""
            jobs=[{'index':i,'directory':f'episode_{i:04d}','returncode':None,
                   'argv':[sys.executable,'-c',script,str(root),str(i),str(release)]} for i in range(5)]
            attempts=[]
            def update(): return summarize(root,5,'hold',time.monotonic(),utc_now(),attempts,'test',5)
            sample={'at':'test','gpu_total_mib':49140,'gpu_used_mib':30000,
                    'gpu_free_mib':19000,'ram_available_mib':24000}
            env={**os.environ,'GPT6_EVAL_WORKER_RESERVATION_MIB':'9216'}
            with patch.object(resource_wait,'memory_sample',return_value=sample):
                self.assertTrue(run_wave(jobs,attempts,root,env,update,startup_timeout_s=10,smoke_release=release))
            marker=json.loads(release.read_text())
            self.assertEqual(marker['memory_at_residency']['ready_workers'],5)
            evidence=json.loads(release.with_suffix('.memory.json').read_text())
            self.assertEqual(evidence['peak_gpu_used_mib'],30000)
            self.assertEqual(evidence['min_ram_available_mib'],24000)
            self.assertTrue(all(a['returncode']==0 for a in attempts))

    def test_five_smoke_requires_actual_memory_evidence(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'startup').mkdir()
            (root/'result.json').write_text(json.dumps({'state':'completed','workers':5,
                'planned_episodes':5,'episodes':[{'valid':True}]*5}))
            (root/'startup/wave_0000.json').write_text(json.dumps({'resident_workers':5,
                'memory_at_residency':{'ready_workers':5,'gpu_free_mib':10000,'ram_available_mib':20000}}))
            p=root/'startup/wave_0000.memory.json'
            good={'samples':[{}],'min_gpu_free_mib':10000,'min_ram_available_mib':20000}
            p.write_text(json.dumps(good));self.assertEqual(campaign.successful('smoke',root)['workers'],5)
            for field,value in [('samples',[]),('min_gpu_free_mib',2047),('min_ram_available_mib',4095)]:
                p.write_text(json.dumps({**good,field:value}))
                with self.assertRaises(ValueError): campaign.successful('smoke',root)


if __name__=='__main__': unittest.main()
