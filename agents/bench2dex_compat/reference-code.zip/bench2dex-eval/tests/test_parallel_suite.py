import json
import os
from pathlib import Path
import sys
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from gpt6_eval import parallel_batch
from gpt6_eval.batch import run_wave, summarize
from gpt6_eval.cli import ROOT, load_config
from gpt6_eval.core import write_json
from gpt6_eval.monitor import request_stop, status
from gpt6_eval.suite import collect_results, episode_stages, validate_resource_evidence
from gpt6_eval.telemetry import utc_now


class ParallelSuiteTests(unittest.TestCase):
    def setUp(self):
        self.plan = json.loads((ROOT / 'configs/results_first11_six_workers.json').read_text())
        self.config = load_config(ROOT / 'configs/results_first11_two_samples.json')
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def test_22_fixed_samples_in_waves_6_6_6_4_with_unchanged_model(self):
        jobs = parallel_batch.schedule(self.plan, self.config, 'codex')
        self.assertEqual([(j['task_id'], j['upstream_episode_index']) for j in jobs],
                         [(t, e) for t in self.plan['task_ids'] for e in [3, 4]])
        self.assertEqual([len(jobs[i:i+6]) for i in range(0, 22, 6)], [6, 6, 6, 4])
        self.assertEqual(len({j['directory'] for j in jobs}), 22)
        self.assertEqual(self.config['model'], 'gpt-6-astra')
        self.assertEqual(self.config['reasoning_effort'], 'max')
        stages = episode_stages(self.root, self.plan, [])
        self.assertEqual([s[0] for s in stages], ['smoke', 'evaluation'])
        self.assertTrue(all('gpt6_eval.parallel_batch' in s[1] for s in stages))

    def test_smokes_are_separate_and_unscored(self):
        jobs = parallel_batch.schedule(self.plan,
             {**self.config, 'num_episodes': 1, 'start_episode': 1001}, 'hold')
        self.assertEqual(len(jobs), 11)
        self.assertEqual({j['upstream_episode_index'] for j in jobs}, {1001})
        with self.assertRaises(ValueError):
            parallel_batch.schedule(self.plan, self.config, 'hold')

    def test_six_real_subprocesses_overlap(self):
        script = (
            'import pathlib,sys,time,json; r=pathlib.Path(sys.argv[1]); i=sys.argv[2]; '
            '(r/("ready"+i)).touch(); deadline=time.monotonic()+10;\n'
            'while len(list(r.glob("ready*")))<6:\n'
            ' assert time.monotonic()<deadline, "Six workers did not overlap"\n'
            ' time.sleep(.01)\n'
            'd=r/("episode_"+i); d.mkdir(); '
            '(d/"result.json").write_text(json.dumps({"complete":True}))')
        jobs = [{'index': i, 'directory': f'episode_{i}', 'returncode': None,
                 'argv': [sys.executable, '-c', script, str(self.root), str(i)]}
                for i in range(6)]
        attempts = []
        def update():
            return summarize(self.root, 6, 'hold', time.monotonic(), utc_now(), attempts, 'running', 6)
        self.assertTrue(run_wave(jobs, attempts, self.root, dict(os.environ), update))
        self.assertEqual(len(attempts), 6)
        self.assertTrue(all(a['returncode'] == 0 for a in attempts))

    def args(self):
        evidence = self.root / 'memory.json'
        write_json(evidence, {'returncode': 0, 'samples': 10, 'peak_tree_rss_mib': 7000})
        return SimpleNamespace(output=self.root / 'evaluation', mode='codex',
            upstream=self.root, isaaclab=self.root, assets=self.root, python=Path(sys.executable),
            auth=self.root, resource_validation=evidence)

    def test_lower_memory_reservation_requires_successful_measured_headroom(self):
        for evidence in (None, {'returncode': 1},
                         {'returncode': 0, 'samples': 10, 'peak_tree_rss_mib': 8000},
                         {'returncode': 0, 'samples': 10, 'peak_tree_rss_mib': float('nan')}):
            with self.assertRaises(ValueError):
                validate_resource_evidence(self.plan, evidence)
        validate_resource_evidence(self.plan, {'returncode': 0, 'samples': 10, 'peak_tree_rss_mib': 7000})

    def test_stop_drains_wave_and_does_not_admit_later_samples(self):
        args = self.args()
        def wave(jobs, attempts, output, env, updated):
            request_stop(output)
            for job in jobs:
                write_json(output / job['directory'] / 'result.json',
                           {'complete': True, 'eligible_for_gpt6_score': True, 'success_rate': 0.0})
                attempts.append({**job, 'returncode': 0})
            updated()
            return True
        with patch('gpt6_eval.parallel_batch.signal.signal'), \
             patch('gpt6_eval.parallel_batch.resource_snapshot', return_value={'admitted': True}), \
             patch('gpt6_eval.parallel_batch.run_wave', side_effect=wave) as runner:
            state = parallel_batch.run(args, self.plan, self.config)
        self.assertEqual(state, 'stopped_by_request')
        self.assertEqual(runner.call_count, 1)
        result = json.loads((args.output / 'result.json').read_text())
        self.assertEqual(result['scored_episodes'], 6)
        self.assertEqual(result['not_attempted_episodes'], 16)
        self.assertIsNone(result['success_rate'])
        report = collect_results(self.root, self.plan, state, 'now', 1)
        self.assertEqual(report['workers'], 6)
        self.assertEqual(report['scored_episodes'], 6)
        self.assertIsNone(report['success_rate'])
        write_json(self.root / 'suite.json', {'state': state})
        self.assertEqual(len(status(self.root)['episodes']), 6)
        request_stop(self.root)

    def test_resource_rejection_starts_no_samples(self):
        with patch('gpt6_eval.parallel_batch.signal.signal'), \
             patch('gpt6_eval.parallel_batch.resource_snapshot', return_value={'admitted': False}), \
             patch('gpt6_eval.parallel_batch.run_wave') as runner:
            self.assertEqual(parallel_batch.run(self.args(), self.plan, self.config), 'blocked_on_resources')
        runner.assert_not_called()

    def test_infrastructure_error_does_not_retry_or_report_full_score(self):
        args = self.args()
        def wave(jobs, attempts, *unused):
            attempts.append({**jobs[0], 'returncode': 1})
            return False
        with patch('gpt6_eval.parallel_batch.signal.signal'), \
             patch('gpt6_eval.parallel_batch.resource_snapshot', return_value={'admitted': True}), \
             patch('gpt6_eval.parallel_batch.run_wave', side_effect=wave) as runner:
            self.assertEqual(parallel_batch.run(args, self.plan, self.config), 'stopped_on_infrastructure_error')
        self.assertEqual(runner.call_count, 1)
        r = json.loads((args.output / 'result.json').read_text())
        self.assertEqual(r['infrastructure_errors'], 1)
        self.assertEqual(r['scored_episodes'], 0)
        self.assertEqual(r['failures'], 0)
        self.assertIsNone(r['success_rate'])


if __name__ == '__main__':
    unittest.main()
