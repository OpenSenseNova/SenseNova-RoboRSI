import json
import os
from pathlib import Path
import tempfile
import time
import sys
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from gpt6_eval.batch import episode_configs, summarize, run_wave, resource_snapshot, startup_options
from gpt6_eval.cli import ROOT, load_config
from gpt6_eval.core import write_json
from gpt6_eval.telemetry import utc_now
from gpt6_eval.prepare_task26_assets import verify_inventory


class BatchTests(unittest.TestCase):
    def test_three_worker_schedule_and_startup_contract(self):
        config = load_config(ROOT / 'configs/task26_icl_six.json')
        self.assertEqual([c['start_episode'] for c in episode_configs(config)], list(range(5, 11)))
        args = SimpleNamespace(output=Path('/run'), mode='hold', startup_timeout_s=600,
                               hold_until_resident=True)
        self.assertEqual(startup_options(args, 1), {'startup_timeout_s': 600,
                         'smoke_release': Path('/run/startup/wave_0001.json')})
        args.mode = 'codex'
        with self.assertRaises(ValueError): startup_options(args, 0)
        args.hold_until_resident = False
        self.assertEqual(startup_options(args, 0), {'startup_timeout_s': 600})
        for bad in (0, -1, float('nan'), float('inf')):
            args.startup_timeout_s = bad
            with self.assertRaises(ValueError): startup_options(args, 0)
        args.startup_timeout_s = None
        self.assertEqual(startup_options(args, 0), {})
        with patch('gpt6_eval.batch.subprocess.check_output', return_value='48000\n'), \
                patch.object(Path, 'read_text', return_value='MemAvailable: 55000000 kB\n'):
            resources = resource_snapshot(3)
        self.assertTrue(resources['admitted'])
        self.assertEqual(resources['required_ram_mib'], 30720)
        self.assertEqual(resources['required_gpu_mib'], 18432)

    def test_resource_admission_for_two_workers(self):
        with patch("gpt6_eval.batch.subprocess.check_output", return_value="8800\n"), \
                patch.object(Path, "read_text", return_value="MemAvailable: 41943040 kB\n"):
            resources = resource_snapshot(2)
        self.assertFalse(resources["admitted"])
        self.assertEqual(resources["required_gpu_mib"], 12288)
        self.assertEqual(resources["required_ram_mib"], 20480)

    def test_two_processes_overlap_with_separate_outputs(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            script = (
                "import json,pathlib,sys,time; root=pathlib.Path(sys.argv[1]); i=int(sys.argv[2]); "
                "(root/('ready'+str(i))).touch(); deadline=time.monotonic()+5;\n"
                "while not (root/('ready'+str(1-i))).exists():\n"
                " assert time.monotonic()<deadline, 'Workers did not overlap'\n"
                " time.sleep(.01)\n"
                "out=root/('episode_'+str(i)); out.mkdir(); "
                "(out/'result.json').write_text(json.dumps({'complete':True}))"
            )
            jobs = [{"index": i, "directory": f"episode_{i}", "returncode": None,
                     "argv": [sys.executable, "-c", script, str(root), str(i)]} for i in range(2)]
            attempts = []
            def update():
                return summarize(root, 2, "hold", time.monotonic(), utc_now(), attempts, "test", 2)
            self.assertTrue(run_wave(jobs, attempts, root, dict(os.environ), update))
            self.assertEqual([a["returncode"] for a in attempts], [0, 0])
            self.assertEqual(update()["workers"], 2)
            self.assertEqual(update()["infrastructure_errors"], 0)

    def test_failed_worker_cancels_peer(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            jobs = [{"index": i, "directory": f"episode_{i}", "returncode": None,
                     "argv": [sys.executable, "-c", code]} for i, code in enumerate(
                         ["raise SystemExit(1)", "import time; time.sleep(30)"])]
            attempts = []
            def update():
                return summarize(root, 2, "hold", time.monotonic(), utc_now(), attempts, "test", 2)
            self.assertFalse(run_wave(jobs, attempts, root, dict(os.environ), update))
            self.assertTrue(all(a["returncode"] is not None for a in attempts))
            self.assertIn("cancellation_reason", attempts[1])
            self.assertEqual(update()["running_episodes"], 0)

    def test_do_not_read_running_child_partial_result(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "episode_0").mkdir()
            (root / "episode_0/result.json").write_text('{"complete":')
            result = summarize(root, 8, "codex", time.monotonic(), utc_now(),
                               [{"directory": "episode_0", "returncode": None}], "running", 2)
            self.assertEqual(result["running_episodes"], 1)
            self.assertIsNone(result["success_rate"])

    def test_partial_download_is_not_accepted(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            path = root / "fixture"
            path.write_bytes(b"123")
            verify_inventory(root, [{"path": "fixture", "bytes": 3}])
            for record in ({"path": "missing", "bytes": 3},
                           {"path": "fixture", "bytes": 4},
                           {"path": "fixture", "bytes": 3, "sha256": "wrong"}):
                with self.assertRaises(RuntimeError):
                    verify_inventory(root, [record])

    def test_eight_distinct_sequential_episodes(self):
        config = load_config(ROOT / "configs/task26_pilot8.json")
        children = episode_configs(config)
        self.assertEqual([c["start_episode"] for c in children], list(range(1, 9)))
        self.assertTrue(all(c["num_episodes"] == 1 and c["model"] == "gpt-6-astra" for c in children))
        self.assertEqual(config["num_episodes"], 8)

    def test_score_requires_every_planned_episode_and_no_infrastructure_error(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            attempts = []
            for i in range(8):
                directory = f"episode_{i:04d}"
                write_json(root / directory / "result.json", {
                    "complete": True, "eligible_for_gpt6_score": True,
                    "success_rate": 1.0 if i < 3 else 0.0})
                attempts.append({"directory": directory, "returncode": 0})
            def report(rows):
                return summarize(root, 8, "codex", time.monotonic(), utc_now(), rows, "fixture")
            self.assertEqual(report(attempts)["success_rate"], 3 / 8)
            self.assertIsNone(report(attempts[:7])["success_rate"])
            attempts[-1]["returncode"] = 1
            self.assertIsNone(report(attempts)["success_rate"])
            self.assertEqual(report(attempts)["infrastructure_errors"], 1)


if __name__ == "__main__":
    unittest.main()
