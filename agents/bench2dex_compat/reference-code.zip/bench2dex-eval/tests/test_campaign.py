import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from gpt6_eval import resource_wait

spec=importlib.util.spec_from_file_location('campaign',Path(__file__).resolve().parents[1]/'scripts/run_icl_campaign.py')
campaign=importlib.util.module_from_spec(spec); spec.loader.exec_module(campaign)

class CampaignTests(unittest.TestCase):
    def test_offline_admission_while_gpu_waits_or_starts(self):
        # Current waiting worker reserves10GiB; research still fits in44GiB.
        for gpu in (None, 0, 8658):
            self.assertEqual(campaign.capacity(gpu, 44478), 0)
            self.assertEqual(campaign.offline_capacity(44478, 10240), 1)
        # A future four-worker startup retains every byte of its reservation.
        self.assertEqual(campaign.offline_capacity(53248, 40960), 1)
        self.assertEqual(campaign.offline_capacity(53247, 40960), 0)

    def test_offline_limits_still_fail_closed_for_ram_and_existing_work(self):
        self.assertEqual(campaign.offline_capacity(None, 0), 0)
        self.assertEqual(campaign.offline_capacity(12287, 0), 0)
        self.assertEqual(campaign.offline_capacity(12288, 0), 1)
        self.assertEqual(campaign.offline_capacity(64000, 0, 1), 0)

    def test_two_preparations_preserve_four_gpu_workers_and_os_headroom(self):
        gpu_reservation=4*campaign.WORKER_MIB
        available=53248
        self.assertEqual(campaign.parallel_preparation_slots(available,gpu_reservation,1,0),1)
        self.assertEqual(campaign.parallel_preparation_slots(available,gpu_reservation,2,0),0)
        self.assertEqual(campaign.parallel_preparation_slots(available,gpu_reservation,1,1),0)
        self.assertEqual(campaign.parallel_preparation_slots(available+4096,gpu_reservation,1,1),1)
        self.assertEqual(campaign.parallel_preparation_slots(None,gpu_reservation,1,0),0)
        self.assertEqual(campaign.parallel_preparation_slots(49151,gpu_reservation,1,0),0)
        self.assertEqual(campaign.capacity(48524,available,
                         offline_reserved_mib=2*campaign.PREPARATION_MIB),4)
        self.assertEqual(campaign.capacity(48524,available,
                         offline_reserved_mib=2*campaign.PREPARATION_MIB+campaign.TRAINING_MIB),3)

    def test_indexing_can_overlap_two_explorations_and_three_gpu_workers(self):
        gpu_reservation=3*campaign.WORKER_MIB
        exact=gpu_reservation+4096+2*campaign.PREPARATION_MIB+campaign.TRAINING_MIB
        self.assertEqual(campaign.training_slots(exact,gpu_reservation,2,0),1)
        self.assertEqual(campaign.training_slots(exact-1,gpu_reservation,2,0),0)
        self.assertEqual(campaign.training_slots(exact,gpu_reservation,2,1),0)
        self.assertEqual(campaign.training_slots(None,gpu_reservation,0,0),0)

    def test_preparation_can_start_before_current_indexing_or_gpu_wave_ends(self):
        reservation=2*campaign.WORKER_MIB
        exact=reservation+4096+campaign.TRAINING_MIB+2*campaign.PREPARATION_MIB
        self.assertEqual(campaign.parallel_preparation_slots(exact,reservation,0,1),2)
        self.assertEqual(campaign.parallel_preparation_slots(exact-1,reservation,0,1),1)
        self.assertEqual(campaign.parallel_preparation_slots(exact,reservation,2,1),0)

    def test_gpu_query_timeout_can_use_independent_host_ram(self):
        with patch.object(campaign.Path, 'read_text', return_value='MemAvailable: 20480000 kB\n'):
            self.assertEqual(campaign.host_ram_available_mib(), 20000)
            self.assertEqual(campaign.offline_capacity(campaign.host_ram_available_mib(), 0), 1)
            self.assertEqual(campaign.capacity(None, 20000), 0)
        with patch.object(campaign.Path, 'read_text', side_effect=OSError('unavailable')):
            self.assertIsNone(campaign.host_ram_available_mib())

    def test_memory_accounting_excludes_file_cache_and_apportions_shared_memory(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            for pid,pss,children in [(1,4096,'2'),(2,2048,'')]:
                p=root/str(pid);(p/'task'/str(pid)).mkdir(parents=True)
                (p/'smaps_rollup').write_text(f'Pss_Anon: {pss} kB\nPss_Shmem: 1024 kB\nPss_File: 999999 kB\n')
                (p/'task'/str(pid)/'children').write_text(children)
            self.assertEqual(campaign.resident_memory_mib([{'pid':1},{'pid':2}],root),8)
            self.assertEqual(campaign.resident_memory_mib([{'pid':999}],root),0)

    def test_offline_work_waits_for_complete_residency(self):
        with tempfile.TemporaryDirectory() as d:
            job={'output':d,'workers':2}
            self.assertTrue(campaign.gpu_starting([job]))
            p=Path(d)/'result.json'
            row={'startup_ready_at':'now','returncode':None}
            p.write_text(json.dumps({'episodes':[row]}))
            self.assertTrue(campaign.gpu_starting([job]))
            p.write_text(json.dumps({'episodes':[row,row]}))
            self.assertFalse(campaign.gpu_starting([job]))
            p.write_text(json.dumps({'episodes':[row,{'returncode':None}]}))
            self.assertTrue(campaign.gpu_starting([job]))

    def test_child_io_priorities_preserve_command_and_scope(self):
        with patch.object(campaign.shutil,'which',return_value='/usr/bin/ionice'):
            self.assertEqual(campaign.io_command(['python','job'],'training'),['/usr/bin/ionice','-c','2','-n','4','python','job'])
            self.assertEqual(campaign.io_command(['python','job'],'evaluation'),['/usr/bin/ionice','-c','2','-n','0','python','job'])
        with patch.object(campaign.shutil,'which',return_value=None):
            self.assertEqual(campaign.io_command(['python','job'],'training'),['python','job'])

    def test_capacity_includes_os_offline_and_missing_gpu(self):
        self.assertEqual(campaign.capacity(49140,63957),5)
        self.assertEqual(campaign.capacity(49140,35000,2),1)
        self.assertEqual(campaign.capacity(None,63957),0)
        self.assertEqual(campaign.capacity(9000,63957),0)

    def test_next_indices_preserves_holes_and_valid_failures(self):
        t={'new_episode_indices':[5,6,7,8]}
        with patch.object(campaign,'collect',return_value={5:{},7:{}}):
            self.assertEqual(campaign.next_indices(t,4),[6])
        with patch.object(campaign,'collect',return_value={5:{}}):
            self.assertEqual(campaign.next_indices(t,2),[6,7])

    def test_rolling_admission_fills_two_released_slots_without_double_reserving(self):
        # Three resident workers still occupy18GiB; two slots can be filled
        # without waiting for their parent batch, provided host RAM permits.
        self.assertEqual(campaign.rolling_capacity(30720,46080,3,18432,8192,4096),2)
        self.assertEqual(campaign.rolling_capacity(30720,46079,3,18432,8192,4096),1)

    def test_scoped_campaign_admits_only_task51_and_pauses_on_its_own_completion(self):
        tasks={'51':{'task_id':51,'target_valid_count':10,'valid_episodes':[]},
               '60':{'task_id':60,'target_valid_count':10,'valid_episodes':[]}}
        self.assertEqual([t['task_id'] for t in campaign.scoped_admission_tasks(tasks,[60,51],51)],[51])
        self.assertIsNone(campaign.scoped_terminal_state(tasks,51))
        tasks['51']['valid_episodes']=[{'episode_index':i} for i in range(5,15)]
        self.assertEqual(campaign.scoped_terminal_state(tasks,51),'paused_after_scoped_task')
        self.assertEqual(tasks['60']['valid_episodes'],[])
        self.assertEqual(campaign.rolling_capacity(60000,60000,5,46080,46080,0),0)
        self.assertEqual(campaign.rolling_capacity(60000,60000,4,36864,36864,0),1)

    def test_rolling_admission_reserves_unstarted_workers_and_offline_ram(self):
        self.assertEqual(campaign.rolling_capacity(49140,63957,3,0,0,8192),2)
        self.assertEqual(campaign.rolling_capacity(30000,63957,3,0,0,0),0)
        exact=4096+8192+3*campaign.WORKER_MIB+campaign.WORKER_MIB
        self.assertEqual(campaign.rolling_capacity(49140,exact,3,0,0,8192),1)
        self.assertEqual(campaign.rolling_capacity(49140,exact-1,3,0,0,8192),0)
        self.assertEqual(campaign.rolling_capacity(None,63957,1,0,0,0),0)
        self.assertEqual(campaign.rolling_capacity(49140,None,1,0,0,0),0)

    def test_live_batches_exclude_owned_indices_even_when_rows_have_finished(self):
        task={'task_id':34,'new_episode_indices':list(range(5,15))}
        live=[{'task_id':34,'indices':[5,6,7]}, {'task_id':42,'indices':[8,9]},
              {'task_id':34,'indices':[10,11]}]
        with patch.object(campaign,'collect',return_value={5:{}}):
            self.assertEqual(campaign.next_indices(task,5,live),[8,9])
            self.assertEqual(campaign.next_indices(task,0,live),[])
        with patch.object(campaign,'collect',return_value={5:{},6:{},7:{},8:{},9:{}}):
            self.assertEqual(campaign.next_indices(task,5,live),[12,13,14])

    def test_gpu_residency_credits_only_owned_descendants_and_retains_missing_reserve(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            for pid,children in [(1,'2'),(2,''),(3,'4'),(4,'')]:
                p=root/str(pid)/'task'/str(pid);p.mkdir(parents=True)
                (p/'children').write_text(children)
            jobs=[{'pid':1,'output':str(root/'first'),'workers':2},
                  {'pid':3,'output':str(root/'second'),'workers':1}]
            with patch.object(campaign.subprocess,'check_output',return_value='2, 20000\n4, 6000\n999, 15000\n'):
                self.assertEqual(campaign.resident_gpu_memory_mib(jobs,root),18432+6000)
            for output in ('2, N/A\n','2, -1\n','2, 6000\n2, 6000\n'):
                with patch.object(campaign.subprocess,'check_output',return_value=output):
                    self.assertEqual(campaign.resident_gpu_memory_mib(jobs,root),0)
            with patch.object(campaign.subprocess,'check_output',side_effect=campaign.subprocess.TimeoutExpired('nvidia-smi',5)):
                self.assertEqual(campaign.resident_gpu_memory_mib(jobs,root),0)

    def test_only_reaped_valid_workers_release_a_slot(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);proc=root/'proc';(proc/'22').mkdir(parents=True)
            job={'workers':3,'output':d}
            rows=[{'worker_index':0,'pid':11,'valid':True,'returncode':0,'ended_at':'now'},
                  {'worker_index':1,'pid':22,'valid':True,'returncode':0,'ended_at':'now'},
                  {'worker_index':2,'pid':33,'valid':False,'returncode':1,'ended_at':'now'}]
            (root/'result.json').write_text(json.dumps({'workers':3,'episodes':rows}))
            self.assertEqual(campaign.remaining_worker_slots(job,proc),2)
            rows[2].update(valid=True,returncode=0)
            (root/'result.json').write_text(json.dumps({'workers':3,'episodes':rows}))
            self.assertEqual(campaign.remaining_worker_slots(job,proc),1)
            rows[2]['worker_index']=0
            (root/'result.json').write_text(json.dumps({'workers':3,'episodes':rows}))
            self.assertEqual(campaign.remaining_worker_slots(job,proc),3)

    def test_eligible_rejects_wrong_index_and_package(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'result.json'
            p.write_text(json.dumps({'complete':True,'eligible_for_gpt6_score':True,
                'evaluation_setting':'task_icl_v3','task_package_sha256':'pkg',
                'episodes':[{'episode_index':5,'official_success':False}]}))
            self.assertEqual(campaign.eligible(p,5,'pkg')['episode_index'],5)
            for idx,pkg in [(6,'pkg'),(5,'other')]:
                with self.assertRaises(ValueError): campaign.eligible(p,idx,pkg)

    def test_collect_rejects_duplicate_and_changed_inheritance(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); ep=root/'episode_0000'; ep.mkdir()
            p=ep/'result.json'
            p.write_text(json.dumps({'complete':True,'eligible_for_gpt6_score':True,
                'evaluation_setting':'task_icl_v3','task_package_sha256':'pkg',
                'episodes':[{'episode_index':5}]}))
            ref=campaign.eligible(p,5,'pkg')
            task={'new_episode_indices':[6],'inherited':[ref],'package':{'sha256':'pkg'},'jobs':[]}
            self.assertEqual(list(campaign.collect(task)),[5])
            (root/'result.json').write_text(json.dumps({'episodes':[{'valid':True,'upstream_episode_index':5,'directory':ep.name}]}))
            task['jobs']=[{'stage':'evaluation','ended_at':'now','output':str(root)}]
            with self.assertRaisesRegex(ValueError,'Duplicate'): campaign.collect(task)
            task['jobs']=[]; p.write_text('{}')
            with self.assertRaisesRegex(ValueError,'changed'): campaign.collect(task)

    def test_residency_smoke_gate_rejects_partial(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'result.json'
            p.write_text(json.dumps({'state':'completed','planned_episodes':2,'episodes':[{'valid':True}]}))
            with self.assertRaises(ValueError): campaign.successful('smoke',d)

    def test_resource_fault_not_inferred_from_policy_text(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'episode_0000/policy'; p.mkdir(parents=True)
            (p/'simulator.log').write_text('[Error] CUDA_ERROR_OUT_OF_MEMORY')
            self.assertFalse(campaign.resource_failure(d))
            p=Path(d)/'episode_0000/private'; p.mkdir()
            (p/'simulator.log').write_text('[Error] CUDA_ERROR_OUT_OF_MEMORY')
            self.assertTrue(campaign.resource_failure(d))

    def test_os_headroom_blocks_then_admits(self):
        with tempfile.TemporaryDirectory() as d, patch.dict('os.environ',{'GPT6_EVAL_RAM_HEADROOM_MIB':'4096'}):
            reports=[{'admitted':True,'required_ram_mib':10240,'ram_available_mib':12000},
                     {'admitted':True,'required_ram_mib':10240,'ram_available_mib':15000}]
            with patch.object(resource_wait,'snapshot',side_effect=reports),patch.object(resource_wait.time,'sleep') as sleep:
                r=resource_wait.wait_for_resources(Path(d)/'r.json')
            self.assertEqual(r['required_ram_mib'],14336)
            sleep.assert_called_once_with(15)

if __name__=='__main__': unittest.main()
