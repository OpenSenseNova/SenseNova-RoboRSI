import json
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch
from types import SimpleNamespace

import numpy as np

from gpt6_eval.core import canonical
from gpt6_eval.telemetry import EpisodeTelemetry, sum_usage, token_usage, summarize_run, utc_now


class TelemetryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.session = self.root / "codex-home/sessions/one.jsonl"
        self.session.parent.mkdir(parents=True)
        self.counts = {"input_tokens": 100, "cached_input_tokens": 60,
                       "output_tokens": 20, "reasoning_output_tokens": 10}

    def tearDown(self):
        self.tmp.cleanup()

    def snapshot(self, counts):
        return canonical({"type": "event_msg", "payload": {"type": "token_count",
                         "info": {"total_token_usage": counts}}})

    def test_completed_usage_without_double_counting_breakdowns(self):
        self.session.write_bytes(self.snapshot(self.counts))
        (self.root / "codex.events.jsonl").write_bytes(
            canonical({"type": "turn.completed", "usage": self.counts}))
        result = token_usage(self.root, "codex", returncode=0)
        self.assertEqual(result["total_tokens"], 120)
        self.assertEqual(result["status"], "complete")
        self.assertIsNone(result["cache_write_input_tokens"])

    def test_partial_cumulative_duplicates_and_truncated_tail(self):
        previous = {**self.counts, "input_tokens": 50}
        self.session.write_bytes(self.snapshot(previous) + self.snapshot(self.counts) * 2 + b'{"type":"\xe2')
        usage = token_usage(self.root, "codex")
        self.assertEqual(usage["total_tokens"], 120)
        self.assertEqual(usage["status"], "partial")

    def test_unknown_is_not_zero_and_non_model_is_zero(self):
        self.assertIsNone(token_usage(self.root, "codex")["total_tokens"])
        for mode in ("hold", "replay"):
            self.assertEqual(token_usage(self.root, mode)["total_tokens"], 0)
        self.assertEqual(token_usage(self.root, "codex", process_started=False)["total_tokens"], 0)

    def test_multiple_sessions_fail_closed(self):
        self.session.write_bytes(self.snapshot(self.counts))
        self.session.with_name("two.jsonl").write_bytes(self.snapshot(self.counts))
        self.assertEqual(token_usage(self.root, "codex")["status"], "unavailable")

    def test_later_partial_usage_does_not_use_older_complete_total(self):
        self.session.write_bytes(self.snapshot(self.counts))
        (self.root / "codex.events.jsonl").write_bytes(canonical({"type": "turn.completed",
            "usage": {**self.counts, "input_tokens": 50}}))
        self.assertEqual(token_usage(self.root, "codex", returncode=0)["status"], "partial")

    def test_aggregate_exposes_missing_usage(self):
        a = token_usage(self.root, "hold")
        b = token_usage(self.root, "codex")
        total = sum_usage([a, b])
        self.assertEqual(total["status"], "partial")
        self.assertIsNone(total["total_tokens"])
        self.assertEqual(total["incomplete_episodes"], 1)

    def test_invalid_token_number_is_unavailable(self):
        self.session.write_bytes(self.snapshot({**self.counts, "input_tokens": -1}))
        self.assertEqual(token_usage(self.root, "codex")["status"], "unavailable")

    def test_interrupted_setup_retains_summary_without_overwriting_old_runs(self):
        from gpt6_eval.cli import run
        args = SimpleNamespace(output=self.root / "run", mode="hold")
        def interrupted(args, *_):
            args.output.mkdir()
            args._created_output = True
            raise KeyboardInterrupt("fixture interrupt")
        with patch("gpt6_eval.cli._run", side_effect=interrupted):
            with self.assertRaises(KeyboardInterrupt):
                run(args)
        result = (args.output / "result.json").read_bytes()
        self.assertFalse(json.loads(result)["eligible_for_gpt6_score"])
        self.assertTrue((args.output / "telemetry.json").exists())
        with patch("gpt6_eval.cli._run", side_effect=ValueError("existing output")):
            with self.assertRaises(ValueError):
                run(args)
        self.assertEqual(result, (args.output / "result.json").read_bytes())

    def test_failed_decision_and_finalization_are_saved(self):
        private = self.root / "episode_0000/private"
        timer = EpisodeTelemetry(private, "codex")
        timer.model_process_started = True
        timer.decision(0, 0, time.monotonic() - 0.1, utc_now(), False, "fixture error")
        timer.flush(finished=True)
        record = json.loads((private / "telemetry.json").read_text())
        self.assertTrue(record["finalized"])
        self.assertGreaterEqual(record["timing"]["policy_inference_wall_seconds"], 0.1)
        self.assertIsNone(record["timing"]["model_server_inference_seconds"])
        first = (private / "telemetry.json").read_bytes()
        timer.flush(finished=True)
        self.assertEqual(first, (private / "telemetry.json").read_bytes())
        summary = summarize_run(self.root, "codex", time.monotonic(), utc_now(), 1.0,
                                [{"steps": 12}])
        self.assertEqual(summary["timing"]["simulated_seconds_from_official_results"], 0.2)
        self.assertEqual(summary["tokens"]["status"], "partial")


class TrajectoryTests(unittest.TestCase):
    def test_incremental_and_finalized_hdf5_with_articulated_objects(self):
        try:
            import h5py
            from gpt6_eval.trajectory import TrajectoryRecorder
        except ImportError:
            self.skipTest("Simulator h5py dependency not installed")
        with tempfile.TemporaryDirectory() as folder:
            context = {"scene_file": "scene.yaml", "robot_key": "robot", "scene_name": "scene",
                       "action_names": ["j1"], "camera_frames": {"camera": {
                           "intrinsic": np.eye(3), "extrinsic_world_from_cam": np.eye(4),
                           "camera_model": "pinhole"}}}
            recorder = TrajectoryRecorder(folder, record_all=True, context=context)
            recorder.start_episode(["door"], ["camera"], 20, joint_names=["j1"],
                                   metadata={"scene_generalization_sample": {"background": "fixture"}})
            states = {"door": {"pose_world": np.zeros(7), "lin_vel_world": np.zeros(3),
                               "ang_vel_world": np.zeros(3), "qpos": np.zeros(1),
                               "qvel": np.zeros(1), "joint_names": ["hinge"]}}
            for index in range(2):
                recorder.record_step(np.array([index]), np.array([0.2]), states,
                                     {"camera": np.full((8, 8, 3), index, np.uint8)})
                with h5py.File(recorder.path) as hf:
                    self.assertEqual(hf["meta/frame_count"][()], index + 1)
                    self.assertFalse(hf.attrs["finalized"])
            path = Path(recorder.finish_episode(False))
            self.assertEqual(path.parent.name, "failure")
            with h5py.File(path) as hf:
                self.assertTrue(hf.attrs["finalized"])
                self.assertFalse(hf.attrs["official_success"])
                self.assertEqual(hf["robot/qpos"].shape, (2, 1))
                self.assertEqual(hf["objects/door/qpos"].shape, (2, 1))
                self.assertEqual(hf["action/action_names"][0], b"j1")
                np.testing.assert_array_equal(hf["time/physics_step"][:], [0, 3])
                self.assertEqual(hf["meta/scene_file"][()], b"scene.yaml")
                self.assertGreater(len(hf["cameras/camera/rgb"][0]), 0)
                self.assertEqual(hf["cameras/camera/intrinsic"].shape, (2, 3, 3))
                self.assertEqual(hf["cameras/camera/extrinsic_world_from_cam"].shape, (2, 4, 4))
            recorder.start_episode(["door"], ["camera"], 21, joint_names=["j1"])
            recorder.record_step(np.zeros(1), np.zeros(1), states, {"camera": None})
            success_path = Path(recorder.finish_episode(True))
            self.assertEqual(success_path.parent.name, "success")
            with h5py.File(success_path) as hf:
                self.assertEqual(hf["meta/frame_count"][()], 1)
                self.assertTrue(hf.attrs["official_success"])
            with self.assertRaises(ValueError):
                TrajectoryRecorder(folder)


if __name__ == "__main__":
    unittest.main()
