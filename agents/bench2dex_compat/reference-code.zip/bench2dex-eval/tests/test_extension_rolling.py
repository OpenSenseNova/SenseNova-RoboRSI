import copy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch

from gpt6_eval.core import write_json
from gpt6_eval.extension import SETTING, reference
from gpt6_eval import extension_rolling as rolling


class RollingQueueTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.ready = self.root / 'startup_ready.json'
        write_json(self.ready, {'phase': 'first_validated_observation'})
        self.worker = {'startup_ready': str(self.ready)}
        self.profile = {'max_workers': 6, 'launch_reservation_mib': 9216,
                        'ram_headroom_mib': 4096, 'poll_seconds': 15}
        self.resources = {'gpu_free_mib': 16000, 'ram_available_mib': 20000}
        self.source = {'ref': {'result': '/original/result.json', 'sha256': 'original'}}
        self.baseline = {'eligible_for_extension': True}

    def admission(self, active, external=(), resources=None):
        return rolling.admission(active, list(external), resources or self.resources, self.profile)

    def test_six_global_slots_include_both_preserved_workers(self):
        active = {str(index): self.worker for index in range(4)}
        result = self.admission(active, [self.worker, self.worker])
        self.assertFalse(result['admitted'])
        self.assertEqual(result['occupied'], 6)
        self.assertTrue(self.admission(active, [self.worker])['admitted'])

    def test_no_batch_barrier_when_a_single_slot_finishes(self):
        active = {str(index): self.worker for index in range(6)}
        del active['2']
        self.assertTrue(self.admission(active)['admitted'])

    def test_startups_are_serialized_until_resident(self):
        result = self.admission({'one': {'startup_ready': str(self.root / 'missing')}})
        self.assertEqual(result['reason'], 'waiting_for_startup_residency')
        self.assertFalse(result['admitted'])

    def test_live_free_memory_and_os_headroom_are_required(self):
        for resources in ({'gpu_free_mib': 9215, 'ram_available_mib': 30000},
                          {'gpu_free_mib': 20000, 'ram_available_mib': 13311}):
            self.assertFalse(self.admission({}, resources=resources)['admitted'])
        self.assertTrue(self.admission({}, resources={'gpu_free_mib': 9216, 'ram_available_mib': 13312})['admitted'])

    def slots(self):
        return [{'task_id': task, 'episode_index': index, 'original': {}}
                for index in (5, 8) for task in (3, 6, 9)]

    def test_carried_success_and_active_slots_are_never_launched_again(self):
        slots = self.slots()
        state = {'slots': {'03_05': {'state': 'active'}, '06_05': {'state': 'external_active'}}}
        source = {'ref': {}}
        with patch.object(rolling, 'select_source', return_value=source), patch.object(
                rolling, 'source_summary', return_value={'eligible_for_extension': False, 'success': True}):
            self.assertEqual(rolling.prepare_slots({'slots': slots}, state, {}), [])
        self.assertEqual(state['slots']['09_05']['state'], 'carried')
        self.assertNotIn('03_08', state['slots'])

    def test_slow_active_first_pass_blocks_second_pass_not_other_first_slots(self):
        slots = self.slots()
        state = {'slots': {'03_05': {'state': 'external_active'}}}
        with patch.object(rolling, 'select_source', return_value={'ref': {}}), patch.object(
                rolling, 'source_summary', return_value=self.baseline):
            ready = rolling.prepare_slots({'slots': slots}, state, {})
        self.assertEqual([rolling.slot_key(slot) for slot in ready], ['06_05', '09_05'])

    def test_second_pass_opens_only_after_every_first_pass_slot_settles(self):
        state = {'slots': {f'{task:02d}_05': {'state': 'carried'} for task in (3, 6, 9)}}
        with patch.object(rolling, 'select_source', return_value={'ref': {}}), patch.object(
                rolling, 'source_summary', return_value=self.baseline):
            ready = rolling.prepare_slots({'slots': self.slots()}, state, {})
        self.assertEqual([slot['episode_index'] for slot in ready], [8, 8, 8])

    def test_uncertified_source_does_not_block_other_ready_slots(self):
        slots = self.slots()[:3]
        with patch.object(rolling, 'select_source', side_effect=[None, {'ref': {}}, None]), patch.object(
                rolling, 'supplemental_source', side_effect=[(None, None), (None, {'reason': 'missing'})]), patch.object(
                rolling, 'source_summary', return_value=self.baseline):
            state = {'slots': {}}
            ready = rolling.prepare_slots({'slots': slots}, state, {})
        self.assertEqual([rolling.slot_key(slot) for slot in ready], ['06_05'])
        self.assertEqual(state['slots']['09_05']['state'], 'source_unavailable')

    def result(self, code=0):
        output = self.root / 'attempt'
        result_path = output / 'result.json'
        write_json(result_path, {'evaluation_setting': SETTING, 'baseline': self.baseline,
            'eligible_for_extension_score': True, 'extension': {'state': 'verified', 'replay_validated': True,
            'source_result': {'path': '/original/result.json', 'sha256': 'original'}}})
        return {'slot': '03_05', 'output': str(output), 'pid': 99, 'returncode': code, 'result': reference(result_path)}

    def test_healthy_first_defers_unresolved_without_reclassifying_or_retrying(self):
        state = {'slots': {f'{task:02d}_05': {'state': 'carried'} for task in (3, 6, 9)}}
        state['slots']['03_05'] = {'state': 'needs_diagnosis', 'attempts': [{'returncode': 1}]}
        before = copy.deepcopy(state['slots']['03_05'])
        plan = {'slots': self.slots(), 'healthy_first_authorization': {'path': 'approved'}}
        with patch.object(rolling, 'select_source', return_value={'ref': {}}), patch.object(
                rolling, 'source_summary', return_value=self.baseline):
            ready = rolling.prepare_slots(plan, state, {})
        self.assertEqual([slot['episode_index'] for slot in ready], [8, 8, 8])
        self.assertEqual(state['slots']['03_05'], before)
        self.assertNotIn('needs_diagnosis', rolling.completion_states({}))

    def test_healthy_preflight_defers_missing_source_then_selects_next(self):
        slots = self.slots()[:2]
        source = {'ref': {'result': '/source/result.json'}, 'audit': {'path': '/audit', 'sha256': 'pin'}}
        state = {'slots': {rolling.slot_key(slot): {'source': source, 'baseline': self.baseline,
                                                  'state': 'ready'} for slot in slots}}
        with patch.object(rolling, 'reference', return_value=source['audit']), patch.object(
                rolling, 'source_summary', side_effect=[FileNotFoundError('missing'), self.baseline]), patch.object(
                rolling, 'read', return_value={'config': {}}):
            self.assertEqual(rolling.prepare_healthy_launch(slots, state), [slots[1]])
        self.assertEqual(state['slots']['03_05']['state'], 'needs_diagnosis')
        self.assertNotIn('attempts', state['slots']['03_05'])
        self.assertEqual(state['slots']['06_05']['state'], 'ready')

    def test_shared_io_fault_is_not_treated_as_disposable_source_problem(self):
        slots = self.slots()[:1]
        state = {'slots': {'03_05': {'source': {'audit': {'path': '/audit'}}, 'state': 'ready'}}}
        with patch.object(rolling, 'reference', side_effect=OSError(5, 'Input/output error')):
            with self.assertRaises(OSError):
                rolling.prepare_healthy_launch(slots, state)
        self.assertEqual(state['slots']['03_05']['state'], 'ready')

    def test_result_must_match_source_and_qualified_replay(self):
        attempt = self.result()
        record = {'source': self.source, 'baseline': self.baseline}
        rolling.validate_result(record, attempt)
        self.assertEqual(record['state'], 'complete')
        record['source'] = {'ref': {'result': '/wrong/result.json', 'sha256': 'wrong'}}
        with self.assertRaisesRegex(ValueError, 'source or setting'):
            rolling.validate_result(record, attempt)

    def test_reaping_one_worker_preserves_other_workers(self):
        attempt = self.result()
        state = {'active': {'03_05': attempt, '06_05': self.worker},
                 'slots': {'03_05': {'source': self.source, 'baseline': self.baseline}}}
        processes = {'03_05': Mock(poll=lambda: 0), '06_05': Mock(poll=lambda: None)}
        rolling.collect(state, processes)
        self.assertEqual(state['slots']['03_05']['state'], 'complete')
        self.assertEqual(set(processes), {'06_05'})
        self.assertEqual(set(state['active']), {'06_05'})

    def test_nonzero_exit_with_result_requires_diagnosis_not_retry(self):
        record = {'source': self.source, 'baseline': self.baseline}
        rolling.validate_result(record, self.result(code=1))
        self.assertEqual(record['state'], 'needs_diagnosis')

    def test_divergence_remains_unresolved_not_scored_failure(self):
        attempt = self.result(code=1)
        result_path = Path(attempt['result']['path'])
        result = rolling.read(result_path)
        result['eligible_for_extension_score'] = False
        result['extension']['replay_validation'] = {'state': 'diverged'}
        write_json(result_path, result)
        attempt['result'] = reference(result_path)
        record = {'source': self.source, 'baseline': self.baseline}
        rolling.validate_result(record, attempt)
        self.assertEqual(record['state'], 'diverged')

    def predecessor(self):
        attempt = self.result()
        active = {key: attempt[key] for key in ('slot', 'pid', 'output')}
        previous = {'pid': 1, 'plan': {'id': 'old'}, 'probe_verified': True, 'qualification_imported': {'id': 'probe'},
                    'active': active, 'slots': {'03_05': {'state': 'ready', 'source': self.source, 'baseline': self.baseline}}}
        snapshot_path = self.root / 'before.json'
        write_json(snapshot_path, previous)
        identity = {'pid': 1}
        receipt_path = self.root / 'drain.json'
        write_json(receipt_path, {'identity': identity, 'signal': 'SIGTERM', 'snapshot': reference(snapshot_path)})
        predecessor = {'snapshot': reference(snapshot_path), 'drain_receipt': reference(receipt_path),
                       'identity': identity, 'worker_identity': {'pid': 99}, 'control': str(self.root / 'old'),
                       'plan': previous['plan']}
        plan_path = self.root / 'plan.json'
        plan = {'predecessor': predecessor}
        write_json(plan_path, plan)
        write_json(self.root / 'old/state.json', previous)
        state = rolling.initialize(plan_path, plan)
        return plan, state, previous, attempt

    def test_predecessor_is_reserved_not_adopted_or_restarted(self):
        plan, state, previous, attempt = self.predecessor()
        with patch.object(rolling, 'live_identity', return_value=True):
            external = rolling.reconcile_predecessor(plan, state)
        self.assertEqual(len(external), 1)
        self.assertEqual(state['slots']['03_05']['state'], 'external_active')
        self.assertEqual(state['active'], {})

    def test_predecessor_finished_result_imported_once(self):
        plan, state, previous, attempt = self.predecessor()
        previous.pop('active')
        previous['slots']['03_05'].update(state='complete', attempts=[attempt])
        write_json(self.root / 'old/state.json', previous)
        self.assertEqual(rolling.reconcile_predecessor(plan, state), [])
        self.assertEqual(state['slots']['03_05']['state'], 'complete')
        self.assertTrue(state['predecessor_imported'])
        self.assertEqual(rolling.reconcile_predecessor(plan, state), [])

    def test_unexpected_predecessor_launch_is_rejected(self):
        plan, state, previous, attempt = self.predecessor()
        previous['slots']['06_05'] = copy.deepcopy(previous['slots']['03_05'])
        write_json(self.root / 'old/state.json', previous)
        with self.assertRaisesRegex(ValueError, 'unexpected slots'):
            rolling.reconcile_predecessor(plan, state)

    def test_predecessor_collection_latency_does_not_cause_spurious_fault(self):
        plan, state, previous, attempt = self.predecessor()
        with patch.object(rolling, 'live_identity', side_effect=[True, False]):
            self.assertEqual(len(rolling.reconcile_predecessor(plan, state)), 1)

    def test_missing_predecessor_owner_never_triggers_duplicate_attempt(self):
        plan, state, previous, attempt = self.predecessor()
        with patch.object(rolling, 'live_identity', return_value=False):
            with self.assertRaisesRegex(ValueError, 'owner disappeared'):
                rolling.reconcile_predecessor(plan, state)

    def test_minimal_infrastructure_result_is_preserved_as_needing_diagnosis(self):
        attempt = self.result(code=1)
        result_path = Path(attempt['result']['path'])
        write_json(result_path, {'complete': False, 'infrastructure_error': 'resume API unavailable'})
        attempt['result'] = reference(result_path)
        record = {'source': self.source, 'baseline': self.baseline}
        rolling.validate_result(record, attempt)
        self.assertEqual(record['state'], 'needs_diagnosis')

    def test_stopped_invalid_attempt_requires_hash_bound_same_source_repair(self):
        plan, state, previous, attempt = self.predecessor()
        attempt['output'] = str(self.root / 'attempt_0001')
        result_path = Path(attempt['output']) / 'result.json'
        write_json(result_path, {'complete': False, 'infrastructure_error': 'resume API unavailable'})
        attempt.update(returncode=1, result=reference(result_path))
        previous.pop('active')
        previous.update(state='needs_diagnosis', error='resume failed')
        previous['slots']['03_05'].update(state='needs_diagnosis', attempts=[attempt])
        snapshot_path = self.root / 'stopped.json'
        write_json(snapshot_path, previous)
        predecessor = plan['predecessor']
        predecessor['snapshot'] = reference(snapshot_path)
        receipt_path = self.root / 'stopped_receipt.json'
        write_json(receipt_path, {'identity': predecessor['identity'], 'signal': 'already_exited',
                                 'snapshot': predecessor['snapshot']})
        predecessor['drain_receipt'] = reference(receipt_path)
        plan_path = self.root / 'stopped_plan.json'
        write_json(plan_path, plan)
        with patch.object(rolling, 'live_identity', return_value=False):
            imported = rolling.initialize(plan_path, plan)
        self.assertEqual(imported['slots']['03_05']['state'], 'needs_diagnosis')
        repair_path = self.root / 'repair.json'
        repair = {'predecessor_state': predecessor['snapshot'], 'state': 'verified', 'retries': {
            '03_05': {'failed_result': attempt['result'], 'source': self.source, 'next_attempt': 2}}}
        write_json(repair_path, repair)
        plan['retry_resolution'] = reference(repair_path)
        write_json(plan_path, plan)
        with patch.object(rolling, 'live_identity', return_value=False):
            imported = rolling.initialize(plan_path, plan)
        self.assertEqual(imported['slots']['03_05']['next_attempt'], 2)
        self.assertEqual(imported['slots']['03_05']['attempts'], [attempt])
        repair['retries']['03_05']['source'] = {'ref': {'result': 'wrong'}}
        write_json(repair_path, repair)
        plan['retry_resolution'] = reference(repair_path)
        with patch.object(rolling, 'live_identity', return_value=False):
            with self.assertRaisesRegex(ValueError, 'preserve the diagnosed attempt'):
                rolling.initialize(plan_path, plan)


if __name__ == '__main__':
    unittest.main()
