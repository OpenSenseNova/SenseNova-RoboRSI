"""Pure host final-auditor fixtures; no campaign files or raw-data access."""
import copy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from finalize_campaign_task import cohort_interpretation, training_provenance_qualification
from gpt6_eval import task51_legacy_provenance as legacy


class Task51FinalAuditTests(unittest.TestCase):
    def setUp(self):
        rows = [{'path': f'fixture/{i}.hdf5', 'bytes': i+1, 'sha256': f'{i:064x}'} for i in range(100)]
        patcher = patch.object(legacy, 'SET_SHA256', legacy.entries_digest(rows))
        patcher.start(); self.addCleanup(patcher.stop)
        self.training = {'task_id':51, 'dataset_repo':legacy.REPO, 'dataset_revision':legacy.REVISION,
            'scene_name':legacy.SCENE, 'robot_key':legacy.ROBOT, 'access_mode':'trusted_reader_v1',
            'provenance_exception':legacy.disclosure(),
            'demonstrations':[{**r,'split':'seen','collection_seed':None,'collection_namespace':None,
                'collection_provenance':'UNKNOWN','provenance_exception':legacy.EXCEPTION} for r in rows]}
        self.prep = {'task_id':51,'provenance_exception':legacy.disclosure(),'training_manifest_sha256':'a'*64}
        self.package = copy.deepcopy(self.prep)

    def qualify(self):
        return training_provenance_qualification(51,self.training,self.prep,self.package)

    def test_explicit_json_and_report_disclosure(self):
        result=self.qualify()
        self.assertEqual(result['provenance_exception'],legacy.disclosure())
        text=result['provenance_qualification']
        for phrase in ('UNKNOWN (null)','not inferred','not evidence','No additional full raw-source'):
            self.assertIn(phrase,text)
        report=cohort_interpretation(10,list(range(5,15)))+' '+text
        self.assertIn('Task51-only',report)
        self.assertIn('Task22 historical archive qualification remains separate',report)

    def test_other_task_outputs_unchanged(self):
        for task in (3,6,7,8,9,12,21,24,27,32,34,42,43,44,60,61,62,64,67,73,76,79,80):
            before={'interpretation':cohort_interpretation(10,list(range(5,15))),'task_id':task}
            after=dict(before)
            after.update(training_provenance_qualification(task,{'task_id':task},{'task_id':task},{}))
            self.assertEqual(before,after)

    def test_other_task_cannot_carry_exception(self):
        for position in range(3):
            records=[{},{},{}];records[position]['provenance_exception']=legacy.disclosure()
            with self.subTest(position=position),self.assertRaises(ValueError):
                training_provenance_qualification(60,*records)

    def test_missing_or_changed_exception_rejected(self):
        for record in (self.training,self.prep,self.package):
            old=record.pop('provenance_exception')
            with self.assertRaises((ValueError,KeyError)):self.qualify()
            record['provenance_exception']={**old,'collection_namespace':'collection'}
            with self.assertRaises(ValueError):self.qualify()
            record['provenance_exception']=old

    def test_exact_source_set_rechecked(self):
        for key,value in [('path','wrong'),('sha256','b'*64),('bytes',999)]:
            original=self.training['demonstrations'][0][key]
            self.training['demonstrations'][0][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):self.qualify()
            self.training['demonstrations'][0][key]=original
        saved=self.training['demonstrations'].pop()
        with self.assertRaises(ValueError):self.qualify()
        self.training['demonstrations'].append(saved)

    def test_unknown_seed_cannot_be_invented(self):
        self.training['demonstrations'][0]['collection_seed']=0
        with self.assertRaises(ValueError):self.qualify()

    def test_package_training_hash_binding_required(self):
        self.package['training_manifest_sha256']='b'*64
        with self.assertRaises(ValueError):self.qualify()
        self.package.pop('training_manifest_sha256');self.prep.pop('training_manifest_sha256')
        with self.assertRaises(ValueError):self.qualify()

    def test_all_three_task_identities_required(self):
        for record in (self.training,self.prep,self.package):
            record['task_id']=60
            with self.assertRaises(ValueError):self.qualify()
            record['task_id']=51


if __name__ == '__main__':unittest.main()
