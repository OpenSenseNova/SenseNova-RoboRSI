import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
import xml.etree.ElementTree as ET
import shutil
import subprocess

import numpy as np
from scipy.spatial.transform import Rotation

from gpt6_eval.calibration import export_calibration, validate_calibration, RAW_FROM_OPTICAL
from gpt6_eval.kinematics_tool import RobotKinematics, transform
from gpt6_eval.robot import kinematic_urdf, kinematics
from gpt6_eval.core import CAMERAS, save_observation, canonical
from gpt6_eval.cli import ROOT, load_config, runtime_command
from gpt6_eval.bridge import Episode
from gpt6_eval import isolation
from test_pipeline import observation


def calibration_frames():
    return {name: SimpleNamespace(camera_model="fisheye" if "wrist" in name else "pinhole",
             image_shape=(480, 640), intrinsic=np.array([[300, 0, 320], [0, 300, 240], [0, 0, 1]]),
             fisheye_camera_matrix=np.array([[220, 0, 320], [0, 220, 240], [0, 0, 1]]),
             distortion_coefficients=np.zeros(4) if "wrist" in name else None,
             extrinsic_world_from_cam=np.eye(4), depth_m="SECRET", object_pose="SECRET")
            for name in set(sum(CAMERAS.values(), ()))}


def robot_card():
    joints = [
        {"name": "joint", "type": "revolute", "parent": {"link": "base"},
         "child": {"link": "arm"}, "axis": {"xyz": "0 0 1"},
         "limit": {"lower": "-3", "upper": "3"}},
        {"name": "fixed", "type": "fixed", "parent": {"link": "arm"},
         "child": {"link": "tip"}, "origin": {"xyz": "1 0 0", "rpy": "0 0 0"}}]
    return {"active_joint_names": ["joint"], "position_limits": [[-3, 3]],
            "kinematics": {"joints": joints}, "inactive_joint_positions": {}}


class DeploymentTests(unittest.TestCase):
    def test_isolated_tool_import_and_v1_environment_preserved(self):
        binary = Path(shutil.which("codex") or "/missing")
        if not shutil.which("bwrap") or not binary.resolve().with_name("codex-code-mode-host").is_file():
            self.skipTest("Requires configured Linux Codex/bubblewrap installation")
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            workspace, home, interface = root / "workspace", root / "home", root / "interface"
            (workspace / "input").mkdir(parents=True)
            home.mkdir()
            interface.mkdir()
            shutil.copyfile(ROOT / "src/gpt6_eval/kinematics_tool.py", interface / "kinematics_tool.py")
            old = isolation.mounts(workspace, home, interface, binary)
            self.assertNotIn("LD_LIBRARY_PATH", old)
            cmd = isolation.mounts(workspace, home, interface, binary, numerical_runtime=True)
            code = "import sys;sys.path.insert(0,'/interface');from kinematics_tool import RobotKinematics;print('ok')"
            result = subprocess.run(cmd + ["--", "/usr/bin/python3", "-c", code], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout.strip(), "ok")

    def test_optical_transform_and_world_origin_independence(self):
        frames = calibration_frames()
        output = export_calibration(frames, np.eye(4), "base", CAMERAS["baseline_4cam"])
        self.assertNotIn("cam_overhead", output)
        self.assertNotIn("SECRET", canonical(output).decode())
        actual = np.array(output["cam_stereo_left"]["T_robot_base_from_camera_optical"])
        np.testing.assert_allclose(actual @ [0, 0, 1, 1], [1, 0, 0, 1])
        shift = transform([4, 2, 7], [.3, -.4, 1.2])
        for frame in frames.values():
            frame.extrinsic_world_from_cam = shift
        moved = export_calibration(frames, shift, "base", CAMERAS["baseline_4cam"])
        np.testing.assert_allclose(moved["cam_stereo_left"]["T_robot_base_from_camera_optical"], actual, atol=1e-12)

    def test_calibration_validation_fails_closed(self):
        for field, bad in [("intrinsic_matrix", [[1]]), ("distortion_coefficients", [1]),
                           ("image_size_wh", [1280, 960]), ("optical_axes", "unknown"),
                           ("T_robot_base_from_camera_optical", np.zeros((4, 4)).tolist())]:
            data = export_calibration(calibration_frames(), np.eye(4), "base", CAMERAS["baseline_4cam"])
            data["cam_stereo_left"][field] = bad
            with self.assertRaises(ValueError):
                validate_calibration(data, CAMERAS["baseline_4cam"])
        data["cam_stereo_left"]["object_pose"] = "SECRET"
        with self.assertRaises(ValueError):
            validate_calibration(data, CAMERAS["baseline_4cam"])

    def test_v1_excludes_calibration_v2_archives_it_deterministically(self):
        raw = observation()
        raw["camera_calibration"] = export_calibration(calibration_frames(), np.eye(4), "base", CAMERAS["baseline_4cam"])
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            old = save_observation(root / "old", 0, raw, "baseline_4cam", 2, 4)
            self.assertNotIn("camera_calibration", old)
            first = save_observation(root / "new", 0, raw, "baseline_4cam", 2, 4, calibrated=True)
            second = save_observation(root / "new2", 0, raw, "baseline_4cam", 2, 4, calibrated=True)
            self.assertEqual(canonical(first), canonical(second))
            self.assertNotIn("SECRET", canonical(first).decode())
            del raw["camera_calibration"]
            with self.assertRaises(KeyError):
                save_observation(root / "bad", 0, raw, "baseline_4cam", 2, 4, calibrated=True)

    def test_fk_ik_roundtrip_and_unreachable(self):
        robot = RobotKinematics(robot_card())
        target = robot.fk([.8])["tip"]
        np.testing.assert_allclose(target[:3, 3], [np.cos(.8), np.sin(.8), 0])
        result = robot.ik([0], "tip", target, ["joint"])
        self.assertTrue(result["success"])
        self.assertAlmostEqual(result["qpos"][0], .8, places=5)
        self.assertEqual(result, robot.ik([0], "tip", target, ["joint"]))
        target[0, 3] = 20
        self.assertFalse(robot.ik([0], "tip", target, ["joint"])["success"])

    def test_mimic_and_inactive_joints_not_silently_zeroed(self):
        card = robot_card()
        card["kinematics"]["joints"].append({"name": "passive", "type": "prismatic",
            "parent": {"link": "base"}, "child": {"link": "slider"}, "axis": {"xyz": "1 0 0"}})
        with self.assertRaises(ValueError):
            RobotKinematics(card).fk([.4])
        card["inactive_joint_positions"] = {"passive": .2}
        self.assertAlmostEqual(RobotKinematics(card).fk([.4])["slider"][0, 3], .2)
        card["kinematics"]["joints"][-1]["mimic"] = {"joint": "joint", "multiplier": "2", "offset": ".1"}
        self.assertAlmostEqual(RobotKinematics(card).fk([.4])["slider"][0, 3], .9)

    def test_geometry_urdf_no_asset_references(self):
        card = robot_card()
        card["kinematics"]["joints"][0]["untrusted"] = {"path": "SECRET"}
        xml = kinematic_urdf(card)
        self.assertNotIn("SECRET", xml)
        self.assertEqual(len(ET.fromstring(xml).findall("link")), 3)

    def test_explicit_v2_config_and_simulator_flags(self):
        config = load_config(ROOT / "configs/task26_calibrated_single.json")
        args = SimpleNamespace(python=Path("/python"), upstream=Path("/repo"), mode="hold", anchor=None)
        command = runtime_command(args, config, Path("/scene"), "robot", 4, 123, Path("/output"))
        self.assertIn("calibrated_deployment_v2", command)
        legacy = load_config(ROOT / "configs/task26_single.json")
        self.assertNotIn("--deployment-profile", runtime_command(args, legacy, Path("/scene"), "robot", 4, 123, Path("/output")))
        with tempfile.TemporaryDirectory() as folder:
            config["deployment_profile"] = "unknown"
            path = Path(folder) / "config.json"
            path.write_text(json.dumps(config))
            with self.assertRaises(ValueError):
                load_config(path)

    def test_v2_episode_supplies_only_safe_tools_and_urdf(self):
        config = load_config(ROOT / "configs/task26_calibrated_single.json")
        raw = observation(1)
        raw["robot_metadata"]["active_joint_names"] = ["joint"]
        raw["robot_metadata"]["position_limits"] = [[-3, 3]]
        raw["robot_metadata"]["joint_units"] = ["radian"]
        raw["camera_calibration"] = export_calibration(calibration_frames(), np.eye(4), "base", CAMERAS["baseline_4cam"])
        card = robot_card()["kinematics"]
        card["inactive_joint_positions"] = {}
        with tempfile.TemporaryDirectory() as folder:
            episode = Episode(Path(folder) / "episode", config, "Move the cup", "test_robot",
                              card, 4, Path("/codex"), Path("/auth"), "prompt", "hold")
            episode.action(raw)
            self.assertTrue((episode.inputs / "robot.urdf").is_file())
            self.assertTrue((episode.interface / "kinematics_tool.py").is_file())
            self.assertNotIn("SECRET", (episode.private / "observations/000000/observation.json").read_text())
            episode.finish()


if __name__ == "__main__":
    unittest.main()
