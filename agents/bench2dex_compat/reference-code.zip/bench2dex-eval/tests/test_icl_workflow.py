import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

from gpt6_eval.cli import ROOT, load_config
from gpt6_eval.core import write_json
from gpt6_eval.icl_workflow import stages, validate_stage, smoke_config


class ICLWorkflowTests(unittest.TestCase):
    def test_three_workers_six_tests_and_separate_resident_smoke(self):
        args=SimpleNamespace(output=Path('/run'),task=26,upstream=Path('/repo'),
            isaaclab=Path('/lab'),assets=Path('/assets'),python=Path('/python'),
            auth=Path('/auth'),dataset=Path('/demos'),workers=3,startup_timeout_s=600)
        plan=dict(stages(args))
        self.assertIn('gpt6_eval.batch',plan['smoke'])
        self.assertIn('--hold-until-resident',plan['smoke'])
        for name in ('smoke','evaluation'):
            self.assertEqual(plan[name][plan[name].index('--workers')+1],'3')
            self.assertEqual(plan[name][plan[name].index('--startup-timeout-s')+1],'600')
        self.assertNotIn('--hold-until-resident',plan['evaluation'])
        config=load_config(ROOT/'configs/task26_icl_six.json')
        smoke=smoke_config(config,3,1003)
        self.assertEqual((smoke['start_episode'],smoke['num_episodes']),(1003,3))
        self.assertEqual((config['start_episode'],config['num_episodes']),(5,6))
        self.assertEqual((config['model'],config['reasoning_effort']),('gpt-6-astra','max'))
        for first in (3,5,10):
            with self.assertRaises(ValueError): smoke_config(config,3,first)
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            row={'state':'completed','mode':'hold','planned_episodes':3,
                 'episodes':[{'valid':True}]*3,'infrastructure_errors':0}
            write_json(root/'smoke/result.json',row)
            validate_stage(root,'smoke')
            for bad in ({**row,'episodes':[{'valid':True}]*2},
                        {**row,'episodes':[{'valid':True},{'valid':False},{'valid':True}]},
                        {**row,'state':'interrupted'}):
                write_json(root/'smoke/result.json',bad)
                with self.assertRaises(RuntimeError): validate_stage(root,'smoke')

    def test_frozen_stage_order_one_test_and_no_extra_model_smoke(self):
        args=SimpleNamespace(output=Path('/run'),task=22,upstream=Path('/repo'),
            isaaclab=Path('/lab'),assets=Path('/assets'),python=Path('/python'),
            auth=Path('/auth'),dataset=Path('/demos'))
        plan=stages(args)
        self.assertEqual([n for n,_ in plan],['isolation','smoke','training','preparation','test_config','evaluation'])
        self.assertNotIn('--model-smoke',plan[0][1])
        self.assertIn('hold',plan[1][1])
        self.assertIn('/run/test_config.json',plan[-1][1])
        self.assertIn('--workers',plan[-1][1])
        config=load_config(ROOT/'configs/task22_icl_pilot.json')
        self.assertEqual((config['model'],config['reasoning_effort'],config['start_episode'],config['num_episodes']),
                         ('gpt-6-astra','max',5,1))

    def test_no_scoring_on_partial_training_or_unready_package(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            write_json(root/'training/manifest.json',{'state':'complete','demonstrations':[{}]*99})
            with self.assertRaises(RuntimeError):validate_stage(root,'training')
            write_json(root/'preparation/preparation.json',{'state':'failed'})
            with self.assertRaises(RuntimeError):validate_stage(root,'preparation')
            write_json(root/'evaluation/result.json',{'state':'completed','eligible_for_gpt6_score':True,
                                                     'evaluation_setting':'zero_shot'})
            with self.assertRaises(RuntimeError):validate_stage(root,'evaluation')


if __name__=='__main__':unittest.main()
