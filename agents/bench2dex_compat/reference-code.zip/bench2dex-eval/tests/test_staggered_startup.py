import json
import os
from pathlib import Path
import sys
import tempfile
import time
import unittest

from gpt6_eval.batch import run_wave, summarize
from gpt6_eval.cli import ROOT, load_config
from gpt6_eval.suite import validate_plan
from gpt6_eval.telemetry import utc_now


class StaggeredStartupTests(unittest.TestCase):
    def test_three_resident_workers_in_two_separate_waves(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); attempts=[]
            script='''
import json,pathlib,sys,time,os
r=pathlib.Path(sys.argv[1]); i=int(sys.argv[2]); first=int(sys.argv[3]); release=pathlib.Path(sys.argv[4])
d=r/f'episode_{i}'; (d/'private').mkdir(parents=True)
if i>first: assert (r/f'episode_{i-1}/private/startup_ready.json').is_file()
(d/'private/startup_started.json').write_text(json.dumps({'phase':'simulator_launch','worker_pid':os.getpid(),'started_at':'start','monotonic':time.monotonic()}))
m=d/'private/startup_ready.json'; t=m.with_suffix('.tmp')
t.write_text(json.dumps({'ready_at':'ready','phase':'first_validated_observation'})); t.replace(m)
deadline=time.monotonic()+10
while not release.is_file():
    assert time.monotonic()<deadline
    time.sleep(.01)
assert json.loads(release.read_text())['resident_workers']==3
(d/'result.json').write_text(json.dumps({'complete':True}))
'''
            def update():
                return summarize(root,6,'hold',time.monotonic(),utc_now(),attempts,'running',3)
            for first in (0,3):
                release=root/f'release_{first}.json'
                jobs=[{'index':i,'directory':f'episode_{i}','returncode':None,
                       'argv':[sys.executable,'-c',script,str(root),str(i),str(first),str(release)]}
                      for i in range(first,first+3)]
                self.assertTrue(run_wave(jobs,attempts,root,dict(os.environ),update,
                                         startup_timeout_s=10,smoke_release=release))
            self.assertEqual(len(attempts),6)
            self.assertTrue(all(a.get('startup_ready_at') and a['returncode']==0 for a in attempts))

    def test_resident_six_workers_with_serial_startup(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            release = root / 'release.json'
            script = '''
import json,pathlib,sys,time,os
r=pathlib.Path(sys.argv[1]); i=int(sys.argv[2]); d=r/f'episode_{i}'
(d/'private').mkdir(parents=True)
if i: assert (r/f'episode_{i-1}/private/startup_ready.json').exists()
(d/'private/startup_started.json').write_text(json.dumps({'phase':'simulator_launch','worker_pid':os.getpid(),'started_at':'start','monotonic':time.monotonic()}))
time.sleep(.05)
m=d/'private/startup_ready.json'
t=m.with_suffix('.tmp'); t.write_text(json.dumps({'ready_at':str(time.time()),'phase':'first_validated_observation'})); t.replace(m)
deadline=time.monotonic()+10
while not (r/'release.json').exists():
    assert time.monotonic()<deadline
    time.sleep(.01)
assert len(list(r.glob('episode_*/private/startup_ready.json')))==6
(d/'result.json').write_text(json.dumps({'complete':True}))
'''
            jobs = [{'index':i,'directory':f'episode_{i}','returncode':None,
                     'argv':[sys.executable,'-c',script,str(root),str(i)]} for i in range(6)]
            attempts=[]
            def update():
                return summarize(root,6,'hold',time.monotonic(),utc_now(),attempts,'running',6)
            self.assertTrue(run_wave(jobs,attempts,root,dict(os.environ),update,
                                     startup_timeout_s=10,smoke_release=release))
            self.assertEqual(json.loads(release.read_text())['resident_workers'],6)
            self.assertTrue(all(a.get('startup_ready_at') for a in attempts))

    def test_startup_timeout_stops_admission_and_cleans_child(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); attempts=[]
            script = '''
import json,pathlib,sys,time,os
d=pathlib.Path(sys.argv[1])/sys.argv[2]/'private'; d.mkdir(parents=True)
(d/'startup_started.json').write_text(json.dumps({'phase':'simulator_launch','worker_pid':os.getpid(),'started_at':'start','monotonic':time.monotonic()}))
time.sleep(30)
'''
            jobs=[{'index':i,'directory':f'episode_{i}','returncode':None,
                   'argv':[sys.executable,'-c',script,str(root),f'episode_{i}']} for i in range(2)]
            def update():
                return summarize(root,2,'hold',time.monotonic(),utc_now(),attempts,'running',2)
            with self.assertRaisesRegex(RuntimeError,'startup readiness timeout'):
                run_wave(jobs,attempts,root,dict(os.environ),update,startup_timeout_s=.1)
            self.assertEqual(len(attempts),1)
            self.assertIsNotNone(attempts[0]['returncode'])

    def test_plan_preserves_sample_and_model_contract(self):
        plan=json.loads((ROOT/'configs/results_first11_staggered.json').read_text())
        config=load_config(ROOT/'configs/results_first11_two_samples.json')
        validate_plan(plan,config)
        self.assertEqual(plan['workers'],6)
        self.assertEqual(plan['episode_indices'],[3,4])
        self.assertEqual(config['model'],'gpt-6-astra')
        self.assertEqual(config['reasoning_effort'],'max')
        with self.assertRaises(ValueError):
            validate_plan({**plan,'startup_timeout_s':0},config)

    def test_ready_worker_has_no_inference_deadline(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); attempts=[]
            script = '''
import pathlib,json,time,sys,os
d=pathlib.Path(sys.argv[1])/'episode_0'; (d/'private').mkdir(parents=True)
# Reproduce preparation lasting longer than the simulator startup allowance.
time.sleep(.8)
m=d/'private/startup_started.json'; t=m.with_suffix('.tmp')
t.write_text(json.dumps({'phase':'simulator_launch','worker_pid':os.getpid(),'started_at':'start','monotonic':time.monotonic()})); t.replace(m)
m=d/'private/startup_ready.json'; t=m.with_suffix('.tmp')
t.write_text(json.dumps({'ready_at':'ready','phase':'first_validated_observation'})); t.replace(m)
time.sleep(.8)
(d/'result.json').write_text(json.dumps({'complete':True,'eligible_for_gpt6_score':True,'success_rate':0.0}))
'''
            jobs=[{'index':0,'directory':'episode_0','returncode':None,
                   'argv':[sys.executable,'-c',script,str(root)]}]
            def update():
                return summarize(root,1,'codex',time.monotonic(),utc_now(),attempts,'running',1)
            self.assertTrue(run_wave(jobs,attempts,root,dict(os.environ),update,startup_timeout_s=.4))
            self.assertIn('simulator_started_at', attempts[0])

    def test_preparation_failure_stops_without_admitting_next_worker(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); attempts=[]
            jobs=[{'index':i,'directory':f'episode_{i}','returncode':None,
                   'argv':[sys.executable,'-c','import sys; sys.exit(7)']} for i in range(2)]
            def update():
                return summarize(root,2,'hold',time.monotonic(),utc_now(),attempts,'running',2)
            self.assertFalse(run_wave(jobs,attempts,root,dict(os.environ),update,startup_timeout_s=.1))
            self.assertEqual(len(attempts),1)
            self.assertEqual(attempts[0]['returncode'],7)


if __name__ == '__main__':
    unittest.main()
