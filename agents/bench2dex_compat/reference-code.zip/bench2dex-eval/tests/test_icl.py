import io
import json
from pathlib import Path
import tempfile
import unittest
import shutil
import subprocess
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np
from PIL import Image

from gpt6_eval.cli import ROOT, load_config
from gpt6_eval.core import CAMERAS, digest, write_json
from gpt6_eval.icl import export_demo, make_config, explore
from gpt6_eval.knowledge import (SETTING, contract, file_hash, tree_hashes,
    verify_package, attach_package, snapshot_packages)
from gpt6_eval import isolation


def package(root, config, task=3):
    (root / 'payload').mkdir(parents=True)
    (root / 'payload/TASK.md').write_text('Task skills; use your observations.')
    (root / 'payload/SOURCES.md').write_text('Training demo 0000. No web sources.')
    (root / 'payload/control.py').write_text('VALUE = 1\n')
    write_json(root / 'manifest.json', {'setting': SETTING, 'task_id': task,
        'contract': contract(config), 'preparation_model': 'gpt-6-astra',
        'robot_key': 'robot', 'instruction_sha256': digest(b'instruction'),
        'ready': True, 'files': tree_hashes(root / 'payload')})
    return {'path': str(root), 'sha256': file_hash(root / 'manifest.json')}


class KnowledgeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.base = load_config(ROOT / 'configs/task26_calibrated_single.json')
        self.ref = package(self.root / 'package', self.base)
        self.config = {**self.base, 'schema_version': 3, 'evaluation_setting': SETTING,
                       'task_packages': {'3': self.ref}}

    def test_schema_and_legacy_unchanged(self):
        path = self.root/'config.json'
        write_json(path, self.config)
        self.assertEqual(load_config(path), self.config)
        self.assertNotIn('task_packages', self.base)
        for field, value in [('evaluation_setting', 'zero_shot'), ('model','gpt-5.6'),
                             ('generalization_split','seen'), ('reasoning_effort','high')]:
            write_json(path, {**self.config, field:value})
            with self.assertRaises(ValueError): load_config(path)

    def test_task_model_sensor_and_content_binding(self):
        root = Path(self.ref['path'])
        verify_package(root, self.ref['sha256'], 3, self.config)
        with self.assertRaises(ValueError): verify_package(root, self.ref['sha256'], 6, self.config)
        with self.assertRaises(ValueError): verify_package(root, '0'*64, 3, self.config)
        with self.assertRaises(ValueError):
            verify_package(root, self.ref['sha256'], 3, {**self.config,'observation_profile':'baseline_3cam'})
        (root/'payload/control.py').write_text('CHANGED')
        with self.assertRaises(ValueError): verify_package(root, self.ref['sha256'], 3, self.config)

    def test_no_symlinks_hardlinks_or_hidden_extra_files(self):
        root = Path(self.ref['path'])
        for name in ('secret', 'linked_dir'):
            p=root/'payload'/name
            p.symlink_to(self.root, target_is_directory=True)
            with self.assertRaises(ValueError): tree_hashes(root)
            p.unlink()
        p=root/'payload/hardlink'
        p.hardlink_to(root/'payload/TASK.md')
        with self.assertRaises(ValueError): tree_hashes(root)
        p.unlink()
        (root/'extra.txt').write_text('not in manifest')
        with self.assertRaises(ValueError): verify_package(root,self.ref['sha256'],3,self.config)

    def test_fresh_episode_copies_never_share_writable_memory(self):
        root = Path(self.ref['path'])
        for n in ('a','b'):
            attach_package(root,self.ref['sha256'],3,self.config,self.root/n/'input',self.root/n/'private')
        a=self.root/'a/input/task_knowledge/TASK.md'
        b=self.root/'b/input/task_knowledge/TASK.md'
        a.write_text('test outcome not shared')
        self.assertNotEqual(a.read_bytes(),b.read_bytes())
        self.assertEqual(b.read_bytes(),(root/'payload/TASK.md').read_bytes())

    def test_suite_snapshot_missing_task_and_mutation(self):
        with self.assertRaises(ValueError): snapshot_packages(self.config,[6],self.root/'missing')
        cfg=snapshot_packages(self.config,[3],self.root/'snapshot')
        (Path(self.ref['path'])/'payload/TASK.md').write_text('modified external prep')
        ref=cfg['task_packages']['3']
        verify_package(Path(ref['path']),ref['sha256'],3,cfg)

    def test_preparation_only_web_search_and_readonly_input_mount(self):
        fake=['bwrap','--ro-bind','training/public','/workspace/input']
        with patch.object(isolation,'mounts',return_value=fake):
            test=isolation.command(Path('w'),Path('h'),Path('i'),Path('b'),self.config)
            prep=isolation.command(Path('w'),Path('h'),Path('i'),Path('b'),self.base,
                                   preparation=True,input_source=Path('training/public'))
        self.assertIn('web_search="disabled"',test)
        self.assertIn('web_search="live"',prep)
        for cmd in (test,prep):
            self.assertIn('sandbox_workspace_write.network_access=false',cmd)
            self.assertIn('gpt-6-astra',cmd)
            self.assertIn('multi_agent',cmd)

    def test_config_rejects_failed_preparation(self):
        from types import SimpleNamespace
        run=self.root/'prep';run.mkdir()
        write_json(run/'preparation.json',{'state':'failed'})
        with self.assertRaises(ValueError):
            make_config(SimpleNamespace(config=ROOT/'configs/task26_calibrated_single.json',
                preparation=[run],output=self.root/'new.json'))

    def test_actual_preparation_mount_cannot_write_inputs_or_read_host(self):
        binary=Path(shutil.which('codex') or '/missing')
        if not shutil.which('bwrap') or not binary.resolve().with_name('codex-code-mode-host').is_file():
            self.skipTest('Requires pinned Codex installation and bubblewrap')
        workspace=self.root/'workspace';(workspace/'input').mkdir(parents=True)
        public=self.root/'public';public.mkdir();(public/'demo.txt').write_text('safe')
        home=self.root/'home';home.mkdir()
        interface=self.root/'interface';interface.mkdir()
        secret=self.root/'private.txt';secret.write_text('SECRET')
        cmd=isolation.mounts(workspace,home,interface,binary,input_source=public)
        code=("from pathlib import Path\n"
              "assert Path('/workspace/input/demo.txt').read_text()=='safe'\n"
              f"assert not Path({str(secret)!r}).exists()\n"
              "assert not Path('/data').exists()\n"
              "try: Path('/workspace/input/demo.txt').write_text('bad')\n"
              "except OSError: pass\n"
              "else: raise AssertionError('Input writable')\n")
        subprocess.run(cmd+['--','/usr/bin/python3','-c',code],check=True,capture_output=True)

    def test_preparation_ready_freezes_and_records_usage_without_real_model(self):
        training=self.root/'training';(training/'public').mkdir(parents=True)
        (training/'public/task.json').write_text('{"instruction":"instruction"}')
        write_json(training/'manifest.json',{'state':'complete','contract':contract(self.base),
            'task_id':3,'robot_key':'robot','instruction_sha256':digest(b'instruction'),
            'public_files':tree_hashes(training/'public')})
        auth=self.root/'auth.json';auth.write_text('{"FAKE":"test-only"}')
        output=self.root/'exploration'
        class FakeProcess:
            returncode=0
            def __init__(self,cmd,**kwargs):self.out=kwargs['stdout']
            def communicate(self,prompt):
                self.out.write(b'{"type":"turn.completed","usage":{"input_tokens":10,"output_tokens":5}}\n')
                (output/'workspace/package/TASK.md').write_text('Task skill')
                (output/'workspace/package/SOURCES.md').write_text('demo 0000')
                write_json(output/'workspace/ready.json',{'ready':True,'summary':'Prepared'})
                session=output/'private/codex-home/sessions/session.jsonl'
                session.parent.mkdir(parents=True)
                session.write_text('{"type":"turn_context","payload":{"model":"gpt-6-astra"}}\n')
            def poll(self):return self.returncode
        args=SimpleNamespace(config=ROOT/'configs/task26_calibrated_single.json',
            training=training,output=output,auth=auth)
        with patch('gpt6_eval.icl.subprocess.check_output',side_effect=[self.base['codex_version'],b'test packages']), \
             patch('gpt6_eval.icl.subprocess.Popen',FakeProcess):
            explore(args)
        record=json.loads((output/'preparation.json').read_text())
        self.assertEqual(record['state'],'ready')
        self.assertEqual(record['tokens']['total_tokens'],15)
        self.assertFalse((output/'private/codex-home/auth.json').exists())
        ref=record['package']
        verify_package(Path(ref['path']),ref['sha256'],3,self.base)
        target=self.root/'test.json'
        make_config(SimpleNamespace(config=args.config,preparation=[output],output=target))
        self.assertEqual(load_config(target)['schema_version'],3)


class ExportTests(unittest.TestCase):
    def setUp(self):
        try: import h5py
        except ImportError: self.skipTest('h5py needed for exporter tests')
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.source=self.root/'source.hdf5'
        buf=io.BytesIO();Image.new('RGB',(640,480)).save(buf,format='JPEG')
        with h5py.File(self.source,'w') as f:
            for name,value in {'scene_generalization_sample':json.dumps({'_generalization_split':'seen'}),
                 'seed_namespace':'collection','robot_key':'robot','instruction':'instruction',
                 'scene_name':'scene',
                 'episode_seed':123,'step_stride':3,'effective_fps':20.0,'homing_start_sim_step':6}.items():
                f.create_dataset('meta/'+name,data=value)
            f.create_dataset('robot/joint_names',data=['j1','j2'])
            f.create_dataset('action/action_names',data=['j2','j1'])
            f.create_dataset('robot/qpos',data=[[1,2],[3,4],[5,6]])
            f.create_dataset('action/commanded',data=[[20,10],[40,30],[60,50]])
            f.create_dataset('time/sim_step',data=[0,3,6])
            f.create_dataset('objects/SECRET/pose_world',data=[987654321])
            f.create_dataset('metrics/SECRET',data=[987654321])
            for camera in (*CAMERAS['baseline_4cam'],'cam_overhead'):
                ds=f.create_dataset(f'cameras/{camera}/rgb',(3,),dtype=h5py.vlen_dtype(np.dtype('uint8')))
                for i in range(3):ds[i]=np.frombuffer(buf.getvalue(),dtype=np.uint8)

    def export(self,output):
        return export_demo(self.source,output,['j2','j1'],'instruction','robot',CAMERAS['baseline_4cam'],'scene')

    def test_whitelist_joint_reordering_and_homing(self):
        out=self.root/'public';private=self.export(out)
        self.assertEqual(private['collection_seed'],123)
        np.testing.assert_equal(np.load(out/'qpos.npy'),[[2,1],[4,3]])
        np.testing.assert_equal(np.load(out/'actions.npy'),[[20,10],[40,30]])
        files=tree_hashes(out)
        self.assertEqual(len(files),11)
        self.assertFalse(any('SECRET' in p or 'overhead' in p or 'meta' in p for p in files))
        self.assertNotIn('collection_seed',json.loads((out/'demo.json').read_text()))

    def test_deterministic_export(self):
        self.export(self.root/'a');self.export(self.root/'b')
        self.assertEqual(tree_hashes(self.root/'a'),tree_hashes(self.root/'b'))

    def test_recorded_instruction_difference_is_explicit(self):
        import h5py
        with h5py.File(self.source,'r+') as f:f['meta/instruction'][()]='Earlier task description'
        record=self.export(self.root/'public')
        self.assertFalse(record['instruction_matches_current_task'])
        public=json.loads((self.root/'public/demo.json').read_text())
        self.assertEqual(public['recorded_instruction'],'Earlier task description')
        with h5py.File(self.source,'r+') as f:f['meta/scene_name'][()]='different_scene'
        with self.assertRaises(ValueError):self.export(self.root/'wrong')

    def test_task62_scene_alias_is_exact_and_private(self):
        import h5py
        from gpt6_eval.task62_scene_alias import disclosure
        with h5py.File(self.source,'r+') as f:
            del f['meta/robot_key']; f.create_dataset('meta/robot_key',data='multi_xarm7_with_leap')
            del f['meta/scene_name']; f.create_dataset('meta/scene_name',data='62_pet_shoebox_accessory_pack')
        out=self.root/'alias'
        record=export_demo(self.source,out,['j2','j1'],'instruction',
            'multi_xarm7_with_leap',CAMERAS['baseline_4cam'],
            '62_shoebox_accessory_pack',include_images=False,scene_alias=disclosure())
        self.assertEqual(record['recorded_scene_name'],'62_pet_shoebox_accessory_pack')
        self.assertNotIn('recorded_scene_name',json.loads((out/'demo.json').read_text()))
        with self.assertRaises(ValueError):
            export_demo(self.source,self.root/'wrong_alias',['j2','j1'],'instruction',
                'multi_xarm7_with_leap',CAMERAS['baseline_4cam'],
                '62_shoebox_accessory_pack',include_images=False,
                scene_alias={**disclosure(),'source_count':99})
        with self.assertRaises(ValueError):
            export_demo(self.source,self.root/'no_alias',['j2','j1'],'instruction',
                'multi_xarm7_with_leap',CAMERAS['baseline_4cam'],
                '62_shoebox_accessory_pack',include_images=False)

    def test_rejects_unseen_and_evaluation_data(self):
        import h5py
        with h5py.File(self.source,'r+') as f:
            f['meta/scene_generalization_sample'][()]=json.dumps({'_generalization_split':'unseen'})
        with self.assertRaises(ValueError):self.export(self.root/'bad')
        with h5py.File(self.source,'r+') as f:
            f['meta/scene_generalization_sample'][()]=json.dumps({'_generalization_split':'seen'})
            f['meta/seed_namespace'][()]='evaluation'
        with self.assertRaises(ValueError):self.export(self.root/'bad2')


if __name__=='__main__':unittest.main()
