"""Host-only tests: successful completed workers release only CPU reservations."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

spec=importlib.util.spec_from_file_location('slot_campaign',Path(__file__).parents[1]/'scripts/run_icl_campaign.py')
host=importlib.util.module_from_spec(spec);spec.loader.exec_module(host)

class CompletedSlots(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.proc=self.root/'proc';self.proc.mkdir()
        self.job={'workers':5,'output':str(self.root)}
        self.rows=[{'worker_index':i,'pid':100+i,'returncode':None,'valid':False} for i in range(5)]
    def count(self):
        (self.root/'result.json').write_text(json.dumps({'workers':5,'episodes':self.rows}))
        return host.remaining_worker_slots(self.job,self.proc)
    def finish(self,i):
        self.rows[i].update(valid=True,returncode=0,ended_at='2026-09-28T16:00:00+00:00')
    def test_running_and_unstarted_keep_budget(self):
        self.assertEqual(self.count(),5);self.rows=self.rows[:2];self.assertEqual(self.count(),5)
    def test_finished_reaped_slots_release(self):
        self.finish(0);self.finish(2);self.assertEqual(self.count(),3)
        self.assertEqual(host.offline_capacity(39124,3*9216-17032),1)
        self.assertEqual(host.offline_capacity(39124,5*9216-17032),0)
    def test_live_or_reused_pid_retains(self):
        self.finish(0);(self.proc/'100').mkdir();self.assertEqual(self.count(),5)
    def test_invalid_or_unfinalized_retains(self):
        self.finish(0);self.rows[0]['valid']=False;self.assertEqual(self.count(),5)
        self.finish(0);self.rows[0]['ended_at']=None;self.assertEqual(self.count(),5)
    def test_duplicate_slots_fail_closed(self):
        self.finish(0);self.rows[1]['worker_index']=0;self.assertEqual(self.count(),5)
    def test_missing_malformed_evidence_retains(self):
        self.assertEqual(host.remaining_worker_slots(self.job,self.proc),5)
        (self.root/'result.json').write_text('{');self.assertEqual(host.remaining_worker_slots(self.job,self.proc),5)
    def test_all_finished_zero_pending(self):
        for i in range(5):self.finish(i)
        self.assertEqual(self.count(),0)

if __name__=='__main__':unittest.main()
