import json
from pathlib import Path
import tempfile
import unittest

from gpt6_eval.cli import ROOT, load_config
from gpt6_eval.suite import collect_results, validate_plan


class SuiteTests(unittest.TestCase):
    def test_frozen_results_order_and_two_fresh_samples(self):
        plan = json.loads((ROOT / 'configs/results_first11_suite.json').read_text())
        config = load_config(ROOT / 'configs/results_first11_two_samples.json')
        validate_plan(plan, config)
        self.assertEqual(plan['task_ids'], [32, 26, 73, 80, 61, 22, 64, 67, 24, 79, 3])
        self.assertEqual(plan['episode_indices'], [3, 4])
        self.assertEqual(config['model'], 'gpt-6-astra')
        self.assertEqual(config['generalization_profile'], 'inv_cov')
        self.assertEqual(config['deployment_profile'], 'calibrated_deployment_v2')

    def test_rejects_overlap_duplicate_tasks_and_multiple_workers(self):
        plan = json.loads((ROOT / 'configs/results_first11_suite.json').read_text())
        config = load_config(ROOT / 'configs/results_first11_two_samples.json')
        for change in ({'workers': 2}, {'smoke_episode_index': 3},
                       {'task_ids': [32] * 11}, {'episode_indices': [1, 2]}):
            with self.assertRaises(ValueError): validate_plan({**plan, **change}, config)

    def collect_fixture(self, state, second):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        root = Path(tmp.name)
        plan = {'task_ids': [32, 26], 'task_names': ['A', 'B'], 'episodes_per_task': 2}
        for task_id, r in [(32, {'state': 'completed', 'eligible_for_gpt6_score': True,
                               'planned_episodes': 2, 'scored_episodes': 2,
                               'successes': 1, 'failures': 1, 'success_rate': 0.5}), (26, second)]:
            if r is not None:
                p = root / f'evaluation/task_{task_id:02d}/result.json'
                p.parent.mkdir(parents=True)
                p.write_text(json.dumps(r))
        return collect_results(root, plan, state, 'fixed', 1.0)

    def test_incomplete_suite_retains_planned_denominator(self):
        r = self.collect_fixture('evaluation/task_26', None)
        self.assertEqual(r['planned_episodes'], 4)
        self.assertEqual(r['scored_episodes'], 2)
        self.assertIsNone(r['success_rate'])
        self.assertEqual(r['tasks'][0]['success_rate'], 0.5)
        self.assertEqual(r['tasks'][1]['state'], 'not_started')

    def test_valid_failures_count_and_completed_suite_aggregates(self):
        r = self.collect_fixture('completed', {'state': 'completed', 'eligible_for_gpt6_score': True,
              'planned_episodes': 2, 'scored_episodes': 2, 'successes': 0, 'failures': 2,
              'success_rate': 0.0})
        self.assertTrue(r['eligible_for_gpt6_score'])
        self.assertEqual(r['success_rate'], 0.25)
        self.assertEqual(r['failures'], 3)

    def test_infrastructure_error_never_becomes_a_scored_failure(self):
        r = self.collect_fixture('stopped_on_infrastructure_error',
             {'state': 'stopped_on_infrastructure_error', 'eligible_for_gpt6_score': False,
              'scored_episodes': 0, 'infrastructure_errors': 1})
        self.assertEqual(r['infrastructure_errors'], 1)
        self.assertEqual(r['failures'], 1)
        self.assertIsNone(r['success_rate'])
        self.assertIsNone(r['tasks'][1]['success_rate'])


if __name__ == '__main__': unittest.main()
