import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import uuid
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np

from test_icl import ExportTests
from gpt6_eval import isolation
from gpt6_eval.core import CAMERAS, write_json
from gpt6_eval.demo_reader import DemoReader, source_signature, verified_source
from gpt6_eval.icl import export_demo
from gpt6_eval.knowledge import file_hash, tree_hashes


class ReaderTests(ExportTests):
    def make_reader(self):
        public = self.root / 'indexed'
        args = (['j2', 'j1'], 'instruction', 'robot', CAMERAS['baseline_4cam'], 'scene')
        export_demo(self.source, public / 'demos/0000', *args, include_images=False)
        entries = []
        for n in range(100):
            ident = f'{n:04d}'
            if n:
                shutil.copytree(public / 'demos/0000', public / 'demos' / ident)
            entries.append({'public_id': ident, 'path': self.source.name,
                'sha256': file_hash(self.source), 'frames': 2,
                'source_signature': source_signature(self.source)})
        private = self.root / 'private'; private.mkdir()
        training = {'access_mode': 'trusted_reader_v1', 'contract': {'observation_profile': 'baseline_4cam'},
                    'dataset_root': str(self.root), 'demonstrations': entries}
        reader = DemoReader(training, public, private, reserve_bytes=0)
        self.addCleanup(reader.close)
        return reader

    def request(self, reader, data):
        name = uuid.uuid4().hex + '.json'
        write_json(reader.requests / name, data)
        reply = reader.responses / 'replies' / name
        until = time.monotonic() + 10
        while not reply.exists():
            if time.monotonic() > until: self.fail('Reader did not answer')
            time.sleep(.02)
        return json.loads(reply.read_text())

    def test_lazy_metadata_and_all_pixels_equal_full_export(self):
        reader = self.make_reader()
        self.export(self.root / 'full')
        for name, h in tree_hashes(reader.public / 'demos/0000').items():
            self.assertEqual(h, file_hash(self.root / 'full' / name))
        self.assertEqual(len(tree_hashes(reader.public / 'demos/0000')), 3)
        reader.start()
        for cam in CAMERAS['baseline_4cam']:
            reply = self.request(reader, {'demo': '0000', 'camera': cam, 'frames': [1, 0, 1]})
            self.assertTrue(reply['ok'])
            self.assertEqual([x['frame'] for x in reply['images']], [1, 0, 1])
            for row in reply['images']:
                self.assertEqual(row['sha256'], file_hash(self.root / 'full' / cam / f'{row["frame"]:06d}.png'))
        self.assertEqual(len(reader.served), 8)
        reader.finish()
        self.assertEqual(json.loads((reader.private / 'demo_reader_audit.json').read_text())['state'], 'verified')

    def test_rejects_private_fields_cameras_and_out_of_range(self):
        reader = self.make_reader(); reader.start()
        good = {'demo': '0000', 'camera': 'cam_stereo_left', 'frames': [0]}
        for request in ({**good, 'path': '/etc/passwd'}, {**good, 'demo': '../secret'},
                        {**good, 'camera': 'cam_overhead'}, {**good, 'camera': 'objects/SECRET/pose_world'},
                        {**good, 'frames': [2]}, {**good, 'frames': [-1]},
                        {**good, 'frames': [True]}, {**good, 'frames': [0]*65},
                        {**good, 'frames': []}, {**good, 'frames': '0'}, []):
            self.assertFalse(self.request(reader, request)['ok'])
        self.assertTrue(self.request(reader, good)['ok'])
        self.assertIsNone(reader.failure)

    def test_mutated_source_fails_closed(self):
        reader = self.make_reader(); reader.start()
        with self.source.open('ab') as f: f.write(b'mutated')
        reply = self.request(reader, {'demo': '0000', 'camera': 'cam_stereo_left', 'frames': [0]})
        self.assertFalse(reply['ok'])
        self.assertNotIn(str(self.root), json.dumps(reply))
        with self.assertRaises(RuntimeError): reader.finish()

    def test_post_preparation_verification_detects_unused_source_change(self):
        reader = self.make_reader(); reader.start()
        with self.source.open('ab') as f: f.write(b'mutated')
        with self.assertRaises(ValueError): reader.finish()

    def test_corrupt_delivered_image_rejects_freeze(self):
        reader = self.make_reader(); reader.start()
        self.request(reader, {'demo': '0000', 'camera': 'cam_stereo_left', 'frames': [0]})
        reader.close()
        (reader.responses / 'images/0000/cam_stereo_left/000000.png').write_bytes(b'bad')
        with self.assertRaises(ValueError): reader.finish()

    def test_symlink_hardlink_fifo_requests_cannot_escape(self):
        reader = self.make_reader(); reader.start()
        for kind in ('symlink', 'hardlink', 'fifo'):
            name = uuid.uuid4().hex + '.json'; p = reader.requests / name
            if kind == 'symlink': p.symlink_to(self.source)
            elif kind == 'hardlink': p.hardlink_to(self.source)
            else: os.mkfifo(p)
            end = time.monotonic() + 5
            reply = reader.responses / 'replies' / name
            while not reply.exists() and time.monotonic() < end: time.sleep(.02)
            self.assertFalse(json.loads(reply.read_text())['ok'])
            p.unlink()
        self.assertEqual(reader.served, {})

    def test_insufficient_storage_fails_without_partial_success(self):
        reader = self.make_reader(); reader.reserve_bytes = 10**30; reader.start()
        reply = self.request(reader, {'demo': '0000', 'camera': 'cam_stereo_left', 'frames': [0]})
        self.assertFalse(reply['ok'])
        with self.assertRaises(RuntimeError): reader.finish()

    def test_actual_namespace_client_and_private_boundary(self):
        binary = shutil.which('codex')
        if not shutil.which('bwrap') or not binary or not Path(binary).resolve().with_name('codex-code-mode-host').is_file():
            self.skipTest('Linux bubblewrap and Codex companion required')
        reader = self.make_reader(); reader.start()
        work = self.root / 'workspace'; (work / 'input').mkdir(parents=True)
        home = self.root / 'home'; home.mkdir()
        interface = reader.private / 'interface'; interface.mkdir()
        from gpt6_eval import demo_reader_client
        shutil.copyfile(demo_reader_client.__file__, interface / 'demo_reader.py')
        cmd = isolation.mounts(work, home, interface, Path(shutil.which('codex')),
                               numerical_runtime=True, input_source=reader.public)
        code = """
import sys
from pathlib import Path
sys.path.insert(0, '/interface')
from demo_reader import frames
p = Path(frames('0000', 'cam_stereo_left', [0])[0])
assert p.read_bytes().startswith(b'\\x89PNG')
assert not Path('/data').exists()
assert not Path('/interface/demo_reader_server.py').exists()
try: p.write_bytes(b'bad')
except OSError: pass
else: raise AssertionError('Response writable')
try: Path('/workspace/input/demos/0000/demo.json').write_text('bad')
except OSError: pass
else: raise AssertionError('Input writable')
print('reader namespace passed')
"""
        for nested in ([], ['/opt/codex', 'sandbox', '-c', 'sandbox_mode="workspace-write"',
                             '-c', 'sandbox_workspace_write.network_access=false', '--']):
            run = subprocess.run(cmd + ['--'] + nested + ['/usr/bin/python3', '-c', code],
                                 capture_output=True, text=True, timeout=30)
            self.assertEqual(run.returncode, 0, run.stderr)
            self.assertIn('reader namespace passed', run.stdout)

    def test_exploration_freezes_reader_audit_and_only_selected_package_data(self):
        from gpt6_eval.icl import explore
        from gpt6_eval.cli import ROOT, load_config
        from gpt6_eval.knowledge import contract
        reader = self.make_reader(); reader.close()
        base = load_config(ROOT / 'configs/task26_calibrated_single.json')
        training = self.root / 'training'; training.mkdir()
        shutil.copytree(reader.public, training / 'public')
        manifest = {**reader.training, 'state': 'complete', 'task_id': 3,
                    'contract': contract(base), 'robot_key': 'robot',
                    'instruction_sha256': hashlib.sha256(b'instruction').hexdigest(),
                    'public_files': tree_hashes(training / 'public')}
        write_json(training / 'manifest.json', manifest)
        output = self.root / 'explore'
        auth = self.root / 'auth.json'; auth.write_text('{"FAKE":"test-only"}')
        case = self
        class FakeProcess:
            returncode = 0
            def __init__(self, cmd, **kwargs): self.out = kwargs['stdout']
            def communicate(self, prompt):
                case.assertIn(b'/interface/demo_reader.py', prompt)
                service = SimpleNamespace(requests=output/'private/demo-reader-requests',
                                          responses=output/'private/demo-reader-public')
                reply = case.request(service, {'demo': '0000', 'camera': 'cam_stereo_left', 'frames': [0]})
                case.assertTrue(reply['ok'])
                self.out.write(b'{"type":"turn.completed","usage":{"input_tokens":10,"output_tokens":5}}\n')
                (output/'workspace/package/TASK.md').write_text('Task skill')
                (output/'workspace/package/SOURCES.md').write_text('demo 0000')
                write_json(output/'workspace/ready.json', {'ready':True,'summary':'Prepared'})
                session=output/'private/codex-home/sessions/session.jsonl'; session.parent.mkdir(parents=True)
                session.write_text('{"type":"turn_context","payload":{"model":"gpt-6-astra"}}\n')
            def poll(self): return self.returncode
        with patch('gpt6_eval.icl.subprocess.check_output', side_effect=[base['codex_version'], b'test packages']), \
             patch('gpt6_eval.icl.subprocess.Popen', FakeProcess), \
             patch('gpt6_eval.demo_reader.DemoReader', side_effect=lambda *a: DemoReader(*a, reserve_bytes=0)):
            explore(SimpleNamespace(config=ROOT/'configs/task26_calibrated_single.json',
                                    training=training, output=output, auth=auth))
        record=json.loads((output/'preparation.json').read_text())
        case.assertEqual(record['state'], 'ready')
        package=json.loads((output/'frozen/manifest.json').read_text())
        case.assertEqual(package['demonstration_access'], 'trusted_reader_v1')
        case.assertEqual(package['reader_audit_sha256'], file_hash(output/'private/demo_reader_audit.json'))
        case.assertEqual(set(package['files']), {'TASK.md', 'SOURCES.md'})
        case.assertFalse((output/'private/codex-home/auth.json').exists())
