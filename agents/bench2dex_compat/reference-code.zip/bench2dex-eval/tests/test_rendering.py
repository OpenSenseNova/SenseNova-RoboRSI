import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
import os
import subprocess
import sys

from gpt6_eval.rendering import validate_rendering, SETTING_KEYS
from gpt6_eval.prepare_task26_assets import selection
from gpt6_eval.cli import ROOT


class RenderingTests(unittest.TestCase):
    def test_real_usd_recursive_payload_and_texture_gate(self):
        if not list(Path(sys.prefix).glob("lib/python*/site-packages/isaacsim/kit")):
            self.skipTest("Requires installed IsaacLab bundled USD runtime")
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "scene.usda").write_text('#usda 1.0\n( subLayers = [@child.usda@] )\n')
            (root / "child.usda").write_text(
                '#usda 1.0\ndef Scope "Material" {\n asset texture = @missing.png@\n}\n')
            cmd = [sys.executable, "-m", "gpt6_eval.audit_scene_assets", "--assets", str(root),
                   "--scene", str(root / "scene.usda"), "--output", str(root / "report.json")]
            env = {**os.environ, "PYTHONPATH": str(ROOT / "src")}
            result = subprocess.run(cmd, env=env, capture_output=True, text=True)
            self.assertEqual(result.returncode, 1, result.stderr)
            report = json.loads((root / "report.json").read_text())
            self.assertEqual(report["unresolved_count"], 1)
            (root / "missing.png").write_bytes(b"dependency existence fixture")
            result = subprocess.run(cmd, env=env, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads((root / "report.json").read_text())["unresolved_count"], 0)

    def test_missing_dependency_fails_closed_and_saves_evidence(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "rendering.json"
            stage = SimpleNamespace(GetRootLayer=lambda: SimpleNamespace(identifier="anon:fixture"))
            compute = lambda root: ([], [], ["missing/room.usda", "missing/texture.png"])
            with self.assertRaisesRegex(RuntimeError, "2 unresolved USD assets"):
                validate_rendering(stage, {}, path, compute_dependencies=compute)
            report = json.loads(path.read_text())
            self.assertEqual(report["status"], "failed")
            self.assertEqual(report["dependencies"]["unresolved"],
                             ["missing/room.usda", "missing/texture.png"])

    def test_success_records_effective_settings_without_modifying_them(self):
        with tempfile.TemporaryDirectory() as folder:
            stage = SimpleNamespace(GetRootLayer=lambda: SimpleNamespace(identifier="anon:fixture"))
            settings = {key: False for key in SETTING_KEYS}
            compute = lambda root: ([SimpleNamespace(identifier="robot.usd")], ["texture.png"], [])
            report = validate_rendering(stage, settings, Path(folder) / "report.json",
                                        compute_dependencies=compute)
            self.assertEqual(report["status"], "passed")
            self.assertEqual(report["settings"], settings)
            self.assertEqual(report["dependencies"]["layers"], ["robot.usd"])

    def test_download_includes_separate_room_object_assets(self):
        upstream = ROOT.parent / "Bench2Dex"
        if not upstream.is_dir():
            self.skipTest("Local upstream not installed")
        patterns = selection(upstream)
        self.assertIn("Objects/thor/*", patterns)
        self.assertFalse(any("teleop" in p or "checkpoint" in p for p in patterns))


if __name__ == "__main__":
    unittest.main()
