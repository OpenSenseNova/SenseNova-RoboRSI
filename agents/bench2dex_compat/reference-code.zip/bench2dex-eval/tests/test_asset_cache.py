import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from gpt6_eval import throughput


class AssetCacheTests(unittest.TestCase):
    def test_reuse_requires_matching_tree_and_periodic_full_refresh(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / 'assets'; root.mkdir()
            (root / 'scene.usd').write_bytes(b'original scene')
            cache = Path(d) / 'cache.json'
            first, evidence = throughput.cached_asset_hashes(root, cache)
            self.assertEqual(evidence['mode'], 'full_hash')
            with patch.object(throughput, 'content_hashes', side_effect=AssertionError('rehash')):
                second, reused = throughput.cached_asset_hashes(root, cache)
            self.assertEqual(first, second)
            self.assertEqual(reused['mode'], 'metadata_reuse')
            _, refreshed = throughput.cached_asset_hashes(root, cache, max_age_s=0)
            self.assertEqual(refreshed['mode'], 'full_hash')

            (root / 'scene.usd').write_bytes(b'changed scene')
            with self.assertRaisesRegex(ValueError, 'Asset content changed'):
                throughput.cached_asset_hashes(root, cache)

    def test_missing_asset_fails_closed(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / 'assets'; root.mkdir()
            asset = root / 'scene.usd'; asset.write_bytes(b'scene')
            cache = Path(d) / 'cache.json'
            throughput.cached_asset_hashes(root, cache)
            asset.unlink()
            with self.assertRaisesRegex(ValueError, 'Asset file set changed'):
                throughput.cached_asset_hashes(root, cache)


if __name__ == '__main__':
    unittest.main()
