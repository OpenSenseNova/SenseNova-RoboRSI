import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from gpt6_eval import batch
from gpt6_eval.cli import ROOT
from gpt6_eval.core import write_json
from gpt6_eval.monitor import request_stop, status


class MonitorTests(unittest.TestCase):
    def test_single_config_changes_only_episode_count(self):
        single = json.loads((ROOT / "configs/task26_single.json").read_text())
        pilot = json.loads((ROOT / "configs/task26_pilot8.json").read_text())
        self.assertEqual(single, {**pilot, "num_episodes": 1})

    def test_stop_is_idempotent_and_requires_support(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            with self.assertRaises(RuntimeError):
                request_stop(root)
            write_json(root / "manifest.json", {"cooperative_stop": True})
            request_stop(root)
            first = (root / batch.STOP_FILE).read_bytes()
            request_stop(root)
            self.assertEqual(first, (root / batch.STOP_FILE).read_bytes())
            self.assertTrue(batch.stop_requested(root))

    def test_status_reads_live_step_and_handles_partial_json(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            write_json(root / "workflow.json", {"state": "evaluation"})
            output = root / "evaluation"
            child = output / "episode_0000"
            write_json(output / "result.json", {"state": "running", "episodes": [
                {"directory": "episode_0000", "upstream_episode_index": 1}]})
            write_json(child / "episode_0000/policy/input/observation.json", {"policy_step": 339})
            write_json(child / "private/manifest.json", {"executed_policy_budget": 871})
            result = status(root)
            self.assertEqual(result["episodes"][0]["policy_step"], 339)
            self.assertEqual(result["episodes"][0]["policy_budget"], 871)
            (output / "result.json").write_text('{"state":')
            self.assertEqual(status(root)["state"], "evaluation")

    def test_batch_finishes_wave_then_stops_without_scoring_missing_episodes(self):
        with tempfile.TemporaryDirectory() as folder:
            output = Path(folder) / "batch"
            argv = ["batch", "--config", str(ROOT / "configs/task26_pilot8.json"),
                    "--task", "26", "--workers", "1", "--output", str(output)]
            for key in ("upstream", "isaaclab", "assets", "python"):
                argv.extend(["--" + key, folder])
            def wave(jobs, attempts, root, env, updated):
                # Operator requests a drain while episode one is running.
                request_stop(root)
                for job in jobs:
                    write_json(root / job["directory"] / "result.json", {
                        "complete": True, "eligible_for_gpt6_score": True, "success_rate": 0.0})
                    attempts.append({**job, "returncode": 0})
                return True
            with patch("sys.argv", argv), patch("gpt6_eval.batch.signal.signal"), \
                    patch("gpt6_eval.batch.resource_snapshot", return_value={"admitted": True}), \
                    patch("gpt6_eval.batch.run_wave", side_effect=wave) as runner:
                with self.assertRaises(SystemExit) as caught:
                    batch.main()
            self.assertEqual(caught.exception.code, 0)
            self.assertEqual(runner.call_count, 1)
            report = json.loads((output / "result.json").read_text())
            self.assertEqual(report["state"], "stopped_by_request")
            self.assertEqual(report["scored_episodes"], 1)
            self.assertEqual(report["not_attempted_episodes"], 7)
            self.assertEqual(report["infrastructure_errors"], 0)
            self.assertIsNone(report["success_rate"])


if __name__ == "__main__":
    unittest.main()
