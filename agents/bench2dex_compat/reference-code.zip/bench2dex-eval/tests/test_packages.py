"""Public package installation, corruption rejection and archive containment."""
import hashlib
import json
from pathlib import Path
import shutil
import stat
import tempfile
import unittest
from unittest.mock import patch
import zipfile

from gpt6_eval.cli import ROOT, load_config
from gpt6_eval.knowledge import SETTING, contract
from gpt6_eval.packages import install, verify_installed


def sha(data):
    return hashlib.sha256(data).hexdigest()


class PackageInstallationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='package test ')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / 'downloaded dataset'
        (self.source / 'packages').mkdir(parents=True)
        self.output = self.root / 'installed packages'
        self.catalog_path = self.root / 'catalog.json'
        self.archive = self.source / 'packages/task_26.zip'
        base = load_config(ROOT / 'configs/icl_base.json')
        manifest = {'task_id': 26, 'setting': SETTING, 'contract': contract(base),
                    'preparation_model': base['model'], 'ready': True,
                    'files': {'TASK.md': sha(b'task'), 'SOURCES.md': sha(b'sources')}}
        self.members = {'manifest.json': json.dumps(manifest).encode(),
                        'payload/TASK.md': b'task', 'payload/SOURCES.md': b'sources'}
        self.catalog = {'schema_version': 1, 'setting': SETTING, 'contract': contract(base),
                        'packages': [{'task_id': 26, 'archive': 'packages/task_26.zip',
                                      'manifest_sha256': sha(self.members['manifest.json'])}]}
        self.write_archive()

    def write_archive(self, special=None):
        with zipfile.ZipFile(self.archive, 'w', zipfile.ZIP_DEFLATED) as bundle:
            for name, data in self.members.items():
                if special == name:
                    info = zipfile.ZipInfo(name)
                    info.create_system = 3
                    info.external_attr = (stat.S_IFLNK | 0o777) << 16
                    bundle.writestr(info, data)
                else:
                    bundle.writestr(name, data)
        self.catalog['packages'][0].update(sha256=sha(self.archive.read_bytes()),
            archive_bytes=self.archive.stat().st_size, package_bytes=sum(map(len, self.members.values())))
        self.catalog_path.write_text(json.dumps(self.catalog))

    def run_install(self, **kwargs):
        return install(self.catalog_path, self.output, source=self.source, **kwargs)

    def test_install_and_relocate_without_preparation(self):
        config = json.loads(self.run_install().read_text())
        self.assertEqual(config['schema_version'], 3)
        self.assertEqual(config['task_packages']['26']['path'], 'task_26')
        self.assertEqual(verify_installed(self.output), [26])
        moved = self.root / 'moved again'
        shutil.move(self.output, moved)
        self.assertEqual(verify_installed(moved), [26])

    def test_archive_hash_mismatch_leaves_no_installation(self):
        self.archive.write_bytes(self.archive.read_bytes() + b'changed')
        with self.assertRaisesRegex(ValueError, 'hash mismatch'):
            self.run_install()
        self.assertFalse(self.output.exists())
        self.assertEqual(list(self.root.glob('.icl-install-*')), [])

    def test_payload_changes_rejected_even_with_new_archive_hash(self):
        self.members['payload/TASK.md'] = b'altered'
        self.write_archive()
        with self.assertRaisesRegex(ValueError, 'changed after freezing'):
            self.run_install()

    def test_manifest_changes_rejected(self):
        self.members['manifest.json'] += b' '
        self.write_archive()
        with self.assertRaisesRegex(ValueError, 'manifest hash mismatch'):
            self.run_install()

    def test_unknown_task_rejected(self):
        with self.assertRaisesRegex(ValueError, 'not included'):
            self.run_install(tasks=[3])

    def test_reject_existing_output(self):
        self.output.mkdir()
        (self.output / 'keep').write_text('unchanged')
        with self.assertRaisesRegex(ValueError, 'already exists'):
            self.run_install()
        self.assertEqual((self.output / 'keep').read_text(), 'unchanged')

    def test_unsafe_archive_paths_rejected(self):
        for name in ('../escaped', '/absolute', 'payload/../../escaped',
                     'payload/../escaped', 'payload\\escaped', 'payload/a:b'):
            with self.subTest(name=name):
                self.members[name] = b'bad'
                self.write_archive()
                with self.assertRaisesRegex(ValueError, 'Unsafe'):
                    self.run_install()
                del self.members[name]
        self.assertFalse((self.root / 'escaped').exists())

    def test_archive_symlink_rejected(self):
        self.write_archive(special='payload/TASK.md')
        with self.assertRaisesRegex(ValueError, 'Unsafe'):
            self.run_install()

    def test_undeclared_file_rejected(self):
        self.members['payload/extra.txt'] = b'unexpected'
        self.write_archive()
        with self.assertRaisesRegex(ValueError, 'changed after freezing'):
            self.run_install()

    def test_wrong_contract_rejected(self):
        self.catalog['contract']['observation_profile'] = 'baseline_3cam'
        self.catalog_path.write_text(json.dumps(self.catalog))
        with self.assertRaisesRegex(ValueError, 'contract differ'):
            self.run_install()

    def test_download_uses_dataset_api_and_pinned_local_hash(self):
        with patch('huggingface_hub.hf_hub_download', return_value=str(self.archive)) as download:
            install(self.catalog_path, self.output, repo_id='example/dataset', revision='revision')
        download.assert_called_once_with(repo_id='example/dataset', repo_type='dataset',
                                         revision='revision', filename='packages/task_26.zip')
        self.assertEqual(verify_installed(self.output), [26])


if __name__ == '__main__':
    unittest.main()
