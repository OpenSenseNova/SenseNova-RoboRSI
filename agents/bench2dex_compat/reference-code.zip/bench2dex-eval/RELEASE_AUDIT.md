# Public release audit — 2026-10-12

The source and frozen-package distributions were prepared as separate copies.
Owner license selection remains pending. No Git history, credentials, raw runs,
model transcripts, private maintenance files or simulator installation is shipped.

| Examination | Result |
| --- | --- |
| Source completeness | All 43 original runtime modules, all 37 original test files and all 7 prompts retained; public preflight/download tooling and tests added. |
| Sensitive information | Source text scan, excluded-artifact scan, archive member review, package text and binary metadata inspection. Final distribution scans have no findings. Heuristic scans cannot prove absence of every possible secret. |
| Frozen packages | 26 originals verified against recorded manifests; 3,610 payload files remain byte-identical. Only outer manifests omit session filenames and add explicit public provenance. |
| Package metadata | 2,406 images checked for embedded metadata; 5,463 NumPy arrays read with pickle disabled. One visual sample/contact sheet per task reviewed. Four apparent email matches were Python matrix operators, confirmed by tokenization. |
| Package selfchecks | All 26 passed in read-only mounts without network, raw demonstrations or the preparation workspace. Repeated successfully with the fresh pinned dependency environment. |
| Direct use / relocation | All 26 ZIPs installed through the public helper, then the whole installed collection was moved to a path containing spaces and verified again. Config references remain relative. |
| Reproduction schedule | All 78 original standard-budget result digests/configs checked: 26 tasks, indices 5–7, original seeds and contract. A portable schedule and commands are included. |
| Source regression | **340 passed, 5 skipped (345 total)** in a relocated source copy. Skips are four tests requiring adjacent upstream checkouts and one test requiring USD in the host test Python. |
| Installation | Fresh Python 3.10 environment with pinned data/test dependencies; dependency consistency passed. Source distribution and wheel built successfully. |
| Wheel resources | Installed outside the repository; six CLI help interfaces, prompt/config/catalog lookup and complete source snapshot verified. |
| Isolation | Pinned CLI no-model doctor passed mount, nested tool sandbox and action transport checks. |
| Static checks | Python syntax, shell syntax, JSON parsing and local documentation links checked. |
| Simulator smoke | Task 26, downloaded/relocated frozen package, index 5: **4 policy steps / 12 physics steps completed**, no infrastructure error; rendering validation passed. Integrity audit verified 400 artifacts and 4 observations. No hosted model call or benchmark score. |
| Hosted inference | No new hosted model call made. Exact-model access remains a user prerequisite. |
| Original preservation | All 181 original source/config/test/script/document files unchanged; all 26 original frozen packages reverified; pinned upstream checkouts clean. Original disk accessed read-only. |

## Portability and integrity

User paths are supplied by command options/environment variables. The policy's
fixed isolated paths are part of its interface, not workstation locations.
Download catalogs pin archive and manifest digests. Installation rejects changed
payloads, malformed catalogs, path traversal, duplicate members, symlinks and
unexpected files. It refuses to overwrite an existing installation.

Preflight checks the selected config and its ICL package, pinned checkout state,
asset layout, simulator versions, policy libraries (including OpenCV), CLI and
local authentication presence when requested. It does not send credentials or
contact the model. Tests cover invalid config handling and simulator version drift.

The historical extension storage monitor now takes its mount from
`BENCH2DEX_EVAL_DISK` instead of a workstation-specific default. Its health and
reserve gates remain unchanged. Package downloads and generated outputs are
ignored by Git. Run outputs require working Linux permissions and Unix sockets.

Scoring, official budgets, sensors, isolation, model identity, prompts, and frozen
payloads are preserved. Fresh model inference and GPU physics may vary. Exact
replay of the historical paired 10x continuations requires the excluded private
source runs/transcripts; a fresh longer run is a different experiment.

The tested fresh host installation uses h5py 3.14.0; the existing simulator
installation has h5py 3.16.0. This release provides explicit installation pins,
not a recovered complete lockfile for every original run. Simulator and policy
versions are recorded in each generated run.

## Recheck a clean distribution

Before installing or creating files in the source directory:

```bash
python scripts/check_release.py
sha256sum -c SHA256SUMS
```

After installing the data/test extras, inspect a downloaded dataset with:

```bash
python scripts/check_package_release.py --dataset /path/to/downloaded-dataset
```

`RELEASE_CONTENTS.json` records copied-file provenance. `SHA256SUMS` covers all
source files except itself; the dataset has its own checksum file and `AUDIT.json`.
Build/test caches or edited files will change a source-distribution check. Hosted
runs contain private information and require separate review before sharing.
