"""Download and verify official DexJoCo task demonstrations at a pinned revision."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

from huggingface_hub import HfApi, snapshot_download

REPO = "DexJoCo/DexJoCo-Datasets-Raw"
REVISION = "125df5c1019e97503929ef1a0ad8f90373436afa"
ROOTS = {"rand_obj": "dexjoco_raw_datasets",
         "rand_full": "dexjoco_raw_datasets_rand_full"}


def file_hashes(path: Path) -> tuple[str, str]:
    """Return content SHA-256 and the Git blob SHA-1 for a local file."""
    size = path.stat().st_size
    h = hashlib.sha256()
    blob = hashlib.sha1(f"blob {size}\0".encode())
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
            blob.update(block)
    return h.hexdigest(), blob.hexdigest()


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--task", required=True, help="Official task name, or all")
    p.add_argument("--regime", choices=tuple(ROOTS), required=True)
    p.add_argument("--workers", type=int, default=8)
    p.add_argument("--verify-only", action="store_true",
                   help="Verify an existing pinned checkout and write task inventories")
    args = p.parse_args()
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
    from gpt6_eval.dexjoco_adapter import TASKS
    if args.task not in (*TASKS, "all") or not 1 <= args.workers <= 32:
        p.error("Choose an official task or all, and 1–32 download workers")
    tasks = TASKS if args.task == "all" else (args.task,)
    prefixes = {task: f"{ROOTS[args.regime]}/{task}/" for task in tasks}
    api = HfApi()
    info = api.repo_info(REPO, repo_type="dataset", revision=REVISION,
                         files_metadata=True)
    if info.sha != REVISION:
        raise RuntimeError("Dataset revision changed")
    selected = {task: sorted((s for s in info.siblings
                             if s.rfilename.startswith(prefix)), key=lambda s: s.rfilename)
                for task, prefix in prefixes.items()}
    if any(not rows for rows in selected.values()):
        raise RuntimeError("Official dataset has no files for at least one task/regime")
    args.output.mkdir(parents=True, exist_ok=True)
    if not args.verify_only:
        snapshot_download(repo_id=REPO, repo_type="dataset", revision=REVISION,
                          allow_patterns=[prefix + "*" for prefix in prefixes.values()], local_dir=args.output,
                          max_workers=args.workers)
    for task, siblings in selected.items():
        rows = []
        for s in siblings:
            path = args.output / s.rfilename
            if not path.is_file() or path.is_symlink() or path.stat().st_size != s.size:
                raise RuntimeError(f"Missing or incomplete dataset file: {s.rfilename}")
            checksum, git_blob = file_hashes(path)
            lfs = getattr(s, "lfs", None)
            expected = getattr(lfs, "sha256", None) if lfs is not None else None
            if expected is not None:
                if checksum != expected:
                    raise RuntimeError(f"Published LFS checksum mismatch: {s.rfilename}")
            elif git_blob != s.blob_id:
                raise RuntimeError(f"Published Git blob checksum mismatch: {s.rfilename}")
            rows.append({"path": s.rfilename, "bytes": s.size, "sha256": checksum})
        manifest = {"repo": REPO, "revision": REVISION, "task": task,
                    "regime": args.regime, "files": rows,
                    "total_bytes": sum(row["bytes"] for row in rows)}
        target = args.output / "gpt6_eval_manifests" / f"{args.regime}_{task}.json"
        target.parent.mkdir(exist_ok=True)
        target.write_text(json.dumps(manifest, sort_keys=True, indent=2) + "\n")
        print(f"Verified {task}: {len(rows)} files, {manifest['total_bytes']} bytes: {target}",
              flush=True)


if __name__ == "__main__":
    main()
