"""Scoped diagnostic action transport: discard only a known metadata envelope.

This file replaces step.py only in the separately staged pinch-tongs diagnostic
source tree. The original v2 source and ongoing 55-episode run stay unchanged.
"""
import hashlib
import json
from pathlib import Path
import sys
import time


def submit(payload_path, workspace=Path("/workspace"), transport=None):
    root = workspace / "input"
    transport = transport or workspace / ".action_transport"
    payload_path = Path(payload_path)
    if payload_path.resolve().is_relative_to(transport.resolve()):
        raise ValueError("Save the action payload outside the reserved transport directory")
    current = json.loads((root / "observation.json").read_text())
    payload_bytes = payload_path.read_bytes()
    payload = json.loads(payload_bytes)
    protocol_path = root / "protocol.json"
    protocol = json.loads(protocol_path.read_text()) if protocol_path.is_file() else {}
    if isinstance(payload, list) and protocol.get("accept_bare_action_arrays") is True:
        payload = {"actions": payload}
    adapter_record = None
    if isinstance(payload, dict) and set(payload) == {"actions", "metadata"}:
        if (protocol.get("revision") != "robot_reference_array_adapter_v2"
                or not isinstance(payload["metadata"], dict)):
            raise ValueError("Metadata action envelopes require the pinned v2 robot protocol")
        adapter_record = {
            "adapter": "pinch_metadata_envelope_transport_v3",
            "decision": current["decision"],
            "original_payload_sha256": hashlib.sha256(payload_bytes).hexdigest(),
            "metadata_keys": sorted(payload["metadata"]),
            "action_rows_sha256": hashlib.sha256(
                json.dumps(payload["actions"], allow_nan=False,
                           separators=(",", ":")).encode()).hexdigest(),
        }
        # The action values are forwarded unchanged. The original file remains
        # in the policy workspace, and the host still validates every row.
        payload = {"actions": payload["actions"]}
    request = {"decision": current["decision"], "payload": payload}
    with (transport / "submission.lock").open("x"):
        try:
            target = transport / "request.json"
            if target.exists():
                raise RuntimeError("An action submission is already pending")
            if adapter_record is not None:
                (transport / f"metadata_adapter_{current['decision']:06d}.json").write_text(
                    json.dumps(adapter_record, sort_keys=True) + "\n")
            temp = transport / "request.tmp"
            temp.write_text(json.dumps(request, allow_nan=False))
            temp.replace(target)
            while True:
                if (root / "episode_done.json").exists():
                    return {"episode_done": True}
                nxt = json.loads((root / "observation.json").read_text())
                if nxt["decision"] > current["decision"]:
                    return nxt
                time.sleep(0.1)
        finally:
            (transport / "submission.lock").unlink(missing_ok=True)


if __name__ == "__main__":
    print(json.dumps(submit(Path(sys.argv[1])), allow_nan=False))
