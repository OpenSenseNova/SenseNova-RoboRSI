"""Portable, standard-library validation of the pinned frozen knowledge assets."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_KNOWLEDGE = ROOT / "knowledge"
INDEX = ROOT / "provenance/knowledge_packages.json"


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def safe_relative(value):
    path = PurePosixPath(value)
    if (not value or path.is_absolute() or ".." in path.parts or "\\" in value
            or str(path) != value or ":" in value):
        raise ValueError("Unsafe asset-relative path")
    return Path(*path.parts)


def catalog(index=INDEX):
    entries = json.loads(Path(index).read_text())["packages"]
    for task, row in entries.items():
        if safe_relative(row["path"]) != Path("knowledge/rand_full") / task:
            raise ValueError("Unexpected package layout")
        safe_relative(task)
        if "/" in task:
            raise ValueError("Invalid task name")
        for name in row["payload_files"]:
            safe_relative(name)
        for value in [row["manifest_sha256"], *row["payload_files"].values()]:
            if len(value) != 64 or any(c not in "0123456789abcdef" for c in value):
                raise ValueError("Invalid SHA-256 in catalog")
    return entries


def package_path(root, task):
    if safe_relative(task).parts != (task,):
        raise ValueError("Invalid task name")
    return Path(root) / "rand_full" / task


def expected_files(entries):
    files = {}
    for task, row in entries.items():
        prefix = Path("rand_full") / task
        files[(prefix / "manifest.json").as_posix()] = row["manifest_sha256"]
        for name, sha in row["payload_files"].items():
            files[(prefix / "payload" / safe_relative(name)).as_posix()] = sha
    return files


def verify_assets(root, entries=None):
    """Check exact manifests/payloads and reject links or undeclared task files."""
    root = Path(root).expanduser().absolute()
    entries = catalog() if entries is None else entries
    if not root.is_dir() or root.is_symlink():
        raise ValueError("Knowledge root is missing or is a symlink; run scripts/fetch_knowledge.py")
    files = expected_files(entries)
    for name, sha in files.items():
        relative = safe_relative(name)
        path = root / relative
        for part in [path, *list(path.parents)[:len(relative.parts) - 1]]:
            if part.is_symlink():
                raise ValueError(f"Asset symlink is prohibited: {name}")
        if not path.is_file() or digest(path) != sha:
            raise ValueError(f"Asset missing or hash mismatch: {name}")
    for task, row in entries.items():
        folder = package_path(root, task)
        expected = {name for name in files if name.startswith(f"rand_full/{task}/")}
        actual = set()
        for path in folder.rglob("*"):
            if path.is_symlink() or not (path.is_file() or path.is_dir()):
                raise ValueError(f"Unsafe asset entry in task: {task}")
            if path.is_file():
                actual.add(path.relative_to(root).as_posix())
        if actual != expected:
            raise ValueError(f"Undeclared asset files in task: {task}")
        manifest = json.loads((folder / "manifest.json").read_text())
        if manifest["files"] != row["payload_files"]:
            raise ValueError(f"Manifest and catalog disagree: {task}")
    return {"packages_checked": len(entries), "asset_files_checked": len(files)}
