"""Install the pinned frozen ICL packages from a public Hugging Face dataset or local folder."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import shutil
import tempfile

from release_assets import DEFAULT_KNOWLEDGE, catalog, expected_files, safe_relative, verify_assets


def install_assets(source, destination, entries=None):
    entries = catalog() if entries is None else entries
    source = Path(source).expanduser().absolute()
    destination = Path(destination).expanduser().absolute()
    verify_assets(source, entries)
    if destination.exists() or destination.is_symlink():
        verified = verify_assets(destination, entries)
        return {**verified, "status": "already_verified"}
    destination.parent.mkdir(parents=True, exist_ok=True)
    # Stage beside the destination: all hashes must pass before the atomic rename.
    with tempfile.TemporaryDirectory(prefix=".dexjoco-assets-", dir=destination.parent) as tmp:
        stage = Path(tmp) / "knowledge"
        stage.mkdir()
        for name in expected_files(entries):
            rel = safe_relative(name)
            target = stage / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source / rel, target)
        result = verify_assets(stage, entries)
        if destination.exists() or destination.is_symlink():
            raise ValueError("Destination appeared during installation; refusing overwrite")
        stage.rename(destination)
    return {**result, "status": "installed"}


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    source = p.add_mutually_exclusive_group(required=True)
    source.add_argument("--repo-id", help="Public Hugging Face dataset repository: owner/name")
    source.add_argument("--local-dir", type=Path, help="Downloaded asset repository root (contains rand_full/)")
    p.add_argument("--revision", help="Required for downloads: full 40-character dataset commit SHA")
    p.add_argument("--destination", type=Path, default=DEFAULT_KNOWLEDGE,
                   help="Installation root; default: ignored knowledge/ folder beside this code")
    args = p.parse_args(argv)
    if args.repo_id and (not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", args.repo_id)
                         or not args.revision or not re.fullmatch(r"[a-fA-F0-9]{40}", args.revision)):
        p.error("Downloads require --repo-id owner/name and --revision with the full dataset commit SHA")
    if args.local_dir and args.revision:
        p.error("--revision applies only to --repo-id")
    try:
        entries = catalog()
        if args.local_dir:
            result = install_assets(args.local_dir, args.destination, entries)
        elif args.destination.exists() or args.destination.is_symlink():
            result = {**verify_assets(args.destination, entries), "status": "already_verified"}
        else:
            from huggingface_hub import snapshot_download
            with tempfile.TemporaryDirectory(prefix="dexjoco-download-") as tmp:
                snapshot_download(repo_id=args.repo_id, repo_type="dataset", revision=args.revision,
                                  allow_patterns=list(expected_files(entries)), local_dir=tmp,
                                  token=False, max_workers=4)
                result = install_assets(Path(tmp), args.destination, entries)
        print(json.dumps(result, indent=2))
        return 0
    except (ValueError, OSError) as exc:
        # Asset validation errors never include credential values or file contents.
        p.exit(1, f"Asset installation failed: {exc}\n")
    except ImportError:
        p.exit(1, "Install requirements-eval.txt first, or use --local-dir (standard library only).\n")
    except Exception as exc:
        # Do not echo network responses, URLs, or account information.
        p.exit(1, f"Download failed ({type(exc).__name__}); check the public dataset ID, commit and connection.\n")


if __name__ == "__main__":
    raise SystemExit(main())
