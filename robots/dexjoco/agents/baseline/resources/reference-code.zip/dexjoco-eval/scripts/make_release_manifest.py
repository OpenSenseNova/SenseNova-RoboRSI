"""Regenerate the public repository inventory after an intentional release-document edit."""
import argparse
from pathlib import Path

from verify_release import ROOT, audit, file_hash, generated, tree_entries


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, default=ROOT)
    args = p.parse_args()
    root = args.root.expanduser().resolve()
    assets_only = (root / "knowledge_packages.json").is_file() and (root / "rand_full").is_dir()
    result = audit(root, check_manifest=False, assets_only=assets_only)
    if not result["passed"]:
        p.exit(1, "Static/provenance verification failed; run verify_release.py to inspect findings.\n")
    rows = []
    for path in sorted(tree_entries(root, exclude_knowledge=not assets_only)):
        rel = path.relative_to(root)
        if path.is_file() and not generated(rel) and path.name != "MANIFEST.sha256":
            rows.append(f"{file_hash(path)}  {rel.as_posix()}\n")
    (root / "MANIFEST.sha256").write_text("".join(rows))
    print(f"Inventoried {len(rows)} public files; frozen task manifests were not modified.")


if __name__ == "__main__":
    main()
