"""Evaluate the distributed frozen rand-full packages, without repeating ICL."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))
from release_assets import DEFAULT_KNOWLEDGE, catalog, package_path, verify_assets
from gpt6_eval.dexjoco_adapter import TASKS
from gpt6_eval.dexjoco_eval import load_config, verify_package, verify_upstream
from gpt6_eval.knowledge import file_hash
from gpt6_eval.telemetry import sum_usage

CONFIG = ROOT / "configs/dexjoco_icl_5ep_rand_full_robot_v2_two_session.json"


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def aggregate(results, planned, profile, mode):
    complete = mode == "codex" and sum(r["completed"] for r in results) == planned
    complete = complete and all(r["complete_valid"] for r in results)
    one = sum(r["successes_1x"] for r in results)
    ten = sum(r["successes_10x"] for r in results)
    usage = sum_usage([r["tokens"] for r in results])
    if sum(r["completed"] for r in results) < planned:
        usage["status"] = "partial"
    return {"profile": profile, "mode": mode, "planned_episodes": planned,
            "completed_episodes": sum(r["completed"] for r in results),
            "complete_valid": complete, "successes_1x": one, "successes_10x": ten,
            "success_rate_1x": one / planned if complete else None,
            "success_rate_10x": ten / planned if complete else None,
            "test_tokens": usage,
            "icl_cost_incurred_this_run": False,
            "note": "Uses frozen historical preparation; test tokens include the initial session.",
            "tasks": {r["task"]: {"result": f"{r['task']}/result.json",
                       "complete_valid": r["complete_valid"]} for r in results}}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--upstream", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--knowledge-root", type=Path, default=DEFAULT_KNOWLEDGE,
                   help="Folder containing rand_full/; default: downloaded knowledge/ beside code")
    p.add_argument("--tasks", nargs="+", choices=TASKS, default=list(TASKS))
    p.add_argument("--profile", choices=("rand-full-v2", "pinch-envelope-v3"), default="rand-full-v2")
    p.add_argument("--mode", choices=("codex", "smoke"), default="codex")
    p.add_argument("--episode-index", type=int, choices=range(5))
    p.add_argument("--episode-workers", type=int, choices=range(1, 5), default=1)
    p.add_argument("--auth", type=Path, default=Path.home() / ".codex/auth.json")
    p.add_argument("--dry-run", action="store_true", help="Validate packages and print the plan; no simulator/model calls")
    args = p.parse_args()
    tasks = list(dict.fromkeys(args.tasks))
    if args.profile == "pinch-envelope-v3" and tasks != ["pinch_tongs"]:
        p.error("The diagnostic profile requires --tasks pinch_tongs")
    if args.mode == "smoke" and args.episode_index is not None:
        p.error("Smoke tests use a separate fixed smoke seed, not a scored episode index")
    args.upstream, args.output, args.auth = (x.expanduser().resolve() for x in
                                             (args.upstream, args.output, args.auth))
    args.knowledge_root = args.knowledge_root.expanduser().absolute()
    if args.output.exists():
        p.error("Output exists; use a fresh directory")
    if args.output.is_relative_to(ROOT):
        p.error("Keep private outputs outside the public release checkout")
    if os.environ.get("MUJOCO_GL", "osmesa") != "osmesa":
        p.error("This profile requires MUJOCO_GL=osmesa")
    cfg = load_config(CONFIG)
    verify_upstream(args.upstream, cfg)
    inventory = catalog()
    try:
        verify_assets(args.knowledge_root, {task: inventory[task] for task in tasks})
    except ValueError as exc:
        p.error(str(exc) + "; see scripts/fetch_knowledge.py or --knowledge-root")
    packages = {}
    for task in tasks:
        item = inventory[task]
        package = package_path(args.knowledge_root, task)
        verify_package(package, task, cfg, item["manifest_sha256"])
        packages[task] = item["manifest_sha256"]
    per_task = 1 if args.mode == "smoke" or args.episode_index is not None else cfg["episodes"]
    plan = {"profile": args.profile, "mode": args.mode, "tasks": tasks,
            "episodes_per_task": per_task, "planned_episodes": per_task * len(tasks),
            "episode_index": args.episode_index, "config_sha256": file_hash(CONFIG),
            "upstream_commit": cfg["upstream_commit"], "package_sha256": packages,
            "episode_workers": args.episode_workers, "renderer": "osmesa",
            "model": cfg["model"], "reasoning_effort": cfg["reasoning_effort"],
            "codex_version": cfg["codex_version"]}
    if args.dry_run:
        print(json.dumps(plan, indent=2, sort_keys=True))
        return 0
    if args.mode == "codex":
        cli = shutil.which("codex")
        if not cli or subprocess.check_output([cli, "--version"], text=True).strip() != cfg["codex_version"]:
            p.error("Pinned Codex CLI is required on PATH; see README")
        if not args.auth.is_file():
            p.error("Supply your own Codex auth file; see --auth")
    args.output.mkdir(parents=True)
    source = ROOT
    if args.profile == "pinch-envelope-v3":
        source = args.output / "private/diagnostic_source"
        for folder in ("src", "prompts", "configs"):
            shutil.copytree(ROOT / folder, source / folder,
                            ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.egg-info"))
        adapter = ROOT / "scripts/variants/pinch_metadata_step_v3.py"
        shutil.copyfile(adapter, source / "src/gpt6_eval/step.py")
        plan["diagnostic_step_sha256"] = file_hash(adapter)
    write(args.output / "release_run.json", plan)
    env = {**os.environ, "PYTHONPATH": str(source / "src"),
           "PYTHONHASHSEED": "0", "PYTHONDONTWRITEBYTECODE": "1", "MUJOCO_GL": "osmesa"}
    results = []
    for task in tasks:
        command = [sys.executable, "-m", "gpt6_eval.dexjoco_eval", "--config", str(CONFIG),
                   "--upstream", str(args.upstream), "--task", task, "--mode", args.mode,
                   "--output", str(args.output / task), "--episode-workers", str(args.episode_workers)]
        if args.mode == "codex":
            command += ["--package", str(package_path(args.knowledge_root, task)),
                        "--package-sha256", packages[task], "--auth", str(args.auth)]
            if args.episode_index is not None:
                command += ["--episode-index", str(args.episode_index)]
        with (args.output / f"{task}.log").open("wb") as log:
            result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT)
        path = args.output / task / "result.json"
        if path.is_file():
            results.append(json.loads(path.read_text()))
        summary = aggregate(results, plan["planned_episodes"], args.profile, args.mode)
        summary["last_exit_code"] = result.returncode
        write(args.output / "summary.json", summary)
        print(f"{task}: exit={result.returncode}; result={path}", flush=True)
        if result.returncode:
            return result.returncode
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
