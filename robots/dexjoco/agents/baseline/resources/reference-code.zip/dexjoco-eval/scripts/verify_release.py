"""Verify public release integrity, package contracts, and sensitive-file exclusions."""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))
from release_assets import INDEX as INDEX_PATH, catalog, expected_files, verify_assets

PATTERNS = {
    "credential_token": re.compile(r"(?:sk-[A-Za-z0-9_-]{20,}|hf_[A-Za-z0-9]{20,}|gh[pousr]_[A-Za-z0-9]{20,})"),
    "private_key": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    "jwt": re.compile(r"eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}"),
    "host_path": re.compile(r"/(?:home|Users|root|data/shared)/(?!policy(?:/|\b))[A-Za-z0-9_.-]+(?:/[^\s\"'<>]*)?"),
    "url_credentials": re.compile(r"https?://[^\s/@:]+:[^\s/@]+@"),
    "credential_assignment": re.compile(r'''(?i)["']?(?:api_key|access_token|refresh_token|client_secret)["']?\s*[:=]\s*["'][A-Za-z0-9_.-]{16,}["']'''),
}
FORBIDDEN = {"auth.json", ".env", ".git", ".codex", ".codex-cli", ".venv",
             "private", "runs", ".DS_Store", "PROJECT_MEMORY.md"}
TEXT_SUFFIXES = {".py", ".md", ".txt", ".json", ".toml", ".yaml", ".yml", ".sh"}


def file_hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def generated(path):
    return any(p == "__pycache__" or p.endswith(".egg-info") for p in path.parts) or path.suffix == ".pyc"


def scan_text(text, relative, findings):
    for name, regex in PATTERNS.items():
        for match in regex.finditer(text):
            findings.append({"file": relative, "line": text.count("\n", 0, match.start()) + 1,
                             "kind": name})  # Never echo a matched secret.


def scan_file(path, root, findings):
    relative = str(path.relative_to(root))
    if (path.suffix in TEXT_SUFFIXES or path.name in {"LICENSE", ".gitignore", ".gitattributes", "MANIFEST.sha256"}
            or path.name.endswith("-LICENSE") or path.name.startswith("LICENSE-")):
        text = path.read_text(encoding="utf-8")
        scan_text(text, relative, findings)
        if path.suffix == ".py":
            ast.parse(text, filename=relative)
    elif path.suffix.lower() in {".jpg", ".jpeg", ".png"}:
        from PIL import Image
        with Image.open(path) as image:
            scan_text(repr(image.info) + repr(dict(image.getexif())), relative, findings)
            image.verify()
    elif path.suffix in {".npy", ".npz"}:
        import numpy as np
        def check(array):
            if array.dtype.hasobject:
                raise ValueError(f"Pickled/object array prohibited: {relative}")
            if array.dtype.kind in {"S", "U"}:
                scan_text(str(array.tolist()), relative, findings)
        if path.suffix == ".npy":
            check(np.load(path, allow_pickle=False))
        else:
            with zipfile.ZipFile(path) as archive:
                for entry in archive.infolist():
                    if Path(entry.filename).is_absolute() or ".." in Path(entry.filename).parts:
                        raise ValueError(f"Unsafe NumPy archive entry: {relative}")
            with np.load(path, allow_pickle=False) as arrays:
                for name in arrays.files:
                    check(arrays[name])
    else:
        findings.append({"file": relative, "kind": "unreviewed_file_type"})


def tree_entries(root, exclude_knowledge=False):
    # A Git clone contains local Git metadata; it is never part of the release inventory.
    for directory, folders, files in os.walk(root, followlinks=False):
        parent = Path(directory)
        folders[:] = [name for name in folders if name != ".git" and not generated(Path(name))
                      and not (exclude_knowledge and parent == root and name == "knowledge")]
        for name in folders + files:
            if parent == root and name == ".git":
                continue
            yield parent / name


def audit(root, check_manifest=True, knowledge_root=None, require_knowledge=False, assets_only=False):
    findings, hashes = [], {}
    for path in sorted(tree_entries(root, exclude_knowledge=not assets_only)):
        rel = path.relative_to(root)
        mode = path.lstat().st_mode
        if stat.S_ISLNK(mode) or not (stat.S_ISREG(mode) or stat.S_ISDIR(mode)):
            findings.append({"file": str(rel), "kind": "link_or_special_file"})
            continue
        if any(p in FORBIDDEN or p.startswith(".env.") for p in rel.parts) or path.suffix in {".pem", ".key", ".sqlite", ".db"}:
            findings.append({"file": str(rel), "kind": "private_file_or_directory"})
            continue
        if path.is_dir() or generated(rel):
            continue
        try:
            scan_file(path, root, findings)
        except Exception as exc:
            findings.append({"file": str(rel), "kind": "file_validation", "error_type": type(exc).__name__})
        if path.name != "MANIFEST.sha256":
            hashes[str(rel)] = file_hash(path)
    if check_manifest:
        manifest = root / "MANIFEST.sha256"
        if not manifest.is_file():
            findings.append({"file": manifest.name, "kind": "missing_release_inventory"})
        else:
            expected = {}
            for line in manifest.read_text().splitlines():
                value, name = line.split("  ", 1)
                if name in expected:
                    findings.append({"file": name, "kind": "duplicate_inventory_entry"})
                expected[name] = value
            for name in sorted(set(expected) | set(hashes)):
                if expected.get(name) != hashes.get(name):
                    findings.append({"file": name, "kind": "release_hash_or_inventory_mismatch"})
    source = {}
    if not assets_only:
        source = json.loads((root / "provenance/source_copy.json").read_text())["files"]
        for name, expected in source.items():
            path = root / name
            if not path.is_file() or file_hash(path) != expected:
                findings.append({"file": name, "kind": "original_source_copy_changed"})
    index = catalog(INDEX_PATH if assets_only else root / "provenance/knowledge_packages.json")
    checked = 0
    assets = root if assets_only else (knowledge_root or root / "knowledge")
    if assets_only:
        if json.loads((root / "knowledge_packages.json").read_text())["packages"] != index:
            findings.append({"kind": "asset_catalog_mismatch"})
    if assets.exists() or require_knowledge or assets_only:
        try:
            checked = verify_assets(assets, index)["packages_checked"]
            if not assets_only:
                for name in expected_files(index):
                    scan_file(assets / name, assets, findings)
        except Exception as exc:
            findings.append({"kind": "knowledge_contract", "error_type": type(exc).__name__})
    return {"passed": not findings, "files_checked": len(hashes), "packages_checked": checked,
            "original_source_files_checked": len(source),
            "assets_status": "verified" if checked else "not_installed" if not assets.exists() else "invalid",
            "findings": findings, "scope": "Integrity and static sensitive-data checks; not model evaluation"}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, default=ROOT)
    p.add_argument("--knowledge-root", type=Path, help="Optional external folder containing rand_full/")
    p.add_argument("--require-knowledge", action="store_true", help="Fail if any frozen package is absent")
    p.add_argument("--assets-only", action="store_true", help="Verify a Hugging Face asset repository supplied as --root")
    args = p.parse_args()
    if args.assets_only and args.knowledge_root:
        p.error("--assets-only uses --root; omit --knowledge-root")
    result = audit(args.root.expanduser().resolve(),
                   knowledge_root=args.knowledge_root.expanduser().absolute() if args.knowledge_root else None,
                   require_knowledge=args.require_knowledge, assets_only=args.assets_only)
    print(json.dumps(result, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
