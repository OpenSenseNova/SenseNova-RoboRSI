"""Check public evaluation prerequisites without authenticating or making model calls."""
from __future__ import annotations

import argparse
import ctypes.util
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from gpt6_eval import isolation
from gpt6_eval.dexjoco_eval import load_config, verify_upstream, task_config
from gpt6_eval.dexjoco_adapter import TASKS


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--upstream", type=Path, required=True)
    p.add_argument("--check-policy", action="store_true", help="Also check pinned CLI and namespace mounts; no auth/model request")
    args = p.parse_args()
    issues, checks = [], {}
    cfg = load_config(ROOT / "configs/dexjoco_icl_5ep_rand_full_robot_v2_two_session.json")
    upstream = args.upstream.expanduser().resolve()
    checks["python"] = platform.python_version()
    if (platform.system() != "Linux" or platform.machine() not in ("x86_64", "AMD64")
            or sys.version_info[:2] not in ((3, 10), (3, 11))):
        issues.append("Use Linux x86-64 with Python 3.10 or 3.11; macOS, Windows and ARM are unsupported")
    for library in ("OSMesa", "GL"):
        if not ctypes.util.find_library(library):
            issues.append(f"Missing system library {library}; install libosmesa6 and libgl1")
    if not shutil.which("git"):
        issues.append("Install git to verify the pinned simulator checkout")
    if sys.prefix == sys.base_prefix:
        issues.append("Use a dedicated virtual environment as described in README")
    if ROOT.is_relative_to(Path(sys.prefix).resolve()) or upstream.is_relative_to(Path(sys.prefix).resolve()):
        issues.append("The checkout and simulator must be outside the policy Python environment")
    spec = importlib.util.find_spec("dexjoco")
    if spec and spec.origin and Path(spec.origin).resolve().is_relative_to(Path(sys.prefix).resolve()):
        issues.append("Remove the installed simulator from the policy environment; keep it in the external checkout")
    if os.environ.get("MUJOCO_GL", "osmesa") != "osmesa":
        issues.append("Set MUJOCO_GL=osmesa for the recorded condition")
    try:
        verify_upstream(upstream, cfg)
        for task in TASKS:
            task_config(upstream, "rand_full", task)
        checks["clean_pinned_upstream"] = True
    except Exception as exc:
        issues.append(f"Upstream check: {type(exc).__name__}: {exc}")
    checked = 0
    for row in (ROOT / "requirements-eval.txt").read_text().splitlines():
        if not row.strip() or row.startswith("#"):
            continue
        name, expected = row.split("==")
        try:
            actual = importlib.metadata.version(name)
            if actual != expected:
                issues.append(f"Version mismatch: {name} expected {expected}, found {actual}")
            checked += 1
        except importlib.metadata.PackageNotFoundError:
            issues.append(f"Missing distribution: {name}=={expected}")
    checks["recorded_distributions_checked"] = checked
    if args.check_policy:
        binary = shutil.which("codex")
        try:
            if not binary:
                raise ValueError("codex is not on PATH")
            version = subprocess.check_output([binary, "--version"], text=True).strip()
            if version != cfg["codex_version"]:
                raise ValueError(f"Expected {cfg['codex_version']}; found {version}")
            with tempfile.TemporaryDirectory(prefix="dexjoco-preflight-") as tmp:
                root = Path(tmp)
                for rel in ("workspace/input", "home", "private/interface", "private/action-transport"):
                    (root / rel).mkdir(parents=True)
                checks["namespace_probe"] = isolation.probe(root / "workspace", root / "home",
                    root / "private/interface", Path(binary), root / "private").strip()
                cmd = isolation.mounts(root / "workspace", root / "home", root / "private/interface",
                    Path(binary), policy_python=Path(sys.prefix))
                code = ("import importlib.util,numpy,scipy,PIL; "
                        "assert importlib.util.find_spec('dexjoco') is None; "
                        "assert importlib.util.find_spec('gpt6_eval') is None; "
                        "print('public numerical environment only')")
                result = subprocess.run(cmd + ["--", "/opt/policy-python/bin/python3", "-c", code],
                                        capture_output=True, text=True, check=True)
                checks["policy_python_probe"] = result.stdout.strip()
            checks["codex_version"] = version
        except Exception as exc:
            issues.append(f"Policy prerequisites: {type(exc).__name__}: {exc}")
    print(json.dumps({"passed": not issues, "checks": checks, "issues": issues,
                      "model_access_tested": False}, indent=2))
    return 1 if issues else 0


if __name__ == "__main__":
    raise SystemExit(main())
