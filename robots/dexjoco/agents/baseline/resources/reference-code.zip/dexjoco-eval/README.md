# DexJoCo: demonstration-informed Astra evaluation

Evaluation code for 11 rand-full tasks, five fixed seeds per task, with 1× and
cumulative 10× interaction budgets. **This repository contains code only.** The
11 historical frozen ICL packages are a separate Hugging Face dataset (about
35 MB unpacked); they let you evaluate without repeating preparation or
fetching the full demonstration corpus.

## 1. Set up the runtime

Use **Linux x86-64 and Python 3.10** (evaluated: 3.10.12). Python 3.11 is allowed
by the package but is not the recorded runtime. macOS, Windows, ARM, and
containers without unprivileged user namespaces are unsupported. Install
`git`, `bubblewrap`, `libosmesa6`, `libgl1`, and `python3-venv` with your system
package manager. Run these commands from the code checkout:

```bash
python3.10 -m venv ../dexjoco-eval-env
source ../dexjoco-eval-env/bin/activate
python -m pip install -r requirements-eval.txt
python -m pip install --no-deps -e .
python -m pip check
git clone https://github.com/brave-eai/dexjoco.git ../dexjoco-upstream
git -C ../dexjoco-upstream checkout 8d23b0fab23b17a58c4b55f3942e17013aaf8267
export MUJOCO_GL=osmesa
python scripts/verify_release.py
python scripts/preflight.py --upstream ../dexjoco-upstream
```

Keep the code, simulator, and asset directories **outside the virtual
environment**. Use the editable installation above; a standalone wheel is not
supported. Do not install the simulator into the policy environment. The
trusted host loads it from the external pinned checkout. No OpenPI checkpoint,
policy server, GPU, or ICL preparation is needed for frozen-package testing.

## 2. Get the frozen ICL packages

Download the companion **Hugging Face dataset** using its repository ID and
full 40-character commit SHA (from its Files and versions / commit history).
Replace both example values below with the published dataset's values:

```bash
python scripts/fetch_knowledge.py \
  --repo-id YOUR_ORG/dexjoco-icl-rand-full --revision DATASET_COMMIT_SHA
python scripts/verify_release.py --require-knowledge
```

The downloader makes public, unauthenticated requests, selects only the pinned
279 asset files, checks every SHA-256 against this code's catalog, and installs
atomically into `knowledge/` (ignored by Git). It refuses corrupt or modified
packages and never overwrites an existing installation with different contents.

If you already downloaded/extracted the asset folder, import it offline:

```bash
python scripts/fetch_knowledge.py --local-dir ../dexjoco-icl-rand-full
```

Alternatively, avoid a copy and pass `--knowledge-root ../dexjoco-icl-rand-full`
to the launcher and verifier. That folder must directly contain `rand_full/`.
All paths are resolved from the supplied arguments or this script's location;
spaces are supported. The source and knowledge may live in different folders.

## 3. Verify and run

Run tests and a four-step, **no-model** simulator smoke test:

```bash
python -m unittest discover -s tests -v
python scripts/run_frozen.py --mode smoke --tasks water_plant \
  --upstream ../dexjoco-upstream --output ../dexjoco-runs/smoke-water
```

Scored evaluation requires your own authenticated access to **`gpt-6-astra`
with `max` effort** and **Codex CLI 0.154.0**, including its native
`codex-code-mode-host` companion on `PATH`. These are external prerequisites;
availability depends on your provider/account. The harness does not substitute
another model/build. `--auth` accepts your own Codex auth file, defaulting to
`~/.codex/auth.json`. Keep credentials outside the repository.

```bash
python scripts/preflight.py --upstream ../dexjoco-upstream --check-policy
python scripts/run_frozen.py --tasks water_plant --dry-run \
  --upstream ../dexjoco-upstream --output ../dexjoco-runs/water
python scripts/run_frozen.py --tasks water_plant \
  --upstream ../dexjoco-upstream --output ../dexjoco-runs/water
```

Omit `--tasks` for all 11 tasks. Add `--episode-index 0` for only seed 100000;
omit it for all five seeds. Outputs must be fresh directories outside this
checkout. One episode runs at a time by default; `--episode-workers 2` allows
parallel episodes (maximum 4). Model calls incur usage; full evaluations can
take hours and frame archives can consume substantial disk space.

The default `rand-full-v2` profile preserves the original uniform protocol.
The separate `--profile pinch-envelope-v3 --tasks pinch_tongs` diagnostic
handles the known metadata envelope while preserving numerical action rows.
Report that diagnostic separately. Outputs include `release_run.json`,
`summary.json`, per-task `result.json`, per-session token/time records,
actions, states, model evidence, and checkpoints. **Do not publish raw run
outputs without a separate privacy review.**

See [protocol](docs/PROTOCOL.md), [fresh preparation / rand-obj](docs/REPRODUCIBILITY.md),
[troubleshooting](docs/TROUBLESHOOTING.md), [release audit](docs/RELEASE_AUDIT.md),
[privacy](docs/PRIVACY.md), and [licenses](THIRD_PARTY_NOTICES.md).
