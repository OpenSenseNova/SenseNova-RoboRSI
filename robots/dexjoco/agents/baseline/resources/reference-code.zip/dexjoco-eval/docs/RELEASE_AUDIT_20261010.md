# Public release audit — 2026-10-10

## Summary

The public copy passed the checks below. The original evaluation directory and
upstream checkout were not edited. This is a release-readiness check, not a new
model evaluation or a guarantee of identical success rates.

| Check | Result |
|---|---|
| Original source preservation | 158 original files rehashed; zero changes; upstream Git checkout clean |
| Selected source/config/prompt/test copies | 33 copied files retain their original content hashes |
| Frozen rand-full packages | All 11 original manifests and every declared payload file match |
| Runtime installation | All 48 recorded distribution versions installed in a new Python 3.10.12 environment |
| Dependency consistency | `pip check` passed |
| Automated tests | 17 passed, covering sensor boundaries, package tampering, continuation state, preparation scheduling, action formats, accounting, and incomplete results |
| Command entry points | All eight evaluator/preparation/pipeline/helper `--help` commands passed |
| Isolation | Bubblewrap mount probe passed; policy Python can load numerical libraries but cannot import evaluator or simulator source |
| Simulator/renderer | All 11 tasks completed no-model OSMesa smoke tests; all robot-reference hashes match the frozen preparation |
| Smoke step counts | Four policy steps each; Click Mouse additionally performs its 30-step upstream startup alignment |
| Relocation | Ran from a different folder containing spaces; Water Plant's archived states/actions/rewards/info and all 10 RGB hashes match the first smoke run |
| Sensitive-data review | No credential or author-machine-path matches; no auth files, private logs, symlinks, environments, or Git history in the archive |
| Binary assets | Images decoded and metadata scanned; 154 training reference images visually reviewed as a contact sheet; NumPy arrays opened without pickle |

The final `MANIFEST.sha256` inventories every distributed file except itself.
Run `python scripts/verify_release.py` after extraction to check integrity and
repeat the static scan. The ZIP also has a separate SHA-256 checksum.
Structured validation evidence is in `provenance/validation.json`.

## Release changes

- Selected the DexJoCo evaluator, preparation/reader, schedulers, shared
  utilities, exact prompts/configs, tests, and historical frozen rand-full
  packages. Omitted unrelated benchmark workflows and local report generators.
- Added a portable launcher, dependency/environment preflight, integrity/privacy
  verification, short README, protocol/reproduction notes, and release tests.
- Replaced the original project metadata/documentation with DexJoCo-specific
  packaging and MIT licensing. Included attribution and upstream asset notices.
- Main evaluator behavior and frozen payloads remain unchanged. The optional
  metadata-envelope diagnostic stages a separate copy of its archived adapter.

## Limits

No authenticated model calls were made during packaging. Users need their own
access to the exact model and CLI build. Fresh model outputs and different host
libraries may change outcomes. The relocation check covers a short simulator
trajectory, not full-episode deterministic replay. The namespace check covers
mount visibility and imports; the CLI's tool-network enforcement was not retested
through a paid policy session. The simulated two-session unit test validates
the continuation handoff without spending model tokens.

Raw private run archives and the post hoc rand-obj replay experiment are not
distributed. Static scans do not establish an absolute absence of every possible
secret; new run outputs require their own review. Historical source-compatibility
checks in the adaptive importer remain strict and are not generalized to accept
arbitrary modified-source runs. Third-party terms remain applicable, including
GeoRT's noncommercial condition; see THIRD_PARTY_NOTICES.md.
