# Setup checks and common failures

- **Missing knowledge:** use `scripts/fetch_knowledge.py` or set
  `--knowledge-root` to a folder containing `rand_full/`. An extra extraction
  directory level is a common cause. Do not edit or regenerate package hashes.
- **Hugging Face download fails:** use a public dataset repository ID (not a
  model ID) and its full commit SHA. No token is needed. Offline import from
  an extracted download is supported. An LFS pointer in place of a binary will
  fail verification; fetch the actual files.
- **Python/dependency errors:** use a new Python 3.10 virtual environment,
  install `requirements-eval.txt`, then `pip install --no-deps -e .` and
  `pip check`. Avoid shared Conda environments and globally installed simulator
  packages. The recorded pins target Linux x86-64.
- **OSMesa or GL errors:** install `libosmesa6` and `libgl1`, set
  `MUJOCO_GL=osmesa`, then run the preflight and smoke commands.
- **Bubblewrap permission errors:** the host must permit unprivileged user
  namespaces. Containers and some managed hosts disable them. Ask the host
  administrator to enable the required sandbox support; the evaluator refuses
  an unsandboxed fallback. Do not run it as root to bypass isolation.
- **Codex version/native companion error:** use CLI 0.154.0 with its matching
  native companion; run `codex --version` and the policy preflight. Later CLI
  versions may have incompatible features or sandbox behavior.
- **Model unavailable:** access to the exact Astra model/effort is an external
  prerequisite. Smoke tests work without it; a different model is a different
  experimental condition.
- **Upstream verification fails:** use the clean pinned commit. Modified task
  code or assets invalidate the condition. Keep outputs outside that checkout.
- **Output exists:** use a new output directory. The launcher does not silently
  overwrite an earlier evaluation or automatically retry scored failures.
- **Token status partial:** report the measured total as a lower bound. Missing
  usage records must not be converted to zero or described as exact.

Unit tests and smoke runs validate packaging and simulation, not hosted model
availability or an identical future success rate. Review `docs/RELEASE_AUDIT.md`
for exactly what was tested.
