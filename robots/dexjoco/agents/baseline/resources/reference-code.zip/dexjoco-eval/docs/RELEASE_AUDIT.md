# Split public release audit — 2026-10-12

## Deliverables

- **GitHub:** code, configs, prompts, tests, documentation, MIT license,
  third-party notices, and hash catalogs. No frozen binary assets or run outputs.
- **Hugging Face dataset:** 11 rand-full frozen packages (279 original files),
  dataset card, complete notices, and a separate release inventory.

The earlier combined release and original evaluation files are preserved.
The 33 selected evaluator/config/prompt files and all original frozen package
manifests/payloads retain their hashes. Only release wrappers and documentation
were changed. The upstream simulator checkout remains clean.

## Checks performed

| Check | Result |
|---|---|
| Clean runtime | New Python 3.10.12 venv; all 48 pinned distributions installed; editable code install; pip check passed |
| Tests with assets | 22 passed; action formats, boundaries, continuation, accounting, tampering, safe installation and mocked Hub download covered |
| Tests without assets | 21 passed; one optional historical-asset integration test correctly skipped |
| Command entry points | All 10 help commands passed from outside the checkout |
| Public asset download contract | Mocked Hub transfer checked dataset type, full commit SHA, exact file allowlist and token=False |
| Local/offline download | All 11 packages imported and verified before atomic installation; repeat install accepted only when hashes match |
| Unsafe/corrupt downloads | Modified files, undeclared task files and symlinks rejected; existing modifications not overwritten |
| Relocation | Code and assets in separate paths with spaces; default installed-assets verification and external-assets 55-episode dry-run passed |
| Sandbox | Pinned CLI namespace mount probe and policy Python visibility probe passed without authentication |
| Simulator | All 11 tasks passed OSMesa smoke tests using external asset paths; four policy steps each (Click Mouse includes its 30-step startup); robot hashes matched |
| Git upload boundary | Test staging included only code files; downloaded knowledge, generated files and environments excluded |
| Privacy/integrity | No findings in either public tree; image metadata and non-pickle NumPy data checked; original image visual review remains applicable |
| Original preservation | Previous combined-release files rehashed unchanged; selected evaluator and package hash contracts preserved |

`provenance/validation.json` provides structured results. Historical all-task
smoke and visual-review evidence is retained in `validation_20261010.json` and
`docs/RELEASE_AUDIT_20261010.md`. Each repository has its own `MANIFEST.sha256`;
the published ZIPs have separate checksums. The release manifest does not
replace or rewrite the original per-task frozen manifests.

## Verification commands

From the code checkout:

```bash
python scripts/verify_release.py
python scripts/verify_release.py --require-knowledge
python scripts/verify_release.py --assets-only --root ../dexjoco-icl-rand-full
```

The first command works before asset installation. The second requires all
11 installed packages, or accepts an external `--knowledge-root`.

## Practical limits

No credentials were used and no paid model calls were made. Hosted Astra/CLI
access, OS libraries, user namespaces, and stochastic model responses remain
external prerequisites. The split workflow was checked in a clean environment
on the available Linux host; it is not a cross-platform guarantee. A live
fetch from the publisher's future Hugging Face repository can only be checked
after that repository exists. Supply its actual ID and full revision SHA at
run time, or use the tested offline import/external-folder workflow.

Static scans do not prove absence of every possible secret; raw future run
outputs need their own review. Relative session filenames and event hashes in
frozen manifests are retained as provenance, without the underlying private
transcripts. Component licenses remain applicable, including the supplied
GeoRT noncommercial terms. See THIRD_PARTY_NOTICES.md.
