# Privacy and release boundary

The GitHub repository contains selected source, prompts, configuration, tests,
and relative provenance hashes. The separate Hugging Face dataset contains
frozen training-derived task knowledge and its licensing/provenance records.
It excludes credentials, auth files, user configuration, repositories' history,
raw Codex sessions, preparation scratch work, evaluation outputs, private
simulator archives, environment directories, and machine-specific reports.

The paths `/workspace`, `/interface`, `/codex-home`, and `/opt/policy-python`
in code/prompts are fixed paths inside the isolated policy namespace. They
are necessary interface names, not paths on the authors' machine. External
paths are supplied through CLI arguments. Credentials must be supplied by the
operator and never placed in this repository.

The original runner makes a restricted `auth.json` copy for each isolated CLI
and removes it after exit. A hard crash may leave it behind. New outputs also
contain local paths, model transcript/session metadata, invocation arguments,
and scratch files. An absent auth file does not make those outputs public-safe.
Review/export results separately before sharing; do not zip an output directory
or a whole Codex home. `.gitignore` is an additional safeguard, not an audit.

`scripts/verify_release.py` verifies the checked-in inventory and scans for
credential formats, personal paths, suspicious file types, links, and undeclared
files. It inspects text, image metadata, and non-pickle NumPy arrays. Pattern
scanning cannot prove absence of every possible secret. Review newly added
binary data and all future release changes as well.

## Split distribution

`knowledge/` is ignored by Git. The downloader requests public assets with
`token=False`; no Hugging Face login is needed. Its temporary Hub metadata is
not copied into the installation. Only the catalogued manifests and payloads
are installed. The asset repository's root documentation/licenses remain in
the original download; the code carries the same notices for local use.

The verifier supports ordinary Git clones by excluding `.git` metadata. It
checks all shipped files against the relevant inventory; downloaded assets are
checked separately from the code inventory. Do not publish existing local Git
history or the parent work directory. Create a new repository from the prepared
code folder, and upload only the contents of the prepared asset folder to the
Hugging Face dataset. The release ZIPs contain only inventoried public files.
