# Evaluation protocol

## Pinned condition

- Benchmark: DexJoCo commit `8d23b0fab23b17a58c4b55f3942e17013aaf8267`.
- Demonstrations: `DexJoCo/DexJoCo-Datasets-Raw` revision
  `125df5c1019e97503929ef1a0ad8f90373436afa`.
- Model: `gpt-6-astra`, `max`; Codex CLI 0.154.0. Never substitute silently.
- Main cohort: 11 rand-full tasks, seeds 100000–100004 per task; OSMesa CPU
  rendering. Configuration and prompts are copied from the evaluated source.
- Preparation reads sanitized released demonstrations, may use hosted web
  search, and freezes a separate task package. It never sees held-out test
  episodes. Testing has no web access or information from other test episodes.

## Observations and actions

Only official task camera RGB, language, and the first 23 single-arm or 46
bimanual robot-state values are policy-visible. Extra state (including object
poses), rewards, success flags, seeds, and evaluator source are private.
The v2 condition additionally supplies pinned robot-only MJCF/URDF assets.
No depth, segmentation, contacts, or object ground truth is exposed.

Actions are absolute end-effector xyz, rotation vector, and 16 hand targets
per arm, at 30 Hz: 22 values for one arm, 44 for two. Chunks contain 1–30
rows and cannot exceed remaining steps. Rotation vectors are converted to
scalar-first quaternions; numeric rows are not clipped/interpolated by the
wrapper. Click Mouse retains the upstream 30-step startup alignment.
Rendering pauses while the model reasons. Policy latency is not real-time
robot control. Official simulator success and natural failure conditions apply.

| Task | 1× control-step budget |
|---|---:|
| Assembly | 1500 |
| Hanoi | 1500 |
| Microwave | 1100 |
| Photograph | 1000 |
| Unlock iPad | 1200 |
| Click Mouse | 1200 |
| Fold Glasses | 1200 |
| Hammer Nail | 1000 |
| Pick Bucket | 1200 |
| Pinch Tongs | 1000 |
| Water Plant | 1000 |

## Two-session continuation

The initial fresh policy session sees only the 1× budget. Only a nonterminal
budget failure receives a new policy session and up to 9× more steps in the
same live simulator. The continuation can read that episode's public history
and scratch scripts/notes, plus the same frozen package. It cannot access
private states or scores. Successes, natural terminal failures, and invalid
actions do not receive an extension. Checkpoints are audit artifacts; crash
restoration from those checkpoints is not validated by this release.

## Action-format conditions

`rand-full-v2` is the original uniform condition: the transport accepts
`{"actions": [...]}` and wraps bare numeric arrays. Extra object keys remain
invalid. The original Pinch Tongs seed 100001 had a step-zero metadata-envelope
abort; it remains in the historical uniform score.

`pinch-envelope-v3` stages a separate source copy with the archived diagnostic
step adapter. For Pinch Tongs only, it accepts exactly `actions` and a dictionary
`metadata`, records a sidecar hash, and forwards the original numeric rows.
The original helper, frozen package, and uniform scores are not overwritten.
Report that diagnostic separately. Replacing only a prespecified formatting
abort in an aggregate is a post hoc correction and must be labeled as such.

## Accounting and validity

Total tokens = input + output, including cached input and reasoning output as
subsets. ICL is incurred once per task; cumulative 10× testing includes 1×.
Incomplete token records are partial lower bounds, never exact costs.
Infrastructure failures invalidate aggregate completion; model policy failures
are scored failures. No automatic favorable retry is implemented. Fresh model
outputs are stochastic; fixed code/packages/seeds do not guarantee identical SR.
