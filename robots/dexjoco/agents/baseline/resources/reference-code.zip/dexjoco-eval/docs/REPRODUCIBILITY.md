# Reproducibility and preparation

## What is supplied

The source is a selected copy of the evaluated DexJoCo adapter and shared
utilities. The simulator, task logic, and success predicates remain upstream.
`provenance/source_copy.json` records original hashes. `provenance/knowledge_packages.json`
records frozen manifest and payload hashes. `MANIFEST.sha256` covers this public
code release. The asset repository has a separate inventory; use the verifier with
`--assets-only --root` to check it. Archived model transcript filenames in package manifests are provenance
references; the transcripts themselves are intentionally not distributed.

The 11 separately distributed rand-full packages include task notes, sources, numerical helpers,
demonstration-derived motion arrays, geometry/reference data, and selected
training images. These are the frozen packages supplied to test episodes.
Raw demonstrations and all held-out test trajectories are excluded.

The evaluated runtime was Python 3.10.12 on Linux x86-64. `requirements-eval.txt`
contains the 48 version-pinned distributions recorded in the original runtime,
without local paths or authentication. These are version pins, not a portable
OS/container image or a cryptographic wheel lock. Host libraries, rendering,
model availability, and service behavior may still differ. Use `pip check`
and the preflight/smoke tests on the target machine.

The editable installation is intentional: the original evaluator uses source
and prompt paths relative to its checkout and archives their hashes per run.
Keep the Python environment dedicated to this evaluation, with no benchmark
code or datasets installed inside it: the policy mounts that environment's
libraries read-only. The trusted host imports simulator code directly from the
external clean checkout. Do not install the evaluator non-editably or install
the upstream simulator into the policy environment.

## Prepare new rand-full packages

Run from the release checkout, using the environment in the README:

```bash
python scripts/download_dexjoco_demos.py --task all --regime rand_full \
  --output ../dexjoco-demos --workers 4
python -m gpt6_eval.dexjoco_pipeline \
  --config configs/dexjoco_icl_5ep_rand_full_robot_v2_two_session.json \
  --upstream ../dexjoco-upstream --dataset ../dexjoco-demos \
  --prep-workers 1 --test-workers 1 --episode-workers 1 \
  --output ../dexjoco-runs/fresh-preparation
```

This performs new, potentially stochastic preparation and testing. It does not
reconstruct the original frozen packages. To prepare only one task, use:

```bash
python -m gpt6_eval.dexjoco_icl \
  --config configs/dexjoco_icl_5ep_rand_full_robot_v2_two_session.json \
  --task water_plant --upstream ../dexjoco-upstream \
  --dataset ../dexjoco-demos --output ../dexjoco-runs/new-water-preparation
```

Then pass the resulting `frozen` directory and the `package_sha256` in
`preparation.json` to `python -m gpt6_eval.dexjoco_eval`, with `--mode codex`,
the same config/task/upstream, and a new `--output`. Never hand-edit the payload
or recompute a new hash to conceal a change. To evaluate all tasks using the
downloaded historical packages, use `scripts/run_frozen.py` instead; it does not
require downloading the full demonstration corpus.

## Rand-obj and historical variants

The adapter supports both regimes. For fresh original-strict rand-obj 1×,
download `--regime rand_obj` and use `configs/dexjoco_icl_5ep_one_x.json` with
the preparation/pipeline commands above. The main downloadable packages are
rand-full and will be rejected for rand-obj. To prepare and evaluate corrected
v2 Assembly, select `--tasks bimanual_assembly` and
`configs/dexjoco_icl_5ep_rand_obj_robot_v2_assembly.json` in a separate output.

Other `dexjoco_icl*.json` files preserve historical pilot/single-session and
two-session variants; their names describe their settings. Do not combine
them into a uniform score. In particular, schema-2 10× runs tell the first
session the extended budget; schema-3 uses an initial 1×-only session.

The original post hoc rand-obj 10× extension reconstructed archived 1× failures
by checked action replay and supplied history without prior scratch code. That
historical run is not reconstructed by the fresh two-session workflow here;
the private episode archives needed for it are not distributed.

## Expected results and limits

The historical uniform rand-full run completed 55/55 episodes with 43 successes
at 1× and 48 by 10×. Four post-terminal SIGTERM imports have partial token
accounting. The separate five-seed Pinch Tongs diagnostic achieved 3/5 at 1×
and 5/5 by 10×. These are historical reference outcomes, not guarantees or
assertions made by fresh runs. The public wrapper never imports those scores.

This release reproduces the evaluation procedure and frozen test inputs;
it cannot guarantee identical hosted model outputs. No fresh paid model
evaluation is needed to validate packaging, and none is represented as such.
