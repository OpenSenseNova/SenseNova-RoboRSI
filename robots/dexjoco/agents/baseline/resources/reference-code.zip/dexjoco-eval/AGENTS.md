# Public evaluation package

Read docs/PROTOCOL.md and docs/REPRODUCIBILITY.md before changing evaluator
behavior. Preserve model identity, information boundaries, immutable package
verification, action semantics, seeds, and scoring. Version protocol changes
explicitly. Keep upstream checkouts clean. Never commit credentials, raw
policy transcripts, output directories, or local environment files. Verify
the release with scripts/verify_release.py and run the tests before sharing.
