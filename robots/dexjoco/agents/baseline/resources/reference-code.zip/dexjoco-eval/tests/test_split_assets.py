"""Asset installs must preserve provenance and refuse corrupt or unsafe input."""
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from fetch_knowledge import install_assets, main
from release_assets import safe_relative, verify_assets


class SplitAssetTests(unittest.TestCase):
    def fixture(self, root):
        task = "water_plant"
        folder = root / "rand_full" / task
        (folder / "payload").mkdir(parents=True)
        text = b"Demonstration notes\n"
        (folder / "payload/TASK.md").write_bytes(text)
        payload = {"TASK.md": hashlib.sha256(text).hexdigest()}
        manifest = json.dumps({"files": payload}).encode()
        (folder / "manifest.json").write_bytes(manifest)
        return {task: {"manifest_sha256": hashlib.sha256(manifest).hexdigest(), "payload_files": payload}}

    def test_verified_install_in_paths_with_spaces_and_idempotence(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, dest = Path(tmp) / "download with spaces", Path(tmp) / "code with spaces/knowledge"
            entries = self.fixture(source)
            self.assertEqual(install_assets(source, dest, entries)["status"], "installed")
            self.assertEqual(verify_assets(dest, entries)["packages_checked"], 1)
            self.assertEqual(install_assets(source, dest, entries)["status"], "already_verified")

    def test_corrupt_download_never_installed_and_existing_files_not_overwritten(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, dest = Path(tmp) / "source", Path(tmp) / "installed"
            entries = self.fixture(source)
            file = source / "rand_full/water_plant/payload/TASK.md"
            original = file.read_bytes()
            file.write_bytes(b"corrupt")
            with self.assertRaises(ValueError):
                install_assets(source, dest, entries)
            self.assertFalse(dest.exists())
            file.write_bytes(original)
            install_assets(source, dest, entries)
            existing = dest / "rand_full/water_plant/payload/TASK.md"
            existing.write_bytes(b"local modification")
            with self.assertRaises(ValueError):
                install_assets(source, dest, entries)
            self.assertEqual(existing.read_bytes(), b"local modification")

    def test_extra_files_and_symlinks_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "source"
            entries = self.fixture(root)
            extra = root / "rand_full/water_plant/private.txt"
            extra.write_text("unreviewed data")
            with self.assertRaises(ValueError):
                verify_assets(root, entries)
            extra.unlink()
            payload = root / "rand_full/water_plant/payload/TASK.md"
            outside = Path(tmp) / "outside.md"
            payload.rename(outside)
            payload.symlink_to(outside)
            with self.assertRaises(ValueError):
                verify_assets(root, entries)

    def test_unsafe_relative_paths_rejected(self):
        for value in ("../escape", "/escape", "a/../../b", "C:\\escape", "a//b"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                safe_relative(value)

    def test_mock_public_download_pins_revision_and_uses_no_credentials(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            entries = self.fixture(root / "source")
            def download(**kwargs):
                self.assertEqual(kwargs["revision"], "a" * 40)
                self.assertEqual(kwargs["repo_type"], "dataset")
                self.assertIs(kwargs["token"], False)
                self.assertEqual(set(kwargs["allow_patterns"]), {
                    "rand_full/water_plant/manifest.json", "rand_full/water_plant/payload/TASK.md"})
                self.fixture(Path(kwargs["local_dir"]))
            with patch("fetch_knowledge.catalog", return_value=entries), patch("huggingface_hub.snapshot_download", side_effect=download):
                self.assertEqual(main(["--repo-id", "example/assets", "--revision", "a" * 40,
                                       "--destination", str(root / "installed")]), 0)
            self.assertEqual(verify_assets(root / "installed", entries)["packages_checked"], 1)


if __name__ == "__main__":
    unittest.main()
