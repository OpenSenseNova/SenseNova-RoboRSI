import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
from scipy.spatial.transform import Rotation

from gpt6_eval.dexjoco_adapter import (hold_action, public_observation,
                                        save_observation, to_environment_action,
                                        validate_actions)
from gpt6_eval.dexjoco_eval import SETTING, load_config, verify_package
from gpt6_eval.knowledge import file_hash, tree_hashes


class DexJoCoBoundaryTests(unittest.TestCase):
    def test_privileged_state_and_extra_camera_are_not_exported(self):
        raw = {"state": np.arange(38, dtype=float),
               "front": np.zeros((8, 10, 3), dtype=np.uint8),
               "hidden": np.full((8, 10, 3), 255, dtype=np.uint8),
               "succeed": True}
        public, images = public_observation(raw, {"base": "front"}, False, "task")
        self.assertEqual(len(public["state"]), 23)
        self.assertEqual(set(images), {"front"})
        self.assertNotIn("succeed", public)
        with tempfile.TemporaryDirectory() as tmp:
            saved = save_observation(Path(tmp), 0, 0, raw, {"base": "front"},
                                     False, "task", 1000)
            self.assertEqual([x["name"] for x in saved["cameras"]], ["front"])
            self.assertEqual(len(list(Path(tmp).rglob("*.png"))), 1)

    def test_dual_action_matches_upstream_layout_and_hold(self):
        state = np.zeros(46)
        state[3] = state[10] = 1.0
        state[14:30] = 0.1
        state[30:46] = 0.2
        action = hold_action(state, True)
        converted = to_environment_action(action, True)
        self.assertEqual(converted.shape, (46,))
        np.testing.assert_allclose(converted[:14], state[:14])
        np.testing.assert_allclose(converted[14:], state[14:])
        self.assertEqual(Rotation.from_quat(converted[3:7], scalar_first=True).magnitude(), 0)

    def test_rejects_oversized_and_nonfinite_chunks(self):
        with self.assertRaises(ValueError):
            validate_actions({"actions": [[0] * 22] * 31}, False, 100)
        with self.assertRaises(ValueError):
            validate_actions({"actions": [[float("nan")] * 22]}, False, 100)
        with self.assertRaises(ValueError):
            validate_actions({"actions": [[0] * 22], "private": 1}, False, 100)

    def test_frozen_package_rejects_tampering(self):
        config = load_config(Path(__file__).resolve().parents[1] /
                             "configs/dexjoco_icl.json")
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            payload = root / "payload"
            payload.mkdir()
            (payload / "TASK.md").write_text("first plan")
            (payload / "SOURCES.md").write_text("released demonstrations")
            manifest = {"setting": SETTING, "task": "water_plant",
                        "regime": config["regime"],
                        "upstream_commit": config["upstream_commit"],
                        "dataset_revision": config["dataset_revision"],
                        "model": config["model"], "ready": True,
                        "model_evidence": [{"model": config["model"]}],
                        "training_manifest_sha256": "a" * 64,
                        "files": tree_hashes(payload)}
            (root / "manifest.json").write_text(json.dumps(manifest))
            expected = file_hash(root / "manifest.json")
            verify_package(root, "water_plant", config, expected)
            (payload / "TASK.md").write_text("changed after preparation")
            with self.assertRaises(ValueError):
                verify_package(root, "water_plant", config, expected)


if __name__ == "__main__":
    unittest.main()
