from concurrent.futures import ThreadPoolExecutor
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import time
import unittest

from gpt6_eval.core import write_json
from gpt6_eval.dexjoco_adapter import TASKS, validate_actions
from gpt6_eval.dexjoco_eval import load_config, verify_package
from gpt6_eval.step import submit
from gpt6_eval.telemetry import normalize_usage, sum_usage

ROOT = Path(__file__).resolve().parents[1]


def load_script(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class PublicReleaseTests(unittest.TestCase):
    def test_all_historical_packages_validate(self):
        assets = Path(os.environ.get("DEXJOCO_TEST_KNOWLEDGE", ROOT / "knowledge"))
        if not (assets / "rand_full").is_dir():
            self.skipTest("Optional ICL assets absent; fetch them or set DEXJOCO_TEST_KNOWLEDGE")
        cfg = load_config(ROOT / "configs/dexjoco_icl_5ep_rand_full_robot_v2_two_session.json")
        entries = json.loads((ROOT / "provenance/knowledge_packages.json").read_text())["packages"]
        self.assertEqual(set(entries), set(TASKS))
        for task, row in entries.items():
            with self.subTest(task=task):
                self.assertEqual(row["manifest_sha256"], row["original_manifest_sha256"])
                result = verify_package(assets / "rand_full" / task, task, cfg, row["manifest_sha256"])
                self.assertEqual(result["files"], row["payload_files"])

    def test_cumulative_token_accounting_preserves_partial_and_subsets(self):
        usage = normalize_usage({"input_tokens": 100, "cached_input_tokens": 90,
                                 "output_tokens": 10, "reasoning_output_tokens": 7})
        self.assertEqual(usage["total_tokens"], 110)
        summed = sum_usage([{**usage, "status": "complete"}, {**usage, "status": "partial"}])
        self.assertEqual(summed["total_tokens"], 220)
        self.assertEqual(summed["status"], "partial")

    def test_metadata_fix_is_separate_and_preserves_numeric_rows(self):
        variant = load_script("diagnostic_step", ROOT / "scripts/variants/pinch_metadata_step_v3.py")
        for helper, accepts in ((submit, False), (variant.submit, True)):
            with self.subTest(diagnostic=accepts), tempfile.TemporaryDirectory() as tmp:
                workspace = Path(tmp)
                (workspace / "input").mkdir()
                transport = workspace / ".action_transport"
                transport.mkdir()
                write_json(workspace / "input/observation.json", {"decision": 0})
                write_json(workspace / "input/protocol.json", {
                    "revision": "robot_reference_array_adapter_v2", "accept_bare_action_arrays": True})
                rows = [[float(i) / 100 for i in range(22)] for _ in range(3)]
                action = workspace / "action.json"
                write_json(action, {"actions": rows, "metadata": {"source": "frozen helper"}})
                original = action.read_bytes()
                with ThreadPoolExecutor(max_workers=1) as pool:
                    future = pool.submit(helper, action, workspace, transport)
                    try:
                        limit = time.monotonic() + 3
                        while not (transport / "request.json").exists():
                            self.assertLess(time.monotonic(), limit)
                            time.sleep(.01)
                        payload = json.loads((transport / "request.json").read_text())["payload"]
                        if accepts:
                            self.assertEqual(payload, {"actions": rows})
                            self.assertEqual(validate_actions(payload, False, 30).tolist(), rows)
                            self.assertTrue((transport / "metadata_adapter_000000.json").is_file())
                        else:
                            with self.assertRaises(ValueError):
                                validate_actions(payload, False, 30)
                        self.assertEqual(original, action.read_bytes())
                    finally:
                        write_json(workspace / "input/episode_done.json", {"episode_done": True})
                    self.assertEqual(future.result(timeout=3), {"episode_done": True})

    def test_incomplete_runs_have_no_success_rate(self):
        runner = load_script("public_runner", ROOT / "scripts/run_frozen.py")
        usage = {"status": "complete", "input_tokens": 100, "output_tokens": 10, "total_tokens": 110}
        task = {"task": "water_plant", "completed": 1, "complete_valid": True,
                "successes_1x": 1, "successes_10x": 1, "tokens": usage}
        report = runner.aggregate([task], 5, "rand-full-v2", "codex")
        self.assertFalse(report["complete_valid"])
        self.assertIsNone(report["success_rate_10x"])
        self.assertEqual(report["test_tokens"]["status"], "partial")
        report = runner.aggregate([task], 1, "rand-full-v2", "codex")
        self.assertEqual(report["success_rate_1x"], 1.0)
        self.assertFalse(runner.aggregate([task], 1, "rand-full-v2", "smoke")["complete_valid"])

    def test_scan_does_not_echo_credential_matches(self):
        scanner = load_script("release_scanner", ROOT / "scripts/verify_release.py")
        findings = []
        value = "sk-" + "a" * 30
        scanner.scan_text(value, "fixture.txt", findings)
        self.assertTrue(findings)
        self.assertNotIn(value, json.dumps(findings))


if __name__ == "__main__":
    unittest.main()
