import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

import numpy as np

from gpt6_eval import dexjoco_eval
from gpt6_eval.dexjoco_eval import load_config
from gpt6_eval.dexjoco_horizon import extend_episode_limit


class ToyEnvironment:
    def __init__(self):
        self.env_step = 0
        self.success = False

    def step(self):
        self.env_step += 1
        terminated = self.env_step >= 3 or self.success
        return terminated, self.success


class HorizonTests(unittest.TestCase):
    def test_changes_only_one_environment_instance_and_keeps_success_terminal(self):
        extended = ToyEnvironment()
        original = ToyEnvironment()
        audit = extend_episode_limit(extended, 3, 10)
        self.assertEqual(audit["extended_step_limit"], 30)
        self.assertEqual([extended.step()[0] for _ in range(3)], [False] * 3)
        self.assertEqual([original.step()[0] for _ in range(3)], [False, False, True])
        extended.success = True
        self.assertEqual(extended.step(), (True, True))
        extended.success = False
        extended.env_step = 29
        self.assertEqual(extended.step(), (True, False))

    def test_rejects_mismatched_limit(self):
        with self.assertRaises(ValueError):
            extend_episode_limit(ToyEnvironment(), 4, 10)

    def test_extended_config_is_explicit_and_strict(self):
        path = Path(__file__).resolve().parents[1] / "configs/dexjoco_icl_5ep_10x.json"
        cfg = load_config(path)
        self.assertEqual((cfg["episodes"], cfg["horizon_multiplier"]), (5, 10))
        with tempfile.TemporaryDirectory() as tmp:
            bad = Path(tmp) / "bad.json"
            bad.write_text(json.dumps({**cfg, "horizon_multiplier": 1}))
            with self.assertRaises(ValueError):
                load_config(bad)

    def test_continuation_starts_fresh_session_at_exact_1x_state(self):
        class FakeEnv:
            def __init__(self):
                self.env_step = 0
            def reset(self):
                return self.observation(), {}
            def observation(self):
                state = np.zeros(23)
                state[3] = 1
                return {"state": state, "camera": np.zeros((2, 2, 3), dtype=np.uint8)}
            def step(self, action):
                self.env_step += 1
                success = self.env_step == 6
                return self.observation(), float(success), success, False, {"succeed": success}
            def close(self):
                pass

        class Factory:
            def get_environment(self, **kwargs):
                return environment

        class FakeProc:
            returncode = 0
            def wait(self, timeout=None):
                return 0

        environment = FakeEnv()
        session_starts = []
        actions_requested = []
        def fake_start(ep, cfg, binary, auth, prompt, session_private=None):
            inputs = ep / "policy/input"
            observation = json.loads((inputs / "observation.json").read_text())
            if environment.env_step == 0:
                self.assertEqual(observation["remaining_steps"], 4)
                self.assertFalse((inputs / "continuation.json").exists())
                self.assertFalse((inputs / "first_session_history.jsonl").exists())
                self.assertNotIn("nine more", prompt)
            else:
                self.assertEqual(observation["remaining_steps"], 36)
                self.assertTrue((inputs / "continuation.json").exists())
                self.assertTrue((inputs / "first_session_history.jsonl").exists())
            session_starts.append((environment.env_step, str(session_private), prompt))
            folder = session_private or ep / "private"
            folder.mkdir(parents=True, exist_ok=True)
            (folder / "codex.events.jsonl").write_text("")
            streams = ((folder / "fake_stdout").open("wb"),
                       (folder / "fake_stderr").open("wb"))
            return FakeProc(), streams
        def fake_wait(ep, cfg, proc, decision, remaining, dual_arm, session_private=None):
            actions_requested.append((environment.env_step, remaining, str(session_private)))
            count = min(remaining, 4)
            return np.zeros((count, 22)), {"model_evidence": [{"model": "gpt-6-astra"}]}
        def fake_snapshot(env, path):
            path.write_bytes(b"checkpoint")
            return "snapshot-hash"
        zero_tokens = {"status": "complete", "total_tokens": 0,
                       "input_tokens": 0, "cached_input_tokens": 0,
                       "cache_write_input_tokens": 0, "output_tokens": 0,
                       "reasoning_output_tokens": 0}
        cfg = load_config(Path(__file__).resolve().parents[1] /
                          "configs/dexjoco_icl_5ep_two_session.json")
        fake_package = types.ModuleType("dexjoco")
        fake_package.__path__ = []
        fake_tasks = types.ModuleType("dexjoco.tasks")
        fake_tasks.CONFIG_MAPPING = {"water_plant": Factory}
        with tempfile.TemporaryDirectory() as tmp, \
                patch.dict(dexjoco_eval.LIMITS, {"water_plant": 4}), \
                patch.dict(sys.modules, {"dexjoco": fake_package,
                                         "dexjoco.tasks": fake_tasks}), \
                patch.object(dexjoco_eval, "extend_episode_limit",
                             return_value={"extended_step_limit": 40}), \
                patch.object(dexjoco_eval, "_start_policy", side_effect=fake_start), \
                patch.object(dexjoco_eval, "_wait_action", side_effect=fake_wait), \
                patch.object(dexjoco_eval, "_save_live_simulator_checkpoint", side_effect=fake_snapshot), \
                patch.object(dexjoco_eval, "token_usage", return_value=zero_tokens):
            ep = Path(tmp) / "episode"
            package = Path(tmp) / "package"
            (package / "payload").mkdir(parents=True)
            (package / "payload/TASK.md").write_text("Task notes")
            (package / "payload/SOURCES.md").write_text("Training sources")
            result = dexjoco_eval._run_episode(ep, Path(tmp), cfg, "water_plant",
                {"robot_type": "single_arm", "camera_mapping": {"front": "camera"},
                 "prompt": "Water the plant"}, package, "codex", None, None, 100000)
            self.assertEqual(result["outcome"], "success", result["error"])
            self.assertFalse(result["success_by_1x"])
            self.assertTrue(result["success_by_10x"])
            self.assertEqual(result["simulator_steps"], 6)
            self.assertEqual([x[0] for x in session_starts], [0, 4])
            self.assertEqual([x[:2] for x in actions_requested], [(0, 4), (4, 36)])
            self.assertEqual([x["phase"] for x in result["session_records"]],
                             ["initial", "continuation"])
            self.assertTrue((ep / "private/checkpoint_simulator_1x.npz").is_file())
            history = (ep / "policy/input/first_session_history.jsonl").read_text().splitlines()
            self.assertEqual(len(history), 5)
            self.assertNotIn("reward", history[-1])
            self.assertEqual(json.loads((ep / "private/checkpoint_1x.json").read_text())["step"], 4)


if __name__ == "__main__":
    unittest.main()
