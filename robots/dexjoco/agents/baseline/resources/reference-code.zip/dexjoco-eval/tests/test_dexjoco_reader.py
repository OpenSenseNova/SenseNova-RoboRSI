import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
import zarr

from gpt6_eval.dexjoco_reader import DemoReader


class DemoReaderTests(unittest.TestCase):
    def test_only_public_arrays_and_selected_video_are_served(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "source"
            data = zarr.open(str(source / "replay.zarr"), mode="w").create_group("data")
            state = np.arange(38, dtype=np.float32)[None, :].repeat(2, axis=0)
            data.create_dataset("state", data=state)
            data.create_dataset("action_rotvec", data=np.ones((2, 22), dtype=np.float32))
            data.create_dataset("timestamp", data=np.array([0.0, 1.0]))
            videos = source / "videos"
            videos.mkdir()
            (videos / "front.mp4").write_bytes(b"selected rgb")
            (videos / "hidden.mp4").write_bytes(b"private camera")
            workspace = root / "workspace"
            workspace.mkdir()
            transport = root / "transport"
            transport.mkdir()
            reader = DemoReader([{"id": "0000", "steps": 2, "cameras": ["front"],
                                  "source": source}], {"robot_type": "single_arm"},
                                workspace, transport, root / "audit.jsonl")
            result = reader.handle({"op": "arrays", "demo": "0000"}, "a" * 32)
            with np.load(workspace / result["path"]) as public:
                self.assertEqual(set(public.files), {"state", "actions", "timestamps"})
                self.assertEqual(public["state"].shape, (2, 23))
                np.testing.assert_array_equal(public["state"][0], state[0, :23])
            video = reader.handle({"op": "video", "demo": "0000", "camera": "front"},
                                  "b" * 32)
            self.assertEqual((workspace / video["path"]).read_bytes(), b"selected rgb")
            with self.assertRaises(ValueError):
                reader.handle({"op": "video", "demo": "0000", "camera": "hidden"}, "c" * 32)
            with self.assertRaises(ValueError):
                reader.handle({"op": "arrays", "demo": "../source"}, "d" * 32)
            with self.assertRaises(ValueError):
                reader.handle({"op": "raw", "demo": "0000"}, "e" * 32)
            self.assertEqual(len(reader.handle({"op": "list"}, "f" * 32)["demos"]), 1)


if __name__ == "__main__":
    unittest.main()
