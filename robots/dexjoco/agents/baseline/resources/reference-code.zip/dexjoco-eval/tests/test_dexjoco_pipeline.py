from argparse import Namespace
import json
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

from gpt6_eval import dexjoco_pipeline


class PipelineSchedulingTests(unittest.TestCase):
    def test_test_starts_after_own_freeze_and_overlaps_next_preparation(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            manifest = root / "training.json"
            manifest.write_text("{}")
            config = Path(__file__).resolve().parents[1] / "configs/dexjoco_icl.json"
            output = root / "run"
            args = Namespace(config=config, upstream=root, dataset=root,
                             tasks=["water_plant", "click_mouse"], prep_workers=1,
                             test_workers=1, episode_workers=1,
                             auth=root / "auth.json", output=output, prepared=[])
            testing = threading.Event()
            overlapped = []
            usage = {"status": "complete", "input_tokens": 2,
                     "cached_input_tokens": 0, "cache_write_input_tokens": 0,
                     "output_tokens": 1, "reasoning_output_tokens": 1,
                     "total_tokens": 3}

            def fake_run(command, log, env):
                task = command[command.index("--task") + 1]
                target = Path(command[command.index("--output") + 1])
                target.mkdir(parents=True)
                if "gpt6_eval.dexjoco_icl" in command:
                    if task == "click_mouse":
                        overlapped.append(testing.wait(1))
                    (target / "frozen").mkdir()
                    (target / "preparation.json").write_text(json.dumps({
                        "state": "ready", "package_sha256": "a" * 64,
                        "training_manifest_sha256": dexjoco_pipeline.file_hash(manifest),
                        "preparation_tokens": usage, "wall_seconds": 0.1}))
                    return 0
                prep = output / "preparation" / task / "preparation.json"
                if json.loads(prep.read_text())["state"] != "ready":
                    raise AssertionError("Scored test began before task freeze")
                if task == "water_plant":
                    testing.set()
                    time.sleep(0.2)
                (target / "result.json").write_text(json.dumps({
                    "complete_valid": True, "successes": 1, "completed": 1,
                    "tokens": usage,
                    "episode_wall_seconds": 0.2,
                    "simulator_step_wall_seconds": 0.1,
                    "simulator_steps": 4}))
                return 0

            with patch.object(dexjoco_pipeline, "verify_upstream"), \
                 patch.object(dexjoco_pipeline, "task_config", return_value={}), \
                 patch.object(dexjoco_pipeline, "verified_inventory",
                              return_value=(manifest, [{}])), \
                 patch.object(dexjoco_pipeline, "verify_package"), \
                 patch.object(dexjoco_pipeline, "_run", side_effect=fake_run):
                self.assertEqual(dexjoco_pipeline.run(args), 0)
            report = json.loads((output / "pipeline_result.json").read_text())
            self.assertTrue(report["complete_valid"])
            self.assertEqual(report["successes"], 2)
            self.assertEqual(report["tokens"]["total_tokens"], 12)
            self.assertEqual(report["tokens"]["status"], "complete")
            self.assertEqual(report["reported_model_sessions"], 4)
            self.assertEqual(overlapped, [True])

    def test_prepared_task_is_verified_and_tested_without_repeat_preparation(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            manifest = root / "training.json"
            manifest.write_text("{}")
            config = Path(__file__).resolve().parents[1] / "configs/dexjoco_icl.json"
            cfg = dexjoco_pipeline.load_config(config)
            source = root / "preexisting"
            (source / "frozen").mkdir(parents=True)
            (source / "preparation.json").write_text(json.dumps({
                "state": "ready", "task": "water_plant", "regime": cfg["regime"],
                "upstream_commit": cfg["upstream_commit"],
                "dataset_revision": cfg["dataset_revision"],
                "training_manifest_sha256": dexjoco_pipeline.file_hash(manifest),
                "package_sha256": "a" * 64, "wall_seconds": 1.0}))
            output = root / "run"
            args = Namespace(config=config, upstream=root, dataset=root,
                             tasks=["water_plant"], prep_workers=2,
                             test_workers=2, episode_workers=1,
                             auth=root / "auth.json", output=output,
                             prepared=[f"water_plant={source}"])
            called = []

            def fake_run(command, log, env):
                called.append(command)
                if "gpt6_eval.dexjoco_icl" in command:
                    raise AssertionError("Preparation was repeated")
                target = Path(command[command.index("--output") + 1])
                target.mkdir(parents=True)
                (target / "result.json").write_text(json.dumps({
                    "complete_valid": True, "successes": 0}))
                return 0

            with patch.object(dexjoco_pipeline, "verify_upstream"), \
                 patch.object(dexjoco_pipeline, "task_config", return_value={}), \
                 patch.object(dexjoco_pipeline, "verified_inventory",
                              return_value=(manifest, [{}])), \
                 patch.object(dexjoco_pipeline, "verify_package"), \
                 patch.object(dexjoco_pipeline, "_run", side_effect=fake_run):
                self.assertEqual(dexjoco_pipeline.run(args), 0)
            self.assertEqual(len(called), 1)
            self.assertTrue((output / "preparation/water_plant/preparation.json").is_file())

    def test_live_external_preparation_is_tested_only_after_readiness(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            manifest = root / "training.json"
            manifest.write_text("{}")
            config = Path(__file__).resolve().parents[1] / "configs/dexjoco_icl.json"
            cfg = dexjoco_pipeline.load_config(config)
            source = root / "external"
            source.mkdir()
            record = {"state": "preparing", "task": "water_plant",
                      "regime": cfg["regime"],
                      "upstream_commit": cfg["upstream_commit"],
                      "dataset_revision": cfg["dataset_revision"],
                      "training_manifest_sha256": dexjoco_pipeline.file_hash(manifest)}
            (source / "preparation.json").write_text(json.dumps(record))
            output = root / "run"
            args = Namespace(config=config, upstream=root, dataset=root,
                             tasks=["water_plant"], prep_workers=1,
                             test_workers=1, episode_workers=1,
                             auth=root / "auth.json", output=output,
                             prepared=[f"water_plant={source}"])
            ready = threading.Event()

            def finish_preparation():
                time.sleep(0.05)
                (source / "frozen").mkdir()
                record.update(state="ready", package_sha256="a" * 64)
                (source / "preparation.json").write_text(json.dumps(record))
                ready.set()

            def fake_run(command, log, env):
                self.assertTrue(ready.is_set())
                self.assertNotIn("gpt6_eval.dexjoco_icl", command)
                target = Path(command[command.index("--output") + 1])
                target.mkdir(parents=True)
                (target / "result.json").write_text(json.dumps({
                    "complete_valid": True, "successes": 0}))
                return 0

            thread = threading.Thread(target=finish_preparation)
            thread.start()
            original_sleep = time.sleep
            with patch.object(dexjoco_pipeline, "verify_upstream"), \
                 patch.object(dexjoco_pipeline, "task_config", return_value={}), \
                 patch.object(dexjoco_pipeline, "verified_inventory",
                              return_value=(manifest, [{}])), \
                 patch.object(dexjoco_pipeline, "verify_package"), \
                 patch.object(dexjoco_pipeline, "_run", side_effect=fake_run), \
                 patch.object(dexjoco_pipeline.time, "sleep",
                              side_effect=lambda _: original_sleep(0.01)):
                self.assertEqual(dexjoco_pipeline.run(args), 0)
            thread.join()
            self.assertTrue((output / "preparation/water_plant/frozen").is_dir())


if __name__ == "__main__":
    unittest.main()
