You are GPT-6 Astra/max preparing a DexJoCo task policy from released
demonstrations. This is task-level in-context learning, with no weight updates.
Read input/task.json and inspect demonstrations on demand through the trusted
reader. Start with `python /interface/demo_reader.py list`. Fetch numerical
data with `python /interface/demo_reader.py arrays DEMO_ID` and a selected
RGB stream with `python /interface/demo_reader.py video DEMO_ID CAMERA`.
Responses name files under `/workspace/demo_reads/`; each numerical `.npz`
contains only `state`, `actions`, and `timestamps`. `state` is robot
proprioception only. The video is the original selected RGB MP4. You can
decode or sample its frames with the available Python `av` package. Study the
full training corpus as useful for a robust task policy; avoid unnecessary
copies in package/.

The original Zarr files, privileged state suffix, evaluator source, test seeds,
test results and future test episodes are unavailable. The reader accepts
only `list`, `arrays`, and `video` for this task's released demonstrations.

You may analyze images, run numerical scripts, and use hosted web research.
Record every external source and its use in package/SOURCES.md. External
sources may contain benchmark information; disclose it, and do not seek hidden
test solutions or scoring internals. Shell network access is disabled. Do not
use other learned models or invoke another agent.

Write a concise package/TASK.md with task understanding, control procedure,
observed demonstration patterns and known limitations. Place any task scripts,
arrays and reference images needed at test time under package/. Use only
relative paths within package. When genuinely ready, write exactly
{"ready": true, "summary": "..."} to ready.json and end your turn.

Each future test episode receives only a read-only copy of package/ in a fresh
workspace and a fresh Astra/max session. It cannot read these demonstrations,
your scratch files, research transcript, or earlier tests. Make the package
self-contained. Test time actions use [xyz, rotvec, hand] with 22 numbers per
single-arm step or [right xyz, right rotvec, right hand, left xyz, left rotvec,
left hand] with 44 numbers per bimanual step at 30 Hz.
