"""Private DexJoCo runner: fresh isolated Astra session and simulator per episode."""
from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import json
import os
from pathlib import Path
import platform
import random
import shutil
import stat
import subprocess
import sys
import time

import numpy as np
import yaml

from . import isolation
from .core import MODEL, digest, verify_model_rollouts, write_json
from .dexjoco_adapter import (TASKS, dimensions, hold_action,
                              save_observation, to_environment_action, validate_actions)
from .dexjoco_horizon import extend_episode_limit
from .dexjoco_robot_reference import copy_robot_reference
from .knowledge import file_hash, tree_hashes
from .telemetry import sum_usage, token_usage, utc_now

ROOT = Path(__file__).resolve().parents[2]
SETTING = "dexjoco_task_icl_v1"
PROTOCOL_V2 = "robot_reference_array_adapter_v2"
LIMITS = {"bimanual_assembly": 1500, "bimanual_hanoi": 1500,
          "bimanual_microwave_cook": 1100, "bimanual_photograph": 1000,
          "bimanual_unlock_ipad": 1200, "click_mouse": 1200,
          "fold_glasses": 1200, "hammer_nail": 1000,
          "pick_bucket": 1200, "pinch_tongs": 1000, "water_plant": 1000}


class PolicyError(RuntimeError):
    """The policy failed to provide a valid action; the simulator is still valid."""


def _jsonable(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    return value


def git(repo: Path, *args: str) -> str:
    return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()


def load_config(path: Path) -> dict:
    cfg = json.loads(path.read_text())
    expected = {"schema_version", "setting", "model", "reasoning_effort",
                "codex_version", "upstream_commit", "dataset_revision",
                "regime", "seed_start", "episodes", "max_chunk",
                "decision_timeout_s"}
    protocol = cfg.get("protocol_revision")
    if protocol is not None:
        if protocol != PROTOCOL_V2:
            raise ValueError("Unknown DexJoCo ICL protocol revision")
        expected.add("protocol_revision")
    schema = cfg.get("schema_version")
    if (schema == 1 and set(cfg) != expected or
            schema == 2 and set(cfg) != expected | {"horizon_multiplier"} or
            schema == 3 and set(cfg) != expected | {"continuation_multiplier"} or
            schema not in {1, 2, 3} or cfg.get("setting") != SETTING):
        raise ValueError("Use an exact DexJoCo ICL config schema")
    if schema == 2 and (type(cfg["horizon_multiplier"]) is not int
                        or cfg["horizon_multiplier"] < 2):
        raise ValueError("Extended horizon multiplier must be an integer >= 2")
    if schema == 3 and (type(cfg["continuation_multiplier"]) is not int
                        or cfg["continuation_multiplier"] < 2):
        raise ValueError("Continuation multiplier must be an integer >= 2")
    if cfg["model"] != MODEL or cfg["reasoning_effort"] != "max":
        raise ValueError("DexJoCo ICL requires exact gpt-6-astra/max")
    if cfg["regime"] not in {"rand_obj", "rand_full"}:
        raise ValueError("Unknown official DexJoCo regime")
    for key in ("seed_start", "episodes", "max_chunk"):
        if type(cfg[key]) is not int or cfg[key] < (0 if key == "seed_start" else 1):
            raise ValueError(f"Invalid {key}")
    if cfg["max_chunk"] > 30:
        raise ValueError("DexJoCo OpenPI reference uses a 30-step action horizon")
    timeout = cfg["decision_timeout_s"]
    if timeout is not None and (not isinstance(timeout, (int, float)) or timeout <= 0):
        raise ValueError("Decision timeout must be null or positive")
    return cfg


def task_config(upstream: Path, regime: str, task: str) -> dict:
    if task not in TASKS:
        raise ValueError("Task must be one of the 11 official DexJoCo tasks")
    path = upstream / "configs" / regime / f"{task}.yaml"
    data = yaml.safe_load(path.read_text())
    if (data["env_name"] != task or data["robot_type"] not in {"single_arm", "dual_arm"}
            or not isinstance(data["camera_mapping"], dict)
            or not data["camera_mapping"] or not data["prompt"]):
        raise ValueError("Invalid upstream task configuration")
    return data


def verify_upstream(upstream: Path, cfg: dict) -> None:
    if git(upstream, "rev-parse", "HEAD") != cfg["upstream_commit"]:
        raise ValueError("DexJoCo commit does not match pinned config")
    if git(upstream, "status", "--porcelain"):
        raise ValueError("DexJoCo upstream must remain clean")


def verify_package(package: Path, task: str, cfg: dict,
                   expected_sha256: str | None = None) -> dict:
    container = tree_hashes(package)
    if expected_sha256 is not None and file_hash(package / "manifest.json") != expected_sha256:
        raise ValueError("Frozen task package hash mismatch")
    manifest = json.loads((package / "manifest.json").read_text())
    if (manifest.get("setting") != SETTING or manifest.get("task") != task
            or manifest.get("regime") != cfg["regime"]
            or manifest.get("protocol_revision") != cfg.get("protocol_revision")
            or manifest.get("upstream_commit") != cfg["upstream_commit"]
            or manifest.get("dataset_revision") != cfg["dataset_revision"]
            or manifest.get("model") != MODEL or manifest.get("ready") is not True
            or not manifest.get("model_evidence")
            or not manifest.get("training_manifest_sha256")):
        raise ValueError("Knowledge package contract mismatch")
    if cfg.get("protocol_revision") == PROTOCOL_V2 and not manifest.get("robot_reference_sha256"):
        raise ValueError("Knowledge package lacks pinned robot reference")
    files = tree_hashes(package / "payload")
    if files != manifest.get("files") or not all(k in files for k in ("TASK.md", "SOURCES.md")):
        raise ValueError("Frozen task knowledge changed or is incomplete")
    if set(container) != {"manifest.json", *("payload/" + k for k in files)}:
        raise ValueError("Undeclared knowledge package files")
    return manifest


def _read_request(path: Path, decision: int) -> tuple[bytes, object]:
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as stream:
        if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
            raise RuntimeError("Action transport is not a regular file")
        data = stream.read(16 * 1024 * 1024 + 1)
    if len(data) > 16 * 1024 * 1024:
        raise RuntimeError("Action transport exceeds size limit")
    envelope = json.loads(data)
    if not isinstance(envelope, dict) or set(envelope) != {"decision", "payload"}:
        raise RuntimeError("Malformed action transport envelope")
    if envelope["decision"] != decision:
        raise RuntimeError("Stale action transport envelope")
    return data, envelope["payload"]


def _start_policy(ep: Path, cfg: dict, binary: Path, auth: Path, prompt: str,
                  session_private: Path | None = None):
    workspace, private = ep / "policy", ep / "private"
    session_private = session_private or private
    session_private.mkdir(parents=True, exist_ok=True)
    home, interface = session_private / "codex-home", private / "interface"
    isolation.prepare_auth(home, auth)
    isolation.probe(workspace, home, interface, binary, private)
    cmd = isolation.command(workspace, home, interface, binary, cfg,
                            policy_python=Path(sys.prefix))
    write_json(session_private / "invocation.json", {"argv": cmd})
    (session_private / "prompt.md").write_text(prompt)
    stdout = (session_private / "codex.events.jsonl").open("wb")
    stderr = (session_private / "codex.stderr.log").open("wb")
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=stdout, stderr=stderr,
                            start_new_session=True)
    proc.stdin.write(prompt.encode())
    proc.stdin.close()
    return proc, (stdout, stderr)


def _finish_policy_session(inputs: Path, session_private: Path, proc,
                           logs: tuple, phase: str, started: float) -> dict:
    write_json(inputs / "episode_done.json", {"episode_done": True})
    try:
        proc.wait(timeout=30)
    except subprocess.TimeoutExpired:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
    for stream in logs:
        stream.close()
    (session_private / "codex-home/auth.json").unlink(missing_ok=True)
    usage = token_usage(session_private, "codex", process_started=True,
                        returncode=proc.returncode)
    record = {"phase": phase, "started_at_monotonic": started,
              "ended_at": utc_now(), "wall_seconds": time.monotonic() - started,
              "returncode": proc.returncode, "tokens": usage}
    write_json(session_private / "session_result.json", record)
    return record


def _export_first_session_history(inputs: Path, private: Path,
                                  standard_limit: int) -> str:
    """Expose public observations and executed actions, never private reward/state."""
    path = inputs / "first_session_history.jsonl"
    with path.open("w") as stream:
        for step in range(standard_limit + 1):
            observation = json.loads((inputs / "observations" /
                f"{step:06d}" / "observation.json").read_text())
            row = {"step": step, "observation": f"observations/{step:06d}/observation.json",
                   "public_state": observation["state"],
                   "cameras": observation["cameras"]}
            if step:
                action = json.loads((private / "steps" / f"{step:06d}.json").read_text())
                row["executed_action"] = action["action"]
                row["phase"] = action["phase"]
            stream.write(json.dumps(row, sort_keys=True) + "\n")
    return file_hash(path)


def _save_live_simulator_checkpoint(env, path: Path) -> str:
    target = env
    while hasattr(target, "env"):
        target = target.env
    data = target._data
    model = target._model
    np.savez_compressed(path, env_step=np.array([target.env_step]),
        time=np.array([data.time]), qpos=np.array(data.qpos), qvel=np.array(data.qvel),
        act=np.array(data.act), ctrl=np.array(data.ctrl),
        qacc_warmstart=np.array(data.qacc_warmstart),
        qfrc_applied=np.array(data.qfrc_applied), xfrc_applied=np.array(data.xfrc_applied),
        mocap_pos=np.array(data.mocap_pos), mocap_quat=np.array(data.mocap_quat),
        userdata=np.array(data.userdata), body_pos=np.array(model.body_pos),
        body_quat=np.array(model.body_quat), geom_rgba=np.array(model.geom_rgba))
    return file_hash(path)


def _record_step(private: Path, step: int, phase: str, action: np.ndarray,
                 environment_action: np.ndarray, raw: dict, reward: float,
                 terminated: bool, truncated: bool, info: dict,
                 wall_seconds: float) -> None:
    entry = {"event": "step", "step": step, "phase": phase,
             "recorded_at": utc_now(), "action": action.tolist(),
             "environment_action": environment_action.tolist(),
             "state": np.asarray(raw["state"]).reshape(-1).tolist(),
             "reward": float(reward), "terminated": bool(terminated),
             "truncated": bool(truncated), "info": _jsonable(info),
             "simulator_step_wall_seconds": wall_seconds,
             "rgb_observation": f"policy/input/observations/{step:06d}/observation.json"}
    write_json(private / "steps" / f"{step:06d}.json", entry)
    with (private / "trajectory.jsonl").open("a") as stream:
        stream.write(json.dumps(entry, sort_keys=True) + "\n")


def _wait_action(ep: Path, cfg: dict, proc, decision: int, remaining: int,
                 dual_arm: bool, session_private: Path | None = None) -> tuple[np.ndarray, dict]:
    path = ep / "private/action-transport/request.json"
    started = time.monotonic()
    while True:
        if path.exists():
            data, payload = _read_request(path, decision)
            path.unlink()
            evidence = verify_model_rollouts((session_private or ep / "private") / "codex-home")
            try:
                actions = validate_actions(payload, dual_arm, remaining, cfg["max_chunk"])
            except (ValueError, TypeError, OverflowError) as exc:
                raise PolicyError(f"Invalid policy action: {exc}") from exc
            return actions, {"model_evidence": evidence, "request_sha256": digest(data),
                             "reasoning_wall_seconds": time.monotonic() - started}
        code = proc.poll()
        if code is not None:
            if code != 0:
                raise RuntimeError(f"Codex process exited {code}")
            if (ep / "private/action-transport/submission.lock").exists():
                raise RuntimeError("Codex ended with an unresolved action submission lock")
            if _interrupted_step_helper(session_private or ep / "private"):
                raise RuntimeError("Codex ended after a terminated step helper command")
            raise PolicyError("Codex ended before the simulator episode")
        if cfg["decision_timeout_s"] is not None and time.monotonic() - started > cfg["decision_timeout_s"]:
            raise RuntimeError("Configured decision watchdog expired")
        time.sleep(0.05)


def _interrupted_step_helper(session_private: Path) -> bool:
    events = session_private / "codex.events.jsonl"
    if not events.is_file():
        return False
    with events.open() as stream:
        for line in stream:
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            item = event.get("item") or {}
            if (event.get("type") == "item.completed"
                    and item.get("type") == "command_execution"
                    and "/interface/step.py" in item.get("command", "")
                    and item.get("exit_code") in {137, 143}):
                return True
    return False


def _release_completed_submission_lock(transport: Path) -> None:
    """The host calls this only after publishing the next decision."""
    if not (transport / "request.json").exists():
        (transport / "submission.lock").unlink(missing_ok=True)


def _run_episode(ep: Path, upstream: Path, cfg: dict, task: str,
                 task_cfg: dict, package: Path | None, mode: str,
                 binary: Path | None, auth: Path | None, seed: int) -> dict:
    """Keep the complete DexJoCo environment and score outside the policy mount."""
    dual_arm = task_cfg["robot_type"] == "dual_arm"
    standard_limit = LIMITS[task]
    continuation_mode = cfg["schema_version"] == 3
    horizon_multiplier = cfg.get("horizon_multiplier", cfg.get("continuation_multiplier", 1))
    episode_limit = standard_limit * horizon_multiplier
    workspace, private = ep / "policy", ep / "private"
    inputs, interface = workspace / "input", private / "interface"
    for p in (inputs, interface, private / "action-transport"):
        p.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(Path(__file__).with_name("step.py"), interface / "step.py")
    if package is not None:
        shutil.copytree(package / "payload", inputs / "task_knowledge")
        if tree_hashes(inputs / "task_knowledge") != tree_hashes(package / "payload"):
            raise RuntimeError("Knowledge copy changed before episode")
    robot_reference = None
    if cfg.get("protocol_revision") == PROTOCOL_V2:
        robot_reference = copy_robot_reference(
            upstream, inputs / "robot_reference", task_cfg["robot_type"],
            cfg["upstream_commit"])
        if package is not None:
            package_manifest = json.loads((package / "manifest.json").read_text())
            if package_manifest.get("robot_reference_sha256") != robot_reference["manifest_sha256"]:
                raise RuntimeError("Pinned robot reference differs from ICL preparation")
        write_json(inputs / "protocol.json", {
            "revision": PROTOCOL_V2, "accept_bare_action_arrays": True,
            "robot_reference_sha256": robot_reference["manifest_sha256"]})
    robot_card = {"robot_type": task_cfg["robot_type"],
                  "public_state_dim": dimensions(dual_arm)[0],
                  "action_dim": dimensions(dual_arm)[1], "control_hz": 30,
                  "action_layout": ("[r_xyz3,r_rotvec3,r_hand16,l_xyz3,l_rotvec3,l_hand16]"
                                    if dual_arm else "[xyz3,rotvec3,hand16]"),
                  "state_layout": ("[r_pose7,l_pose7,r_hand16,l_hand16]"
                                   if dual_arm else "[pose7,hand16]"),
                  "quaternion_order_in_state": "wxyz"}
    if robot_reference is not None:
        robot_card["robot_reference"] = "robot_reference/README.md"
    write_json(inputs / "robot.json", robot_card)
    robot_prompt_suffix = ("\nThe pinned public robot model is at "
                           "input/robot_reference/README.md, with simulator MJCF and "
                           "Allegro hand URDF. The step helper also accepts a bare "
                           "numeric action array emitted by the frozen ICL package; "
                           "it wraps that array without changing any action row.\n"
                           if robot_reference is not None else "")
    prompt = (ROOT / "prompts/dexjoco_policy_icl.md").read_text() + robot_prompt_suffix
    proc, logs, env = None, (), None
    phase = "initial"
    current_limit = standard_limit if continuation_mode else episode_limit
    session_private = private
    session_started = None
    session_records = []
    continuation_attempted = False
    step, decision, smoke_steps, success, done = 0, 0, 0, False, False
    first_success_step, checkpoint_1x = None, None
    raw = None
    outcome, error = "infrastructure_error", None
    started = time.monotonic()
    started_at = utc_now()
    simulator_step_seconds = 0.0

    def note_step(reward: float, terminated: bool, truncated: bool, info: dict) -> None:
        nonlocal first_success_step, checkpoint_1x
        if info.get("succeed", False) and first_success_step is None:
            first_success_step = step
        if step == standard_limit:
            checkpoint_1x = {"step": step, "reached": True,
                "success_by_1x": first_success_step is not None,
                "reward": float(reward), "terminated": bool(terminated),
                "truncated": bool(truncated), "info": _jsonable(info),
                "state": np.asarray(raw["state"]).reshape(-1).tolist(),
                "recorded_at": utc_now()}
            write_json(private / "checkpoint_1x.json", checkpoint_1x)
            with (private / "trajectory.jsonl").open("a") as stream:
                stream.write(json.dumps({"event": "checkpoint_1x", **checkpoint_1x},
                                        sort_keys=True) + "\n")

    try:
        os.environ.setdefault("MUJOCO_GL", "osmesa")
        np.random.seed(seed)
        random.seed(seed)
        sys.path.insert(0, str(upstream / "dexjoco"))
        from dexjoco.tasks import CONFIG_MAPPING
        kwargs = {"policy_mode": True, "render_mode": "rgb_array",
                  "randomize": cfg["regime"] == "rand_full", "seed": seed,
                  "randomize_dynamics": False}
        if "password" in task_cfg:
            kwargs["password"] = task_cfg["password"]
        env = CONFIG_MAPPING[task]().get_environment(**kwargs)
        if horizon_multiplier > 1:
            write_json(private / "horizon_patch.json",
                       extend_episode_limit(env, standard_limit, horizon_multiplier))
        reset_started = time.monotonic()
        raw, reset_info = env.reset()
        reset_seconds = time.monotonic() - reset_started
        write_json(private / "reset.json", {"seed": seed,
                   "reset_info": _jsonable(reset_info) if isinstance(reset_info, dict) else {},
                   "state": np.asarray(raw["state"]).reshape(-1).tolist(),
                   "reset_wall_seconds": reset_seconds})
        save_observation(inputs, 0, 0, raw, task_cfg["camera_mapping"],
                         dual_arm, task_cfg["prompt"], current_limit)
        with (private / "trajectory.jsonl").open("a") as stream:
            stream.write(json.dumps({"event": "reset", "step": 0, "seed": seed,
                "recorded_at": utc_now(),
                "state": np.asarray(raw["state"]).reshape(-1).tolist(),
                "reset_wall_seconds": reset_seconds,
                "rgb_observation": "policy/input/observations/000000/observation.json"},
                sort_keys=True) + "\n")
        # The official OpenPI client uses this fixed 30-step alignment for click_mouse.
        if task == "click_mouse":
            align = np.array([-4.4294e-01, 1.3729e-06, 1.5170,
                              -3.14156462, -6.91584035e-05, -1.40317984e-03,
                              0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                              0, 0, 0.263, 0, 0, 0], dtype=np.float64)
            for _ in range(30):
                environment_action = to_environment_action(align, False)
                step_started = time.monotonic()
                raw, reward, terminated, truncated, info = env.step(environment_action)
                elapsed = time.monotonic() - step_started
                simulator_step_seconds += elapsed
                step += 1
                save_observation(inputs, step, 0, raw, task_cfg["camera_mapping"],
                                 dual_arm, task_cfg["prompt"], current_limit)
                _record_step(private, step, "startup_alignment", align,
                             environment_action, raw, reward, terminated, truncated,
                             info, elapsed)
                note_step(reward, terminated, truncated, info)
                if terminated or truncated:
                    done, success = True, bool(info.get("succeed", False))
                    break
        while not done and step < episode_limit:
            observation_file = inputs / "observations" / f"{step:06d}" / "observation.json"
            if observation_file.exists():
                public = json.loads(observation_file.read_text())
                if continuation_mode and phase == "continuation" and step == standard_limit:
                    public.update(decision=decision, remaining_steps=episode_limit - step,
                                  continuation=True)
            else:
                public = save_observation(inputs, step, decision, raw,
                          task_cfg["camera_mapping"], dual_arm, task_cfg["prompt"], current_limit)
            write_json(inputs / "observation.json", public)
            write_json(private / "decisions" / f"{decision:06d}.json", public)
            # The request for the previous decision has been consumed and its
            # entire action chunk has executed. Release its submission lock
            # after publishing the new observation: Codex may have terminated
            # the waiting step.py command before its finally block ran.
            transport = private / "action-transport"
            if decision > 0:
                _release_completed_submission_lock(transport)
            if mode == "codex" and proc is None:
                session_started = time.monotonic()
                proc, logs = _start_policy(ep, cfg, binary, auth, prompt,
                                           session_private=session_private)
            if mode == "smoke":
                actions = np.array([hold_action(public["state"], dual_arm)])
                evidence = {"policy": "development_hold"}
            else:
                actions, evidence = _wait_action(ep, cfg, proc, decision,
                                                current_limit - step, dual_arm,
                                                session_private=session_private)
            write_json(private / "actions" / f"{decision:06d}.json",
                       {"decision": decision, "start_step": step,
                        "session_phase": phase, "actions": actions.tolist(), **evidence})
            decision += 1
            for action in actions:
                environment_action = to_environment_action(action, dual_arm)
                step_started = time.monotonic()
                raw, reward, terminated, truncated, info = env.step(environment_action)
                elapsed = time.monotonic() - step_started
                simulator_step_seconds += elapsed
                step += 1
                save_observation(inputs, step, decision, raw,
                    task_cfg["camera_mapping"], dual_arm, task_cfg["prompt"], current_limit)
                _record_step(private, step, "policy_" + phase if continuation_mode else "policy",
                             action, environment_action,
                             raw, reward, terminated, truncated, info, elapsed)
                note_step(reward, terminated, truncated, info)
                if mode == "smoke":
                    smoke_steps += 1
                if terminated or truncated:
                    done, success = True, bool(info.get("succeed", False))
                    break
                if step >= episode_limit:
                    raise RuntimeError("DexJoCo did not terminate at the configured step limit")
                if continuation_mode and phase == "initial" and step >= standard_limit:
                    break
            if mode == "smoke" and smoke_steps >= 4:
                outcome = "smoke_complete"
                break
            if (continuation_mode and mode == "codex" and phase == "initial"
                    and not done and step == standard_limit):
                snapshot = private / "checkpoint_simulator_1x.npz"
                snapshot_sha = _save_live_simulator_checkpoint(env, snapshot)
                session_records.append(_finish_policy_session(
                    inputs, private, proc, logs, "initial", session_started))
                proc, logs = None, ()
                stale = private / "action-transport/request.json"
                if stale.exists():
                    (private / "stale_request_after_1x.json").write_bytes(stale.read_bytes())
                    stale.unlink()
                (private / "action-transport/submission.lock").unlink(missing_ok=True)
                (private / "action-transport/request.tmp").unlink(missing_ok=True)
                if package is None or tree_hashes(inputs / "task_knowledge") != tree_hashes(package / "payload"):
                    raise RuntimeError("Frozen task package changed before continuation")
                history_sha = _export_first_session_history(inputs, private, standard_limit)
                checkpoint_1x.update(status="budget_exhausted",
                    simulator_snapshot="private/checkpoint_simulator_1x.npz",
                    simulator_snapshot_sha256=snapshot_sha,
                    public_history="policy/input/first_session_history.jsonl",
                    public_history_sha256=history_sha)
                write_json(private / "checkpoint_1x.json", checkpoint_1x)
                write_json(inputs / "continuation.json", {
                    "phase": "continuation", "standard_step_limit": standard_limit,
                    "additional_step_budget": episode_limit - standard_limit,
                    "public_history": "first_session_history.jsonl",
                    "history_sha256": history_sha})
                (inputs / "episode_done.json").unlink()
                phase = "continuation"
                current_limit = episode_limit
                session_private = private / "continuation"
                prompt = ((ROOT / "prompts/dexjoco_policy_continuation.md").read_text()
                          + robot_prompt_suffix)
                continuation_attempted = True
                with (private / "trajectory.jsonl").open("a") as stream:
                    stream.write(json.dumps({"event": "continuation_start", "step": step,
                        "recorded_at": utc_now(), "simulator_snapshot_sha256": snapshot_sha,
                        "public_history_sha256": history_sha}, sort_keys=True) + "\n")
        if done:
            outcome = "success" if success else "failure"
        elif mode == "codex" and outcome != "smoke_complete":
            raise RuntimeError("Simulator did not reach a terminal state")
    except PolicyError as exc:
        outcome, error = "policy_failure", f"{type(exc).__name__}: {exc}"
    except BaseException as exc:
        outcome, error = "infrastructure_error", f"{type(exc).__name__}: {exc}"
    finally:
        if checkpoint_1x is None:
            checkpoint_1x = {"step": step, "reached": False,
                "success_by_1x": first_success_step is not None and first_success_step <= standard_limit,
                "status": outcome, "first_success_step": first_success_step,
                "recorded_at": utc_now()}
            write_json(private / "checkpoint_1x.json", checkpoint_1x)
            with (private / "trajectory.jsonl").open("a") as stream:
                stream.write(json.dumps({"event": "checkpoint_1x", **checkpoint_1x},
                                        sort_keys=True) + "\n")
        write_json(inputs / "episode_done.json", {"episode_done": True})
        if proc is not None:
            if continuation_mode or cfg.get("protocol_revision") == PROTOCOL_V2:
                session_records.append(_finish_policy_session(
                    inputs, session_private, proc, logs, phase, session_started))
                proc, logs = None, ()
            else:
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.terminate()
                    try: proc.wait(timeout=5)
                    except subprocess.TimeoutExpired: proc.kill(); proc.wait()
        for stream in logs:
            stream.close()
        if not continuation_mode:
            (private / "codex-home/auth.json").unlink(missing_ok=True)
        if env is not None:
            env.close()
    usage = (sum_usage([record["tokens"] for record in session_records])
             if mode == "codex" and (continuation_mode or cfg.get("protocol_revision") == PROTOCOL_V2) else
             token_usage(private, "codex", process_started=proc is not None,
                         returncode=proc.returncode if proc is not None else None))
    report = {"task": task, "seed": seed, "regime": cfg["regime"],
              "setting": SETTING, "mode": mode, "outcome": outcome,
              "protocol_revision": cfg.get("protocol_revision"),
              "robot_reference_sha256": (robot_reference["manifest_sha256"]
                                         if robot_reference is not None else None),
              "success": success if done else False, "simulator_steps": step,
              "success_by_1x": bool(checkpoint_1x["success_by_1x"]),
              "success_by_10x": success if done else False,
              "standard_step_limit": standard_limit,
              "extended_step_limit": episode_limit,
              "horizon_multiplier": horizon_multiplier,
              "continuation_protocol": continuation_mode,
              "continuation_attempted": continuation_attempted,
              "first_session_outcome": ("success" if first_success_step is not None
                  and first_success_step <= standard_limit else
                  "budget_exhausted" if step >= standard_limit else
                  "ended_before_budget"),
              "session_records": session_records,
              "first_success_step": first_success_step,
              "checkpoint_1x": "private/checkpoint_1x.json",
              "decisions": decision, "official_terminal": done and step <= standard_limit,
              "simulator_terminal": done,
              "error": error, "started_at": started_at, "ended_at": utc_now(),
              "wall_seconds": time.monotonic() - started,
              "simulator_step_wall_seconds": simulator_step_seconds,
              "trajectory": "private/trajectory.jsonl",
              "tokens": usage}
    write_json(ep / "result.json", report)
    return report


def run(args: argparse.Namespace) -> int:
    cfg = load_config(args.config)
    selected_index = getattr(args, "episode_index", None)
    if selected_index is not None and (args.mode != "codex" or
            type(selected_index) is not int or not 0 <= selected_index < cfg["episodes"]):
        raise ValueError("Episode index must select one configured scored seed")
    if not 1 <= args.episode_workers <= 4:
        raise ValueError("Episode workers must be 1–4")
    verify_upstream(args.upstream, cfg)
    task_cfg = task_config(args.upstream, cfg["regime"], args.task)
    if args.output.exists():
        raise ValueError("Use a new output directory; existing runs are immutable")
    package = None
    if args.mode == "codex":
        if args.package is None or args.package_sha256 is None:
            raise ValueError("Scored ICL testing requires a frozen package and manifest hash")
        verify_package(args.package, args.task, cfg, args.package_sha256)
        binary = Path(shutil.which("codex") or "/missing")
        actual = subprocess.check_output([str(binary), "--version"], text=True).strip()
        if actual != cfg["codex_version"]:
            raise ValueError(f"Pinned Codex CLI required: {cfg['codex_version']}; found {actual}")
        if not args.auth.is_file():
            raise ValueError("Missing Codex auth.json")
        package = args.output / "private/task_package"
    else:
        binary = None
    args.output.mkdir(parents=True)
    if package is not None:
        shutil.copytree(args.package, package)
        verify_package(package, args.task, cfg, args.package_sha256)
    source = {}
    source_files = [Path(__file__),
        *(Path(__file__).with_name(name) for name in
          ("dexjoco_adapter.py", "dexjoco_horizon.py", "dexjoco_icl.py", "dexjoco_reader.py",
           "dexjoco_reader_client.py", "dexjoco_pipeline.py", "isolation.py", "core.py",
           "step.py", "dexjoco_robot_reference.py", "knowledge.py", "telemetry.py")),
        ROOT / "prompts/dexjoco_policy_icl.md",
        ROOT / "prompts/dexjoco_policy_continuation.md",
        ROOT / "prompts/dexjoco_preparation.md", args.config,
        args.upstream / "configs" / cfg["regime"] / f"{args.task}.yaml"]
    for path in source_files:
        if path.is_relative_to(ROOT):
            rel = path.relative_to(ROOT)
        elif path.is_relative_to(args.upstream):
            rel = Path("upstream") / path.relative_to(args.upstream)
        else:
            rel = Path("external") / path.name
        dest = args.output / "private/source" / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, dest)
        source[str(rel)] = file_hash(dest)
    write_json(args.output / "private/manifest.json",
               {"setting": SETTING, "task": args.task, "config": cfg,
                "upstream_commit": git(args.upstream, "rev-parse", "HEAD"),
                "task_config": task_cfg, "source_hashes": source,
                "package_sha256": file_hash(package / "manifest.json") if package else None,
                "codex_binary_sha256": file_hash(binary.resolve()) if binary else None,
                "python": sys.version, "platform": platform.platform(),
                "started_at": utc_now(), "argv": sys.argv})
    (args.output / "private/runtime-packages.txt").write_bytes(
        subprocess.check_output([sys.executable, "-m", "pip", "freeze"]))
    indices = (list(range(cfg["episodes"])) if args.mode == "codex" and selected_index is None
               else [selected_index] if args.mode == "codex" else [0])
    count = len(indices)
    reports = []
    def episode_args(i: int) -> tuple:
        return (args.output / f"episode_{i:04d}", args.upstream, cfg, args.task,
                task_cfg, package, args.mode, binary, args.auth,
                cfg["seed_start"] + i if args.mode == "codex" else args.smoke_seed)
    if args.episode_workers == 1 or count == 1:
        for i in indices:
            reports.append(_run_episode(*episode_args(i)))
            if reports[-1]["outcome"] == "infrastructure_error":
                break
    else:
        # Separate processes keep MuJoCo render contexts and RNGs independent.
        with ProcessPoolExecutor(max_workers=args.episode_workers) as pool:
            futures = {pool.submit(_run_episode, *episode_args(i)): i for i in indices}
            for future in as_completed(futures):
                reports.append(future.result())
        reports.sort(key=lambda report: report["seed"])
    complete = (args.mode == "codex" and len(reports) == count
                and all(r["outcome"] in {"success", "failure", "policy_failure"} for r in reports))
    multiplier = cfg.get("horizon_multiplier", cfg.get("continuation_multiplier", 1))
    summary = {"setting": SETTING, "task": args.task, "mode": args.mode,
               "horizon_multiplier": multiplier,
               "continuation_protocol": cfg["schema_version"] == 3,
               "standard_step_limit": LIMITS[args.task],
               "extended_step_limit": LIMITS[args.task] * multiplier,
               "planned": count,
               "completed": len(reports), "complete_valid": complete,
               "successes": sum(r["outcome"] == "success" for r in reports),
               "successes_1x": sum(r["success_by_1x"] for r in reports),
               "successes_10x": sum(r["success_by_10x"] for r in reports),
               "continuations": sum(r["continuation_attempted"] for r in reports),
               "model_sessions": (sum(len(r["session_records"]) for r in reports)
                                  if cfg["schema_version"] == 3 else
                                  sum(r["mode"] == "codex" and r["decisions"] > 0
                                      for r in reports)),
               "success_rate_1x": (sum(r["success_by_1x"] for r in reports) / count
                                   if complete else None),
               "success_rate_10x": (sum(r["success_by_10x"] for r in reports) / count
                                    if complete else None),
               "success_rate": (sum(r["outcome"] == "success" for r in reports) / count
                                if complete else None),
               "tokens": sum_usage([r["tokens"] for r in reports]),
               "episode_wall_seconds": sum(r["wall_seconds"] for r in reports),
               "simulator_step_wall_seconds": sum(r["simulator_step_wall_seconds"] for r in reports),
               "simulator_steps": sum(r["simulator_steps"] for r in reports),
               "episodes": reports}
    write_json(args.output / "result.json", summary)
    return 0 if (complete or (args.mode == "smoke" and reports[-1]["outcome"] == "smoke_complete")) else 1


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--config", type=Path, required=True)
    p.add_argument("--upstream", type=Path, required=True)
    p.add_argument("--task", choices=TASKS, required=True)
    p.add_argument("--package", type=Path)
    p.add_argument("--package-sha256")
    p.add_argument("--mode", choices=("smoke", "codex"), default="smoke")
    p.add_argument("--smoke-seed", type=int, default=1000000)
    p.add_argument("--episode-workers", type=int, default=1)
    p.add_argument("--episode-index", type=int,
                   help="Run only one configured seed (for adaptive scheduling)")
    p.add_argument("--auth", type=Path, default=Path.home() / ".codex/auth.json")
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    for key in ("config", "upstream", "package", "auth", "output"):
        value = getattr(args, key)
        if value is not None: setattr(args, key, value.resolve())
    return run(args)


if __name__ == "__main__":
    raise SystemExit(main())
