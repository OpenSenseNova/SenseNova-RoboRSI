"""DexJoCo's public policy boundary. This module never reads simulator state."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from PIL import Image
from scipy.spatial.transform import Rotation

from .core import digest, write_json


TASKS = (
    "bimanual_assembly", "bimanual_hanoi", "bimanual_microwave_cook",
    "bimanual_photograph", "bimanual_unlock_ipad", "click_mouse",
    "fold_glasses", "hammer_nail", "pick_bucket", "pinch_tongs",
    "water_plant",
)


def dimensions(dual_arm: bool) -> tuple[int, int]:
    """Return allowed proprioception and policy rotvec action widths."""
    return (46, 44) if dual_arm else (23, 22)


def public_observation(raw: dict, camera_mapping: dict[str, str], dual_arm: bool,
                       prompt: str) -> tuple[dict, dict[str, np.ndarray]]:
    """Build from an allowlist; never copy DexJoCo's privileged state suffix."""
    state_dim, _ = dimensions(dual_arm)
    state = np.asarray(raw["state"])
    if state.ndim != 1 or state.shape[0] < state_dim:
        raise ValueError("DexJoCo state is shorter than the public proprioception contract")
    proprio = state[:state_dim].astype(np.float64)
    if not np.isfinite(proprio).all():
        raise ValueError("Nonfinite proprioception")
    if not isinstance(prompt, str) or not prompt.strip():
        raise ValueError("Missing task prompt")
    images = {}
    for camera in dict.fromkeys(camera_mapping.values()):
        rgb = np.asarray(raw[camera])
        if rgb.dtype != np.uint8 or rgb.ndim != 3 or rgb.shape[2] != 3:
            raise ValueError(f"Invalid RGB image for {camera}")
        images[camera] = np.ascontiguousarray(rgb).copy()
    return {"prompt": prompt, "state": proprio.tolist()}, images


def save_observation(root: Path, index: int, decision: int, raw: dict,
                     camera_mapping: dict[str, str], dual_arm: bool,
                     prompt: str, max_steps: int) -> dict:
    public, images = public_observation(raw, camera_mapping, dual_arm, prompt)
    folder = root / "observations" / f"{index:06d}"
    folder.mkdir(parents=True)
    public.update(step=index, decision=decision, remaining_steps=max_steps-index,
                  cameras=[], action_format="rotvec_22_or_44")
    for name, rgb in images.items():
        path = folder / f"{name}.png"
        Image.fromarray(rgb).save(path, format="PNG", compress_level=6)
        public["cameras"].append({"name": name,
                                  "path": str(path.relative_to(root)),
                                  "sha256": digest(path.read_bytes()),
                                  "rgb_sha256": digest(rgb.tobytes())})
    write_json(folder / "observation.json", public)
    return public


def validate_actions(payload: object, dual_arm: bool, remaining: int,
                     max_chunk: int = 30) -> np.ndarray:
    if not isinstance(payload, dict) or set(payload) != {"actions"}:
        raise ValueError("Action payload must have only the actions field")
    _, width = dimensions(dual_arm)
    values = np.asarray(payload["actions"])
    if values.dtype.kind not in "iuf" or values.ndim != 2 or values.shape[1] != width:
        raise ValueError(f"Expected numeric [T,{width}] rotvec actions")
    if not 1 <= len(values) <= min(remaining, max_chunk):
        raise ValueError("Action chunk exceeds its declared limit")
    actions = values.astype(np.float64)
    if not np.isfinite(actions).all():
        raise ValueError("Actions must be finite")
    return actions


def to_environment_action(action: np.ndarray, dual_arm: bool) -> np.ndarray:
    """Match upstream DexJoCoOpenPIEnv's scalar-first quaternion layout."""
    row = np.asarray(action, dtype=np.float64)
    _, width = dimensions(dual_arm)
    if row.shape != (width,) or not np.isfinite(row).all():
        raise ValueError("Invalid policy action row")
    if dual_arm:
        return np.concatenate((row[:3], Rotation.from_rotvec(row[3:6]).as_quat(scalar_first=True),
                               row[22:25], Rotation.from_rotvec(row[25:28]).as_quat(scalar_first=True),
                               row[6:22], row[28:44]))
    return np.concatenate((row[:3], Rotation.from_rotvec(row[3:6]).as_quat(scalar_first=True),
                           row[6:22]))


def hold_action(state: object, dual_arm: bool) -> np.ndarray:
    """No-model smoke action in the public policy format."""
    q = np.asarray(state, dtype=np.float64)
    n, _ = dimensions(dual_arm)
    if q.shape != (n,) or not np.isfinite(q).all():
        raise ValueError("Invalid public state")
    if dual_arm:
        return np.concatenate((q[:3], Rotation.from_quat(q[3:7], scalar_first=True).as_rotvec(),
                               q[14:30], q[7:10],
                               Rotation.from_quat(q[10:14], scalar_first=True).as_rotvec(), q[30:46]))
    return np.concatenate((q[:3], Rotation.from_quat(q[3:7], scalar_first=True).as_rotvec(), q[7:23]))
