"""Minimal client mounted inside the isolated preparation workspace."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import time
import uuid


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="op", required=True)
    sub.add_parser("list")
    arrays = sub.add_parser("arrays")
    arrays.add_argument("demo")
    video = sub.add_parser("video")
    video.add_argument("demo")
    video.add_argument("camera")
    args = p.parse_args()
    request_id = uuid.uuid4().hex
    transport = Path("/workspace/.action_transport")
    request = {k: v for k, v in vars(args).items() if v is not None}
    pending = transport / f"pending-{request_id}.json"
    pending.write_text(json.dumps(request, sort_keys=True))
    pending.rename(transport / f"request-{request_id}.json")
    response = transport / f"response-{request_id}.json"
    deadline = time.monotonic() + 120
    while not response.is_file():
        if time.monotonic() > deadline:
            raise TimeoutError("Demo reader did not respond")
        time.sleep(0.05)
    result = json.loads(response.read_text())
    response.unlink()
    print(json.dumps(result, sort_keys=True, indent=2))
    if not result["ok"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
