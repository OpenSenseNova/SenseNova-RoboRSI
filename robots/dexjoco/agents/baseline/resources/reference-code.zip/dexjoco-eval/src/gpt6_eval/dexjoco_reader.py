"""Host-side, allowlisted reader for released DexJoCo demonstrations."""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import stat
import time

import numpy as np

from .core import write_json
from .dexjoco_adapter import dimensions
from .knowledge import file_hash

ROOTS = {"rand_obj": "dexjoco_raw_datasets",
         "rand_full": "dexjoco_raw_datasets_rand_full"}


def verified_inventory(dataset: Path, task: str, regime: str, revision: str,
                       task_card: dict) -> tuple[Path, list[dict]]:
    """Verify the downloaded corpus in place; do not materialize a training export."""
    import zarr

    manifest = dataset / "gpt6_eval_manifests" / f"{regime}_{task}.json"
    inventory = json.loads(manifest.read_text())
    if (inventory.get("repo") != "DexJoCo/DexJoCo-Datasets-Raw"
            or inventory.get("revision") != revision or inventory.get("task") != task
            or inventory.get("regime") != regime):
        raise ValueError("Demonstration inventory does not match pinned task")
    prefix = f"{ROOTS[regime]}/{task}/"
    files = inventory["files"]
    if not files or any(not row["path"].startswith(prefix) for row in files):
        raise ValueError("Demonstration inventory has unexpected paths")
    for row in files:
        rel = Path(row["path"])
        if rel.is_absolute() or ".." in rel.parts:
            raise ValueError("Unsafe dataset path")
        path = dataset / rel
        if (not path.is_file() or path.is_symlink()
                or not path.resolve().is_relative_to(dataset.resolve())
                or path.stat().st_size != row["bytes"] or file_hash(path) != row["sha256"]):
            raise ValueError(f"Missing or modified demonstration file: {rel}")
    names = sorted({Path(row["path"]).parts[2] for row in files
                    if row["path"].endswith("/replay.zarr/.zgroup")})
    if not names:
        raise ValueError("No replay.zarr demonstrations in inventory")
    cameras = tuple(dict.fromkeys(task_card["camera_mapping"].values()))
    state_dim, action_dim = dimensions(task_card["robot_type"] == "dual_arm")
    demos = []
    for index, name in enumerate(names):
        source = dataset / ROOTS[regime] / task / name
        group = zarr.open(str(source / "replay.zarr"), mode="r")["data"]
        state, action, stamp = (group["state"], group["action_rotvec"],
                                group["timestamp"])
        n = state.shape[0]
        if (n < 1 or len(state.shape) not in (2, 3)
                or int(np.prod(state.shape[1:])) < state_dim
                or action.shape != (n, action_dim) or stamp.shape != (n,)):
            raise ValueError(f"Invalid demonstration array shape: {name}")
        for camera in cameras:
            if not (source / "videos" / f"{camera}.mp4").is_file():
                raise ValueError(f"Missing selected RGB camera {camera}: {name}")
        demos.append({"id": f"{index:04d}", "steps": n,
                      "cameras": list(cameras), "source": source})
    return manifest, demos


class DemoReader:
    def __init__(self, demos: list[dict], task_card: dict, workspace: Path,
                 transport: Path, audit: Path):
        self.demos = {d["id"]: d for d in demos}
        self.state_dim, self.action_dim = dimensions(task_card["robot_type"] == "dual_arm")
        self.output = workspace / "demo_reads"
        self.output.mkdir()
        self.transport = transport
        self.audit = audit

    def _demo(self, request: dict) -> dict:
        demo = self.demos.get(request.get("demo"))
        if demo is None:
            raise ValueError("Unknown demonstration ID")
        return demo

    def handle(self, request: dict, request_id: str) -> dict:
        if not isinstance(request, dict):
            raise ValueError("Reader request must be an object")
        op = request.get("op")
        if op == "list" and set(request) == {"op"}:
            return {"demos": [{k: d[k] for k in ("id", "steps", "cameras")}
                              for d in self.demos.values()]}
        if op == "arrays" and set(request) == {"op", "demo"}:
            import zarr
            demo = self._demo(request)
            group = zarr.open(str(demo["source"] / "replay.zarr"), mode="r")["data"]
            stored_state = group["state"]
            if len(stored_state.shape) == 2:
                state = np.asarray(stored_state[:, :self.state_dim], dtype=np.float32)
            elif stored_state.shape[1] == 1:
                state = np.asarray(stored_state[:, 0, :self.state_dim], dtype=np.float32)
            else:
                state = np.asarray(stored_state[:], dtype=np.float32)
                state = state.reshape(demo["steps"], -1)[:, :self.state_dim].copy()
            action = np.asarray(group["action_rotvec"][:], dtype=np.float32)
            stamp = np.asarray(group["timestamp"][:], dtype=np.float64)
            if (state.shape != (demo["steps"], self.state_dim)
                    or action.shape != (demo["steps"], self.action_dim)
                    or stamp.shape != (demo["steps"],)
                    or not np.isfinite(state).all() or not np.isfinite(action).all()
                    or not np.isfinite(stamp).all() or np.any(np.diff(stamp) <= 0)):
                raise ValueError("Invalid public training arrays")
            target = self.output / f"{request_id}.npz"
            np.savez_compressed(target, state=state, actions=action, timestamps=stamp)
            return {"path": str(target.relative_to(self.output.parent)),
                    "sha256": file_hash(target), "steps": demo["steps"]}
        if op == "video" and set(request) == {"op", "demo", "camera"}:
            demo = self._demo(request)
            camera = request.get("camera")
            if camera not in demo["cameras"]:
                raise ValueError("Camera is not selected for this task")
            source = demo["source"] / "videos" / f"{camera}.mp4"
            target = self.output / f"{request_id}.mp4"
            shutil.copyfile(source, target)
            return {"path": str(target.relative_to(self.output.parent)),
                    "sha256": file_hash(target), "camera": camera,
                    "demo": demo["id"]}
        raise ValueError("Allowed requests: list; arrays DEMO; video DEMO CAMERA")

    def poll(self) -> int:
        count = 0
        for request_path in sorted(self.transport.glob("request-*.json")):
            request_id = request_path.stem.removeprefix("request-")
            if len(request_id) != 32 or any(c not in "0123456789abcdef" for c in request_id):
                continue
            fd = os.open(request_path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
            with os.fdopen(fd, "rb") as stream:
                if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
                    raise ValueError("Reader request is not a regular file")
                raw = stream.read(65537)
            request_path.unlink()
            try:
                if len(raw) > 65536:
                    raise ValueError("Reader request exceeds size limit")
                request = json.loads(raw)
                answer = {"ok": True, "result": self.handle(request, request_id)}
            except Exception as exc:
                answer = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
            with self.audit.open("a") as stream:
                stream.write(json.dumps({"request_id": request_id, "request": raw.decode(errors="replace"),
                                         "response": answer}, sort_keys=True) + "\n")
            response = self.transport / f"response-{request_id}.json"
            write_json(response, answer)
            count += 1
        return count

    def serve_until_exit(self, proc, timeout_s: float | None = None) -> None:
        start = time.monotonic()
        while True:
            self.poll()
            if proc.poll() is not None:
                self.poll()
                return
            if timeout_s is not None and time.monotonic() - start > timeout_s:
                raise TimeoutError("Preparation exceeded configured time")
            time.sleep(0.05)
