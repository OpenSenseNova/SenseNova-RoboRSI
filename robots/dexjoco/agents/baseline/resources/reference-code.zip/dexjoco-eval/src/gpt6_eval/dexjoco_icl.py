"""Isolated Astra/max ICL preparation with an on-demand trusted demo reader."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

from . import isolation
from .core import MODEL, digest, verify_model_rollouts, write_json
from .dexjoco_adapter import TASKS
from .dexjoco_eval import (PROTOCOL_V2, ROOT, SETTING, load_config,
                           task_config, verify_upstream)
from .dexjoco_reader import DemoReader, verified_inventory
from .dexjoco_robot_reference import copy_robot_reference
from .knowledge import file_hash, tree_hashes
from .telemetry import token_usage, utc_now


def prepare(args: argparse.Namespace) -> None:
    cfg = load_config(args.config)
    verify_upstream(args.upstream, cfg)
    card = task_config(args.upstream, cfg["regime"], args.task)
    manifest, demos = verified_inventory(args.dataset, args.task, cfg["regime"],
                                         cfg["dataset_revision"], card)
    binary = Path(shutil.which("codex") or "/missing")
    actual = subprocess.check_output([str(binary), "--version"], text=True).strip()
    if actual != cfg["codex_version"]:
        raise ValueError(f"Pinned Codex CLI required: {cfg['codex_version']}; found {actual}")
    if not args.auth.is_file():
        raise ValueError("Missing Codex auth.json")
    if args.output.exists():
        raise ValueError("Use a new immutable preparation directory")
    workspace, private = args.output / "workspace", args.output / "private"
    (workspace / "input").mkdir(parents=True)
    (workspace / "package").mkdir()
    interface, home = private / "interface", private / "codex-home"
    interface.mkdir(parents=True)
    transport = private / "action-transport"
    transport.mkdir()
    card = {"task": args.task, "regime": cfg["regime"],
            "prompt": card["prompt"], "robot_type": card["robot_type"],
            "camera_mapping": card["camera_mapping"],
            "state_layout": ("[r_pose7,l_pose7,r_hand16,l_hand16]" if card["robot_type"] == "dual_arm"
                             else "[pose7,hand16]"),
            "action_layout": ("[r_xyz3,r_rotvec3,r_hand16,l_xyz3,l_rotvec3,l_hand16]"
                              if card["robot_type"] == "dual_arm" else "[xyz3,rotvec3,hand16]"),
            "control_hz": 30, "demonstrations": len(demos)}
    robot_reference = None
    if cfg.get("protocol_revision") == PROTOCOL_V2:
        robot_reference = copy_robot_reference(
            args.upstream, workspace / "input/robot_reference",
            card["robot_type"], cfg["upstream_commit"])
        card["robot_reference"] = "robot_reference/README.md"
    write_json(workspace / "input/task.json", card)
    shutil.copyfile(Path(__file__).with_name("dexjoco_reader_client.py"),
                    interface / "demo_reader.py")
    prompt = (ROOT / "prompts/dexjoco_preparation.md").read_text()
    if robot_reference is not None:
        prompt += ("\nRead input/robot_reference/README.md and the pinned robot "
                   "MJCF/URDF files as needed. They describe the robot only; "
                   "do not treat them as task scene or test feedback.\n")
    cmd = isolation.command(workspace, home, interface, binary, cfg, preparation=True,
                            policy_python=Path(sys.prefix))
    record = {"setting": SETTING, "state": "preparing", "task": args.task,
              "regime": cfg["regime"], "model": MODEL,
              "upstream_commit": cfg["upstream_commit"],
              "dataset_revision": cfg["dataset_revision"],
              "training_manifest_sha256": file_hash(manifest),
              "demonstrations": len(demos), "prompt_sha256": digest(prompt.encode()),
              "started_at": utc_now(), "argv": cmd, "web_search": "live",
              "tool_network": False, "reader": "allowlisted_on_demand_v1"}
    record["protocol_revision"] = cfg.get("protocol_revision")
    record["robot_reference_sha256"] = (robot_reference["manifest_sha256"]
                                         if robot_reference is not None else None)
    write_json(args.output / "preparation.json", record)
    (private / "prompt.md").write_text(prompt)
    for source in (Path(__file__), Path(__file__).with_name("dexjoco_reader.py"),
                   Path(__file__).with_name("dexjoco_reader_client.py"),
                   Path(__file__).with_name("dexjoco_eval.py"),
                   Path(__file__).with_name("dexjoco_horizon.py"),
                   Path(__file__).with_name("dexjoco_adapter.py"),
                   Path(__file__).with_name("dexjoco_robot_reference.py"),
                   Path(__file__).with_name("isolation.py"),
                   ROOT / "prompts/dexjoco_preparation.md", args.config):
        target = private / "source" / source.name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    proc = None
    start = time.monotonic()
    try:
        isolation.prepare_auth(home, args.auth)
        isolation.probe(workspace, home, interface, binary, private)
        reader = DemoReader(demos, card, workspace, transport,
                            private / "reader_audit.jsonl")
        with (private / "codex.events.jsonl").open("wb") as stdout, \
             (private / "codex.stderr.log").open("wb") as stderr:
            proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=stdout,
                                    stderr=stderr, start_new_session=True)
            proc.stdin.write(prompt.encode())
            proc.stdin.close()
            reader.serve_until_exit(proc)
        if proc.returncode != 0:
            raise RuntimeError(f"Preparation Codex exited {proc.returncode}")
        evidence = verify_model_rollouts(home)
        ready_path = workspace / "ready.json"
        if ready_path.is_symlink() or not ready_path.is_file():
            raise ValueError("Preparation did not declare readiness")
        ready = json.loads(ready_path.read_text())
        if (set(ready) != {"ready", "summary"} or ready["ready"] is not True
                or not str(ready["summary"]).strip()):
            raise ValueError("Invalid readiness declaration")
        checked_manifest, checked_demos = verified_inventory(
            args.dataset, args.task, cfg["regime"], cfg["dataset_revision"],
            task_config(args.upstream, cfg["regime"], args.task))
        if (file_hash(checked_manifest) != record["training_manifest_sha256"]
                or len(checked_demos) != len(demos)):
            raise ValueError("Training inventory changed during preparation")
        frozen = args.output / "frozen"
        shutil.copytree(workspace / "package", frozen / "payload")
        files = tree_hashes(frozen / "payload")
        if not all(k in files for k in ("TASK.md", "SOURCES.md")):
            raise ValueError("Missing TASK.md or SOURCES.md in frozen package")
        usage = token_usage(private, "codex", process_started=True,
                            returncode=proc.returncode)
        manifest_doc = {"setting": SETTING, "task": args.task, "regime": cfg["regime"],
                        "protocol_revision": cfg.get("protocol_revision"),
                        "robot_reference_sha256": record["robot_reference_sha256"],
                        "upstream_commit": cfg["upstream_commit"],
                        "dataset_revision": cfg["dataset_revision"],
                        "model": MODEL, "ready": True, "files": files,
                        "training_manifest_sha256": record["training_manifest_sha256"],
                        "model_evidence": evidence,
                        "preparation_tokens": usage}
        write_json(frozen / "manifest.json", manifest_doc)
        record.update(state="ready", package_path=str(frozen),
                      package_sha256=file_hash(frozen / "manifest.json"),
                      model_evidence=evidence, readiness=ready,
                      preparation_tokens=usage,
                      reader_requests=sum(1 for _ in (private / "reader_audit.jsonl").open())
                      if (private / "reader_audit.jsonl").exists() else 0)
    except BaseException as exc:
        record.update(state="failed", error=f"{type(exc).__name__}: {exc}")
        raise
    finally:
        if proc is not None and proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
        (home / "auth.json").unlink(missing_ok=True)
        record.update(ended_at=utc_now(), wall_seconds=time.monotonic() - start)
        write_json(args.output / "preparation.json", record)


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--config", type=Path, required=True)
    p.add_argument("--upstream", type=Path, required=True)
    p.add_argument("--task", choices=TASKS, required=True)
    p.add_argument("--dataset", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--auth", type=Path, default=Path.home() / ".codex/auth.json")
    args = p.parse_args()
    for key, value in vars(args).items():
        if isinstance(value, Path):
            setattr(args, key, value.resolve())
    prepare(args)


if __name__ == "__main__":
    main()
