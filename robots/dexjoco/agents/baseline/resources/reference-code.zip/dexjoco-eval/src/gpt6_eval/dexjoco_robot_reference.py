"""Copy the pinned, public robot description into an isolated ICL workspace.

Only robot models and their assets are exposed. Task scenes, simulator state,
success code, and test seeds remain outside the policy sandbox.
"""
from __future__ import annotations

from pathlib import Path
import shutil

from .core import write_json
from .knowledge import file_hash

VERSION = "pinned_robot_models_v1"
XML_ROOT = Path("dexjoco/dexjoco/sim/envs/xmls")
TELEOP_ROOT = Path("teleoperation/GeoRT/assets")
MODEL_FILES = {
    "dual_arm": ("panda_allegro_bimanual.xml", "panda_allegro_right.xml",
                 "panda_allegro_left.xml"),
    "single_arm": ("panda_allegro_copy.xml",),
}
MESH_DIRS = ("franka_emika_panda/assets", "wonik_allegro/assets",
             "rethink_mount")
HAND_URDFS = {
    "dual_arm": ("allegro_right/allegro_hand_right.urdf",
                 "allegro_left/allegro_hand_left.urdf"),
    "single_arm": ("allegro_right/allegro_hand_right.urdf",),
}


def copy_robot_reference(upstream: Path, target: Path, robot_type: str,
                         upstream_commit: str) -> dict:
    """Expose exact simulator MJCF plus hand URDF, with source hashes."""
    if robot_type not in MODEL_FILES or target.exists():
        raise ValueError("Robot reference needs a new directory and known robot type")
    xml_root = upstream / XML_ROOT
    teleop_root = upstream / TELEOP_ROOT
    files: list[tuple[Path, Path]] = []
    for name in MODEL_FILES[robot_type]:
        files.append((xml_root / name, Path("mjcf") / name))
    for dirname in MESH_DIRS:
        for source in sorted((xml_root / dirname).rglob("*")):
            if source.is_file():
                files.append((source, Path("mjcf") / source.relative_to(xml_root)))
    for name in HAND_URDFS[robot_type]:
        files.append((teleop_root / name, Path("urdf") / name))
        for source in sorted((teleop_root / Path(name).parent).rglob("*")):
            if source.is_file() and source.name != Path(name).name:
                files.append((source, Path("urdf") / source.relative_to(teleop_root)))
    target.mkdir(parents=True)
    rows = []
    seen = set()
    for source, relative in files:
        if relative in seen or source.is_symlink() or not source.is_file():
            raise ValueError(f"Invalid robot reference source: {source}")
        seen.add(relative)
        destination = target / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
        checksum = file_hash(source)
        if file_hash(destination) != checksum:
            raise RuntimeError(f"Robot reference changed during copy: {source}")
        rows.append({"path": relative.as_posix(),
                     "source": source.relative_to(upstream).as_posix(),
                     "bytes": destination.stat().st_size, "sha256": checksum})
    readme = (
        "# Pinned robot reference\n\n"
        "This folder contains the robot model used by the DexJoCo simulator at "
        f"upstream commit `{upstream_commit}`. The `mjcf/` files are the "
        "authoritative MuJoCo robot definition, including its referenced robot "
        "meshes. The `urdf/` files describe the Allegro hand and are supplementary; "
        "the upstream repository does not provide an exact combined arm-and-hand "
        "URDF for this simulator. Read `input/robot.json` for the policy action and "
        "public state layouts. This reference has no task scene, object state, "
        "reward, success logic, or test seed.\n"
    )
    (target / "README.md").write_text(readme)
    manifest = {"version": VERSION, "upstream_commit": upstream_commit,
                "robot_type": robot_type, "files": rows,
                "total_bytes": sum(row["bytes"] for row in rows)}
    write_json(target / "manifest.json", manifest)
    return {"manifest_sha256": file_hash(target / "manifest.json"),
            "files": len(rows), "total_bytes": manifest["total_bytes"]}
