"""A minimal mount namespace around Codex, in addition to its tool sandbox."""
from pathlib import Path
import os
import shutil
import subprocess
import sysconfig

from .core import MODEL

DISABLED = (
    "multi_agent", "multi_agent_v2", "apps", "plugins", "remote_plugin", "hooks",
    "memories", "external_agent_memory_import", "browser_use", "browser_use_external",
    "computer_use", "in_app_browser", "image_generation", "guardian_approval",
    "guardian_ext", "guardianv2", "workspace_dependencies", "skill_search",
    "skill_mcp_dependency_install", "shell_snapshot", "goals",
)


def native_binary(binary: Path) -> Path:
    """Find the native Codex executable behind the official npm bin wrapper."""
    resolved = binary.resolve()
    if resolved.with_name("codex-code-mode-host").is_file():
        return resolved
    if resolved.name == "codex.js":
        scope = resolved.parents[2]
        matches = sorted(scope.glob("codex-linux-*/vendor/*/bin/codex"))
        for candidate in matches:
            if candidate.with_name("codex-code-mode-host").is_file():
                return candidate
    raise RuntimeError("Pinned Codex installation requires native codex and codex-code-mode-host")


def mounts(workspace: Path, codex_home: Path, interface: Path, binary: Path,
           numerical_runtime: bool = False, input_source: Path | None = None,
           policy_python: Path | None = None) -> list[str]:
    if not shutil.which("bwrap"):
        raise RuntimeError("bubblewrap is required; refusing host-visible policy execution")
    native = native_binary(binary)
    command = ["bwrap", "--die-with-parent", "--new-session", "--unshare-user",
               "--unshare-pid", "--unshare-ipc", "--unshare-uts", "--clearenv",
               "--ro-bind", "/usr", "/usr", "--symlink", "usr/bin", "/bin",
               "--symlink", "usr/lib", "/lib", "--symlink", "usr/lib64", "/lib64",
               "--proc", "/proc", "--dev", "/dev", "--tmpfs", "/tmp",
               "--dir", "/home/policy", "--dir", "/etc",
               "--bind", str(workspace), "/workspace",
               "--ro-bind", str(input_source or workspace / "input"), "/workspace/input",
               "--bind", str(codex_home), "/codex-home",
               "--ro-bind", str(interface), "/interface",
               "--ro-bind", str(native), "/opt/codex",
               "--setenv", "HOME", "/home/policy",
               "--setenv", "CODEX_HOME", "/codex-home",
               "--setenv", "PATH", "/usr/bin:/bin", "--setenv", "LANG", "C.UTF-8",
               "--setenv", "PYTHONHASHSEED", "0", "--setenv", "TZ", "UTC",
               "--chdir", "/workspace"]
    transport = interface.parent / "action-transport"
    if transport.is_dir():
        # A mount cannot be replaced by renaming model scratch directories.
        # Expose only transport, never its private parent or evaluator data.
        command.extend(["--bind", str(transport), "/workspace/.action_transport"])
    if numerical_runtime:
        # Debian/Ubuntu BLAS alternatives point through /etc/alternatives,
        # outside this mount. Select only existing system library directories;
        # do not inherit a user's LD_LIBRARY_PATH or expose their home.
        triplet = sysconfig.get_config_var("MULTIARCH")
        paths = [Path("/usr/lib") / str(triplet) / name for name in ("blas", "lapack")]
        paths = [str(p) for p in paths if p.is_dir()]
        if paths:
            command.extend(["--setenv", "LD_LIBRARY_PATH", ":".join(paths)])
    if policy_python is not None:
        if not (policy_python / "bin/python3").is_file():
            raise ValueError("Policy Python runtime must be a complete virtual environment")
        command.extend(["--ro-bind", str(policy_python), "/opt/policy-python",
                        "--setenv", "PATH", "/opt/policy-python/bin:/usr/bin:/bin"])
    for path in ("/etc/ssl/certs", "/etc/resolv.conf", "/etc/hosts", "/etc/nsswitch.conf",
                 "/etc/ld.so.cache"):
        if Path(path).exists():
            command.extend(["--ro-bind", path, path])
    code_host = native.with_name("codex-code-mode-host")
    command.extend(["--ro-bind", str(code_host), "/opt/codex-code-mode-host"])
    return command


def command(workspace, codex_home, interface, binary, config, *, preparation=False,
            input_source=None, policy_python=None):
    result = mounts(workspace, codex_home, interface, binary,
                    numerical_runtime=config.get("deployment_profile") == "calibrated_deployment_v2",
                    input_source=input_source, policy_python=policy_python)
    result += ["--", "/opt/codex", "exec", "--model", MODEL,
               "--ignore-user-config", "--ignore-rules", "--skip-git-repo-check",
               "--sandbox", "workspace-write", "--json", "--color", "never",
               "-c", 'approval_policy="never"', "-c", 'web_search="live"' if preparation else 'web_search="disabled"',
               "-c", "sandbox_workspace_write.network_access=false",
               "-c", 'model_reasoning_effort="' + config["reasoning_effort"] + '"',
               "-c", "allow_login_shell=false", "-c", 'project_doc_max_bytes=0']
    for feature in DISABLED:
        result.extend(["--disable", feature])
    result.append("-")
    return result


def prepare_auth(codex_home: Path, auth: Path):
    # Explicit single auth file only. Never copy user's config, sessions or plugins.
    codex_home.mkdir(parents=True, exist_ok=True)
    target = codex_home / "auth.json"
    shutil.copyfile(auth, target)
    target.chmod(0o600)


def probe(workspace, codex_home, interface, binary, private_path: Path):
    code = ("import os,socket; "
            "assert not os.path.exists(" + repr(str(private_path)) + "); "
            "assert not os.path.exists('/data'); "
            "assert os.path.exists('/workspace'); print('mount isolation passed')")
    return subprocess.run(mounts(workspace, codex_home, interface, binary) +
                          ["--", "/usr/bin/python3", "-c", code],
                          capture_output=True, text=True, check=True).stdout.strip()
