"""Global episode queue for DexJoCo ICL preparation and two-session scoring."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

import psutil

from .core import write_json
from .dexjoco_adapter import TASKS
from .dexjoco_eval import (LIMITS, SETTING, load_config, task_config, verify_package,
                           verify_upstream, _interrupted_step_helper)
from .dexjoco_reader import verified_inventory
from .knowledge import file_hash
from .telemetry import sum_usage, utc_now

ROOT = Path(__file__).resolve().parents[2]

TRANSPORT_REPAIR_SOURCE_HASHES = {
    "src/gpt6_eval/dexjoco_eval.py": (
        "78e2af5290c92b73c4e7b068c52c2079e02484f00b43cf498e59a0db65813673",
        "248c07ded835478590c870c7db3d1c07cbe2f60c172ac4245386b66e5b82b3f0"),
    "src/gpt6_eval/step.py": (
        "923497c829a5c22623b83705805cb5abd71654af11811d13c871442c367c4add",
        "3c28f9b4b0a6d29bfa7891f554caedaf12e7c82d498dd3ff9d3e1c28a7f89d78"),
}


def _specs(values: list[str], allowed: set[str]) -> dict[str, Path]:
    result = {}
    for value in values:
        task, separator, source = value.partition("=")
        if not separator or task not in allowed or task in result:
            raise ValueError("Expected a unique TASK=DIR for a selected task")
        result[task] = Path(source).resolve()
    return result


def _one_x_import_specs(values: list[str], allowed: set[str], episodes: int) -> dict[tuple[str, int], Path]:
    result = {}
    for value in values:
        identity, separator, source = value.partition("=")
        task, colon, raw_index = identity.partition(":")
        if (not separator or not colon or task not in allowed or
                not raw_index.isdecimal() or not 0 <= int(raw_index) < episodes):
            raise ValueError("Expected TASK:INDEX=EPISODE_DIR for a configured seed")
        key = (task, int(raw_index))
        if key in result:
            raise ValueError("Duplicate imported one_x episode")
        result[key] = Path(source).resolve()
    return result


def _completed_episode_specs(values: list[str], allowed: set[str], episodes: int) -> dict[tuple[str, int], Path]:
    """Select complete two-session episodes from an interrupted scheduler attempt."""
    return _one_x_import_specs(values, allowed, episodes)


def _import_completed_episode(ep: Path, task: str, index: int, cfg: dict,
                              package_sha256: str, source_hashes: dict[str, str],
                              codex_binary_sha256: str,
                              allow_transport_repair: bool = False) -> dict:
    manifest = json.loads((ep.parent / "private/manifest.json").read_text())
    old_hashes = manifest.get("source_hashes", {})
    required = {f"src/gpt6_eval/{name}.py" for name in (
        "core", "dexjoco_adapter", "dexjoco_eval", "dexjoco_horizon",
        "dexjoco_icl", "dexjoco_reader", "dexjoco_reader_client",
        "dexjoco_robot_reference", "isolation", "knowledge", "step", "telemetry")}
    required.update({f"prompts/{name}.md" for name in (
        "dexjoco_policy_icl", "dexjoco_policy_continuation", "dexjoco_preparation")})
    if not required <= old_hashes.keys() or not required <= source_hashes.keys():
        raise ValueError(f"Imported episode source inventory is incomplete: {ep}")
    mismatches = {key for key in required if old_hashes[key] != source_hashes[key]}
    compatible_repair = (allow_transport_repair
        and mismatches == set(TRANSPORT_REPAIR_SOURCE_HASHES)
        and all((old_hashes[key], source_hashes[key]) == hashes
                for key, hashes in TRANSPORT_REPAIR_SOURCE_HASHES.items()))
    if (manifest.get("task") != task or manifest.get("config") != cfg
            or manifest.get("package_sha256") != package_sha256
            or manifest.get("codex_binary_sha256") != codex_binary_sha256
            or (mismatches and not compatible_repair)):
        raise ValueError(f"Imported completed episode contract mismatch: {ep}")
    task_result = json.loads((ep.parent / "result.json").read_text())
    episode = json.loads((ep / "result.json").read_text())
    if (episode.get("outcome") == "policy_failure"
            and ((ep / "private/action-transport/submission.lock").exists()
                 or _interrupted_step_helper(ep / "private")
                 or _interrupted_step_helper(ep / "private/continuation"))):
        raise ValueError(f"Scored episode contains a terminated step helper: {ep}")
    sessions = episode.get("session_records") or []
    tokens = episode.get("tokens") or {}
    # A simulator terminal outcome is fully scored even if Codex keeps running
    # after episode_done and the host ends it after the shutdown grace period.
    # This includes the extended horizon cutoff, whose official_terminal flag
    # is false because that flag only describes the standard 1x horizon.
    # Preserve the token lower bound as partial; never present it as exact.
    scored_terminal = (episode.get("official_terminal") is True or
        (episode.get("outcome") == "failure" and
         episode.get("continuation_attempted") is True and
         episode.get("first_session_outcome") == "budget_exhausted" and
         type(episode.get("simulator_steps")) is int and
         type(episode.get("extended_step_limit")) is int and
         episode.get("simulator_steps") == episode.get("extended_step_limit")))
    partial_after_terminal = (tokens.get("status") == "partial"
        and tokens.get("incomplete_episodes") == 1
        and episode.get("outcome") in {"success", "failure"}
        and scored_terminal
        and episode.get("simulator_terminal") is True
        and episode.get("error") is None
        and bool(sessions)
        and all(s.get("tokens", {}).get("status") == "complete" for s in sessions[:-1])
        and sessions[-1].get("returncode") == -signal.SIGTERM
        and sessions[-1].get("tokens", {}).get("status") == "partial"
        and isinstance(tokens.get("known_reported_tokens", {}).get("total_tokens"), int)
        and tokens["known_reported_tokens"]["total_tokens"] > 0
        and not (ep / "private/action-transport/submission.lock").exists()
        and not _interrupted_step_helper(ep / "private")
        and not _interrupted_step_helper(ep / "private/continuation"))
    if (task_result.get("complete_valid") is not True or task_result.get("planned") != 1
            or task_result.get("episodes") != [episode]
            or episode.get("task") != task or episode.get("seed") != cfg["seed_start"] + index
            or episode.get("outcome") not in {"success", "failure", "policy_failure"}
            or episode.get("continuation_protocol") is not True
            or episode.get("horizon_multiplier") != cfg["continuation_multiplier"]
            or (tokens.get("status") != "complete" and not partial_after_terminal)
            or not sessions):
        raise ValueError(f"Incomplete or invalid scored episode import: {ep}")
    trajectory = ep / "private/trajectory.jsonl"
    steps = 0
    last_step = None
    with trajectory.open() as stream:
        for line in stream:
            row = json.loads(line)
            if row.get("event") == "step":
                steps += 1
                last_step = row
    if steps != episode["simulator_steps"]:
        raise ValueError(f"Imported trajectory step count mismatch: {ep}")
    if partial_after_terminal and (not last_step or last_step.get("terminated") is not True
            or last_step.get("step") != steps
            or bool(last_step.get("info", {}).get("succeed")) != (episode["outcome"] == "success")):
        raise ValueError(f"Partial-token import lacks terminal simulator evidence: {ep}")
    for action_file in (ep / "private/actions").glob("*.json"):
        action = json.loads(action_file.read_text())
        evidence = action.get("model_evidence")
        if (not isinstance(evidence, list) or not evidence or
                any(item.get("model") != cfg["model"] for item in evidence)):
            raise ValueError(f"Imported model evidence mismatch: {action_file}")
    episode = dict(episode)
    episode["import_kind"] = "completed_two_session_episode"
    episode["import_source"] = str(ep / "result.json")
    if partial_after_terminal:
        episode["import_telemetry_exception"] = (
            "extended_horizon_budget_score_with_partial_token_lower_bound"
            if episode.get("official_terminal") is False else
            "terminal_score_with_partial_token_lower_bound")
    if compatible_repair:
        episode["import_source_exception"] = "pinned_transport_cleanup_only"
    return episode


def _import_one_x_episode(ep: Path, task: str, index: int, cfg: dict,
                          package_sha256: str) -> dict:
    """Reuse a completed first session; never import its optional 10x outcome."""
    manifest = json.loads((ep.parent / "private/manifest.json").read_text())
    old_cfg = manifest.get("config", {})
    contract = ("setting", "model", "reasoning_effort", "codex_version",
                "upstream_commit", "dataset_revision", "regime", "seed_start",
                "episodes", "max_chunk", "decision_timeout_s")
    if (manifest.get("task") != task or
            manifest.get("package_sha256") != package_sha256 or
            old_cfg.get("schema_version") != 3 or
            any(old_cfg.get(k) != cfg.get(k) for k in contract)):
        raise ValueError(f"Imported first-session contract mismatch: {ep}")
    standard = LIMITS[task]
    checkpoint = json.loads((ep / "private/checkpoint_1x.json").read_text())
    complete_path = ep / "result.json"
    if complete_path.is_file():
        original = json.loads(complete_path.read_text())
        if (original.get("task") != task or original.get("seed") != cfg["seed_start"] + index
                or original.get("continuation_attempted") is not False
                or original.get("simulator_steps", standard + 1) > standard
                or original.get("outcome") not in {"success", "failure", "policy_failure"}
                or original.get("success_by_1x") != checkpoint.get("success_by_1x")):
            raise ValueError(f"Invalid completed first session: {ep}")
        result = dict(original)
        result["import_kind"] = "completed_initial_session"
        result["import_source"] = str(complete_path)
    else:
        session = json.loads((ep / "private/session_result.json").read_text())
        if (checkpoint.get("reached") is not True or checkpoint.get("step") != standard
                or checkpoint.get("success_by_1x") is not False
                or checkpoint.get("status") != "budget_exhausted"
                or session.get("phase") != "initial" or session.get("tokens", {}).get("status") != "complete"):
            raise ValueError(f"Invalid 1x checkpoint import: {ep}")
        result = {"task": task, "seed": cfg["seed_start"] + index,
            "outcome": "failure", "success_by_1x": False,
            "simulator_steps": standard, "continuation_attempted": False,
            "session_records": [session], "tokens": session["tokens"],
            "wall_seconds": session["wall_seconds"],
            "import_kind": "budget_exhausted_initial_session",
            "import_source": str(ep / "private/checkpoint_1x.json")}
    trajectory = ep / "private/trajectory.jsonl"
    with trajectory.open() as stream:
        steps = sum((entry := json.loads(line)).get("event") == "step"
                    and entry.get("step", standard + 1) <= standard for line in stream)
    if steps != result["simulator_steps"]:
        raise ValueError(f"Imported trajectory step count mismatch: {ep}")
    for action_file in (ep / "private/actions").glob("*.json"):
        action = json.loads(action_file.read_text())
        evidence = action.get("model_evidence")
        if (not isinstance(evidence, list) or not evidence or
                any(item.get("model") != cfg["model"] for item in evidence)):
            raise ValueError(f"Imported model evidence mismatch: {action_file}")
    result["continuation_protocol"] = False
    result["horizon_multiplier"] = 1
    result["success_by_10x"] = None
    return result


def _resources(output: Path, external_active: int, local_active: int,
               max_episodes: int) -> dict:
    disk = shutil.disk_usage(output)
    memory = psutil.virtual_memory()
    cpus = psutil.cpu_count(logical=True) or 1
    load = os.getloadavg()[0]
    return {"cpu_count": cpus, "load_1m": load,
            "memory_available_bytes": memory.available,
            "disk_available_bytes": disk.free,
            "external_active_episodes_reserved": external_active,
            "local_active_episodes": local_active,
            "max_active_episodes": max_episodes,
            "render_backend": "osmesa_cpu",
            "can_admit": (external_active + local_active < max_episodes
                          and memory.available >= 16 * 1024**3
                          and disk.free >= 120 * 1024**3
                          and load < cpus * 0.95)}


def _validate_training(source: Path, task: str, cfg: dict, manifest_hash: str) -> dict:
    record = json.loads((source / "preparation.json").read_text())
    if (record.get("task") != task or record.get("state") not in {"preparing", "ready"}
            or record.get("regime") != cfg["regime"]
            or record.get("upstream_commit") != cfg["upstream_commit"]
            or record.get("dataset_revision") != cfg["dataset_revision"]
            or record.get("training_manifest_sha256") != manifest_hash):
        raise ValueError(f"Incompatible preparation for {task}")
    if record["state"] == "ready":
        verify_package(source / "frozen", task, cfg, record["package_sha256"])
    return record


def _validate_external_test(source: Path, task: str, cfg: dict,
                            package_sha256: str) -> dict | None:
    manifest = json.loads((source / "private/manifest.json").read_text())
    if (manifest.get("task") != task or manifest.get("config") != cfg
            or manifest.get("package_sha256") != package_sha256):
        raise ValueError(f"External test contract mismatch for {task}")
    result_path = source / "result.json"
    if not result_path.is_file():
        return None
    result = json.loads(result_path.read_text())
    if (result.get("task") != task or result.get("planned") != cfg["episodes"]
            or not result.get("complete_valid") or len(result.get("episodes", [])) != cfg["episodes"]
            or not all(ep.get("continuation_protocol") for ep in result["episodes"])):
        raise ValueError(f"External task result is incomplete or invalid: {task}")
    return result


def run(args: argparse.Namespace) -> int:
    cfg = load_config(args.config)
    if cfg["schema_version"] not in {1, 3}:
        raise ValueError("Adaptive scheduling requires a 1x or two-session config")
    verify_upstream(args.upstream, cfg)
    tasks = tuple(dict.fromkeys(args.tasks))
    if not tasks or any(task not in TASKS for task in tasks):
        raise ValueError("Choose official DexJoCo tasks")
    if (not 1 <= args.prep_workers <= 4 or not 1 <= args.per_task_workers <= 5
            or not 1 <= args.max_active_episodes <= 20):
        raise ValueError("Invalid concurrency limits")
    if args.output.exists():
        raise ValueError("Use a fresh adaptive pipeline directory")
    binary = Path(shutil.which("codex") or "/missing")
    actual = subprocess.check_output([str(binary), "--version"], text=True).strip()
    if actual != cfg["codex_version"] or not args.auth.is_file():
        raise ValueError("Pinned Codex CLI and auth are required")

    cards = {}
    inventory = {}
    for task in tasks:
        card = task_config(args.upstream, cfg["regime"], task)
        manifest, demos = verified_inventory(args.dataset, task, cfg["regime"],
                                              cfg["dataset_revision"], card)
        cards[task] = card
        inventory[task] = {"training_manifest_sha256": file_hash(manifest),
                           "demonstrations": len(demos)}
    prepared = _specs(args.prepared, set(tasks))
    external_tests = _specs(args.external_test, set(tasks))
    imported_one_x = _one_x_import_specs(args.completed_one_x, set(tasks), cfg["episodes"])
    imported_completed = _completed_episode_specs(args.completed_episode, set(tasks), cfg["episodes"])
    external_episodes = _completed_episode_specs(args.external_episode, set(tasks), cfg["episodes"])
    if imported_one_x and cfg["schema_version"] != 1:
        raise ValueError("First-session imports require a 1x-only config")
    if imported_completed and cfg["schema_version"] != 3:
        raise ValueError("Completed episode imports require a two-session config")
    if external_episodes and cfg["schema_version"] != 3:
        raise ValueError("External episodes require a two-session config")
    if args.transport_repair_import and cfg.get("protocol_revision") != "robot_reference_array_adapter_v2":
        raise ValueError("Transport-repair imports require the pinned v2 protocol")
    if ((set(imported_completed) & set(imported_one_x))
            or (set(external_episodes) & (set(imported_completed) | set(imported_one_x)))):
        raise ValueError("Duplicate episode imports")
    if external_tests and cfg["schema_version"] != 3:
        raise ValueError("External task evaluators require the two-session config")
    if not set(external_tests) <= set(prepared):
        raise ValueError("External tests require their prepared task package")
    if not {task for task, _ in imported_one_x} <= set(prepared):
        raise ValueError("Imported first sessions require their prepared task package")
    if not {task for task, _ in imported_completed} <= set(prepared):
        raise ValueError("Imported completed episodes require their prepared task package")
    if not {task for task, _ in external_episodes} <= set(prepared):
        raise ValueError("External episodes require their prepared task package")

    args.output.mkdir(parents=True)
    private = args.output / "private"
    private.mkdir()
    shutil.copyfile(args.config, private / "config.json")
    source_files = [Path(__file__), Path(__file__).with_name("dexjoco_eval.py"),
        Path(__file__).with_name("dexjoco_horizon.py"),
        Path(__file__).with_name("dexjoco_adapter.py"),
        Path(__file__).with_name("dexjoco_robot_reference.py"),
        Path(__file__).with_name("dexjoco_icl.py"),
        Path(__file__).with_name("dexjoco_reader.py"),
        Path(__file__).with_name("dexjoco_reader_client.py"),
        Path(__file__).with_name("isolation.py"),
        Path(__file__).with_name("step.py"),
        Path(__file__).with_name("core.py"),
        Path(__file__).with_name("knowledge.py"),
        Path(__file__).with_name("telemetry.py"),
        ROOT / "prompts/dexjoco_policy_icl.md",
        ROOT / "prompts/dexjoco_policy_continuation.md",
        ROOT / "prompts/dexjoco_preparation.md", args.config]
    source_hashes = {}
    for source in source_files:
        rel = source.relative_to(ROOT) if source.is_relative_to(ROOT) else Path("external") / source.name
        target = private / "source" / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        source_hashes[str(rel)] = file_hash(target)
    for task in tasks:
        source = args.upstream / "configs" / cfg["regime"] / f"{task}.yaml"
        target = private / "source/upstream/configs" / cfg["regime"] / f"{task}.yaml"
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        source_hashes[str(target.relative_to(private / "source"))] = file_hash(target)
    write_json(private / "manifest.json", {"setting": SETTING, "config": cfg,
        "config_sha256": file_hash(private / "config.json"),
        "upstream_commit": cfg["upstream_commit"], "dataset_revision": cfg["dataset_revision"],
        "codex_binary_sha256": file_hash(binary.resolve()),
        "source_hashes": source_hashes, "started_at": utc_now()})

    started = time.monotonic()
    entries = {task: {"state": "pending", **inventory[task], "episodes": {}}
               for task in tasks}
    report = {"setting": SETTING, "protocol_revision": cfg.get("protocol_revision"),
              "state": "running", "started_at": utc_now(),
              "config_sha256": file_hash(private / "config.json"),
              "one_x_only": cfg["schema_version"] == 1,
              "planned_tasks": list(tasks), "planned_episodes": len(tasks) * cfg["episodes"],
              "prep_workers": args.prep_workers,
              "per_task_workers": args.per_task_workers,
              "max_active_episodes": args.max_active_episodes,
              "external_tests": {task: str(path) for task, path in external_tests.items()},
              "imported_first_sessions": {f"{task}:{index}": str(path)
                  for (task, index), path in imported_one_x.items()},
              "imported_completed_episodes": {f"{task}:{index}": str(path)
                  for (task, index), path in imported_completed.items()},
              "external_episode_sources": {f"{task}:{index}": str(path)
                  for (task, index), path in external_episodes.items()},
              "retried_external_episodes": {},
              "transport_repair_import": args.transport_repair_import,
              "tasks": entries}
    env = {**os.environ, "PYTHONPATH": str(Path(__file__).resolve().parents[1]),
           "PYTHONHASHSEED": "0"}
    ready: dict[str, Path] = {}
    waiting: dict[str, Path] = {}
    prep_processes: dict[str, tuple[subprocess.Popen, object]] = {}
    episode_processes: dict[tuple[str, int], tuple[subprocess.Popen, object]] = {}
    submitted: dict[str, set[int]] = {task: set() for task in tasks}
    episode_reports: dict[str, dict[int, dict]] = {task: {} for task in tasks}
    error = False

    def copy_ready(task: str, source: Path, record: dict) -> None:
        target = args.output / "preparation" / task
        if source != target:
            target.parent.mkdir(exist_ok=True)
            shutil.copytree(source, target)
        verify_package(target / "frozen", task, cfg, record["package_sha256"])
        ready[task] = target
        entries[task].update(state="ready", package_sha256=record["package_sha256"],
            preparation_source=str(source), preparation_tokens=record.get("preparation_tokens"),
            preparation_wall_seconds=record.get("wall_seconds"))

    for task, source in prepared.items():
        record = _validate_training(source, task, cfg,
                                    inventory[task]["training_manifest_sha256"])
        if record["state"] == "ready":
            copy_ready(task, source, record)
        else:
            waiting[task] = source
            entries[task].update(state="waiting_for_external_preparation",
                                 preparation_source=str(source))
    for task in external_tests:
        submitted[task].update(range(cfg["episodes"]))
        entries[task]["state"] = "external_testing"

    def save() -> None:
        values = list(entries.values())
        completed = [ep for x in values for ep in x["episodes"].values()
                     if ep["state"] == "completed"]
        report["updated_at"] = utc_now()
        report["wall_seconds"] = time.monotonic() - started
        report["reported_task_preparations"] = sum(isinstance(x.get("preparation_tokens"), dict)
                                                    for x in values)
        report["completed_episodes"] = len(completed)
        report["successes_1x"] = sum(ep["success_by_1x"] for ep in completed)
        report["successes_10x"] = (sum(ep["success_by_10x"] for ep in completed)
                                    if cfg["schema_version"] == 3 else None)
        report["complete_valid"] = (report["state"] == "completed" and
            report["completed_episodes"] == report["planned_episodes"] and
            all(x["state"] == "completed" for x in values))
        report["success_rate_1x"] = (report["successes_1x"] / report["planned_episodes"]
                                     if report["complete_valid"] else None)
        report["success_rate_10x"] = (report["successes_10x"] / report["planned_episodes"]
                                      if report["complete_valid"] and cfg["schema_version"] == 3
                                      else None)
        prep_usage = [x["preparation_tokens"] for x in values
                      if isinstance(x.get("preparation_tokens"), dict)]
        test_usage = [ep["tokens"] for ep in completed]
        report["preparation_tokens"] = sum_usage(prep_usage)
        report["test_tokens"] = sum_usage(test_usage)
        report["tokens"] = sum_usage([*prep_usage, *test_usage])
        if not report["complete_valid"]:
            report["tokens"]["status"] = "partial"
            report["test_tokens"]["status"] = "partial"
        if len(prep_usage) != len(tasks):
            report["preparation_tokens"]["status"] = "partial"
        write_json(args.output / "pipeline_result.json", report)

    def submit_preparation(task: str) -> None:
        target = args.output / "preparation" / task
        target.parent.mkdir(exist_ok=True)
        command = [sys.executable, "-m", "gpt6_eval.dexjoco_icl", "--config",
            str(private / "config.json"), "--upstream", str(args.upstream),
            "--task", task, "--dataset", str(args.dataset), "--output", str(target),
            "--auth", str(args.auth)]
        stream = (args.output / f"prepare_{task}.log").open("wb")
        proc = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT,
                                env=env, start_new_session=True)
        prep_processes[task] = (proc, stream)
        entries[task]["state"] = "preparing"

    def submit_episode(task: str, index: int) -> None:
        target = args.output / "testing" / task / f"seed_{cfg['seed_start'] + index}"
        target.parent.mkdir(parents=True, exist_ok=True)
        command = [sys.executable, "-m", "gpt6_eval.dexjoco_eval", "--config",
            str(private / "config.json"), "--upstream", str(args.upstream),
            "--task", task, "--package", str(ready[task] / "frozen"),
            "--package-sha256", entries[task]["package_sha256"],
            "--mode", "codex", "--episode-index", str(index),
            "--episode-workers", "1", "--auth", str(args.auth),
            "--output", str(target)]
        stream = (args.output / f"test_{task}_{index}.log").open("wb")
        proc = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT,
                                env=env, start_new_session=True)
        episode_processes[(task, index)] = (proc, stream)
        submitted[task].add(index)
        entries[task]["state"] = "testing"
        entries[task]["episodes"][str(index)] = {"state": "running", "seed": cfg["seed_start"] + index,
            "result": str(target / "result.json")}

    def accept_episode(task: str, index: int, episode: dict, result_path: Path) -> None:
        nonlocal error
        if (episode.get("task") != task or episode.get("seed") != cfg["seed_start"] + index
                or episode.get("continuation_protocol") != (cfg["schema_version"] == 3)
                or episode.get("horizon_multiplier") != cfg.get("continuation_multiplier", 1)
                or episode.get("outcome") not in {"success", "failure", "policy_failure"}):
            entries[task]["state"] = "failed_test"
            entries[task]["error"] = f"Invalid or incomplete episode {index}: {episode.get('error')}"
            error = True
            return
        episode_reports[task][index] = episode
        entries[task]["episodes"][str(index)] = {"state": "completed", "seed": episode["seed"],
            "result": str(result_path), "outcome": episode["outcome"],
            "simulator_steps": episode["simulator_steps"],
            "success_by_1x": episode["success_by_1x"],
            "success_by_10x": episode["success_by_10x"],
            "continuation_attempted": episode["continuation_attempted"],
            "import_kind": episode.get("import_kind"),
            "import_source": episode.get("import_source"),
            "tokens": episode["tokens"], "wall_seconds": episode["wall_seconds"],
            "model_sessions": len(episode["session_records"])}
        if len(episode_reports[task]) == cfg["episodes"]:
            entries[task]["state"] = "completed"

    for (task, index), source in imported_one_x.items():
        if task not in ready:
            raise ValueError(f"Imported first-session package is not ready: {task}")
        episode = _import_one_x_episode(source, task, index, cfg,
                                        entries[task]["package_sha256"])
        submitted[task].add(index)
        accept_episode(task, index, episode,
                       source / "result.json" if (source / "result.json").is_file()
                       else source / "private/checkpoint_1x.json")
    for (task, index), source in imported_completed.items():
        if task not in ready:
            raise ValueError(f"Imported completed episode package is not ready: {task}")
        episode = _import_completed_episode(source, task, index, cfg,
            entries[task]["package_sha256"], source_hashes, file_hash(binary.resolve()),
            args.transport_repair_import)
        submitted[task].add(index)
        accept_episode(task, index, episode, source / "result.json")
    for (task, index), source in external_episodes.items():
        submitted[task].add(index)
        entries[task]["state"] = "testing"
        entries[task]["episodes"][str(index)] = {"state": "external_running",
            "seed": cfg["seed_start"] + index, "result": str(source / "result.json")}
    save()
    tick = 0
    while True:
        changed = False
        for task, source in tuple(waiting.items()):
            try:
                record = _validate_training(source, task, cfg,
                                            inventory[task]["training_manifest_sha256"])
            except ValueError as exc:
                raw = json.loads((source / "preparation.json").read_text())
                if raw.get("state") != "failed":
                    raise
                waiting.pop(task)
                entries[task].update(state="failed_preparation", error=raw.get("error") or str(exc))
                error = True
                changed = True
                continue
            if record["state"] == "ready":
                waiting.pop(task)
                copy_ready(task, source, record)
                if task in external_tests:
                    entries[task]["state"] = "external_testing"
                changed = True
        for task, (proc, stream) in tuple(prep_processes.items()):
            code = proc.poll()
            if code is None:
                continue
            stream.close()
            prep_processes.pop(task)
            source = args.output / "preparation" / task
            record = json.loads((source / "preparation.json").read_text()) if (source / "preparation.json").is_file() else {}
            if code == 0 and record.get("state") == "ready":
                _validate_training(source, task, cfg,
                                   inventory[task]["training_manifest_sha256"])
                copy_ready(task, source, record)
            else:
                entries[task].update(state="failed_preparation", error=record.get("error") or f"exit {code}")
                error = True
            changed = True
        for task, source in external_tests.items():
            if entries[task]["state"] in {"completed", "failed_test"}:
                continue
            if task not in ready:
                continue
            result = _validate_external_test(source, task, cfg, entries[task].get("package_sha256"))
            if result is None:
                alive = False
                for process in psutil.process_iter(["cmdline"]):
                    try:
                        command = process.info["cmdline"] or []
                        if ("gpt6_eval.dexjoco_eval" in command and
                                str(source) in command):
                            alive = True
                            break
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        continue
                if not alive:
                    entries[task].update(state="failed_test",
                        error="External evaluator exited without a complete task result")
                    error = True
                    changed = True
                continue
            for index, episode in enumerate(result["episodes"]):
                accept_episode(task, index, episode,
                               source / f"episode_{index:04d}" / "result.json")
            changed = True
        for key, source in tuple(external_episodes.items()):
            task, index = key
            result_path = source / "result.json"
            if result_path.is_file():
                try:
                    episode = _import_completed_episode(source, task, index, cfg,
                        entries[task]["package_sha256"], source_hashes, file_hash(binary.resolve()),
                        args.transport_repair_import)
                except (ValueError, KeyError, FileNotFoundError) as exc:
                    report["retried_external_episodes"][f"{task}:{index}"] = str(exc)
                    submitted[task].remove(index)
                    entries[task]["episodes"].pop(str(index))
                else:
                    accept_episode(task, index, episode, result_path)
                external_episodes.pop(key)
                changed = True
                continue
            alive = False
            for process in psutil.process_iter(["cmdline"]):
                try:
                    command = process.info["cmdline"] or []
                    if ("gpt6_eval.dexjoco_eval" in command and
                            str(source.parent) in command):
                        alive = True
                        break
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            if not alive:
                report["retried_external_episodes"][f"{task}:{index}"] = "Source evaluator exited without a valid result"
                submitted[task].remove(index)
                entries[task]["episodes"].pop(str(index))
                external_episodes.pop(key)
                changed = True
        for key, (proc, stream) in tuple(episode_processes.items()):
            code = proc.poll()
            if code is None:
                continue
            stream.close()
            episode_processes.pop(key)
            task, index = key
            result_path = args.output / "testing" / task / f"seed_{cfg['seed_start'] + index}" / "result.json"
            result = json.loads(result_path.read_text()) if result_path.is_file() else {}
            if code == 0 and result.get("complete_valid") and result.get("planned") == 1:
                accept_episode(task, index, result["episodes"][0], result_path)
            else:
                entries[task].update(state="failed_test",
                    error=f"Episode {index} exited {code}: " +
                          str(result.get("episodes", [{}])[0].get("error")))
                error = True
            changed = True

        if not error:
            pending = [task for task in tasks if task not in prepared and task not in prep_processes
                       and task not in ready and task not in waiting]
            while pending and len(prep_processes) + len(waiting) < args.prep_workers:
                submit_preparation(pending.pop(0))
                changed = True
            # Reserve two slots per unfinished external task. Its own scheduler
            # can immediately replace a finished worker with the next seed.
            external_active = (2 * sum(entries[task]["state"] == "external_testing"
                                       for task in external_tests) + len(external_episodes))
            while True:
                resource = _resources(args.output, external_active,
                                      len(episode_processes), args.max_active_episodes)
                report["resource_admission"] = resource
                if not resource["can_admit"]:
                    break
                eligible = [task for task in tasks if task in ready and task not in external_tests
                    and entries[task]["state"] not in {"completed", "failed_test"}
                    and len(submitted[task]) < cfg["episodes"]
                    and sum(t == task for t, _ in episode_processes) < args.per_task_workers]
                if not eligible:
                    break
                # Fill the least occupied ready task first, then preserve task order.
                task = min(eligible, key=lambda t: (sum(k == t for k, _ in episode_processes),
                                                    tasks.index(t)))
                index = next(i for i in range(cfg["episodes"]) if i not in submitted[task])
                submit_episode(task, index)
                changed = True
        tick += 1
        if changed or tick % 6 == 0:
            save()
        if all(entry["state"] == "completed" for entry in entries.values()):
            report["state"] = "completed"
            save()
            return 0
        if error and not prep_processes and not episode_processes:
            report["state"] = "stopped_on_error"
            save()
            return 1
        time.sleep(5)


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--config", type=Path, required=True)
    p.add_argument("--upstream", type=Path, required=True)
    p.add_argument("--dataset", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--tasks", nargs="+", choices=TASKS, default=list(TASKS))
    p.add_argument("--prepared", action="append", default=[], metavar="TASK=DIR")
    p.add_argument("--external-test", action="append", default=[], metavar="TASK=DIR")
    p.add_argument("--completed-one-x", action="append", default=[],
                   metavar="TASK:INDEX=EPISODE_DIR",
                   help="Import a completed 1x first session from a superseded two-session run")
    p.add_argument("--completed-episode", action="append", default=[],
                   metavar="TASK:INDEX=EPISODE_DIR",
                   help="Import a valid two-session episode from an interrupted scheduler run")
    p.add_argument("--external-episode", action="append", default=[],
                   metavar="TASK:INDEX=EPISODE_DIR",
                   help="Wait for a running episode from another scheduler, then import or retry it")
    p.add_argument("--transport-repair-import", action="store_true",
                   help="Allow only pinned old-to-new step transport source hashes for valid episode imports")
    p.add_argument("--prep-workers", type=int, default=2)
    p.add_argument("--per-task-workers", type=int, default=5)
    p.add_argument("--max-active-episodes", type=int, default=12)
    p.add_argument("--auth", type=Path, default=Path.home() / ".codex/auth.json")
    args = p.parse_args()
    for key, value in vars(args).items():
        if isinstance(value, Path):
            setattr(args, key, value.resolve())
    return run(args)


if __name__ == "__main__":
    raise SystemExit(main())
