"""Parallel task ICL preparation and scored DexJoCo testing."""
from __future__ import annotations

import argparse
from concurrent.futures import FIRST_COMPLETED, Future, ThreadPoolExecutor, wait
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

from .core import write_json
from .dexjoco_adapter import TASKS
from .dexjoco_eval import SETTING, load_config, task_config, verify_package, verify_upstream
from .dexjoco_reader import verified_inventory
from .knowledge import file_hash
from .telemetry import sum_usage, utc_now


def _run(command: list[str], log: Path, env: dict[str, str]) -> int:
    with log.open("wb") as stream:
        return subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT,
                              env=env).returncode


def run(args: argparse.Namespace) -> int:
    cfg = load_config(args.config)
    verify_upstream(args.upstream, cfg)
    tasks = tuple(dict.fromkeys(args.tasks))
    if not tasks or any(t not in TASKS for t in tasks):
        raise ValueError("Choose one or more official DexJoCo tasks")
    if (not 1 <= args.prep_workers <= 4 or not 1 <= args.test_workers <= 4
            or not 1 <= args.episode_workers <= 4):
        raise ValueError("Worker counts must be 1–4")
    if args.output.exists():
        raise ValueError("Use a new immutable pipeline directory")
    # Preflight all task corpora before any model call or scored episode.
    inventories = {}
    for task in tasks:
        card = task_config(args.upstream, cfg["regime"], task)
        manifest, demos = verified_inventory(args.dataset, task, cfg["regime"],
                                             cfg["dataset_revision"], card)
        inventories[task] = {"manifest_sha256": file_hash(manifest),
                             "demonstrations": len(demos)}
    prepared = {}
    preparing = {}
    for spec in args.prepared:
        task, separator, source_text = spec.partition("=")
        if not separator or task not in tasks or task in prepared or task in preparing:
            raise ValueError("--prepared must be a unique TASK=PREPARATION_DIR")
        source = Path(source_text).resolve()
        record = json.loads((source / "preparation.json").read_text())
        if (record.get("state") not in {"ready", "preparing"} or record.get("task") != task
                or record.get("regime") != cfg["regime"]
                or record.get("upstream_commit") != cfg["upstream_commit"]
                or record.get("dataset_revision") != cfg["dataset_revision"]
                or record.get("training_manifest_sha256") != inventories[task]["manifest_sha256"]):
            raise ValueError(f"Prepared task is incompatible: {task}")
        if record["state"] == "ready":
            verify_package(source / "frozen", task, cfg, record["package_sha256"])
            prepared[task] = source
        else:
            preparing[task] = source
    args.output.mkdir(parents=True)
    private = args.output / "private"
    private.mkdir()
    shutil.copyfile(args.config, private / "config.json")
    started = time.monotonic()
    multiplier = cfg.get("horizon_multiplier", cfg.get("continuation_multiplier", 1))
    report = {"setting": SETTING, "state": "running", "started_at": utc_now(),
              "horizon_multiplier": multiplier,
              "continuation_protocol": cfg["schema_version"] == 3,
              "tasks": {t: {"state": "pending", **inventories[t]} for t in tasks},
              "planned_tasks": list(tasks),
              "planned_episodes": len(tasks) * cfg["episodes"],
              "prep_workers": args.prep_workers, "test_workers": args.test_workers,
              "episode_workers": args.episode_workers,
              "config_sha256": file_hash(private / "config.json")}
    for task, source in prepared.items():
        target = args.output / "preparation" / task
        target.parent.mkdir(exist_ok=True)
        shutil.copytree(source, target)
        record = json.loads((target / "preparation.json").read_text())
        verify_package(target / "frozen", task, cfg, record["package_sha256"])
        report["tasks"][task].update(state="ready", package_sha256=record["package_sha256"],
                                      preparation_tokens=record.get("preparation_tokens"),
                                      preparation_wall_seconds=record.get("wall_seconds"),
                                      preparation_source=str(source))
    for task, source in preparing.items():
        report["tasks"][task].update(state="waiting_for_external_preparation",
                                      preparation_source=str(source))

    def save() -> None:
        report["updated_at"] = utc_now()
        report["wall_seconds"] = time.monotonic() - started
        entries = report["tasks"].values()
        report["complete_valid"] = (report["state"] == "completed" and
                                    all(x.get("complete_valid") for x in entries))
        report["successes"] = sum(x.get("successes", 0) for x in entries)
        report["success_rate"] = (report["successes"] / report["planned_episodes"]
                                  if report["complete_valid"] else None)
        report["successes_1x"] = sum(x.get("successes_1x", 0) for x in entries)
        report["successes_10x"] = sum(x.get("successes_10x", 0) for x in entries)
        report["success_rate_1x"] = (report["successes_1x"] / report["planned_episodes"]
                                     if report["complete_valid"] else None)
        report["success_rate_10x"] = (report["successes_10x"] / report["planned_episodes"]
                                      if report["complete_valid"] else None)
        prep_tokens = [x["preparation_tokens"] for x in entries
                       if isinstance(x.get("preparation_tokens"), dict)]
        test_tokens = [x["test_tokens"] for x in entries
                       if isinstance(x.get("test_tokens"), dict)]
        report["preparation_tokens"] = sum_usage(prep_tokens)
        report["test_tokens"] = sum_usage(test_tokens)
        report["tokens"] = sum_usage([*prep_tokens, *test_tokens])
        report["minimum_model_sessions"] = len(tasks) * (1 + cfg["episodes"])
        report["maximum_model_sessions"] = len(tasks) * (1 +
            cfg["episodes"] * (2 if cfg["schema_version"] == 3 else 1))
        report["planned_model_sessions"] = report["maximum_model_sessions"]
        report["reported_task_preparations"] = len(prep_tokens)
        report["reported_task_tests"] = len(test_tokens)
        report["reported_model_sessions"] = (len(prep_tokens) +
            sum(x.get("test_model_sessions", x.get("completed_episodes", 0)) for x in entries))
        if (not report["complete_valid"] or len(prep_tokens) != len(tasks)
                or len(test_tokens) != len(tasks)):
            report["tokens"]["status"] = "partial"
        if len(prep_tokens) != len(tasks):
            report["preparation_tokens"]["status"] = "partial"
        if len(test_tokens) != len(tasks):
            report["test_tokens"]["status"] = "partial"
        write_json(args.output / "pipeline_result.json", report)

    env = {**os.environ, "PYTHONPATH": str(Path(__file__).resolve().parents[1]),
           "PYTHONHASHSEED": "0"}
    pending = iter(t for t in tasks if t not in prepared and t not in preparing)
    futures: dict[Future[int], tuple[str, str]] = {}
    failed = False

    def submit_prep(pool: ThreadPoolExecutor) -> bool:
        try:
            task = next(pending)
        except StopIteration:
            return False
        out = args.output / "preparation" / task
        out.parent.mkdir(exist_ok=True)
        command = [sys.executable, "-m", "gpt6_eval.dexjoco_icl",
                   "--config", str(private / "config.json"),
                   "--upstream", str(args.upstream), "--task", task,
                   "--dataset", str(args.dataset), "--output", str(out),
                   "--auth", str(args.auth)]
        future = pool.submit(_run, command, args.output / f"prepare_{task}.log", env)
        futures[future] = ("prepare", task)
        report["tasks"][task]["state"] = "preparing"
        save()
        return True

    def submit_test(pool: ThreadPoolExecutor, task: str, package: Path,
                    sha: str) -> None:
        out = args.output / "testing" / task
        out.parent.mkdir(exist_ok=True)
        command = [sys.executable, "-m", "gpt6_eval.dexjoco_eval",
                   "--config", str(private / "config.json"),
                   "--upstream", str(args.upstream), "--task", task,
                   "--mode", "codex", "--package", str(package),
                   "--package-sha256", sha, "--output", str(out),
                   "--episode-workers", str(args.episode_workers)]
        future = pool.submit(_run, command, args.output / f"test_{task}.log", env)
        futures[future] = ("test", task)
        report["tasks"][task]["state"] = "testing"
        save()

    save()
    try:
        with ThreadPoolExecutor(max_workers=args.prep_workers) as prep_pool, \
             ThreadPoolExecutor(max_workers=args.test_workers) as test_pool:
            for task in prepared:
                prep = args.output / "preparation" / task
                sha = report["tasks"][task]["package_sha256"]
                submit_test(test_pool, task, prep / "frozen", sha)
            for _ in range(min(args.prep_workers, len(tasks) - len(prepared) - len(preparing))):
                submit_prep(prep_pool)
            while futures or preparing:
                if futures:
                    completed, _ = wait(tuple(futures), timeout=5,
                                        return_when=FIRST_COMPLETED)
                else:
                    time.sleep(5)
                    completed = set()
                for task, source in tuple(preparing.items()):
                    record = json.loads((source / "preparation.json").read_text())
                    if record.get("state") == "preparing":
                        continue
                    preparing.pop(task)
                    if record.get("state") != "ready":
                        report["tasks"][task].update(state="failed_preparation",
                                                     error=record.get("error"))
                        failed = True
                        continue
                    if record.get("training_manifest_sha256") != inventories[task]["manifest_sha256"]:
                        raise ValueError(f"External training inventory changed for {task}")
                    target = args.output / "preparation" / task
                    target.parent.mkdir(exist_ok=True)
                    shutil.copytree(source, target)
                    copied = json.loads((target / "preparation.json").read_text())
                    sha = copied["package_sha256"]
                    verify_package(target / "frozen", task, cfg, sha)
                    report["tasks"][task].update(state="ready", package_sha256=sha,
                        preparation_tokens=copied.get("preparation_tokens"),
                        preparation_wall_seconds=copied.get("wall_seconds"))
                    submit_test(test_pool, task, target / "frozen", sha)
                for future in completed:
                    stage, task = futures.pop(future)
                    code = future.result()
                    entry = report["tasks"][task]
                    entry[f"{stage}_returncode"] = code
                    if stage == "prepare":
                        prep = args.output / "preparation" / task
                        preparation = json.loads((prep / "preparation.json").read_text()) \
                            if (prep / "preparation.json").is_file() else {}
                        if code == 0 and preparation.get("state") == "ready":
                            package = prep / "frozen"
                            sha = preparation["package_sha256"]
                            verify_package(package, task, cfg, sha)
                            if preparation["training_manifest_sha256"] != entry["manifest_sha256"]:
                                raise ValueError(f"Training inventory changed for {task}")
                            entry.update(state="ready", package_sha256=sha,
                                         preparation_tokens=preparation.get("preparation_tokens"),
                                         preparation_wall_seconds=preparation.get("wall_seconds"))
                            submit_test(test_pool, task, package, sha)
                        else:
                            entry.update(state="failed_preparation", error=preparation.get("error"))
                            failed = True
                        if not failed:
                            submit_prep(prep_pool)
                    else:
                        result_path = args.output / "testing" / task / "result.json"
                        result = json.loads(result_path.read_text()) if result_path.is_file() else {}
                        entry.update(state="completed" if code == 0 and result.get("complete_valid")
                                     else "failed_test", complete_valid=result.get("complete_valid", False),
                                     successes=result.get("successes", 0),
                                     successes_1x=result.get("successes_1x", 0),
                                     successes_10x=result.get("successes_10x", 0),
                                     success_rate_1x=result.get("success_rate_1x"),
                                     success_rate_10x=result.get("success_rate_10x"),
                                     completed_episodes=result.get("completed", 0),
                                     continuations=result.get("continuations", 0),
                                     test_model_sessions=result.get("model_sessions",
                                                                    result.get("completed", 0)),
                                     test_tokens=result.get("tokens"),
                                     episode_wall_seconds=result.get("episode_wall_seconds"),
                                     simulator_step_wall_seconds=result.get("simulator_step_wall_seconds"),
                                     simulator_steps=result.get("simulator_steps"),
                                     result=str(result_path.relative_to(args.output)))
                        if entry["state"] == "failed_test":
                            failed = True
                    save()
            report["state"] = "stopped_on_error" if failed else "completed"
    except BaseException as exc:
        report.update(state="stopped_on_error", error=f"{type(exc).__name__}: {exc}")
        raise
    finally:
        save()
    return 0 if report["complete_valid"] else 1


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--config", type=Path, required=True)
    p.add_argument("--upstream", type=Path, required=True)
    p.add_argument("--dataset", type=Path, required=True)
    p.add_argument("--tasks", nargs="+", choices=TASKS, default=list(TASKS))
    p.add_argument("--prep-workers", type=int, default=2)
    p.add_argument("--test-workers", type=int, default=2)
    p.add_argument("--episode-workers", type=int, default=1)
    p.add_argument("--prepared", action="append", default=[], metavar="TASK=DIR",
                   help="Reuse a verified frozen ICL preparation for one task")
    p.add_argument("--auth", type=Path, default=Path.home() / ".codex/auth.json")
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    for key, value in vars(args).items():
        if isinstance(value, Path):
            setattr(args, key, value.resolve())
    return run(args)


if __name__ == "__main__":
    raise SystemExit(main())
